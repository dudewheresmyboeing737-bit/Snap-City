Object.assign(V7_DEFAULTS, { streetcars:"5", vfPreview:"film", runSpeed:"normal", grainAmt:"normal", halation:"normal", lightLeaks:"normal", signalTiming:"normal", neonAmount:"lots", stringLights:"on", flagsOn:"on", litterOn:"on", mapTransit:"on", trolleyBell:"on" });
function trolleys(){ return Life.cars.filter(c => c.trolley); }
function applyV11(){
  if (!S || !Life.cars) return; const n = +S.custom.streetcars || 0; trolleys().forEach((c, k) => { c.off = k >= n; if (c.off) c.g.visible = false; });
  const t = ({ short:[22, 14], normal:[32, 20], long:[45, 28] })[S.custom.signalTiming] || [32, 20]; SIG.len.carsX = t[0]; SIG.len.walkZ = t[1];
  const na = ({ off:0, some:0.4, lots:1 })[S.custom.neonAmount] ?? 1; NEON.signs.forEach((s, k) => { s.m.visible = (k / Math.max(1, NEON.signs.length)) < na; });
  if (NEON.bulbs) NEON.bulbs.userData.off = S.custom.stringLights === "off";
  FLAGS.forEach(f => f.g.visible = S.custom.flagsOn !== "off"); if (LITTER.mesh) LITTER.mesh.visible = S.custom.litterOn !== "off";
}
(function(){ const base = gameplayUpdate; gameplayUpdate = function(dt){ base(dt); if (!Game.started) return;
  for (const c of trolleys()){ if (c.off){ c.g.visible = false; c.x = 9999; continue; }
    c.bellT = (c.bellT ?? Math.random()*8) - dt; const d = Math.hypot(c.x - Player.x, c.z - Player.z);
    if (c.bellT <= 0 && d < 90 && S.custom.trolleyBell !== "off"){ c.bellT = 7 + Math.random()*8; Audio.bell && Audio.bell(Math.max(0.15, 1 - d/90)); } }
  if (NEON.bulbs && NEON.bulbs.userData.off) NEON.bulbs.visible = false; }; })();
(function(){ const base = drawMinimap; drawMinimap = function(){ base(); if (!S || S.custom.mapTransit === "off" || S.custom.hud === "off") return;
  const c = $("#minimap"), x = c.getContext("2d"), W = c.width, R = 120, s = (W/2)/R, fx = -Math.sin(Player.yaw), fz = -Math.cos(Player.yaw), rx = Math.cos(Player.yaw), rz = -Math.sin(Player.yaw);
  const dot = (wx, wz, col, w, h, ang) => { const dx = wx - Player.x, dz = wz - Player.z; let px = (dx*rx + dz*rz)*s, py = -(dx*fx + dz*fz)*s; const m = Math.hypot(px, py), max = W/2 - 10; if (m > max){ px *= max/m; py *= max/m; }
    x.save(); x.beginPath(); x.arc(W/2, W/2, W/2 - 2, 0, 7); x.clip(); x.translate(W/2 + px, W/2 + py); x.rotate(ang); x.fillStyle = col; x.strokeStyle = "#111"; x.lineWidth = 2; x.fillRect(-w/2, -h/2, w, h); x.strokeRect(-w/2, -h/2, w, h); x.restore(); };
  for (const c of trolleys()) if (!c.off) dot(c.x, c.z, "#e36f2d", 14, 6, -Player.yaw + Math.PI/2);
  if (Life.cable) dot(Life.cable.x, Life.cable.z, "#c0362c", 6, 14, -Player.yaw);
  for (const c of Life.cars) if (c.bus && !c.trolley) dot(c.x, c.z, "#e9e6de", 12, 5, -Player.yaw + Math.PI/2); }; })();
(function(){ const base = menuSettings; menuSettings = function(){ const c = S.custom, seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  return base() + `<div class="sectionhead">Viewfinder & film look</div>
    <div class="formrow"><label>Viewfinder preview</label>${seg("vfPreview",[["film","Film look (B&W when B&W is loaded)"],["optical","Optical (always colour, like the real thing)"]])}</div>
    <div class="formrow"><label>Film grain</label>${seg("grainAmt",[["off","Off"],["light","Light"],["normal","True to stock"],["heavy","Heavy"]])}</div>
    <div class="formrow"><label>Halation & glow</label>${seg("halation",[["off","Off"],["normal","Normal"],["strong","Strong"]])}</div>
    <div class="formrow"><label>Light leaks (toy cameras)</label>${seg("lightLeaks",[["off","Never"],["normal","Sometimes"],["always","Every frame"]])}</div>
    <div class="sectionhead">Getting around</div>
    <div class="formrow"><label>Walking pace</label>${seg("runSpeed",[["normal","Brisk"],["fast","Fast"]])}</div>
    <div class="formrow"><label>Heritage streetcars</label>${seg("streetcars",[["0","None"],["2","Two"],["5","Five"],["8","Eight"]])}<span class="spec">Orange marks on the minimap. They stop mid-block; press Enter beside one to ride.</span></div>
    <div class="formrow"><label>Transit on the map</label>${seg("mapTransit",[["on","Show"],["off","Hide"]])}</div>
    <div class="formrow"><label>Streetcar bells</label>${seg("trolleyBell",[["on","Ding ding"],["off","Quiet"]])}</div>
    <div class="formrow"><label>Crosswalk timing</label>${seg("signalTiming",[["short","Snappy"],["normal","Normal"],["long","Long waits"]])}</div>
    <div class="sectionhead">Street dressing</div>
    <div class="formrow"><label>Neon signs</label>${seg("neonAmount",[["off","Off"],["some","Some"],["lots","Lots"]])}</div>
    <div class="formrow"><label>String lights</label>${seg("stringLights",[["on","On"],["off","Off"]])}</div>
    <div class="formrow"><label>Blowing litter</label>${seg("litterOn",[["on","On"],["off","Off"]])}</div>`; }; })();
(function(){ const base = renderMenu; renderMenu = function(...a){ const r = base(...a); applyV11(); return r; }; })();
(function(){ const base = boot; boot = async function(){ await base(); S.custom = Object.assign({}, V7_DEFAULTS, S.custom); applyV11(); setTimeout(() => { if (Game.started) toast("Listen for the streetcar bell: orange marks on the map are heritage trolleys you can ride.", 3600); }, 12000); }; })();

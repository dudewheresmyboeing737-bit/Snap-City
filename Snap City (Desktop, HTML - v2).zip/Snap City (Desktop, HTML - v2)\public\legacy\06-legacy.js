const SHOPS = [
  { id:"cafe", names:["Fog City Coffee","Morning Ritual","Bean & Anchor"], icon:"cup", light:[1.0,0.82,0.62] },
  { id:"books", names:["Hyde St Books","Paper Moon Books","Second Chapter"], icon:"book", light:[1.0,0.86,0.66] },
  { id:"video", names:["Reel Video","Late Fees Video","Rewind Rentals"], icon:"reel", light:[0.86,0.9,1.0] },
  { id:"bar", names:["The Tipsy Gull","Last Call","Fog Horn Tavern"], icon:"glass", light:[1.0,0.62,0.4] },
  { id:"barber", names:["Hilltop Barbers","Sharp & Son","Clean Cuts"], icon:"scissors", light:[0.95,0.95,1.0] },
  { id:"laundry", names:["Suds Laundromat","Spin City","Clean Break"], icon:"drop", light:[0.85,0.95,1.0] },
  { id:"market", names:["Pacific Market","Gilded Gate Grocery","Harbor Deli & Market"], icon:"apple", light:[0.92,0.98,1.0] },
  { id:"florist", names:["Petal & Stem","Fern & Fog","Bloom Room"], icon:"flower", light:[1.0,0.92,0.8] },
  { id:"records", names:["Groove Merchant","Side B Records","Needle Drop"], icon:"record", light:[1.0,0.8,0.6] },
  { id:"tattoo", names:["Anchor & Rose","Ink Harbor","Lucky Needle"], icon:"heart", light:[1.0,0.55,0.5] },
  { id:"arcade", names:["Pixel Palace","Coin-Op","High Score"], icon:"joy", light:[0.7,0.6,1.0] },
  { id:"dumpling", names:["Golden Dumpling","Steam House","Lucky Bao"], icon:"bowl", light:[1.0,0.7,0.5] },
  { id:"pawn", names:["Hock & Horn","Loan & Pawn","Second Hand Row"], icon:"ring", light:[1.0,0.9,0.7] },
];
const INT = { u:null, TW:768, TH:384 };
function paintShopAtlas(){
  const TW = INT.TW, TH = INT.TH, NT = SHOPS.length, K = Math.min(1, 4000/(TH*NT)), c = document.createElement("canvas"); c.width = Math.floor(TW*4*K); c.height = Math.floor(TH*NT*K);
  const x = c.getContext("2d"), r = mulberry(3131), s = TH/2.95;
  x.scale(K, K);
  const RP = a => a[(r()*a.length)|0], R = (a,b) => a + r()*(b-a);
  const skins = ["#f3d2bb","#e7b48f","#d29a70","#b27a52","#8b5a3b","#6a4128","#4a2d1c"], hairs = ["#1a1411","#3b2a1d","#6b4a2e","#a67c52","#d8c08a","#8f8f8f","#c9c9c9"];
  const clothes = ["#2a2d31","#3f5e7a","#7a2e36","#e9e6de","#c9b28a","#2d4a3c","#8a3b32","#5b6e8a","#d9c9a3","#1d2d44","#b35a3a","#6b5a45"];
  const rr = (X,Y,W,H,R_) => { R_ = Math.min(R_, W/2, H/2); x.beginPath(); x.moveTo(X+R_,Y); x.arcTo(X+W,Y,X+W,Y+H,R_); x.arcTo(X+W,Y+H,X,Y+H,R_); x.arcTo(X,Y+H,X,Y,R_); x.arcTo(X,Y,X+W,Y,R_); x.closePath(); x.fill(); };
  const vshade = (X,Y,W,H,a) => { const g = x.createLinearGradient(X,Y,X,Y+H); g.addColorStop(0, `rgba(255,240,210,${a*0.5})`); g.addColorStop(1, `rgba(0,0,0,${a})`); x.fillStyle = g; x.fillRect(X,Y,W,H); };

  const person = (cx, ground, pose, o={}) => { return;
  const _unused = () => {
    const h = (o.h || R(1.6, 1.84))*s, skin = o.skin || RP(skins), hair = o.hair || RP(hairs), top = o.top || RP(clothes), pant = o.pant || RP(["#23272e","#344a6c","#3a3a3a","#5c5448","#1f2a3d"]);
    const side = pose === "side", sit = pose === "sit", back = pose === "back";
    const drop = sit ? h*0.27 : 0, hip = ground - h*0.52 + drop, sh = ground - h*0.81 + drop, hc = ground - h*0.91 + drop, hw = h*0.064, hh = h*0.082, sw = h*0.21*(side ? 0.6 : 1), ww = h*0.165*(side ? 0.65 : 1);
    if (!sit && pose !== "counter"){ x.fillStyle = pant; if (side){ x.save(); x.translate(cx, hip); x.rotate(0.12); rr(-ww*0.3, 0, ww*0.55, ground - hip - 5, 7); x.restore(); x.save(); x.translate(cx, hip); x.rotate(-0.12); rr(-ww*0.3, 0, ww*0.55, ground - hip - 5, 7); x.restore(); }
      else { rr(cx - ww*0.48, hip, ww*0.44, ground - hip - 4, 7); rr(cx + ww*0.04, hip, ww*0.44, ground - hip - 4, 7); }
      x.fillStyle = "#17130f"; x.beginPath(); x.ellipse(cx - (side ? -6 : ww*0.26), ground - 4, side ? 15 : 9, 5, 0, 0, 7); x.fill(); if (!side){ x.beginPath(); x.ellipse(cx + ww*0.26, ground - 4, 9, 5, 0, 0, 7); x.fill(); } }
    if (sit){ x.fillStyle = pant; rr(cx - ww*0.5, hip - 2, ww*1.0, h*0.1, 8); }
    x.fillStyle = top; x.beginPath(); x.moveTo(cx - sw/2, sh + 7); x.quadraticCurveTo(cx, sh - 5, cx + sw/2, sh + 7); x.lineTo(cx + ww/2, hip + 8); x.lineTo(cx - ww/2, hip + 8); x.closePath(); x.fill();
    if (o.apron){ x.fillStyle = o.apron; rr(cx - ww*0.42, sh + 22, ww*0.84, hip - sh + 10, 5); }
    const aw = h*0.042, al = h*0.32, arm = (sx, bend) => { x.save(); x.fillStyle = top; x.translate(cx + sx*(sw/2 - aw*0.3), sh + 8); if (bend){ rr(-aw/2, 0, aw, al*0.5, aw/2); x.translate(0, al*0.47); x.rotate(-sx*bend); rr(-aw/2, 0, aw, al*0.45, aw/2); x.fillStyle = skin; x.beginPath(); x.arc(0, al*0.47, aw*0.55, 0, 7); x.fill(); } else { x.rotate(sx*0.05); rr(-aw/2, 0, aw, al, aw/2); x.fillStyle = skin; x.beginPath(); x.arc(0, al + 2, aw*0.55, 0, 7); x.fill(); } x.restore(); };
    if (!back){ arm(-1, o.bendL || 0); arm(1, o.bendR || 0); } else { arm(-1, 0); arm(1, 0); }
    if (o.hold === "book"){ x.fillStyle = RP(["#7a2e36","#1e3a5f","#2f5a3a","#c9b28a"]); x.fillRect(cx - 14, sh + al*0.42, 28, 20); }
    if (o.hold === "cup"){ x.fillStyle = "#f2efe6"; rr(cx + sw/2 - 18, sh + al*0.34, 11, 14, 2); }
    if (o.hold === "phone"){ x.fillStyle = "#16181b"; x.fillRect(cx - sw/2 + 6, sh + al*0.4, 10, 16); }
    x.fillStyle = skin; rr(cx - hw*0.35, hc + hh*0.6, hw*0.7, sh - hc - hh*0.4, 3);
    x.beginPath(); x.ellipse(cx, hc, hw, hh, 0, 0, 7); x.fill();
    x.fillStyle = hair;
    if (back){ x.beginPath(); x.ellipse(cx, hc - hh*0.1, hw*1.05, hh*0.95, 0, 0, 7); x.fill(); }
    else { const st = r(); x.beginPath(); x.ellipse(cx, hc - hh*0.42, hw*1.05, hh*0.62, 0, Math.PI, 2*Math.PI); x.fill(); if (st < 0.45){ rr(cx - hw*1.08, hc - hh*0.4, hw*0.32, hh*(st < 0.25 ? 1.5 : 0.7), 5); rr(cx + hw*0.76, hc - hh*0.4, hw*0.32, hh*(st < 0.25 ? 1.5 : 0.7), 5); }
      x.fillStyle = "rgba(40,25,20,.6)"; x.beginPath(); x.ellipse(cx - hw*0.36, hc, 2.4, 1.7, 0, 0, 7); x.ellipse(cx + hw*0.36, hc, 2.4, 1.7, 0, 0, 7); x.fill(); x.fillRect(cx - 5, hc + hh*0.5, 10, 2); }
    if (o.cap){ x.fillStyle = o.cap; x.beginPath(); x.ellipse(cx, hc - hh*0.6, hw*1.1, hh*0.45, 0, Math.PI, 2*Math.PI); x.fill(); }
  };
  };
  const table = (cx, ground, w, hgt, col) => { x.fillStyle = col || "#6a4b32"; rr(cx - w/2, ground - hgt*s, w, 9, 3); x.fillStyle = "#2a2622"; x.fillRect(cx - 4, ground - hgt*s, 8, hgt*s); rr(cx - 26, ground - 6, 52, 6, 3); };
  const chair = (cx, ground, col) => { x.fillStyle = col || "#3a3028"; x.fillRect(cx - 14, ground - 0.47*s, 28, 6); x.fillRect(cx - 13, ground - 0.47*s, 4, 0.47*s); x.fillRect(cx + 9, ground - 0.47*s, 4, 0.47*s); x.fillRect(cx + (r()<0.5?-13:9), ground - 0.9*s, 4, 0.45*s); };
  const shelves = (X, Y, W, H, n, item) => { x.fillStyle = "#4a3828"; x.fillRect(X, Y, W, H); x.fillStyle = "#2c2118"; x.fillRect(X + 4, Y + 4, W - 8, H - 8); const sh = (H - 8)/n;
    for (let k=0;k<n;k++){ const y0 = Y + 4 + k*sh; x.fillStyle = "#5a4430"; x.fillRect(X, y0 + sh - 5, W, 5); let px = X + 6; while (px < X + W - 10){ px += item(px, y0 + sh - 5, sh - 9) + 1; } } };
  const book = (px, base, mh) => { const w = R(6, 12), h = mh*R(0.6, 0.95); x.fillStyle = RP(["#7a2e36","#1e3a5f","#2f5a3a","#c9b28a","#e9e6de","#8a3b32","#3f5e7a","#b8862e","#26231f","#5b3a5a"]); x.fillRect(px, base - h, w, h); x.fillStyle = "rgba(255,240,200,.35)"; x.fillRect(px + 1, base - h + 5, w - 2, 2); return w; };
  const tape = (px, base, mh) => { const w = 12, h = mh*0.8; x.fillStyle = RP(["#c0362c","#e8b82e","#2f7fc1","#16a3a3","#8a3fb5","#f28cb1","#e36f2d","#26231f","#3aa06b"]); x.fillRect(px, base - h, w, h); x.fillStyle = "rgba(255,255,255,.6)"; x.fillRect(px + 2, base - h*0.7, w - 4, 4); return w; };
  const bottle = (px, base, mh) => { const w = 10, h = mh*R(0.55, 0.9); x.fillStyle = RP(["#6b3f14","#2f5a2a","#a8741c","#d8d2c0","#5a1f22","#3a5a6a"]); rr(px, base - h*0.7, w, h*0.7, 3); x.fillRect(px + 3, base - h, 4, h*0.35); x.fillStyle = "rgba(255,230,180,.45)"; x.fillRect(px + 2, base - h*0.65, 2, h*0.5); return w + 3; };
  const pack = (px, base, mh) => { const w = R(12, 22), h = mh*R(0.45, 0.85); x.fillStyle = RP(["#c0362c","#e8b82e","#2f7fc1","#e9e6de","#3aa06b","#e36f2d","#7a2e36","#f2c230"]); x.fillRect(px, base - h, w, h); x.fillStyle = "rgba(255,255,255,.5)"; x.fillRect(px + 2, base - h + 4, w - 4, 3); return w; };
  const pot = (px, base, mh) => { const w = R(16, 26); x.fillStyle = RP(["#b35a3a","#d9c9a3","#3f5e7a","#e9e6de"]); rr(px, base - mh*0.35, w, mh*0.35, 3); x.fillStyle = RP(["#3f6a2e","#4f7d3a","#2e5a2e"]); for (let k=0;k<5;k++){ x.beginPath(); x.ellipse(px + w/2 + R(-8,8), base - mh*0.35 - R(4, mh*0.45), R(5,10), R(8,14), R(-1,1), 0, 7); x.fill(); } return w + 4; };
  const counter = (X, ground, W, hgt, col, top) => { x.fillStyle = col; x.fillRect(X, ground - hgt*s, W, hgt*s); x.fillStyle = top || "rgba(255,255,255,.18)"; x.fillRect(X - 4, ground - hgt*s - 6, W + 8, 8); vshade(X, ground - hgt*s, W, hgt*s, 0.25); };
  const flowers = (cx, ground) => { x.fillStyle = "#54616a"; rr(cx - 18, ground - 0.42*s, 36, 0.42*s, 4); for (let k=0;k<14;k++){ x.fillStyle = "#3f6a2e"; x.fillRect(cx + R(-12,12), ground - 0.42*s - R(10,40), 2, 30); x.fillStyle = RP(["#e2405a","#f2c230","#f28cb1","#ffffff","#b98ee8","#e36f2d"]); x.beginPath(); x.arc(cx + R(-16,16), ground - 0.42*s - R(18,52), R(5,9), 0, 7); x.fill(); } };
  for (let t=0; t<SHOPS.length; t++){
    const id = SHOPS[t].id, Y = t*TH, G_ = Y + TH - 2;
    const tile = (col, fn) => { x.save(); x.beginPath(); x.rect(col*TW, Y, TW, TH); x.clip(); fn(col*TW); x.restore(); };

    tile(0, X => {
      const wallC = { cafe:"#c9a27a", books:"#6b4a2e", video:"#2c3a55", bar:"#3a2418", barber:"#d9d4c6", laundry:"#cfd8d6", market:"#e4e0d4", florist:"#6f8a5c", records:"#2b2522", tattoo:"#6e1f22", arcade:"#120e22", dumpling:"#8a1c1c", pawn:"#4a4034" }[id];
      x.fillStyle = wallC; x.fillRect(X, Y, TW, TH); for (let i=0;i<500;i++){ x.fillStyle = `rgba(0,0,0,${r()*0.05})`; x.fillRect(X + r()*TW, Y + r()*TH, 3, 3); }
      if (id === "cafe"){ x.fillStyle = "#e9e4d8"; for (let yy=G_ - 1.0*s; yy<G_; yy+=14) for (let xx=X + ((yy/14|0)%2)*14; xx<X+TW; xx+=28){ x.fillRect(xx, yy, 26, 12); }
        x.fillStyle = "#1e2320"; rr(X + TW*0.52, Y + 36, TW*0.4, 120, 4); x.fillStyle = "rgba(240,240,230,.85)"; x.font = "italic 22px Georgia, serif"; x.fillText("Espresso  3.5", X + TW*0.55, Y + 70); x.fillText("Cortado  4", X + TW*0.55, Y + 98); x.fillText("Latte  4.75", X + TW*0.55, Y + 126);
        shelves(X + 30, Y + 60, TW*0.4, 110, 2, (px, b, mh) => { x.fillStyle = RP(["#e9e6de","#b35a3a","#3f5e7a","#c9b28a"]); rr(px, b - mh*0.5, 16, mh*0.5, 3); return 20; }); }
      if (id === "books") shelves(X, Y + 10, TW, TH - 12, 6, book);
      if (id === "video"){ shelves(X, Y + 110, TW, TH - 112, 4, tape); for (let k=0;k<3;k++){ x.fillStyle = RP(["#c0362c","#1e3a5f","#26231f","#e8b82e"]); x.fillRect(X + 40 + k*250, Y + 12, 150, 90); x.fillStyle = "rgba(255,255,255,.75)"; x.font = "bold 20px Arial Narrow, sans-serif"; x.fillText(RP(["NIGHT CAB","FOG","HILLS","MIDNIGHT","THE LONG TAKE"]), X + 50 + k*250, Y + 90); } }
      if (id === "bar"){ x.fillStyle = "rgba(180,200,210,.18)"; x.fillRect(X + 20, Y + 20, TW - 40, 120); shelves(X + 10, Y + 150, TW - 20, 150, 3, bottle); x.fillStyle = "#ff5a8a"; x.shadowColor = "#ff5a8a"; x.shadowBlur = 18; x.font = "italic bold 40px Georgia, serif"; x.fillText("cocktails", X + TW*0.35, Y + 95); x.shadowBlur = 0; }
      if (id === "barber"){ for (let i=0;i<TW;i+=36){ x.fillStyle = "rgba(0,0,0,.05)"; x.fillRect(X + i, Y, 18, TH); } for (let k=0;k<3;k++){ x.fillStyle = "#3a3028"; x.fillRect(X + 40 + k*250, Y + 40, 170, 150); x.fillStyle = "#9fb4bf"; x.fillRect(X + 48 + k*250, Y + 48, 154, 134); x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.moveTo(X + 60 + k*250, Y + 180); x.lineTo(X + 110 + k*250, Y + 48); x.lineTo(X + 130 + k*250, Y + 48); x.lineTo(X + 80 + k*250, Y + 180); x.fill(); } shelves(X + 10, Y + 210, TW - 20, 50, 1, pack); }
      if (id === "laundry"){ for (let k=0;k<6;k++) for (let j=0;j<2;j++){ const bx = X + 8 + k*126, by = Y + 20 + j*120; x.fillStyle = "#e8ebe9"; x.fillRect(bx, by, 118, 112); x.fillStyle = "#9aa4a8"; x.beginPath(); x.arc(bx + 59, by + 60, 38, 0, 7); x.fill(); x.fillStyle = "#2a3238"; x.beginPath(); x.arc(bx + 59, by + 60, 30, 0, 7); x.fill(); x.fillStyle = "rgba(255,255,255,.25)"; x.beginPath(); x.arc(bx + 50, by + 50, 10, 0, 7); x.fill(); } }
      if (id === "market") shelves(X, Y + 10, TW, TH - 12, 5, pack);
      if (id === "florist"){ shelves(X + 10, Y + 30, TW - 20, TH - 40, 3, pot); }
      if (id === "records"){ for (let k=0;k<9;k++) for (let j=0;j<3;j++){ const bx = X + 14 + k*84, by = Y + 20 + j*96; x.fillStyle = RP(["#c0362c","#e8b82e","#1e3a5f","#e9e6de","#26231f","#3aa06b","#8a3fb5"]); x.fillRect(bx, by, 76, 76); x.fillStyle = "rgba(0,0,0,.55)"; x.beginPath(); x.arc(bx + 38, by + 38, 22, 0, 7); x.fill(); } }
      if (id === "tattoo"){ for (let k=0;k<12;k++){ const bx = X + 20 + (k%6)*124, by = Y + 24 + ((k/6)|0)*140; x.fillStyle = "#e9e1cc"; x.fillRect(bx, by, 104, 120); x.strokeStyle = RP(["#1e3a5f","#c0362c","#26231f","#2f5a3a"]); x.lineWidth = 5; x.beginPath(); if (k%3===0){ x.moveTo(bx+52, by+95); x.bezierCurveTo(bx+10, by+60, bx+30, by+25, bx+52, by+45); x.bezierCurveTo(bx+74, by+25, bx+94, by+60, bx+52, by+95); } else if (k%3===1){ x.arc(bx+52, by+60, 28, 0, 7); } else { x.moveTo(bx+52, by+20); x.lineTo(bx+52, by+100); x.moveTo(bx+28, by+80); x.quadraticCurveTo(bx+52, by+110, bx+76, by+80); } x.stroke(); } }
      if (id === "arcade"){ for (let k=0;k<8;k++){ x.fillStyle = RP(["#ff4fa0","#5cf2ff","#ffd24a","#7cff6a"]); x.shadowColor = x.fillStyle; x.shadowBlur = 16; x.fillRect(X + 10 + k*96, Y + 30, 60, 4); } x.shadowBlur = 0; }
      if (id === "dumpling"){ for (let k=0;k<5;k++){ x.fillStyle = "#d8352a"; x.beginPath(); x.ellipse(X + 70 + k*150, Y + 60, 34, 42, 0, 0, 7); x.fill(); x.fillStyle = "#f2c230"; x.fillRect(X + 64 + k*150, Y + 100, 12, 22); } x.fillStyle = "#f2e6c9"; for (let k=0;k<3;k++){ x.fillRect(X + 90 + k*220, Y + 150, 150, 60); } x.fillStyle = "#8a1c1c"; x.font = "bold 24px Georgia, serif"; for (let k=0;k<3;k++) x.fillText(RP(["Pork Bao 6","Soup Dumplings 9","Pot Stickers 8","Chow Mein 11","Wontons 7"]), X + 98 + k*220, Y + 188); }
      if (id === "pawn"){ for (let k=0;k<6;k++){ const gx = X + 40 + k*120; x.fillStyle = RP(["#b8741c","#6b3f14","#c0362c","#1a1a1a"]); x.beginPath(); x.ellipse(gx, Y + 200, 30, 40, 0, 0, 7); x.ellipse(gx, Y + 150, 22, 28, 0, 0, 7); x.fill(); x.fillStyle = "#3a2a1c"; x.fillRect(gx - 4, Y + 40, 8, 110); } for (let k=0;k<4;k++){ x.fillStyle = "#e9e6de"; x.beginPath(); x.arc(X + 100 + k*170, Y + 300, 22, 0, 7); x.fill(); x.strokeStyle = "#26231f"; x.lineWidth = 3; x.beginPath(); x.moveTo(X + 100 + k*170, Y + 300); x.lineTo(X + 108 + k*170, Y + 288); x.stroke(); } }
      vshade(X, Y, TW, TH, 0.2);
    });

    tile(3, X => {
      if (id === "cafe"){ counter(X + 60, G_, TW*0.62, 1.05, "#5d4532"); x.fillStyle = "#b9bcc0"; rr(X + 120, G_ - 1.05*s - 70, 90, 70, 6); x.fillStyle = "#26231f"; x.fillRect(X + 130, G_ - 1.05*s - 30, 70, 8); x.fillStyle = "rgba(200,230,255,.35)"; x.fillRect(X + TW*0.4, G_ - 1.05*s - 50, 140, 50); x.fillStyle = "#c98e5a"; for (let k=0;k<6;k++){ x.beginPath(); x.ellipse(X + TW*0.4 + 16 + k*22, G_ - 1.05*s - 16, 9, 6, 0, 0, 7); x.fill(); }
        person(X + 300, G_, "counter", { apron:"#2d2a26", hold:"cup", bendR:2.1 }); counter(X + 60, G_, TW*0.62, 1.05, "#5d4532"); x.fillStyle = "#b9bcc0"; rr(X + 120, G_ - 1.05*s - 70, 90, 70, 6); }
      if (id === "books"){ shelves(X + 20, G_ - 2.1*s, 190, 2.1*s, 5, book); shelves(X + TW - 230, G_ - 2.1*s, 190, 2.1*s, 5, book); }
      if (id === "video"){ person(X + 420, G_, "counter", { bendL:1.6 }); counter(X + 300, G_, 330, 1.0, "#26324a"); x.fillStyle = "#1a1a1a"; rr(X + 330, G_ - 1.0*s - 64, 80, 64, 5); x.fillStyle = "#4a7ad8"; x.fillRect(X + 338, G_ - 1.0*s - 58, 64, 46); }
      if (id === "bar"){ person(X + 380, G_, "counter", { apron:"#1a1a1a", bendR:1.8 }); counter(X + 30, G_, TW - 60, 1.1, "#4a2a18", "#8a5a36"); for (const sx of [160, 560]){ person(X + sx, G_ + 0.05*s, "back"); x.fillStyle = "#2a2622"; x.fillRect(X + sx - 16, G_ - 0.75*s, 32, 8); x.fillRect(X + sx - 3, G_ - 0.75*s, 6, 0.75*s); } }
      if (id === "barber"){ for (const bx of [170, 520]){ x.fillStyle = "#8a1f22"; rr(X + bx - 40, G_ - 0.95*s, 80, 0.55*s, 10); person(X + bx, G_, "sit", { top:"#e9e6de" }); x.fillStyle = "#b9bcc0"; x.fillRect(X + bx - 6, G_ - 0.4*s, 12, 0.4*s); rr(X + bx - 40, G_ - 12, 80, 12, 5); } person(X + 250, G_, "stand", { top:"#e9e6de", bendR:1.4 }); }
      if (id === "laundry"){ for (let k=0;k<5;k++){ const bx = X + 30 + k*145; x.fillStyle = "#eef0ef"; x.fillRect(bx, G_ - 0.9*s, 130, 0.9*s); x.fillStyle = "#2a3238"; x.beginPath(); x.arc(bx + 65, G_ - 0.45*s, 36, 0, 7); x.fill(); x.fillStyle = "rgba(120,150,190,.5)"; x.beginPath(); x.arc(bx + 65, G_ - 0.45*s + 6, 30, 0, Math.PI); x.fill(); } }
      if (id === "market"){ shelves(X + 30, G_ - 1.7*s, 300, 1.7*s, 4, pack); person(X + 560, G_, "counter", { apron:"#2d4a3c" }); counter(X + 460, G_, 250, 1.0, "#39434b"); }
      if (id === "records"){ person(X + 500, G_, "counter", { top:"#26231f", bendR:1.6 }); counter(X + 400, G_, 300, 1.0, "#3a2a1c"); x.fillStyle = "#1a1a1a"; rr(X + 430, G_ - 1.0*s - 18, 90, 16, 4); x.fillStyle = "#26231f"; x.beginPath(); x.ellipse(X + 475, G_ - 1.0*s - 20, 34, 8, 0, 0, 7); x.fill(); }
      if (id === "tattoo"){ x.fillStyle = "#26231f"; rr(X + 200, G_ - 0.9*s, 180, 0.5*s, 12); person(X + 290, G_, "sit", { top:RP(clothes) }); person(X + 420, G_, "stand", { top:"#1a1a1a", bendL:1.9, bendR:1.2 }); }
      if (id === "arcade"){ for (let k=0;k<5;k++){ const bx = X + 30 + k*150; x.fillStyle = RP(["#2a1f4a","#3a1a2a","#1a2a4a"]); x.fillRect(bx, G_ - 1.9*s, 110, 1.9*s); x.fillStyle = RP(["#5cf2ff","#ff4fa0","#7cff6a","#ffd24a"]); x.shadowColor = x.fillStyle; x.shadowBlur = 20; x.fillRect(bx + 14, G_ - 1.65*s, 82, 0.55*s); x.shadowBlur = 0; x.fillStyle = "#111"; x.fillRect(bx + 10, G_ - 1.0*s, 90, 0.12*s); } }
      if (id === "dumpling"){ person(X + 330, G_, "counter", { apron:"#e9e6de", cap:"#e9e6de", bendL:1.5, bendR:1.5 }); counter(X + 180, G_, 380, 1.0, "#6b1f1c"); for (let k=0;k<5;k++){ x.fillStyle = "#c9a26a"; rr(X + 200 + k*70, G_ - 1.0*s - 26, 56, 26, 8); x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(X + 228 + k*70, G_ - 1.0*s - 40, 16, 12, 0, 0, 7); x.fill(); } }
      if (id === "pawn"){ person(X + 420, G_, "counter", { top:"#5c5448", bendL:1.4 }); x.fillStyle = "rgba(190,220,235,.35)"; x.fillRect(X + 250, G_ - 1.0*s, 360, 1.0*s); x.fillStyle = "#3a2a1c"; x.fillRect(X + 250, G_ - 0.2*s, 360, 0.2*s); for (let k=0;k<8;k++){ x.fillStyle = RP(["#e8b82e","#c9c9c4","#b35a3a"]); x.beginPath(); x.arc(X + 280 + k*42, G_ - 0.55*s, 8, 0, 7); x.fill(); } }
      if (id === "florist"){ person(X + 400, G_, "counter", { apron:"#3f5a3a", bendL:1.8, bendR:1.8 }); counter(X + 260, G_, 320, 0.95, "#6e5a44"); x.fillStyle = "#3f6a2e"; for (let k=0;k<8;k++){ x.beginPath(); x.ellipse(X + 380 + R(-20,20), G_ - 0.95*s - R(10, 40), 8, 14, R(-1,1), 0, 7); x.fill(); } }
    });
    tile(2, X => {
      if (id === "cafe"){ for (const tx of [150, 520]){ chair(X + tx - 55, G_); chair(X + tx + 55, G_); if (r() < 0.8) person(X + tx - 50, G_, "sit", { hold: r()<0.5 ? "cup" : "phone", bendR:1.5 }); if (r() < 0.45) person(X + tx + 55, G_, "sit", { bendL:1.4 }); table(X + tx, G_, 120, 0.74); x.fillStyle = "#f2efe6"; rr(X + tx - 10, G_ - 0.74*s - 14, 12, 14, 2); } }
      if (id === "books"){ table(X + 380, G_, 260, 0.78, "#5a3e2a"); for (let k=0;k<7;k++){ x.fillStyle = RP(["#7a2e36","#1e3a5f","#2f5a3a","#c9b28a","#e9e6de"]); x.fillRect(X + 270 + k*32, G_ - 0.78*s - 10 - (k%3)*8, 28, 10 + (k%3)*8); } person(X + 600, G_, "stand", { hold:"book", bendL:1.9, bendR:1.9 }); }
      if (id === "video"){ for (const rx of [150, 560]){ shelves(X + rx - 70, G_ - 1.5*s, 140, 1.5*s, 4, tape); } person(X + 330, G_, "side"); }
      if (id === "bar"){ table(X + 560, G_, 90, 1.05, "#3a2418"); person(X + 520, G_, "stand", { hold:"cup", bendR:1.7 }); person(X + 610, G_, "side"); }
      if (id === "barber"){ x.fillStyle = "#4a3828"; rr(X + 480, G_ - 0.46*s, 200, 14, 4); x.fillRect(X + 490, G_ - 0.46*s, 8, 0.46*s); x.fillRect(X + 662, G_ - 0.46*s, 8, 0.46*s); person(X + 560, G_, "sit", { hold:"book", bendL:1.8, bendR:1.8 }); }
      if (id === "laundry"){ table(X + 200, G_, 220, 0.9, "#c9c9c4"); x.fillStyle = RP(["#e9e6de","#3f5e7a","#c0362c"]); rr(X + 140, G_ - 0.9*s - 24, 110, 24, 6); person(X + 200, G_, "stand", { bendL:1.6, bendR:1.6 }); chair(X + 540, G_, "#e36f2d"); person(X + 540, G_, "sit", { hold:"phone", bendL:1.9 }); }
      if (id === "market"){ for (let k=0;k<3;k++){ const bx = X + 80 + k*120; x.fillStyle = "#8a6a44"; x.fillRect(bx, G_ - 0.8*s, 100, 0.8*s); const fc = RP(["#c0362c","#e8b82e","#e36f2d","#3aa06b","#f2c230"]); for (let j=0;j<16;j++){ x.fillStyle = fc; x.beginPath(); x.arc(bx + 10 + (j%6)*16, G_ - 0.8*s - 4 - (j/6|0)*9, 8, 0, 7); x.fill(); } } person(X + 560, G_, "stand", { hold:"phone", bendL:1.7 }); }
      if (id === "florist"){ for (let k=0;k<6;k++) flowers(X + 60 + k*110, G_); }
      if (id === "records"){ for (let k=0;k<3;k++){ const bx = X + 60 + k*170; x.fillStyle = "#5a3e2a"; x.fillRect(bx, G_ - 0.8*s, 140, 0.8*s); for (let j=0;j<10;j++){ x.fillStyle = RP(["#c0362c","#e8b82e","#1e3a5f","#e9e6de","#3aa06b"]); x.fillRect(bx + 6 + j*13, G_ - 0.8*s - 28 - (j%3)*3, 11, 30); } } person(X + 610, G_, "stand", { hold:"book", bendL:1.9, bendR:1.9 }); }
      if (id === "tattoo"){ x.fillStyle = "#4a2a22"; rr(X + 440, G_ - 0.46*s, 240, 0.46*s, 14); person(X + 520, G_, "sit", { hold:"phone", bendL:1.9 }); }
      if (id === "arcade"){ person(X + 180, G_, "back", { top:RP(clothes) }); person(X + 480, G_, "back", { top:RP(clothes) }); }
      if (id === "dumpling"){ for (const tx of [170, 520]){ chair(X + tx - 55, G_, "#6b1f1c"); chair(X + tx + 55, G_, "#6b1f1c"); person(X + tx - 50, G_, "sit", { bendR:1.6 }); if (r() < 0.6) person(X + tx + 55, G_, "sit", { bendL:1.6 }); table(X + tx, G_, 120, 0.74, "#3a2418"); x.fillStyle = "#e9e6de"; x.beginPath(); x.ellipse(X + tx, G_ - 0.74*s - 8, 22, 8, 0, 0, 7); x.fill(); } }
      if (id === "pawn"){ for (let k=0;k<2;k++){ x.fillStyle = "rgba(190,220,235,.3)"; x.fillRect(X + 80 + k*340, G_ - 1.0*s, 200, 1.0*s); x.fillStyle = "#3a2a1c"; x.fillRect(X + 80 + k*340, G_ - 0.15*s, 200, 0.15*s); } person(X + 330, G_, "side"); }
    });
    tile(1, X => {
      if (id === "cafe" && r() < 0.8){ x.fillStyle = "#6a4b32"; rr(X, G_ - 1.0*s, TW*0.45, 10, 3); person(X + 150, G_, "back", { top:RP(clothes) }); }
      if (id === "books"){ for (let k=0;k<4;k++){ const bx = X + 60 + k*170; x.fillStyle = "#3a2a1c"; x.fillRect(bx, G_ - 0.5*s, 110, 0.5*s); for (let j=0;j<4;j++){ x.fillStyle = RP(["#7a2e36","#1e3a5f","#2f5a3a","#c9b28a","#e9e6de"]); x.fillRect(bx + 10 + j*6, G_ - 0.5*s - 14 - j*12, 90 - j*10, 12); } } }
      if (id === "video"){ x.fillStyle = RP(["#c0362c","#e8b82e","#16a3a3"]); x.fillRect(X + 520, G_ - 1.8*s, 150, 1.8*s); x.fillStyle = "#26231f"; x.beginPath(); x.ellipse(X + 595, G_ - 1.45*s, 30, 40, 0, 0, 7); x.fill(); x.fillStyle = "#fff"; x.font = "bold 26px Arial Narrow, sans-serif"; x.fillText("NOW ON VHS", X + 530, G_ - 0.4*s); }
      if (id === "bar"){ x.fillStyle = "#ffb13b"; x.shadowColor = "#ffb13b"; x.shadowBlur = 22; x.font = "bold 44px Arial Narrow, sans-serif"; x.fillText("ON TAP", X + 60, G_ - 2.0*s); x.shadowBlur = 0; }
      if (id === "barber"){ x.fillStyle = "#e9e6de"; x.fillRect(X + 690, G_ - 1.6*s, 26, 1.2*s); for (let k=0;k<8;k++){ x.fillStyle = k%2 ? "#c0362c" : "#1e3a5f"; x.save(); x.beginPath(); x.rect(X + 690, G_ - 1.6*s, 26, 1.2*s); x.clip(); x.translate(X + 703, G_ - 1.6*s + k*24); x.rotate(-0.6); x.fillRect(-30, 0, 60, 10); x.restore(); } }
      if (id === "laundry"){ x.fillStyle = "#b9bcc0"; x.fillRect(X + 360, G_ - 0.75*s, 90, 0.6*s); x.fillStyle = RP(["#3f5e7a","#e9e6de","#c9b28a"]); rr(X + 365, G_ - 0.9*s, 80, 30, 8); }
      if (id === "market"){ for (let k=0;k<3;k++) flowers(X + 520 + k*70, G_); }
      if (id === "florist"){ for (let k=0;k<5;k++){ pot(X + 40 + k*150, G_, 0.9*s); } }
      if (id === "records"){ for (let k=0;k<3;k++){ x.fillStyle = RP(["#e8b82e","#c0362c","#1e3a5f"]); x.fillRect(X + 80 + k*230, G_ - 1.9*s, 150, 150); x.fillStyle = "#111"; x.beginPath(); x.arc(X + 155 + k*230, G_ - 1.9*s + 75, 50, 0, 7); x.fill(); } }
      if (id === "tattoo"){ x.fillStyle = "#ff4fa0"; x.shadowColor = "#ff4fa0"; x.shadowBlur = 22; x.font = "italic bold 52px Georgia, serif"; x.fillText("Tattoo", X + 420, G_ - 1.9*s); x.shadowBlur = 0; }
      if (id === "arcade"){ x.fillStyle = "rgba(160,220,255,.25)"; x.fillRect(X + 560, G_ - 1.7*s, 150, 1.7*s); for (let k=0;k<18;k++){ x.fillStyle = RP(["#ff4fa0","#ffd24a","#5cf2ff","#7cff6a"]); x.beginPath(); x.arc(X + 580 + (k%6)*22, G_ - 0.4*s - ((k/6)|0)*20, 10, 0, 7); x.fill(); } }
      if (id === "dumpling"){ x.fillStyle = "#b8321a"; for (let k=0;k<3;k++){ x.beginPath(); x.moveTo(X + 120 + k*240, G_ - 1.5*s); x.lineTo(X + 150 + k*240, G_ - 1.2*s); x.lineTo(X + 90 + k*240, G_ - 1.2*s); x.fill(); } }
      if (id === "pawn"){ x.fillStyle = "#e8b82e"; x.font = "bold 44px Arial Narrow, sans-serif"; x.fillText("WE BUY GOLD", X + 60, G_ - 1.8*s); }
    });
  }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; INT.tex = t; return t;
}
function setupInteriorGlass(mat){
  INT.u = { uShop:{ value:paintShopAtlas() }, uTime:{ value:0 }, uBright:{ value:1 } };
  const lights = SHOPS.map(s => `vec3(${s.light.map(v=>v.toFixed(2)).join(",")})`);
  mat.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, INT.u);
    sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nvarying vec3 vWPos; varying vec3 vWN; varying float vTheme;")
      .replace("#include <fog_vertex>", "#include <fog_vertex>\nvWPos = (modelMatrix * vec4(transformed, 1.0)).xyz; vWN = normalize(mat3(modelMatrix) * objectNormal); vTheme = floor(color.r*16.0);");
    sh.fragmentShader = sh.fragmentShader.replace("#include <common>", `#include <common>
      varying vec3 vWPos; varying vec3 vWN; varying float vTheme; uniform sampler2D uShop; uniform float uTime; uniform float uBright;
      float ih(vec2 p){ return fract(sin(dot(p, vec2(41.3, 289.1)))*43758.5453); }
      vec4 shopTile(float col, vec2 uv){ uv.x = fract(uv.x); uv.y = clamp(uv.y, 0.002, 0.998); return texture2D(uShop, vec2((col + uv.x)/4.0, 1.0 - (vTheme + 1.0)/${SHOPS.length}.0 + uv.y/${SHOPS.length}.0)); }`)
      .replace("#include <color_fragment>", "")
      .replace("#include <emissivemap_fragment>", `
      {
        vec3 N = normalize(vWN), V = normalize(vWPos - cameraPosition), room = vec3(0.0);
        if (abs(N.y) < 0.5 && dot(N, V) < 0.0){
          vec3 T = normalize(cross(vec3(0.0,1.0,0.0), N)), B = vec3(0.0,1.0,0.0);
          vec2 du = vec2(dFdx(vUv.x), dFdy(vUv.x)), dv = vec2(dFdx(vUv.y), dFdy(vUv.y)); vec3 px = dFdx(vWPos), py = dFdy(vWPos);
          float det = du.x*dv.y - du.y*dv.x; vec3 dPdu = (px*dv.y - py*dv.x)/det, dPdv = (py*du.x - px*du.y)/det;
          float W = clamp(length(dPdu), 1.0, 20.0), Hh = clamp(length(dPdv), 1.0, 5.0);
          vec3 org = vWPos - dPdu*vUv.x - dPdv*vUv.y; float seed = ih(floor(org.xz*0.5));
          vec3 rd = vec3(dot(V, T), dot(V, B), dot(V, -N)); rd.z = max(rd.z, 0.05);
          vec3 o = vec3(vUv.x*W, vUv.y*Hh, 0.0); float D = 4.3, TWm = 5.5, FL = -0.35, TH = 2.95;
          float tb = D/rd.z, ts = rd.x > 0.0 ? (W - o.x)/rd.x : -o.x/min(rd.x, -1e-4), tf = rd.y < 0.0 ? (FL - o.y)/rd.y : (Hh + 0.45 - o.y)/max(rd.y, 1e-4);
          float t = min(tb, min(ts, tf)); vec3 hp = o + rd*t;
          vec3 L = vec3(1.0); ${lights.map((l,k)=>`if (vTheme == ${k}.0) L = ${l};`).join(" ")}
          if (t == tb) room = shopTile(0.0, vec2(hp.x/TWm + seed, (hp.y - FL)/TH)).rgb;
          else if (t == ts) room = shopTile(0.0, vec2(hp.z/TWm*0.8 + seed*0.3, (hp.y - FL)/TH)).rgb*0.55;
          else if (rd.y < 0.0) room = L*vec3(0.2,0.17,0.14)*(0.9 + 0.3*step(0.5, fract(hp.x*0.8 + floor(hp.z*0.8)*0.5)))*(1.0 - 0.4*hp.z/D);
          else room = L*(0.18 + 0.9*smoothstep(0.1, 0.0, abs(fract(hp.x/1.8 + seed) - 0.5))*step(abs(hp.z - 2.0), 1.2));
          room *= L*mix(0.62, 0.85, 1.0 - hp.z/D);
          float zs0 = 0.75, zs1 = 1.9, zs2 = 3.1;
          for (int k = 0; k < 3; k++){
            float zk = k == 0 ? zs0 : k == 1 ? zs1 : zs2, col = k == 0 ? 1.0 : k == 1 ? 2.0 : 3.0;
            float tk = zk/rd.z; if (tk > t) break;
            vec3 q = o + rd*tk; vec4 pc = shopTile(col, vec2(q.x/TWm + seed + float(k)*0.37, (q.y - FL)/TH));
            if (pc.a > 0.5){ room = pc.rgb*L*(0.85 - 0.08*float(k)); break; }
          }
        }
        totalEmissiveRadiance = room * emissive * uBright;
      }`);
  };
  mat.needsUpdate = true;
}
function applyInteriorSettings(){
  if (!INT.u || !S) return;
  const g = ({ clear:[1.25, 0.25], balanced:[1.0, 0.45], reflective:[0.75, 0.8] })[S.custom.windowGlass] || [1, 0.45];
  INT.u.uBright.value = g[0]; if (World.mats && World.mats.glass) World.mats.glass.envMapIntensity = g[1];
}

function makeShopSigns(){
  const c = cnv(2048, 1536), x = c.getContext("2d"), r = mulberry(77);
  const styles = [
    ["#1e2a24","#f2e6c9","italic 700 62px Georgia, serif","gold",false], ["#f2e6c9","#3a2418","600 58px Georgia, serif","line",false],
    ["#101014","#ff4fa0","italic 700 64px Georgia, serif","none",true], ["#7a2e36","#f6efe0","700 60px Barlow Condensed, Arial Narrow, sans-serif","dots",false],
    ["#0e1a2a","#5cf2ff","700 62px Barlow Condensed, Arial Narrow, sans-serif","none",true], ["#e8a33d","#26231f","800 58px Barlow Condensed, Arial Narrow, sans-serif","line",false],
    ["#2f4b3a","#fff4d6","italic 600 60px Georgia, serif","gold",false], ["#f4f1ea","#c0362c","800 60px Barlow Condensed, Arial Narrow, sans-serif","stripe",false],
  ];
  for (let t=0;t<SHOPS.length;t++) for (let v=0;v<2;v++){
    const i = t*2 + v, col = i%4, row = (i/4)|0, sx = col*512, sy = row*128, st = styles[(t*3 + v*5) % styles.length];
    const [bg, fg, font, frame, neon] = st;
    x.fillStyle = bg; x.fillRect(sx+4, sy+4, 504, 120);
    const g = x.createLinearGradient(0, sy, 0, sy+128); g.addColorStop(0, "rgba(255,255,255,.1)"); g.addColorStop(1, "rgba(0,0,0,.18)"); x.fillStyle = g; x.fillRect(sx+4, sy+4, 504, 120);
    if (frame === "gold"){ x.strokeStyle = "#c9a24a"; x.lineWidth = 4; x.strokeRect(sx+14, sy+14, 484, 100); x.strokeRect(sx+20, sy+20, 472, 88); }
    if (frame === "line"){ x.strokeStyle = fg; x.lineWidth = 3; x.strokeRect(sx+14, sy+14, 484, 100); }
    if (frame === "dots"){ x.fillStyle = "#ffe7a8"; for (let k=0;k<22;k++){ x.beginPath(); x.arc(sx+22+k*22, sy+14, 4, 0, 7); x.arc(sx+22+k*22, sy+114, 4, 0, 7); x.fill(); } }
    if (frame === "stripe"){ for (let k=0;k<10;k++){ x.fillStyle = k%2 ? "#c0362c" : "#f4f1ea"; x.fillRect(sx+4+k*50.4, sy+4, 50.4, 16); } }
    x.fillStyle = fg; x.font = font; x.textAlign = "center"; x.textBaseline = "middle";
    if (neon){ x.shadowColor = fg; x.shadowBlur = 20; }
    x.fillText(SHOPS[t].names[v], sx+256, sy+70, 440); x.shadowBlur = 0;
  }

  const icon = (i, kind) => { const sx = (i%8)*256, sy = 1024 + ((i/8)|0)*256; x.fillStyle = "#1e2a24"; x.beginPath(); x.arc(sx+128, sy+128, 120, 0, 7); x.fill(); x.strokeStyle = "#c9a24a"; x.lineWidth = 8; x.stroke(); x.fillStyle = "#f2e6c9"; x.strokeStyle = "#f2e6c9"; x.lineWidth = 10;
    if (kind === "cup"){ x.fillRect(sx+80, sy+100, 80, 80); x.beginPath(); x.arc(sx+165, sy+140, 22, -1.4, 1.4); x.stroke(); for (let k=0;k<3;k++){ x.beginPath(); x.moveTo(sx+95+k*25, sy+90); x.quadraticCurveTo(sx+110+k*25, sy+70, sx+95+k*25, sy+50); x.stroke(); } }
    if (kind === "book"){ x.fillRect(sx+70, sy+80, 55, 100); x.fillRect(sx+131, sy+80, 55, 100); }
    if (kind === "reel"){ x.beginPath(); x.arc(sx+128, sy+128, 70, 0, 7); x.fill(); x.fillStyle = "#1e2a24"; for (let k=0;k<5;k++){ const a = k/5*6.283; x.beginPath(); x.arc(sx+128+Math.cos(a)*38, sy+128+Math.sin(a)*38, 16, 0, 7); x.fill(); } }
    if (kind === "glass"){ x.beginPath(); x.moveTo(sx+75, sy+70); x.lineTo(sx+181, sy+70); x.lineTo(sx+128, sy+135); x.fill(); x.fillRect(sx+122, sy+130, 12, 50); x.fillRect(sx+95, sy+178, 66, 10); }
    if (kind === "scissors"){ x.beginPath(); x.moveTo(sx+80, sy+70); x.lineTo(sx+176, sy+170); x.moveTo(sx+176, sy+70); x.lineTo(sx+80, sy+170); x.stroke(); x.beginPath(); x.arc(sx+80, sy+180, 18, 0, 7); x.arc(sx+176, sy+180, 18, 0, 7); x.stroke(); }
    if (kind === "drop"){ x.beginPath(); x.moveTo(sx+128, sy+55); x.quadraticCurveTo(sx+190, sy+140, sx+128, sy+190); x.quadraticCurveTo(sx+66, sy+140, sx+128, sy+55); x.fill(); }
    if (kind === "apple"){ x.beginPath(); x.arc(sx+110, sy+140, 45, 0, 7); x.arc(sx+146, sy+140, 45, 0, 7); x.fill(); x.fillRect(sx+124, sy+70, 8, 30); }
    if (kind === "record"){ x.beginPath(); x.arc(sx+128, sy+128, 72, 0, 7); x.fill(); x.fillStyle = "#1e2a24"; x.beginPath(); x.arc(sx+128, sy+128, 22, 0, 7); x.fill(); }
    if (kind === "heart"){ x.beginPath(); x.moveTo(sx+128, sy+190); x.bezierCurveTo(sx+40, sy+120, sx+70, sy+50, sx+128, sy+95); x.bezierCurveTo(sx+186, sy+50, sx+216, sy+120, sx+128, sy+190); x.fill(); }
    if (kind === "joy"){ x.fillRect(sx+70, sy+150, 116, 34); x.fillRect(sx+122, sy+80, 12, 70); x.beginPath(); x.arc(sx+128, sy+78, 20, 0, 7); x.fill(); }
    if (kind === "bowl"){ x.beginPath(); x.arc(sx+128, sy+120, 60, 0, Math.PI); x.fill(); for (let k=0;k<3;k++){ x.beginPath(); x.moveTo(sx+100+k*28, sy+100); x.quadraticCurveTo(sx+112+k*28, sy+80, sx+100+k*28, sy+60); x.stroke(); } }
    if (kind === "ring"){ x.beginPath(); x.arc(sx+128, sy+140, 46, 0, 7); x.stroke(); x.beginPath(); x.moveTo(sx+110, sy+95); x.lineTo(sx+128, sy+70); x.lineTo(sx+146, sy+95); x.fill(); }
    if (kind === "flower"){ for (let k=0;k<6;k++){ const a = k/6*6.283; x.beginPath(); x.arc(sx+128+Math.cos(a)*42, sy+120+Math.sin(a)*42, 26, 0, 7); x.fill(); } x.fillStyle = "#c9a24a"; x.beginPath(); x.arc(sx+128, sy+120, 22, 0, 7); x.fill(); }
  };
  SHOPS.forEach((sp, i) => icon(i, sp.icon));
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; return t;
}
function signUV(theme, variant){ const i = theme*2 + variant, col = i%4, row = (i/4)|0, H = 1536; return [col*0.25 + 0.002, 1 - ((row+1)*128)/H + 0.003, (col+1)*0.25 - 0.002, 1 - (row*128)/H - 0.003]; }
function iconUV(theme){ const col = theme%8, row = (theme/8)|0, H = 1536, y0 = 1024 + row*256; return [col/8 + 0.003, 1 - (y0 + 256)/H + 0.003, (col+1)/8 - 0.003, 1 - y0/H - 0.003]; }

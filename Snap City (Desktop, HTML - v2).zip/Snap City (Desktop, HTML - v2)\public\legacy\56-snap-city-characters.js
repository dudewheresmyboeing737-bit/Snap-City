(function(){
'use strict';const SC=window.SnapCity;
// Name, coat, accent, head silhouette, carried object, back/special silhouette.
const recipes=[
['Samurai','#6b2433','#d8ad50','hornhelm','katana','armor'],
['Alien','#81bca0','#352b62','alien','orb','antenna'],
['Cowboy','#88603c','#d7ba77','brim','lasso','bandana'],
['Pirate','#602b37','#e5c388','tricorn','sword','eyepatch'],
['Viking','#584431','#c9bca4','hornhelm','axe','fur'],
['Ninja','#18252b','#99344a','hood','katana','scarf'],
['Knight','#8a9aa7','#b73143','helmet','sword','shield'],
['Astronaut','#e4e6de','#ef873d','space','scanner','tanks'],
['Wizard','#433667','#ded17f','point','staff','cape'],
['Witch','#292c40','#87ba73','point','broom','cape'],
['Detective','#796d59','#242f38','brim','magnifier','coat'],
['Spy','#242936','#bd454b','glasses','briefcase','tie'],
['Assassin','#373140','#a44054','hood','dagger','scarf'],
['Bounty hunter','#54735d','#d6a04d','visor','scanner','armor'],
['Gladiator','#9c704c','#d1b76a','crest','spear','shield'],
['Monk','#a5652c','#d8bf83','bald','beads','robe'],
['Robot','#819eaa','#62e9d3','robot','claw','antenna'],
['Cyborg','#363d4c','#e95560','cyber','scanner','robotarm'],
['Vampire','#3b2034','#cfbdc8','slick','goblet','cape'],
['Werewolf','#624735','#d6b291','wolf','claw','fur'],
['Zombie','#607764','#aa675e','scar','flower','ragged'],
['Ghost','#bdd6db','#eaf6fa','ghost','orb','shroud'],
['Mermaid','#269b93','#b87fb9','crown','trident','tail'],
['Fairy','#b86ea6','#d8f5de','flowers','wand','wings'],
['Elf','#47775b','#d9c179','ears','bow','quiver'],
['Dwarf','#66503d','#c8985b','helmet','hammer','beard'],
['Orc','#536c3a','#d2c295','tusks','axe','armor'],
['Barbarian','#7b4d38','#c3ad7d','headband','axe','fur'],
['Archer','#52714f','#9e683d','hood','bow','quiver'],
['Alchemist','#544d72','#83ca9f','goggles','potion','satchel'],
['Inventor','#7e624e','#d4a957','goggles','gear','tools'],
['Scientist','#d9e2e0','#54b4bf','glasses','potion','labcoat'],
['Archaeologist','#ad9872','#715941','brim','brush','satchel'],
['Explorer','#8f9260','#e3c479','pith','map','backpack'],
['Treasure hunter','#665548','#d1ad48','headband','chest','satchel'],
['Street racer','#b54445','#e6e1c9','visor','helmet','stripes'],
['Skateboarder','#447994','#ec9c54','cap','skateboard','backpack'],
['Rock star','#443046','#e8b658','mohawk','guitar','studs'],
['Circus performer','#bf4773','#e4c951','tophat','juggle','ruff'],
['Fortune teller','#624379','#d9a952','turban','orb','shawl'],
['Royal guard','#9c263a','#d8bf65','tallhat','spear','epaulettes'],
['Princess','#b6709a','#ead490','crown','flower','gown'],
['Rebel leader','#586d57','#cb523d','beret','megaphone','bandana'],
['Superhero','#35699d','#d94846','mask','fist','cape'],
['Supervillain','#48355d','#86d6a0','hornhelm','orb','cape'],
['Time traveler','#716052','#68dad4','goggles','clock','timepack'],
['Post-apocalyptic survivor','#6b6251','#d0a14e','gasmask','lantern','scrap'],
['Deep-sea diver','#a58449','#8ebec0','dive','lantern','tanks'],
['Dragon rider','#426c6e','#d7844b','hornhelm','spear','dragon'],
['Monster hunter','#4c4e58','#b63c43','brim','crossbow','trophies']
];SC.characterTypes=recipes.map(r=>r[0]);
const geos={box:new THREE.BoxGeometry(1,1,1),ball:new THREE.SphereGeometry(.5,8,6),cyl:new THREE.CylinderGeometry(.5,.5,1,8),cone:new THREE.ConeGeometry(.5,1,8),ring:new THREE.TorusGeometry(.5,.065,4,12)};const mats=new Map();
function mat(c){if(!mats.has(c))mats.set(c,new THREE.MeshStandardMaterial({color:c,roughness:.65,metalness:.15}));return mats.get(c);}
function piece(g,type,c,x,y,z,w,h,d,rz=0){const o=new THREE.Mesh(geos[type],mat(c));o.position.set(x,y,z);o.scale.set(w,h,d);o.rotation.z=rz;g.add(o);return o;}
const camera=document.getElementById('scTitleCamera');if(camera)camera.src=window.SNAP_CAMERA_ART?.nikonf||'./cameras/nikonf.svg';
const dress=dressPerson;window.dressPerson=function(p,r){dress(p,r);if(p.pool||p.role||p.performer||p.id%2)return;const id=Math.floor(p.id/2)%recipes.length;const spec=recipes[id],L=p.look;p.archetype=id;L.top=spec[1];L.bottom=spec[1];L.costume=null;L.acc={};L.hat=null;if(['bald','alien','ghost','robot','space','dive'].includes(spec[3]))L.hair=null;L.smoke=false;L.btype='pants';L.sleeve='long';if(['Dwarf','Alien'].includes(spec[0])){L.h*=.8;L.b*=1.15;}if(['Orc','Barbarian','Werewolf'].includes(spec[0])){L.h*=1.08;L.b*=1.18;}if(spec[0]==='Alien'||spec[0]==='Orc'||spec[0]==='Zombie')L.skin=spec[1];p.top=L.top;};
SC.costumeMeshes=[];
SC.buildCostume=function(id){const [name,coat,accent,hat,prop,extra]=recipes[id],root=new THREE.Group(),head=new THREE.Group(),body=new THREE.Group(),hand=new THREE.Group();root.name=name;root.userData.characterType=name;for(const g of [head,body,hand]){g.matrixAutoUpdate=false;root.add(g);}const p=(g,t,c,x,y,z,w,h,d,r)=>piece(g,t,c,x,y,z,w,h,d,r);
 p(body,'box',coat,0,.04,.01,.44,.47,.28);
 if(['helmet','hornhelm','crest','dive','space','robot','visor'].includes(hat)){p(head,hat==='robot'?'box':'ball',hat==='space'?'#e4e6de':coat,0,.04,0,.5,.49,.48);p(head,'box',hat==='robot'?accent:'#182c38',0,.035,.235,.32,.12,.035);}
 if(hat==='hornhelm')for(const s of [-1,1])p(head,'cone',accent,s*.24,.25,0,.14,.36,.12,-s*.55);
 if(hat==='crest')p(head,'box',accent,0,.36,-.03,.08,.24,.35);
 if(['brim','point','pith','tricorn','tophat','tallhat','cap'].includes(hat)){p(head,'cyl',coat,0,.19,0,.65,.045,.55);p(head,hat==='point'?'cone':'cyl',hat==='pith'?'#d6c599':coat,0,hat==='point'?.48:.32,0,hat==='tallhat'?.39:.33,hat==='point'?.65:hat==='tallhat'?.65:.26,.34);if(hat==='tricorn')for(const s of [-1,1])p(head,'box',coat,s*.25,.27,0,.06,.21,.4,s*.5);}
 if(['hood','ghost','gasmask','wolf','alien'].includes(hat)){p(head,'ball',hat==='ghost'?'#b8d3db':coat,0,.02,-.02,.49,.53,.48);for(const s of [-1,1])p(head,'ball',hat==='alien'?'#152124':accent,s*.1,.05,.215,.11,.09,.035);if(hat==='wolf'){p(head,'box',coat,0,-.06,.22,.21,.17,.22);for(const s of [-1,1])p(head,'cone',coat,s*.18,.27,0,.14,.24,.13);}if(hat==='gasmask')p(head,'cyl','#303a3c',0,-.08,.26,.17,.16,.17);}
 if(['glasses','goggles','cyber','mask'].includes(hat))for(const s of [-1,1]){p(head,'ball',hat==='cyber'?accent:'#182b38',s*.1,.04,.2,.13,.1,.06);if(hat==='goggles')p(head,'ring',accent,s*.1,.04,.235,.15,.15,.1);}
 if(['crown','flowers','turban','beret','headband'].includes(hat)){p(head,'cyl',accent,0,.15,0,.43,hat==='turban'?.22:.07,.42);if(hat==='crown')for(let j=-2;j<=2;j++)p(head,'cone',accent,j*.075,.26,.13,.07,.18,.07);if(hat==='flowers')for(let j=0;j<5;j++)p(head,'ball',j%2?accent:'#ef9bbb',Math.cos(j*1.26)*.22,.19,Math.sin(j*1.26)*.22,.13,.12,.13);}
 if(hat==='mohawk')for(let i=0;i<5;i++)p(head,'cone',accent,0,.31,-.14+i*.07,.08,.28,.1);
 if(hat==='ears')for(const s of [-1,1])p(head,'cone',accent,s*.25,.06,0,.1,.3,.08,-s*.9);
 if(hat==='tusks')for(const s of [-1,1])p(head,'cone',accent,s*.095,-.08,.24,.045,.18,.05);
 if(hat==='bald'){p(head,'ball','#b99975',0,.08,0,.35,.31,.32);for(let i=0;i<8;i++)p(body,'ball',accent,Math.cos(i*.45)*.17,.26-Math.sin(i*.45)*.16,.19,.05,.05,.05);}
 if(hat==='slick')p(head,'ball','#25212c',0,.14,-.045,.4,.18,.36);
 if(hat==='scar')p(head,'box',accent,.08,.05,.21,.035,.22,.02,.4);
 // Equipment provides recognizable silhouettes even at street distance.
 if(['sword','katana','dagger','spear','staff','wand','broom','trident','axe','hammer'].includes(prop)){const len=prop==='dagger'?.4:prop==='wand'?.55:prop==='spear'||prop==='staff'||prop==='broom'?1.45:.95;p(hand,'box',prop==='staff'||prop==='broom'?'#78543a':'#cad5d7',0,.1,.05,.045,len,.04);if(['sword','katana','dagger'].includes(prop))p(hand,'box',accent,0,-len*.26,.05,.25,.04,.055);if(prop==='axe'||prop==='hammer')p(hand,'box',accent,.06,len*.42,.05,.33,.22,.1);if(['staff','wand'].includes(prop))p(hand,'ball',accent,0,len/2+.13,.05,.21,.21,.21);if(prop==='spear')p(hand,'cone',accent,0,.87,.05,.14,.3,.1);if(prop==='broom')p(hand,'cone','#bb9d56',0,-.67,.05,.28,.45,.2);if(prop==='trident')for(const x of [-.16,0,.16])p(hand,'cone',accent,x,.57,.05,.06,.4,.05);}
 else if(['orb','potion','goblet','beads','flower','juggle','fist','helmet'].includes(prop)){p(hand,prop==='goblet'?'cyl':'ball',accent,0,-.04,.16,.25,.29,.25);if(prop==='potion')p(hand,'cyl','#cad9d2',0,.17,.16,.08,.14,.08);if(prop==='flower')for(let j=0;j<5;j++)p(hand,'ball','#e487a5',Math.cos(j)*.1,.12+Math.sin(j)*.1,.18,.13,.13,.13);if(prop==='juggle')for(const s of [-1,1])p(hand,'ball',s<0?'#e3584e':'#54b3c7',s*.24,.32,.16,.18,.18,.18);}
 else if(prop==='bow'||prop==='lasso'){p(hand,'ring',accent,0,.02,.1,.55,prop==='bow'?1.1:.55,.18);}
 else if(prop==='guitar'){p(hand,'ball',accent,0,-.17,.15,.4,.5,.14);p(hand,'box','#aa8051',0,.24,.15,.07,.65,.06);}
 else if(prop==='skateboard'){p(hand,'box',accent,0,.02,.15,.24,.8,.08);for(const s of [-1,1])p(hand,'cyl','#262830',0,s*.27,.21,.3,.07,.08);}
 else if(prop==='magnifier'||prop==='clock'||prop==='gear'){p(hand,'ring',accent,0,.1,.15,.28,.28,.13);p(hand,'box',coat,0,-.11,.15,.04,.24,.04);if(prop==='clock')p(hand,'box',accent,.03,.12,.16,.09,.015,.025,.4);}
 else if(prop==='crossbow'){p(hand,'box','#6b4a38',0,.1,.12,.07,.6,.08);p(hand,'box',accent,0,.3,.12,.6,.05,.05);}
 else if(prop==='claw'){for(const x of [-.08,0,.08])p(hand,'cone',accent,x,.15,.17,.03,.35,.035);}
 else {p(hand,'box',prop==='map'?'#d9cba5':coat,0,-.05,.16,.35,.28,.14);p(hand,'box',accent,0,.02,.238,.22,.1,.025);}
 if(['cape','robe','coat','labcoat','gown','shroud','shawl','ragged'].includes(extra)){p(body,'cone',extra==='labcoat'?'#e7ece7':coat,0,-.3,-.1,extra==='gown'?.86:.58,.95,.46);if(extra==='cape')p(body,'box',accent,0,-.17,-.23,.55,.85,.035);}
 if(extra==='wings'||extra==='dragon')for(const s of [-1,1])p(body,'ball',accent,s*.4,.1,-.23,.65,.65,.055,-s*.4);
 if(extra==='tail'){p(body,'cone',coat,0,-.53,-.06,.47,.95,.32);for(const s of [-1,1])p(body,'ball',accent,s*.16,-.94,-.04,.36,.16,.06,s*.35);}
 if(['tanks','backpack','timepack','quiver','satchel','tools','scrap'].includes(extra)){p(body,'box',coat,0,.02,-.29,.4,.51,.22);for(const s of [-1,1])p(body,'cyl',accent,s*.12,.08,-.36,.12,.55,.12);}
 if(extra==='shield')p(body,'box',accent,-.31,-.01,.06,.12,.55,.43);
 if(extra==='armor'||extra==='epaulettes'||extra==='fur')for(const s of [-1,1])p(body,'ball',accent,s*.25,.24,0,.28,.2,.35);
 if(extra==='beard')p(head,'cone',accent,0,-.27,.17,.24,.45,.15,Math.PI);
 if(['scarf','bandana','tie'].includes(extra))p(body,'box',accent,.08,.1,.18,.13,.4,.04,.25);
 if(extra==='antenna')for(const s of [-1,1]){p(head,'cyl',accent,s*.16,.38,0,.03,.35,.03);p(head,'ball',accent,s*.16,.58,0,.09,.09,.09);}
 if(extra==='stripes'||extra==='studs'||extra==='ruff'||extra==='trophies'||extra==='robotarm')for(let i=0;i<4;i++)p(body,extra==='trophies'?'cone':'box',accent,-.16+i*.105,.17,.17,.07,.13,.055);
 if(name==='Ghost')root.traverse(o=>{if(o.isMesh){o.material=o.material.clone();o.material.transparent=true;o.material.opacity=.65;}});
 return {root,head,body,hand};};
const accessories=SC.drawAccessories;SC.drawAccessories=function(p,index,head,torso,left,right,dist){if(p.archetype===undefined||p.pool||p.role||p.performer)return accessories.apply(this,arguments);if(!p._fantasy){p._fantasy=SC.buildCostume(p.archetype);G.scene.add(p._fantasy.root);SC.costumeMeshes.push(p._fantasy);}const a=p._fantasy;a.root.visible=!p.hidden&&dist<65;a.head.matrix.copy(head);a.body.matrix.copy(torso);a.hand.matrix.copy(right);};
const life=updateLife;window.updateLife=function(){for(const a of SC.costumeMeshes)a.root.visible=false;return life.apply(this,arguments);};
})();

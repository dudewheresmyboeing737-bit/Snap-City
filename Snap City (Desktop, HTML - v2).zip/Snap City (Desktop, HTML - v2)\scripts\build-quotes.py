"""Curated short quotations. Each entry retains its public source link.
Excerpts are complete sentences selected from longer remarks, never rewritten.
"""
import json
from pathlib import Path
from collections import Counter

root=Path(__file__).resolve().parents[1]
quotes=[]
def add(author,source,*texts):
    if not source.startswith('https:'): source='https://photoquotes.com/author/'+source
    for text in texts:
        excerpt=text.startswith('~')
        quotes.append(dict(id=len(quotes)+1,author=author,text=text.lstrip('~'),source=source,excerpt=excerpt))

add('Ansel Adams','https://en.wikiquote.org/wiki/Ansel_Adams',
    'There are always two people in every picture: the photographer and the viewer.',
    '~Then, using that musical analogy, the print is the performance.')
add('Dorothea Lange','https://en.wikiquote.org/wiki/Dorothea_Lange',
    "One should really use the camera as though tomorrow you'd be stricken blind.")
add('Dorothea Lange','dorothea-lange',
    'Photography takes an instant out of time, altering life by holding it still.',
    'To be good, photographs have to be full of the world.')
add('Henri Cartier-Bresson','https://en.wikiquote.org/wiki/Henri_Cartier-Bresson',
    '~I watch, watch, watch. I understand things through my eyes.',
    '~But there is no standard plan, no pattern from which to work.')
add('Diane Arbus','https://en.wikiquote.org/wiki/Diane_Arbus',
    "My favorite thing is to go where I've never been.",
    "I never have taken a picture I've intended. They're always better or worse.")
add('Garry Winogrand','https://en.wikiquote.org/wiki/Garry_Winogrand',
    '~Anything and all things are photographable.',
    '~I like to think of photographing as a two-way act of respect.')
add('Robert Capa','https://en.wikiquote.org/wiki/Robert_Capa',
    "If your pictures aren't good enough, you aren't close enough.")
add('Berenice Abbott','https://en.wikiquote.org/wiki/Berenice_Abbott',
    '~Photography doesn’t teach you how to express your emotions; it teaches you how to see.')
add('Robert Frank','https://en.wikiquote.org/wiki/Robert_Frank',
    '~Black and white are the colors of photography.',
    '~There is one thing the photograph must contain, the humanity of the moment.')
add('Walker Evans','https://en.wikiquote.org/wiki/Walker_Evans',
    '~The important thing is to do the picture.',
    'It is the way to educate your eyes, and more. Stare, pry, listen, eavesdrop.')
add('Man Ray','https://en.wikiquote.org/wiki/Man_Ray',
    'A creator needs only one enthusiast to justify him.',
    'I do not photograph nature. I photograph my visions.')
add('Alfred Stieglitz','https://en.wikiquote.org/wiki/Alfred_Stieglitz',
    '~Photography is my passion.',
    '~Utopia is in the moment.',
    "Nearly right is child's play")
add('Annie Leibovitz','https://www.johnpaulcaponigro.com/blog/12935/28-quotes-by-photographer-annie-leibovitz/',
    'When I take a picture I take 10 percent of what I see.',
    'A very subtle difference can make the picture or not.')
add('Irving Penn','irving-penn',
    'A fashion picture is a portrait just as a portrait is a fashion picture.',
    'Because God lights things better than most photographers I know.')
add('Richard Avedon','richard-avedon',
    'All photographs are accurate. None of them is the truth.',
    'My portraits are more about me than they are about the people I photograph.')
add('Elliott Erwitt','elliott-erwitt',
    'A picture should be looked at - not talked about.',
    '~Photography is simply a function of noticing things. Nothing more.')
add('Elliott Erwitt','https://www.brainyquote.com/authors/elliott-erwitt-quotes',
    '~To me, photography is an art of observation. It’s about finding something interesting in an ordinary place.')
add('Edward Weston','edward-weston',
    'I see no reason for recording the obvious.',
    'Photography is the strongest way of seeing.')
add('Imogen Cunningham','imogen-cunningham',
    "Which of my photographs is my favorite? The one I'm going to take tomorrow.",
    'The thing that’s fascinating about portraiture is that nobody is alike.')
add('Minor White','minor-white',
    'Let the subject generate its own photographs. Become a camera.',
    'I am always mentally photographing everything as practice.')
add('Paul Strand','paul-strand',
    'All good art is abstract in its structure.',
    'Your photography is a record of your living, for anyone who really sees.')
add('Bill Brandt','bill-brandt',
    '~I am not interested in rules or conventions.',
    'Photography is not a sport. It has no rules. Everything must be dared and tried!')
add('Alfred Eisenstaedt','alfred-eisenstaedt',
    'When I have a camera in my hand, I know no fear.',
    'It is more important to click with people than to click the shutter.')
add('André Kertész','andre-kertesz',
    'Seeing is not enough; you have to feel what you photograph.',
    'I do not document anything, I give an interpretation.')
add('Brassaï','brassai',
    'To me photography must suggest, not insist or explain.',
    'I invent nothing, but I imagine everything.')
add('Helmut Newton','helmut-newton',
    'My job as a portrait photographer is to seduce, amuse and entertain.',
    "Look, I'm not an intellectual - I just take pictures.")
add('David Bailey','david-bailey',
    'I like people with their own beauty.',
    'Everyone will take one great picture, I’ve done better because I’ve taken two.')
add('Don McCullin','don-mccullin',
    'I only use a camera like I use a toothbrush. It does the job.',
    '~Photography isn’t about just pushing that button.')
add('Martin Parr','martin-parr',
    'I make serious photographs disguised as entertainment.',
    'Wait for rain, it makes shooting on the street easier and more interesting.')
add('Steve McCurry','steve-mccurry',
    'I strive for individual pictures that will burn in people’s memories.',
    'My photos are just a whimsical, poetic look at this commonality of humanity.')
add('William Eggleston','william-eggleston',
    'You can take a good picture of anything. A bad one, too.',
    'I am at war with the obvious.')
add('William Klein','william-klein',
    'Why must a photograph be a mirror?',
    'If you look carefully at life, you see blur. Shake your hand. Blur is part of life.')
add('Joel Meyerowitz','joel-meyerowitz',
    "Photography looks like pictures but it's really ideas, and they're your ideas.",
    '~Making any statement of your feelings is risky.')
add('Saul Leiter','saul-leiter',
    'I see something, I take a picture.',
    'Seeing is a neglected enterprise.',
    'I don’t have a philosophy; I have a camera.')
add('Sally Mann','sally-mann',
    'Here is my theory of photography: I think pictures actually create memories.',
    'Stop trying to get it right. Just take the picture.')
add('Mary Ellen Mark','mary-ellen-mark',
    'Photograph the world as it is. Nothing\'s more interesting than reality.',
    'If you can shoot on the street you can shoot anything.')
add('Robert Mapplethorpe','robert-mapplethorpe',
    "I'm looking for the unexpected. I'm looking for things I've never seen before.",
    'In the end, photography is the perfect way to make a sculpture.')
add('Sebastião Salgado','sebastiao-salgado',
    'It’s not the photographer who makes the picture, but the person being photographed.',
    'I looked through a lens and ended up abandoning everything else.')
add('Robert Adams','robert-adams',
    'Both poetry and photography tend toward metaphor.',
    'Basically, you photograph because you like what you see.')
add('Stephen Shore','stephen-shore',
    'A photograph has edges, the world does not.',
    '~I can see things fresh.')
add('Duane Michals','duane-michals',
    'I often try to photograph things about a person that are not visible.',
    'I use photography to help me explain my experiences to myself.')
add('Josef Koudelka','josef-koudelka',
    '~I prefer people to look at my pictures and invent their own stories.',
    '~A good photo is a miracle.')
add('Gordon Parks','gordon-parks',
    'The subject matter is so much more important than the photographer.',
    'You know, the camera is not meant just to show misery.')
add('James Nachtwey','james-nachtwey',
    '~I have been a witness, and these pictures are my testimony.',
    'My job is not to go to someplace and fall apart.')
add('David Hurn','david-hurn',
    'Learn from the best; the second-raters have nothing to offer.')
add('Michael Kenna','michael-kenna',
    'Easier is not necessarily better.',
    'Nothing is ever the same twice because everything is always gone forever, and yet each moment has infinite photographic possibilities.')
add('Lee Friedlander','lee-friedlander',
    'The world makes up my pictures, not me.',
    'I tend to photograph the things that get in front of my camera.')
add('Yousuf Karsh','yousuf-karsh',
    'Character, like a photograph, develops in darkness.',
    'Memorable photographs have been made with the simplest of cameras using available light.')
add('Eve Arnold','eve-arnold',
    'My passport was my camera.',
    'What you need to be a good photographer is an overwhelming curiosity and a good digestion.')
add('Nan Goldin','nan-goldin',
    'If I want to take a picture, I take it no matter what.',
    'Where is the line between life and photographing life?')
add('Daido Moriyama','daido-moriyama',
    "The camera doesn't matter.",
    'A single photograph contains different images.',
    'Making a definitive declaration of intent or meaning kills the photograph.')

words=Counter()
for q in quotes: words[q['source']]+=len(q['text'].split())
print('Count',len(quotes),'Authors',len(set(q['author'] for q in quotes)))
assert max(words.values())<=25,[(s,n) for s,n in words.items() if n>25]
assert len({q['text'] for q in quotes})==len(quotes)
assert len(quotes)==100,len(quotes)
(root/'public/quotes.json').write_text(json.dumps(quotes,ensure_ascii=False,indent=2)+'\n')
(root/'public/legacy/43-snap-city-quotes.js').write_text('/* Snap City: 100 short, attributed photographer quotations. */\nwindow.SNAP_QUOTES='+json.dumps(quotes,ensure_ascii=False)+';\n'+'''
(function(){
  const list=window.SNAP_QUOTES, box=document.getElementById('startupQuote');
  let previous=-1;try{previous=Number(localStorage.getItem('snapcity.lastQuote'));}catch(e){}
  const choices=list.filter(q=>q.id!==previous), q=choices[Math.floor(Math.random()*choices.length)];
  try{localStorage.setItem('snapcity.lastQuote',String(q.id));}catch(e){}
  box.replaceChildren();const quote=document.createElement('blockquote'),credit=document.createElement('a');
  quote.textContent='“'+q.text+'”';credit.textContent=q.author+(q.excerpt?' · excerpt':'');
  credit.href=q.source;credit.target='_blank';credit.rel='noopener noreferrer';credit.title='Read the quotation source';
  box.append(quote,credit);box.dataset.quoteId=q.id;window.SnapCity.startupQuote=q;
})();
''')
lines=['# Photographer quotations','',
       '100 short quotations and sentence excerpts by 49 photographers. Each displayed credit links to its source. Excerpts are marked in the game. Wording is preserved; punctuation is normalized in a few entries. Retrieved 25 September 2026.','',
       '| # | Photographer | Quotation | Source |','|---|---|---|---|']
for q in quotes: lines.append(f"| {q['id']} | {q['author']} | {q['text']}"+(' (excerpt)' if q['excerpt'] else '')+f" | [Source]({q['source']}) |")
(root/'QUOTE-SOURCES.md').write_text('\n'.join(lines)+'\n')

(function(){
"use strict";
const SC = window.SnapCity = window.SnapCity || {};
const DESK = SC.desk = { board: 3, hudT: 0 };
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
const EARN = () => (({ half:0.5, normal:1, double:2 })[S.custom && S.custom.earnings] ?? 1);
const TIME_START = { morning:6.6, noon:11, golden:17.9, blue:19.2, night:21 };
const TIME_NAME = { morning:"morning", noon:"midday", golden:"golden hour", blue:"blue hour", night:"night" };

function state(){
  const d = S.desk = S.desk || {};
  d.briefs = d.briefs || []; d.done = d.done || []; d.sales = d.sales || [];
  d.seq = d.seq || 0; d.play = d.play || 0; d.nextAt = d.nextAt || 0;
  d.stats = d.stats || { completed:0, earned:0, expired:0 };
  return d;
}

const inFrame = s => s && s.vis > 0.3 && s.area > 0.0015;
const isPerson = s => s && (s.kind === "person" || s.kind === "performer");
const subs = m => (m && m.subjects) || [];
const has = (m, f) => subs(m).some(s => inFrame(s) && f(s));
const prim = m => (typeof primaryOf === "function" ? primaryOf(subs(m)) : null);
const personPrim = (m, area) => { const p = prim(m); return !!(p && isPerson(p) && p.area > (area || 0.002)); };

const TEMPLATES = [
  { id:"dogwalk", title:"Walking the dog", desc:"A person and a dog sharing the frame.", base:150, diff:0,
    ok:m => has(m, isPerson) && has(m, s => s.kind === "dog"), feasible:() => (Life.dogs || []).length > 0 },
  { id:"tram", title:"The tram and the street", desc:"Pair a pedestrian with the tram.", base:170, diff:1, noHood:true,
    ok:m => has(m, isPerson) && has(m, s => s.kind === "cablecar"), feasible:() => !!Life.cable },
  { id:"busker", title:"An audience", desc:"A street performer with at least two people watching.", base:210, diff:1, noHood:true,
    ok:m => has(m, s => s.kind === "performer") && subs(m).filter(s => s.watcher && s.vis > 0.3).length >= 2,
    feasible:() => (Life.people || []).some(p => p.performer) },
  { id:"birds", title:"Wings and feet", desc:"Birds in the frame with a person.", base:220, diff:2,
    ok:m => has(m, isPerson) && has(m, s => s.kind === "birds"), feasible:() => (Life.flocks || []).length > 0 },
  { id:"gesture", title:"The decisive gesture", desc:"Catch your subject at the peak of a gesture: a wave, a laugh, a shrug.", base:240, diff:2,
    ok:m => { const p = prim(m); return !!(p && isPerson(p) && p.gesture && p.gpeak > 0.72); } },
  { id:"eyes", title:"Eye contact", desc:"Your subject glances straight into the lens.", base:190, diff:1,
    ok:m => { const p = prim(m); return !!(p && isPerson(p) && p.eye && p.area > 0.003); } },
  { id:"umbrella", title:"Umbrella weather", desc:"An umbrella on a rainy street.", base:200, diff:1, weather:"rain",
    ok:m => !!m.rain && has(m, s => s.umbrella) },
  { id:"night", title:"After dark", desc:"A person on the street at blue hour or night.", base:180, diff:1, times:["blue","night"],
    ok:m => (m.time === "blue" || m.time === "night") && personPrim(m) },
  { id:"golden", title:"Golden-hour portrait", desc:"A person filling a good part of the frame, in golden light.", base:180, diff:1, times:["golden"],
    ok:m => m.time === "golden" && personPrim(m, 0.008) },
  { id:"morning", title:"Morning commute", desc:"Someone on their way in the morning light.", base:160, diff:0, times:["morning"],
    ok:m => m.time === "morning" && personPrim(m) },
  { id:"fog", title:"Figures in the fog", desc:"A person half-dissolved in the fog.", base:210, diff:1, weather:"fog",
    ok:m => !!m.fog && has(m, isPerson) },
  { id:"story", title:"Cover a street story", desc:"Photograph someone taking part in a street event while it happens.", base:240, diff:2, noHood:true,
    ok:m => has(m, s => !!s.ev) },
  { id:"taxi", title:"Hailing a cab", desc:"A taxi and a person in the same frame.", base:140, diff:0,
    ok:m => has(m, isPerson) && has(m, s => s.kind === "car" && s.taxi) },
  { id:"layers", title:"Three layers deep", desc:"People at three different distances: near, middle and far.", base:230, diff:2,
    ok:m => new Set(subs(m).filter(s => s.vis > 0.35 && s.kind !== "car").map(s => s.dist < 5 ? 0 : s.dist < 14 ? 1 : s.dist < 35 ? 2 : 3)).size >= 3 }
];
const TPL = Object.fromEntries(TEMPLATES.map(t => [t.id, t]));
DESK.templates = TEMPLATES;

function hoodCenters(){
  if (DESK._hc) return DESK._hc;
  const acc = {}, n = typeof NB !== "undefined" ? NB : 3, lim = (n + 0.5) * P;
  for (let x = -lim; x <= lim; x += P/2) for (let z = -lim; z <= lim; z += P/2){
    let h; try { h = locationName(x, z).hood; } catch(e){ continue; }
    if (!h || h === "Snap City") continue;
    const a = acc[h] = acc[h] || { x:0, z:0, n:0 }; a.x += x; a.z += z; a.n++;
  }
  const out = {}; for (const k in acc) out[k] = { x: acc[k].x/acc[k].n, z: acc[k].z/acc[k].n };
  return DESK._hc = out;
}

function hoursUntil(id){
  const now = S.clock ?? 12, start = TIME_START[id] ?? 12;
  return ((start - now) % 24 + 24) % 24;
}
function timeMatchesNow(times){ return !times || times.includes(S.time); }

function makeBrief(){
  const d = state(), taken = new Set(d.briefs.map(b => b.tpl)), last = d.done[0] && d.done[0].tpl;
  const pool = TEMPLATES.filter(t => !taken.has(t.id) && t.id !== last && (!t.feasible || (()=>{ try { return t.feasible(); } catch(e){ return false; } })()));
  if (!pool.length) return null;
  const t = pool[Math.floor(Math.random() * pool.length)];
  const hoods = Object.keys(hoodCenters());
  const hood = !t.noHood && hoods.length && Math.random() < 0.65 ? hoods[Math.floor(Math.random() * hoods.length)] : null;
  const lvl = Math.max(1, S.level || 1);
  const min = Math.min(80, 55 + t.diff * 5 + Math.min(10, Math.floor((lvl - 1) / 2) * 2));
  const money = Math.round((t.base + (hood ? 50 : 0) + (lvl - 1) * 15) * EARN() / 5) * 5;
  const xp = 40 + t.diff * 20 + (hood ? 10 : 0);
  let minutes = 16 + t.diff * 4 + (hood ? 4 : 0);
  if (t.times){ const h = Math.min(...t.times.map(hoursUntil)); if (!timeMatchesNow(t.times)) minutes = Math.max(minutes, h * 6 + 10); }
  minutes = Math.min(60, minutes);
  d.seq++;
  return { id:"b" + d.seq, tpl:t.id, hood, min, money, xp, issued: d.play, issuedTs: Date.now(), expires: d.play + minutes*60 };
}

function describe(b){
  const t = TPL[b.tpl]; if (!t) return { title:"Brief", desc:"" };
  return { title: t.title + (b.hood ? ` in ${b.hood}` : ""), desc: t.desc };
}

function matches(b, rec, res){
  const t = TPL[b.tpl], m = rec.meta || {};
  if (!t || rec.ts < b.issuedTs || res.total < b.min) return false;
  if (b.hood && m.hood !== b.hood) return false;
  if (t.times && !t.times.includes(m.time)) return false;
  if (t.weather === "rain" && !m.rain) return false;
  if (t.weather === "fog" && !m.fog) return false;
  try { return !!t.ok(m); } catch(e){ return false; }
}

function awardXp(xp){
  S.xp += xp; let ups = 0;
  while (S.xp >= levelXp(S.level)){ S.xp -= levelXp(S.level); S.level++; S.skillPts++; ups++; }
  return ups;
}

function completeFor(rec, res){
  if (rec.brief) return null;
  const d = state();
  const order = d.briefs.slice().sort((a, b) => (b.id === d.pinned) - (a.id === d.pinned) || b.money - a.money);
  const b = order.find(x => matches(x, rec, res));
  if (!b) return null;
  const info = describe(b), money = S.free ? 0 : b.money, ups = awardXp(b.xp);
  if (money) S.money += money;
  rec.brief = { id:b.id, tpl:b.tpl, title:info.title, money, xp:b.xp };
  d.briefs = d.briefs.filter(x => x !== b);
  if (d.pinned === b.id) d.pinned = null;
  d.done.unshift({ id:b.id, tpl:b.tpl, title:info.title, money, xp:b.xp, score:res.total, frameNo:rec.frameNo, at:Date.now() });
  d.done = d.done.slice(0, 8);
  d.stats.completed++; d.stats.earned += money;
  d.nextAt = Math.min(d.nextAt || Infinity, d.play + 30);
  saveState();
  return { title:info.title, money, xp:b.xp, ups };
}

window.marketFactor = function(rec){
  const m = rec.meta || {}, d = state(), p = prim(m), kind = p ? p.kind : "scene", recent = d.sales.slice(0, 12);
  if (m.primaryKey && recent.some(s => s.key === m.primaryKey)) return 0.25;
  if (recent.some(s => s.street === m.street && s.kind === kind)) return 0.5;
  return 1;
};
window.recordSale = function(rec){
  if (rec._sold) return; rec._sold = 1;
  const m = rec.meta || {}, d = state(), p = prim(m);
  d.sales.unshift({ key: m.primaryKey || null, street: m.street || "", kind: p ? p.kind : "scene", ts: Date.now() });
  d.sales = d.sales.slice(0, 24);
};

const baseApply = applyJudgement;
window.applyJudgement = function(rec, res){
  const pay = baseApply.apply(this, arguments) || { money:0, xp:0, ups:0 };
  try {
    const hit = completeFor(rec, res);
    if (hit){
      pay.money = (pay.money || 0) + hit.money; pay.ups = (pay.ups || 0) + hit.ups; pay.brief = hit;
      setTimeout(() => toast(`Photo Desk brief filed: ${hit.title}.${hit.money ? ` The desk pays $${hit.money} (+${hit.xp} XP).` : ` +${hit.xp} XP.`}`, 3600), 3800);
    }
  } catch(e){ console.warn("[Snap City] Photo Desk check skipped:", e); }
  return pay;
};

function relDir(tx, tz){
  const dx = tx - Player.x, dz = tz - Player.z, dist = Math.hypot(dx, dz);
  const fx = -Math.sin(Player.yaw), fz = -Math.cos(Player.yaw);
  const dot = (dx*fx + dz*fz) / (dist || 1), cross = fx*dz - fz*dx;
  const dir = dot > 0.7 ? "ahead" : dot < -0.7 ? "behind you" : cross > 0 ? "to your right" : "to your left";
  return { dist, dir };
}
function conditions(b){
  const t = TPL[b.tpl], out = [];
  if (b.hood){
    let here = false; try { here = locationName(Player.x, Player.z).hood === b.hood; } catch(e){}
    const c = hoodCenters()[b.hood];
    out.push({ ok: here, text: here ? `You're in ${b.hood}` : c ? `${b.hood}, ${Math.round(relDir(c.x, c.z).dist / 10) * 10} m ${relDir(c.x, c.z).dir}` : b.hood });
  }
  if (t && t.times){
    const now = timeMatchesNow(t.times), h = Math.min(...t.times.map(hoursUntil));
    const name = t.times.map(x => TIME_NAME[x]).join(" or ");
    out.push({ ok: now, text: now ? `It's ${name} now` : S.flow === false ? `Needs ${name} (the clock is stopped)` : `Needs ${name}, in about ${Math.max(1, Math.round(h * 6))} min` });
  }
  if (t && t.weather){
    const now = t.weather === "rain" ? !!S.rain : !!S.fog;
    out.push({ ok: now, text: now ? `${t.weather === "rain" ? "It's raining" : "The fog is in"}` : `Needs ${t.weather === "rain" ? "rain" : "fog"}${S.custom.autoWeather === "off" ? " (set it in Time and weather)" : " (wait for it, or set it in Time and weather)"}` });
  }
  out.push({ ok: null, text: `Score ${b.min}+` });
  return out;
}
function timeLeft(b){ const s = Math.max(0, b.expires - state().play); const m = Math.floor(s/60); return m >= 1 ? `${m} min left` : `${Math.ceil(s)} s left`; }
function rewardText(b){ return S.free ? `+${b.xp} XP` : `$${b.money} · +${b.xp} XP`; }

function tick(dt){
  if (!S || !Game.started) return;
  const d = state();
  d.play += dt;
  for (const b of d.briefs.slice()){
    if (d.play > b.expires){
      d.briefs = d.briefs.filter(x => x !== b); d.stats.expired++;
      if (d.pinned === b.id) d.pinned = null;
      toast(`The desk gave "${describe(b).title}" to another photographer.`, 2600);
      d.nextAt = Math.min(d.nextAt || Infinity, d.play + 20);
    }
  }
  if (!d.seq){
    for (let k = 0; k < DESK.board; k++){ const b = makeBrief(); if (b) d.briefs.push(b); }
    if (!d.seq) d.seq = 1;
    d.nextAt = d.play + 45; saveState();
    if (d.briefs.length) setTimeout(() => toast("The Photo Desk has sent you three briefs. Press Tab and open Photo Desk to read them.", 3600), 9000);
  } else if (d.briefs.length < DESK.board && d.play >= (d.nextAt || 0)){
    const b = makeBrief();
    if (b){ d.briefs.push(b); toast(`New brief from the Photo Desk: ${describe(b).title}.`, 2600); }
    d.nextAt = d.play + 45;
    saveState();
  }
  DESK.hudT -= dt; if (DESK.hudT <= 0){ DESK.hudT = 0.5; renderChip(); }
}

function renderChip(){
  const el = document.getElementById("deskChip"); if (!el) return;
  const d = state();
  const b = d.briefs.find(x => x.id === d.pinned) || d.briefs.slice().sort((a, c) => a.expires - c.expires)[0];
  if (!b || S.custom.deskHud === "off"){ el.classList.add("hidden"); return; }
  el.classList.remove("hidden");
  const cs = conditions(b).filter(c => c.ok !== null);
  el.innerHTML = `<div class="dk-head"><span>${d.pinned === b.id ? "PINNED BRIEF" : "PHOTO DESK"}</span><span>${timeLeft(b)}</span></div><b>${esc(describe(b).title)}</b><div class="dk-meta">${rewardText(b)} · score ${b.min}+</div>${cs.map(c => `<div class="dk-cond ${c.ok ? "ok" : ""}">${c.ok ? "✓" : "·"} ${esc(c.text)}</div>`).join("")}${(window.deskRivalNote || (()=>""))(b, "chip")}`;
}

window.menuDesk = function(){
  const d = state();
  const cards = d.briefs.map(b => {
    const info = describe(b), cs = conditions(b), pinned = d.pinned === b.id;
    return `<div class="item desk-brief ${pinned ? "equipped" : ""}"><div class="sc-section-label">BRIEF · ${timeLeft(b).toUpperCase()}</div><h4>${esc(info.title)}</h4><div class="desc">${esc(info.desc)}</div>
      <ul class="desk-conds">${cs.map(c => `<li class="${c.ok === true ? "ok" : c.ok === false ? "no" : ""}">${c.ok === true ? "✓" : c.ok === false ? "○" : "★"} ${esc(c.text)}</li>`).join("")}</ul>
      ${(window.deskRivalNote || (()=>""))(b, "card")}<div class="foot"><span class="spec">${rewardText(b)}</span><span><button class="btn small ${pinned ? "" : "alt"}" data-desk-pin="${b.id}">${pinned ? "Pinned" : "Pin"}</button> <button class="btn small alt" data-desk-pass="${b.id}">Pass</button></span></div></div>`;
  }).join("");
  const next = d.briefs.length < DESK.board ? `<div class="item desk-brief desk-wait"><div class="sc-section-label">NEXT BRIEF</div><h4>The phone will ring</h4><div class="desc">A new brief arrives in about ${Math.max(1, Math.ceil(((d.nextAt || 0) - d.play)/60))} min of street time.</div></div>` : "";
  const hist = d.done.length ? `<div class="sectionhead" style="margin-top:22px">Filed</div><table class="keys desk-history">${d.done.map(x => `<tr><td>${esc(x.title)}</td><td>frame ${x.frameNo} · score ${x.score}</td><td>${S.free || !x.money ? `+${x.xp} XP` : `$${x.money}`}</td></tr>`).join("")}</table>` : "";
  const hud = S.custom.deskHud === "off" ? "off" : "on";
  return `<div class="sectionhead">Photo Desk</div>
    <p class="note">The desk sends briefs. Shoot a frame that fits after the brief arrives, then judge it: the first judged frame that meets the brief and its score is filed and paid${S.free ? " in XP (Free Play)" : ""}. Briefs expire if nobody files them.</p>
    <div class="grid" style="margin-top:14px">${cards}${next}</div>
    <div class="sectionhead" style="margin-top:22px">Open market</div>
    <p class="note">Frames that fit no brief sell on the open market. The desk won't buy anything under 50. A frame that scores 60 earns $15, 70 earns $45, 80 earns $95 and 90 earns $165. It pays half for another sale of the same kind of subject on the same street, and a quarter for the same person again.</p>
    <div class="formrow"><label>Brief on the street</label><div class="seg"><button data-desk-hud="on" aria-pressed="${hud === "on"}">Show</button><button data-desk-hud="off" aria-pressed="${hud === "off"}">Hide</button></div><span class="spec">Shows the pinned brief (or the next to expire) above your money.</span></div>
    ${(window.deskRivalPanel || (()=>""))()}
    <p class="note">${d.stats.completed} brief${d.stats.completed === 1 ? "" : "s"} filed${S.free ? "" : `, $${d.stats.earned.toLocaleString()} earned from briefs`}.</p>${hist}`;
};

const baseMenu = renderMenu;
window.renderMenu = function(){
  const r = baseMenu.apply(this, arguments);
  try {
    if (UI.menuTab === "desk"){
      const body = document.getElementById("menubody"), d = state();
      body.querySelectorAll("[data-desk-pin]").forEach(btn => btn.onclick = () => { d.pinned = d.pinned === btn.dataset.deskPin ? null : btn.dataset.deskPin; saveState(); renderChip(); renderMenu(); });
      body.querySelectorAll("[data-desk-pass]").forEach(btn => btn.onclick = () => { d.briefs = d.briefs.filter(b => b.id !== btn.dataset.deskPass); if (d.pinned === btn.dataset.deskPass) d.pinned = null; d.nextAt = d.play + 60; saveState(); renderChip(); renderMenu(); });
      body.querySelectorAll("[data-desk-hud]").forEach(btn => btn.onclick = () => { S.custom.deskHud = btn.dataset.deskHud; saveState(); renderChip(); renderMenu(); });
    }
  } catch(e){ console.warn("[Snap City] Photo Desk menu:", e); }
  return r;
};

const baseSide = renderLbSide;
window.renderLbSide = function(p, info){
  const r = baseSide.apply(this, arguments);
  try {
    const side = document.getElementById("lbside"); if (!side || !p || !p.judged) return r;
    const note = document.createElement("div"); note.className = "desk-lb";
    if (p.brief) note.innerHTML = `<b>Photo Desk brief filed</b>${esc(p.brief.title)} · ${p.brief.money ? `$${p.brief.money} · ` : ""}+${p.brief.xp} XP`;
    else if (p.score < 50) note.innerHTML = `<b>Open market</b>The desk doesn't buy frames under 50.`;
    else if (p.payFactor !== undefined && p.payFactor < 1) note.innerHTML = `<b>Open market</b>${p.payFactor <= 0.25 ? "The desk already bought this person" : "The desk already bought this kind of frame on this street"}, so it paid ${Math.round(p.payFactor*100)}%.`;
    else return r;
    const score = side.querySelector(".score");
    if (score && score.parentNode === side) score.insertAdjacentElement("afterend", note); else side.prepend(note);
  } catch(e){}
  return r;
};

const baseGameplay = gameplayUpdate;
window.gameplayUpdate = function(dt){
  const r = baseGameplay.apply(this, arguments);
  try { tick(dt); } catch(e){ console.warn("[Snap City] Photo Desk tick skipped:", e); }
  return r;
};

DESK.TPL = TPL; DESK.timeMatchesNow = timeMatchesNow; DESK.state = state; DESK.makeBrief = makeBrief; DESK.matches = matches; DESK.describe = describe; DESK.conditions = conditions; DESK.renderChip = renderChip;
})();

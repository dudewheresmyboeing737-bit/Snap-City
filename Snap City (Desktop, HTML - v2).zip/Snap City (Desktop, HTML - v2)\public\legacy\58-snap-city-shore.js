(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const edge = () => (SC.island && SC.island.edge) || ((NOUT + .5) * P + 20);
  const clampTo = (x, z, pad) => { const L = edge() - pad; return [Math.max(-L, Math.min(L, x)), Math.max(-L, Math.min(L, z))]; };
  if (typeof collidePoint === "function"){
    const base = collidePoint;
    window.collidePoint = function(x, z, r){ const c = base.apply(this, arguments); return clampTo(c[0], c[1], 3); };
  }
  function hook(){
    const C = SC.solids; if (!C || !C.playerAt || C.playerAt._shore) return !!(C && C.playerAt && C.playerAt._shore);
    const base = C.playerAt;
    C.playerAt = function(x, z, r){ const c = base.apply(this, arguments); if (typeof S !== "undefined" && S && S.custom.walkOnWater === "on") return c; return clampTo(c[0], c[1], 1.2); };
    C.playerAt._shore = true; return true;
  }
  if (!hook()){ const iv = setInterval(() => { if (hook()) clearInterval(iv); }, 300); }
  if (typeof menuSettings === "function"){
    const base = menuSettings;
    window.menuSettings = function(){
      const c = S.custom; if (c.walkOnWater === undefined) c.walkOnWater = "off";
      return `<div class="formrow"><label>Walk on water</label><div class="seg" data-seg44="walkOnWater">${[["off","Off"],["on","On"]].map(([v,l]) => `<button data-v="${v}" aria-pressed="${c.walkOnWater===v}">${l}</button>`).join("")}</div><span class="spec">Just for fun: stroll out across the sea. Off keeps you on the island, like everyone else.</span></div>` + base.apply(this, arguments);
    };
  }
})();

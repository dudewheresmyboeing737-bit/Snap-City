(function(){
'use strict';const SC=window.SnapCity,T=SC.traversal;
const C=SC.solids={cells:new Map(),count:0};const key=(x,z)=>Math.floor(x/12)+','+Math.floor(z/12);
function add(b){if(!Number.isFinite(b.top)||b.top-b.bottom<.15)return;C.count++;const rr=Math.hypot(b.w,b.d)/2;for(let x=Math.floor((b.x-rr)/12);x<=Math.floor((b.x+rr)/12);x++)for(let z=Math.floor((b.z-rr)/12);z<=Math.floor((b.z+rr)/12);z++){const k=x+','+z;if(!C.cells.has(k))C.cells.set(k,[]);C.cells.get(k).push(b);}}
C.add=add;
// Capture the actual generated primitives, including narrow hydrants and poles.
const primitive=pushGeom;window.pushGeom=function(k,g,m,c){if(['plain','metal','civic'].includes(k)&&g!==PRIM.leaf){if(!g.boundingBox)g.computeBoundingBox();const b=g.boundingBox.clone().applyMatrix4(m);const w=b.max.x-b.min.x,d=b.max.z-b.min.z,h=b.max.y-b.min.y;if(w>.06&&d>.06&&h>.15&&w<100&&d<100)add({x:(b.min.x+b.max.x)/2,z:(b.min.z+b.max.z)/2,w,d,ry:0,bottom:b.min.y,top:b.max.y});}return primitive.apply(this,arguments);};
const facade=facadeBox;window.facadeBox=function(k,x,y,z,w,h,d,ry){add({x,z,w,d,ry,bottom:y,top:y+h});return facade.apply(this,arguments);};
function pushBox(x,z,r,b,foot,height){if(b.top<=foot+.45||b.bottom>=foot+height)return [x,z];const c=Math.cos(b.ry||0),s=Math.sin(b.ry||0);let dx=x-b.x,dz=z-b.z,lx=dx*c-dz*s,lz=dx*s+dz*c;const w=b.w/2+r,d=b.d/2+r;if(Math.abs(lx)>=w||Math.abs(lz)>=d)return [x,z];if(w-Math.abs(lx)<d-Math.abs(lz))lx=(lx<0?-1:1)*w;else lz=(lz<0?-1:1)*d;return [b.x+lx*c+lz*s,b.z-lx*s+lz*c];}
C.staticAt=function(x,z,r,foot,height=1.65){for(let pass=0;pass<3;pass++){const nearby=new Set();for(let ix=Math.floor((x-r)/12);ix<=Math.floor((x+r)/12);ix++)for(let iz=Math.floor((z-r)/12);iz<=Math.floor((z+r)/12);iz++)for(const b of C.cells.get(ix+","+iz)||[])nearby.add(b);for(const b of nearby)[x,z]=pushBox(x,z,r,b,foot,height);}return [x,z];};
// NPC/path queries use physical structures too; no rectangular lot bans or map-edge clamp.
window.collidePoint=function(x,z,r=.35){return C.staticAt(x,z,r,groundY(x,z));};
function circle(x,z,r,px,pz,pr){const dx=x-px,dz=z-pz,d=Math.hypot(dx,dz),min=r+pr;if(d>=min)return [x,z];if(d<.0001)return [px+min,pz];return [px+dx/d*min,pz+dz/d*min];}
C.playerAt=function(x,z,r=.3){const foot=PLAYX.footY??groundY(x,z),height=Player.crouch>.5?1.05:1.65;
 if(ZONE.mode!=='shop')[x,z]=C.staticAt(x,z,r,foot,height);
 for(const p of Life.people||[]){if(p.hidden||!p.look||Math.abs(p.x-x)>2||Math.abs(p.z-z)>2)continue;const py=p.y??groundY(p.x,p.z);if(py<foot+height&&py+(p.look.h||1.75)>foot+.15)[x,z]=circle(x,z,r,p.x,p.z,.18+.11*(p.look.b||1));}
 for(const k of T.knights||[]){const p=k.p.g.position;if(p.y<foot+height&&p.y+1.85>foot+.15)[x,z]=circle(x,z,r,p.x,p.z,.34);}
 for(const p of SC.life?.shopFolk||[]){const g=p.g;if(!g)continue;const v=g.getWorldPosition(new THREE.Vector3());if(v.y<foot+height&&v.y+1.7>foot+.15)[x,z]=circle(x,z,r,v.x,v.z,.3);}
 for(const car of Life.cars||[]){if(!car.g?.visible||GP.ride?.v===car||Math.abs(car.x-x)>20||Math.abs(car.z-z)>12)continue;if(!car._solidSize){car.g.updateMatrixWorld(true);const box=new THREE.Box3(),tmp=new THREE.Box3();car.g.traverse(o=>{if(!o.isMesh||!o.visible)return;const mt=o.material;if(!mt||mt.transparent||mt.blending===THREE.AdditiveBlending||mt.depthWrite===false||mt.type==='MeshBasicMaterial')return;if(!o.geometry.boundingBox)o.geometry.computeBoundingBox();tmp.copy(o.geometry.boundingBox).applyMatrix4(o.matrixWorld);box.union(tmp);});if(box.isEmpty())box.setFromCenterAndSize(new THREE.Vector3(car.x,H(car.x,car.z)+.8,car.z),new THREE.Vector3(car.width||2,1.5,car.len||4.6));const size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3());car._solidSize={w:size.x,d:size.z,h:size.y,dx:center.x-car.x,dz:center.z-car.z};}const b=car._solidSize;[x,z]=pushBox(x,z,r,{x:car.x+b.dx,z:car.z+b.dz,w:b.w,d:b.d,ry:0,bottom:H(car.x,car.z),top:H(car.x,car.z)+b.h},foot,height);} 
 for(const b of World.benches||[])[x,z]=pushBox(x,z,r,{x:b.x,z:b.z,w:1.8,d:.6,ry:b.ry||0,bottom:b.y,top:b.y+.8},foot,height);
 for(const car of World.parkedCars||[])[x,z]=pushBox(x,z,r,{x:car.x,z:car.z,w:car.W,d:car.L,ry:car.ry||0,bottom:car.y??groundY(car.x,car.z),top:car.top},foot,height);
 return [x,z];};
C.move=function(x,z){const ox=Player.x,oz=Player.z,n=Math.max(1,Math.ceil(Math.hypot(x-ox,z-oz)/.16));let a=ox,b=oz;for(let i=0;i<n;i++)[a,b]=C.playerAt(a+(x-ox)/n,b+(z-oz)/n);return [a,b];};
let detailsRegistered=false;
function registerDetails(){if(detailsRegistered||!window.CS131?.detailGroup)return;detailsRegistered=true;CS131.detailGroup.updateMatrixWorld(true);CS131.detailGroup.traverse(o=>{if(!o.isMesh)return;const b=new THREE.Box3().setFromObject(o);add({x:(b.min.x+b.max.x)/2,z:(b.min.z+b.max.z)/2,w:b.max.x-b.min.x,d:b.max.z-b.min.z,ry:0,bottom:b.min.y,top:b.max.y});});}
const tick=gameplayUpdate;window.gameplayUpdate=function(dt){const result=tick.apply(this,arguments);registerDetails();if(!GP.ride&&Game.started){const [x,z]=C.playerAt(Player.x,Player.z);const dx=x-Player.x,dz=z-Player.z;Player.x=x;Player.z=z;G.cam.position.x+=dx;G.cam.position.z+=dz;}return result;};
// Keep precipitation state authoritative, even after reflection/capture passes.
const updateRain=Rain.update;Rain.update=function(dt,pos){if(this.mesh)this.mesh.visible=!!S.rain&&!S.snow;return updateRain.call(this,dt,pos);};
const weather=SC.weather;SC.weather=function(mode,fog){S.weatherRevision=Number.isFinite(S.weatherRevision)?S.weatherRevision:0;const result=weather(mode,fog);if(Rain.mesh){Rain.mesh.visible=!!S.rain&&!S.snow;Rain.mesh.material.uniforms.uCam.value.copy(G.cam.position);}if(mode==='rain'||mode==='storm')Rain.len=mode==='storm'?.64:.56;return result;};
const wire=wireMenu;window.wireMenu=function(){const result=wire.apply(this,arguments);for(const type of ['rain','snow','storm','fog'])document.querySelectorAll('[data-'+type+'] button').forEach(b=>b.onclick=()=>{S.custom.autoWeather='off';if(type==='fog')SC.weather(null,b.dataset.v==='1');else{S.sky='clear';SC.weather(b.dataset.v==='1'?type:'clear');}saveState();renderMenu();});return result;};
})();

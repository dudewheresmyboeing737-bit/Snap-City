(function(){
  "use strict";
  const read = {
    S:      function(){ return typeof S      !== "undefined" ? S      : undefined; },
    G:      function(){ return typeof G      !== "undefined" ? G      : undefined; },
    World:  function(){ return typeof World  !== "undefined" ? World  : undefined; },
    Player: function(){ return typeof Player !== "undefined" ? Player : undefined; },
    Game:   function(){ return typeof Game   !== "undefined" ? Game   : undefined; },
    Life:   function(){ return typeof Life   !== "undefined" ? Life   : undefined; },
    UI:     function(){ return typeof UI     !== "undefined" ? UI     : undefined; },
    GP:     function(){ return typeof GP     !== "undefined" ? GP     : undefined; },
    WIND:   function(){ return typeof WIND   !== "undefined" ? WIND   : undefined; },
    Refl:   function(){ return typeof Refl   !== "undefined" ? Refl   : undefined; },
    Cam:    function(){ return typeof Cam    !== "undefined" ? Cam    : undefined; },
    VF:     function(){ return typeof VF     !== "undefined" ? VF     : undefined; }
  };
  Object.keys(read).forEach(function(name){
    if (Object.prototype.hasOwnProperty.call(window, name)) return;
    Object.defineProperty(window, name, {
      configurable: true,
      enumerable: false,
      get: read[name],

      set: name === "S" ? function(v){ S = v; } : undefined
    });
  });
})();

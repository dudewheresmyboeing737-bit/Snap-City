export type ExposureStatus =
  | "severely-underexposed"
  | "underexposed"
  | "slightly-underexposed"
  | "correct"
  | "slightly-overexposed"
  | "overexposed"
  | "severely-overexposed";

export interface ExposureSettings {
  aperture: number;
  shutterSeconds: number;
  iso: number;
  exposureCompensation?: number;
}

export interface ExposureReading {
  cameraEv100: number;
  meteredSceneEv100: number;
  compensationEv: number;
  effectiveCameraEv100: number;
  errorEv: number;
  status: ExposureStatus;
  quality: number;
}

export function cameraEv100(aperture: number, shutterSeconds: number, iso: number): number {
  if (aperture <= 0 || shutterSeconds <= 0 || iso <= 0) {
    throw new Error("Aperture, shutter speed, and ISO must be positive.");
  }
  return Math.log2((100 * aperture ** 2) / (iso * shutterSeconds));
}

export function exposureStatus(errorEv: number): ExposureStatus {
  if (errorEv >= 3) return "severely-underexposed";
  if (errorEv >= 1.25) return "underexposed";
  if (errorEv >= 0.35) return "slightly-underexposed";
  if (errorEv > -0.35) return "correct";
  if (errorEv > -1.25) return "slightly-overexposed";
  if (errorEv > -3) return "overexposed";
  return "severely-overexposed";
}

export function readExposure(meteredSceneEv100: number, settings: ExposureSettings): ExposureReading {
  const cameraEv = cameraEv100(settings.aperture, settings.shutterSeconds, settings.iso);
  const compensation = settings.exposureCompensation ?? 0;
  const effectiveCameraEv100 = cameraEv - compensation;
  const errorEv = effectiveCameraEv100 - meteredSceneEv100;
  return {
    cameraEv100: cameraEv,
    meteredSceneEv100,
    compensationEv: compensation,
    effectiveCameraEv100,
    errorEv,
    status: exposureStatus(errorEv),
    quality: Math.max(0, Math.round(100 - Math.abs(errorEv) * 24))
  };
}

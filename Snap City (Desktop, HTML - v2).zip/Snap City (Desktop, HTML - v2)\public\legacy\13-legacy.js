const PRESETS = [
  { id:"none", name:"Original", e:{} },
  { id:"trix", name:"Tri-X 400", e:{ bw:1, filter:"yellow", con:28, sh:8, grain:28, hi:-10 } },
  { id:"portra", name:"Portra 400", e:{ temp:12, sat:-8, con:-10, fade:8, hi:-22, vib:12, sh:10 } },
  { id:"kchrome", name:"Kodachrome", e:{ sat:16, con:20, temp:6, tint:3, sh:-12, vib:6 } },
  { id:"cine", name:"Cinestill 800T", e:{ temp:-24, tint:7, hi:-18, grain:14, con:10, split:18, splitHue:20, splitShHue:190 } },
  { id:"hp5", name:"HP5 pushed", e:{ bw:1, filter:"red", con:42, grain:40, vig:-28, sh:-8 } },
  { id:"fade", name:"Faded summer", e:{ fade:22, sat:-14, temp:10, con:-14, hi:-10 } },
  { id:"street", name:"Street matte", e:{ con:14, fade:12, sat:-22, vig:-18, clarity:0 } },
  { id:"neon", name:"Neon night", e:{ temp:-10, tint:10, sat:22, con:12, hi:-25, sh:14, vib:18 } },
];
const TONE_KEYS = ["ex","con","hi","sh","temp","tint","sat","vib","bw","filter","fade","vig","grain","clarity","split","splitHue","splitShHue"];
const Ed = { rec:null, img:null, e:null, comparing:false, raf:0, overlayT:0, cvs:null, W:1500, H:1000, dirty:false };

async function openEditor(rec){
  if (!rec) { toast("Take a photo first."); return; }
  Ed.rec = rec; Ed.e = Object.assign(defaultEdit(), rec.edit || {}); if (!rec.meta.W) rec.meta.W = 1500, rec.meta.H = 1000;
  Ed.img = await createImageBitmap(rec.orig);
  Ed.W = Ed.img.width; Ed.H = Ed.img.height; Ed.dirty = false;
  showPanel("#editor");
  buildEdSide();
  scheduleEd();
}
function closeEditor(){ $("#editor").classList.add("hidden"); Ed.rec = null; if (Ed.img && Ed.img.close) Ed.img.close(); Ed.img = null; onPanelClosed(); }

function edRow(key, label, min, max, step, fmt){
  const v = Ed.e[key];
  return `<div class="sl"><label for="ed_${key}">${label}</label><output id="edo_${key}">${fmt? fmt(v): v}</output><input type="range" id="ed_${key}" data-k="${key}" min="${min}" max="${max}" step="${step}" value="${v}"></div>`;
}
const FMT = { ex: v=> (v>0?"+":"")+(+v).toFixed(2)+" EV", angle: v=>(+v).toFixed(1)+"°", zoom: v=>(+v).toFixed(2)+"×", pct: v=>(v>0?"+":"")+Math.round(v), hue: v=>Math.round(v)+"°", pan: v=>(+v).toFixed(2) };
function fmtFor(k){ return FMT[k] || (k==="panX"||k==="panY" ? FMT.pan : (k==="splitHue"||k==="splitShHue") ? FMT.hue : FMT.pct); }
function buildEdSide(){
  const e = Ed.e, dr = sk("darkroom");
  const aspectBtns = Object.keys(ASPECTS).map(a=>`<button data-aspect="${a}" aria-pressed="${e.aspect===a}">${a==="orig"?"Original":a}</button>`).join("");
  const filters = ["none","red","yellow","green","blue"].map(f=>`<button data-filter="${f}" aria-pressed="${e.filter===f}">${f==="none"?"No filter":cap(f)}</button>`).join("");
  let presetHtml;
  if (dr >= 1) presetHtml = `<div class="presets" id="edPresets">${PRESETS.map(p=>`<button data-preset="${p.id}" aria-pressed="${e.preset===p.id}"><canvas width="96" height="64"></canvas>${p.name}</button>`).join("")}</div>`;
  else presetHtml = `<p class="note">Film presets unlock with the first rank of the Darkroom skill.</p>`;
  const lvl = Math.abs(Ed.rec.meta.roll) < 15 ? `<button class="btn small alt" id="edLevel">Level the horizon</button>` : "";
  $("#edside").innerHTML = `
    <div class="edgroup">Film looks</div>${presetHtml}
    <div class="edgroup">Crop and straighten</div>
    <div class="seg" id="edAspect">${aspectBtns}</div>
    ${edRow("zoom","Crop in",1,3,0.01,FMT.zoom)}${edRow("panX","Move left and right",-1,1,0.01,FMT.pan)}${edRow("panY","Move up and down",-1,1,0.01,FMT.pan)}
    ${edRow("angle","Straighten",-15,15,0.1,FMT.angle)}${lvl}
    <div class="edgroup">Light</div>
    ${edRow("ex","Exposure",-2,2,0.05,FMT.ex)}${edRow("con","Contrast",-60,60,1,FMT.pct)}${edRow("hi","Highlights",-100,100,1,FMT.pct)}${edRow("sh","Shadows",-100,100,1,FMT.pct)}
    <div class="edgroup">Colour</div>
    ${edRow("temp","Temperature",-60,60,1,FMT.pct)}${edRow("tint","Tint",-50,50,1,FMT.pct)}${edRow("sat","Saturation",-100,80,1,FMT.pct)}${edRow("vib","Vibrance",-60,80,1,FMT.pct)}
    <div class="edgroup">Black and white</div>
    <div class="seg" id="edBW"><button data-bw="0" aria-pressed="${!e.bw}">Colour</button><button data-bw="1" aria-pressed="${!!e.bw}">Black and white</button></div>
    <div class="formrow"><label>Lens filter</label><div class="seg" id="edFilter">${filters}</div></div>
    <div class="edgroup">Finish</div>
    ${edRow("fade","Fade",0,50,1,FMT.pct)}${edRow("vig","Vignette",-60,40,1,FMT.pct)}${edRow("grain","Grain",0,60,1,FMT.pct)}
    <div class="edgroup">Darkroom tricks</div>
    ${dr >= 2 ? edRow("clarity","Clarity",-50,70,1,FMT.pct) + edRow("split","Split toning",0,60,1,FMT.pct) + edRow("splitHue","Highlight hue",0,360,1,FMT.hue) + edRow("splitShHue","Shadow hue",0,360,1,FMT.hue)
      : `<p class="note">Clarity and split toning unlock with the second rank of the Darkroom skill.</p>`}
  `;
  $$("#edside input[type=range]").forEach(inp=>inp.addEventListener("input", ()=>{
    const k = inp.dataset.k; Ed.e[k] = +inp.value; const o = $("#edo_"+k); if (o) o.textContent = fmtFor(k)(Ed.e[k]);
    if (["zoom","panX","panY","angle"].includes(k)) Ed.overlayT = performance.now() + 1200;
    if (TONE_KEYS.includes(k)) Ed.e.preset = "custom";
    Ed.dirty = true; scheduleEd();
  }));
  $$("#edAspect button").forEach(bn=>bn.onclick=()=>{ Ed.e.aspect = bn.dataset.aspect; $$("#edAspect button").forEach(x=>x.setAttribute("aria-pressed", x===bn)); Ed.overlayT = performance.now()+1200; Ed.dirty = true; scheduleEd(); });
  $$("#edFilter button").forEach(bn=>bn.onclick=()=>{ Ed.e.filter = bn.dataset.filter; $$("#edFilter button").forEach(x=>x.setAttribute("aria-pressed", x===bn)); Ed.dirty = true; scheduleEd(); });
  $$("#edBW button").forEach(bn=>bn.onclick=()=>{ Ed.e.bw = +bn.dataset.bw; $$("#edBW button").forEach(x=>x.setAttribute("aria-pressed", x===bn)); Ed.dirty = true; scheduleEd(); });
  const lv = $("#edLevel"); if (lv) lv.onclick = ()=>{ Ed.e.angle = clamp(-Ed.rec.meta.roll, -15, 15); syncEdInputs(); Ed.overlayT = performance.now()+1500; Ed.dirty = true; scheduleEd(); };
  $$("#edPresets button").forEach(bn=>bn.onclick=()=>{
    const p = PRESETS.find(x=>x.id===bn.dataset.preset), d = defaultEdit();
    for (const k of TONE_KEYS) Ed.e[k] = p.e[k] !== undefined ? p.e[k] : d[k];
    Ed.e.preset = p.id; syncEdInputs(); Ed.dirty = true; scheduleEd();
  });
  drawPresetThumbs();
}
function syncEdInputs(){
  $$("#edside input[type=range]").forEach(inp=>{ const k = inp.dataset.k; inp.value = Ed.e[k]; const o = $("#edo_"+k); if (o) o.textContent = fmtFor(k)(Ed.e[k]); });
  $$("#edAspect button").forEach(x=>x.setAttribute("aria-pressed", x.dataset.aspect===Ed.e.aspect));
  $$("#edFilter button").forEach(x=>x.setAttribute("aria-pressed", x.dataset.filter===Ed.e.filter));
  $$("#edBW button").forEach(x=>x.setAttribute("aria-pressed", +x.dataset.bw===+Ed.e.bw));
  $$("#edPresets button").forEach(x=>x.setAttribute("aria-pressed", x.dataset.preset===Ed.e.preset));
}
function drawPresetThumbs(){
  const cs = $$("#edPresets canvas"); if (!cs.length) return;
  const d = defaultEdit();
  PRESETS.forEach((p,i)=>{ const e = Object.assign({}, d, p.e); const c = cs[i]; const x = c.getContext("2d"); x.drawImage(Ed.img, 0, 0, c.width, c.height); const id = x.getImageData(0,0,c.width,c.height); processPixels(id.data, c.width, c.height, e, null); x.putImageData(id,0,0); });
}

function scheduleEd(){ if (Ed.raf) return; Ed.raf = requestAnimationFrame(()=>{ Ed.raf = 0; renderEd(false); }); }
function renderEd(full){
  if (!Ed.img) return null;
  const e = Ed.comparing ? defaultEdit() : Ed.e;
  const g = editGeom(e, Ed.W, Ed.H);
  const k = full ? 1 : Math.min(1, 1100/Math.max(g.ow, g.oh));
  const cv = full ? document.createElement("canvas") : $("#edcanvas");
  const ow = Math.round(g.ow*k), oh = Math.round(g.oh*k);
  if (cv.width !== ow || cv.height !== oh){ cv.width = ow; cv.height = oh; }
  const x = cv.getContext("2d", { willReadFrequently:true });
  x.save(); x.fillStyle = "#000"; x.fillRect(0,0,ow,oh);
  x.imageSmoothingQuality = "high";
  x.translate(ow/2, oh/2); x.rotate(g.th); x.scale(g.sc*k, g.sc*k); x.translate(-g.cx, -g.cy);
  x.drawImage(Ed.img, 0, 0); x.restore();
  if (!Ed.comparing){
    const id = x.getImageData(0,0,ow,oh);
    let blur = null;
    if (e.clarity){ const s = document.createElement("canvas"); s.width = Math.max(2, ow>>4); s.height = Math.max(2, oh>>4); const sx = s.getContext("2d"); sx.drawImage(cv,0,0,s.width,s.height);
      const b2 = document.createElement("canvas"); b2.width = ow; b2.height = oh; const bx = b2.getContext("2d", { willReadFrequently:true }); bx.imageSmoothingQuality = "high"; bx.drawImage(s,0,0,ow,oh); blur = bx.getImageData(0,0,ow,oh).data; }
    processPixels(id.data, ow, oh, e, blur);
    x.putImageData(id, 0, 0);
  }
  if (!full) drawEdOverlay(cv);
  return cv;
}
const FILTERS = { none:[0.2126,0.7152,0.0722], red:[0.72,0.26,0.02], yellow:[0.45,0.5,0.05], green:[0.2,0.7,0.1], blue:[0.1,0.25,0.65] };
function hueRGB(h){ const f = n => { const k = (n + h/60)%6; return 1 - Math.max(0, Math.min(k, 4-k, 1)); }; return [f(5), f(3), f(1)]; }
function processPixels(d, w, h, e, blur){
  const lut = new Float32Array(256); const em = Math.pow(2, e.ex||0);
  for (let i=0;i<256;i++) lut[i] = Math.pow(Math.min(1, Math.pow(i/255, 2.2)*em), 1/2.2) + (em > 1 ? 0 : 0);

  if (em > 1) for (let i=0;i<256;i++){ const v = Math.pow(i/255,2.2)*em; lut[i] = Math.pow(v/(1+v*0.15)*1.15, 1/2.2); }
  const tr = 1 + (e.temp||0)*0.0045 + (e.tint||0)*0.001, tg = 1 - (e.tint||0)*0.004, tb = 1 - (e.temp||0)*0.0055 + (e.tint||0)*0.001;
  const con = 1 + (e.con||0)/100, hi = (e.hi||0)/100, sh = (e.sh||0)/100, sat = 1 + (e.sat||0)/100, vib = (e.vib||0)/100;
  const bw = !!e.bw, fw = FILTERS[e.filter] || FILTERS.none, fade = (e.fade||0)/100*0.3, vig = (e.vig||0)/100, grain = (e.grain||0)/100*0.16, clar = (e.clarity||0)/100*1.4;
  const split = (e.split||0)/100*0.22, hC = hueRGB(e.splitHue||30), sC = hueRGB(e.splitShHue||210);
  const cx = w/2, cy = h/2, rn = 1/(cx*cx+cy*cy);
  for (let y=0, i=0;y<h;y++){
    const dy = y-cy;
    for (let xx=0;xx<w;xx++, i+=4){
      let r = lut[d[i]]*tr, g = lut[d[i+1]]*tg, b = lut[d[i+2]]*tb;
      let l = 0.2126*r + 0.7152*g + 0.0722*b;
      if (hi || sh){
        const nl = l + sh*0.42*Math.pow(1-l,2)*l*2.2 + hi*0.38*l*l*(1-l)*2.4 + (hi<0? hi*0.12*Math.pow(l,4) : 0);
        const f = l > 0.004 ? nl/l : 1; r*=f; g*=f; b*=f; l = nl;
      }
      if (clar && blur){ const bl = (0.2126*blur[i] + 0.7152*blur[i+1] + 0.0722*blur[i+2])/255; const det = (Math.pow(l,1)-bl)*clar*(1-Math.abs(l-0.5)); r+=det; g+=det; b+=det; l+=det; }
      if (con !== 1){ r = (r-0.5)*con+0.5; g = (g-0.5)*con+0.5; b = (b-0.5)*con+0.5; l = (l-0.5)*con+0.5; }
      if (bw){ const m = r*fw[0] + g*fw[1] + b*fw[2]; r = g = b = m; l = m; }
      else if (sat !== 1 || vib){
        const mx = Math.max(r,g,b), mn = Math.min(r,g,b), cs = mx > 0.001 ? (mx-mn)/mx : 0;
        const s = sat + vib*(1-cs)*1.2; r = l + (r-l)*s; g = l + (g-l)*s; b = l + (b-l)*s;
      }
      if (split){ const a = split*l, c2 = split*(1-l)*0.9; r += (hC[0]-0.5)*a + (sC[0]-0.5)*c2; g += (hC[1]-0.5)*a + (sC[1]-0.5)*c2; b += (hC[2]-0.5)*a + (sC[2]-0.5)*c2; }
      if (fade){ r = fade + r*(1-fade*0.9); g = fade + g*(1-fade*0.9); b = fade + b*(1-fade*0.9); }
      if (vig){ const dx = xx-cx, q = (dx*dx+dy*dy)*rn; const f = 1 + vig*q*q*1.6 + vig*q*0.4; r*=f; g*=f; b*=f; }
      if (grain){ const n = (Math.random()+Math.random()+Math.random()-1.5)*grain*(0.6+Math.sin(Math.min(1,Math.max(0,l))*3.14)*0.6); r+=n; g+=n; b+=n; }
      d[i] = r*255; d[i+1] = g*255; d[i+2] = b*255;
    }
  }
}
function drawEdOverlay(cv){
  const ov = $("#edoverlay"), st = $("#edstage").getBoundingClientRect(), rc = cv.getBoundingClientRect();
  ov.style.left = (rc.left - st.left)+"px"; ov.style.top = (rc.top - st.top)+"px"; ov.style.width = rc.width+"px"; ov.style.height = rc.height+"px";
  ov.width = Math.round(rc.width); ov.height = Math.round(rc.height);
  const x = ov.getContext("2d"); x.clearRect(0,0,ov.width,ov.height);
  const show = performance.now() < Ed.overlayT;
  if (show){
    x.strokeStyle = "rgba(255,255,255,.45)"; x.lineWidth = 1;
    for (const f of [1/3,2/3]){ x.beginPath(); x.moveTo(ov.width*f,0); x.lineTo(ov.width*f,ov.height); x.stroke(); x.beginPath(); x.moveTo(0,ov.height*f); x.lineTo(ov.width,ov.height*f); x.stroke(); }
    x.strokeStyle = "rgba(232,163,61,.35)"; for (let i=1;i<12;i++){ x.beginPath(); x.moveTo(0, ov.height*i/12); x.lineTo(ov.width, ov.height*i/12); x.stroke(); }
    clearTimeout(Ed._ovT); Ed._ovT = setTimeout(()=>drawEdOverlay($("#edcanvas")), Ed.overlayT - performance.now() + 30);
  }
}
async function saveEdit(){
  if (!Ed.rec) return;
  const btn = $("#edSave"); btn.disabled = true; btn.textContent = "Developing…";
  await new Promise(r=>setTimeout(r, 30));
  const cv = renderEd(true);
  const blob = await new Promise(res => cv.toBlob(res, "image/jpeg", 0.9));
  const rec = Ed.rec;
  const isDefault = JSON.stringify(Object.assign(defaultEdit(), Ed.e, {preset:"none"})) === JSON.stringify(Object.assign(defaultEdit(), {preset:"none"}));
  if (isDefault){ rec.edited = null; rec.edit = null; rec.editStats = null; rec.editedThumb = null; }
  else { rec.edited = blob; rec.edit = Object.assign({}, Ed.e); rec.editStats = imageStats(cv); rec.editedThumb = makeThumb(cv); }
  const res = judgePhoto(rec, rec.editStats || rec.meta.stats);
  const prev = rec.score;
  const pay = applyJudgement(rec, res);
  await DB.put(rec);
  btn.disabled = false; btn.textContent = "Save and judge";
  $("#editor").classList.add("hidden"); if (Ed.img && Ed.img.close) Ed.img.close(); Ed.img = null; Ed.rec = null;
  await openGallery(); openLightbox(rec.id, { prev, pay });
}
function initEditorEvents(){
  $("#edSave").onclick = saveEdit;
  $("#edCancel").onclick = () => { if (Ed.dirty && !confirm("Discard your darkroom changes?")) return; closeEditor(); };
  $("#edReset").onclick = () => { Ed.e = defaultEdit(); syncEdInputs(); Ed.dirty = true; scheduleEd(); };
  const bf = $("#edBefore");
  const on = ev => { ev.preventDefault(); Ed.comparing = true; bf.setAttribute("aria-pressed","true"); scheduleEd(); };
  const off = () => { if (!Ed.comparing) return; Ed.comparing = false; bf.setAttribute("aria-pressed","false"); scheduleEd(); };
  bf.addEventListener("pointerdown", on); addEventListener("pointerup", off); bf.addEventListener("pointerleave", off);
  bf.addEventListener("keydown", ev=>{ if (ev.key===" "||ev.key==="Enter") on(ev); }); bf.addEventListener("keyup", off);

  const cv = $("#edcanvas"); let drag = null;
  cv.addEventListener("pointerdown", ev=>{ if (!Ed.rec) return; drag = { x:ev.clientX, y:ev.clientY, px:Ed.e.panX, py:Ed.e.panY }; cv.setPointerCapture(ev.pointerId); Ed.overlayT = performance.now()+100000; });
  cv.addEventListener("pointermove", ev=>{ if (!drag) return; const rc = cv.getBoundingClientRect(); const z = Math.max(0.2, (Ed.e.zoom||1)-1);
    Ed.e.panX = clamp(drag.px - (ev.clientX-drag.x)/rc.width*2/z, -1, 1); Ed.e.panY = clamp(drag.py - (ev.clientY-drag.y)/rc.height*2/z, -1, 1);
    const a = $("#ed_panX"), b = $("#ed_panY"); if (a){ a.value = Ed.e.panX; $("#edo_panX").textContent = Ed.e.panX.toFixed(2); } if (b){ b.value = Ed.e.panY; $("#edo_panY").textContent = Ed.e.panY.toFixed(2); }
    Ed.dirty = true; scheduleEd(); });
  const end = ()=>{ if (drag){ drag = null; Ed.overlayT = performance.now()+800; scheduleEd(); } };
  cv.addEventListener("pointerup", end); cv.addEventListener("pointercancel", end);
  cv.addEventListener("wheel", ev=>{ if (!Ed.rec) return; ev.preventDefault(); Ed.e.zoom = clamp((Ed.e.zoom||1) * Math.exp(-ev.deltaY*0.0012), 1, 3); const z = $("#ed_zoom"); if (z){ z.value = Ed.e.zoom; $("#edo_zoom").textContent = FMT.zoom(Ed.e.zoom); } Ed.overlayT = performance.now()+900; Ed.dirty = true; scheduleEd(); }, { passive:false });
  addEventListener("resize", ()=>{ if (Ed.rec) scheduleEd(); });
}

Object.assign(V7_DEFAULTS, { tJoy:"medium", tButtons:"large", tHanded:"right", tHaptics:"on", tLook:"normal" });
const TOUCH = { joy:null, look:null, el:{} };
function isTouch(){ return !!Input.touch; }
function buildTouchUI(){
  if (!isTouch() || $("#tpad")) return;
  document.body.classList.add("touch");
  const vp = document.querySelector('meta[name="viewport"]'); if (vp) vp.content = "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover";
  if (!S.custom._touchInit){ S.custom._touchInit = 1; S.custom.renderQuality = "performance"; applyGraphicsQuality(); saveState(); }
  const d = document.createElement("div"); d.id = "tpad"; d.className = "layer";
  d.innerHTML = `
    <div id="tzoneL"></div><div id="tzoneR"></div>
    <div id="tjoy"><i></i><b></b></div>
    <button class="tb big" id="tbShoot" aria-label="Shutter"><span></span></button>
    <button class="tb" id="tbRaise"><em>◉</em><small>Raise</small></button>
    <button class="tb" id="tbJump"><em>⤒</em><small>Jump</small></button>
    <button class="tb" id="tbRun"><em>»</em><small>Run</small></button>
    <button class="tb act" id="tbAct"><em>↵</em><small>Enter</small></button>
    <button class="tb warn" id="tbWind"><em>⟳</em><small>Wind</small></button>
    <button class="tb top" id="tbDial"><em>⚙</em><small class="dialread">f/— · —</small></button>
    <button class="tb top" id="tbBag"><em>☰</em><small>Bag</small></button>
    <button class="tb top" id="tbPhotos"><em>▦</em><small>Photos</small></button>
    <div id="tportrait"><div>↻</div><p>Turn your phone sideways for the best view.</p><button class="btn small">Keep playing</button></div>`;
  document.body.appendChild(d); const $t = id => d.querySelector(id);
  const tap = (id, fn) => { const b = $t(id); b.addEventListener("pointerdown", ev => { ev.preventDefault(); ev.stopPropagation(); Audio.init(); b.classList.add("down"); fn(ev); haptic(12); }); const up = () => b.classList.remove("down"); b.addEventListener("pointerup", up); b.addEventListener("pointercancel", up); b.addEventListener("pointerleave", up); };
  tap("#tbShoot", () => { if (Player.raise < 0.5 && !Input.touchRaise){ Input.touchRaise = true; return; } captureShot().then(r => { if (r) haptic([18, 30, 12]); }); });
  tap("#tbRaise", () => { Input.touchRaise = !Input.touchRaise; });
  tap("#tbJump", () => jump());
  tap("#tbRun", () => { TOUCH.run = !TOUCH.run; Input.keys.ShiftLeft = TOUCH.run; });
  tap("#tbAct", () => enterAction());
  tap("#tbWind", () => windOn());
  tap("#tbDial", () => document.body.classList.toggle("dialOpen"));
  tap("#tbBag", () => openMenu("gear"));
  tap("#tbPhotos", () => openGallery ? openGallery() : null);
  $t("#tportrait button").onclick = () => { TOUCH.portraitOk = true; $t("#tportrait").classList.remove("on"); };

  const zl = $t("#tzoneL"), zr = $t("#tzoneR"), joy = $t("#tjoy"), knob = joy.querySelector("b");
  const R = () => ({ small:48, medium:62, large:78 })[S.custom.tJoy] || 62;
  zl.addEventListener("pointerdown", ev => { ev.preventDefault(); Audio.init(); zl.setPointerCapture(ev.pointerId); TOUCH.joy = { id:ev.pointerId, x:ev.clientX, y:ev.clientY }; const r = R(); joy.style.width = joy.style.height = r*2 + "px"; joy.style.left = (ev.clientX - r) + "px"; joy.style.top = (ev.clientY - r) + "px"; joy.classList.add("on"); knob.style.transform = "translate(-50%,-50%)"; });
  zl.addEventListener("pointermove", ev => { const j = TOUCH.joy; if (!j || ev.pointerId !== j.id) return; const r = R(); let dx = (ev.clientX - j.x)/r, dy = (ev.clientY - j.y)/r; const l = Math.hypot(dx, dy); if (l > 1){ dx /= l; dy /= l; }
    const dead = 0.12, k = l < dead ? 0 : Math.min(1, (l - dead)/(1 - dead))/Math.max(l, 1e-6); Input.joy.x = dx*k*Math.min(l,1); Input.joy.y = dy*k*Math.min(l,1); knob.style.transform = `translate(calc(-50% + ${dx*r}px), calc(-50% + ${dy*r}px))`;
    if (l > 0.98 && !TOUCH.run) Input.keys.ShiftLeft = true; else if (!TOUCH.run) Input.keys.ShiftLeft = false; });
  const joyEnd = ev => { const j = TOUCH.joy; if (!j || ev.pointerId !== j.id) return; TOUCH.joy = null; Input.joy.x = Input.joy.y = 0; if (!TOUCH.run) Input.keys.ShiftLeft = false; joy.classList.remove("on"); };
  zl.addEventListener("pointerup", joyEnd); zl.addEventListener("pointercancel", joyEnd);

  zr.addEventListener("pointerdown", ev => { ev.preventDefault(); Audio.init(); zr.setPointerCapture(ev.pointerId); TOUCH.look = { id:ev.pointerId, x:ev.clientX, y:ev.clientY, t:performance.now(), moved:0 }; });
  zr.addEventListener("pointermove", ev => { const L = TOUCH.look; if (!L || ev.pointerId !== L.id) return; const k = (({ low:0.0032, normal:0.0052, high:0.0082 })[S.custom.tLook] || 0.0052)*(G.cam.fov/EYE_FOV);
    const dx = ev.clientX - L.x, dy = ev.clientY - L.y; L.moved += Math.abs(dx) + Math.abs(dy); look(dx*k, dy*k); L.x = ev.clientX; L.y = ev.clientY; });
  const lookEnd = ev => { const L = TOUCH.look; if (!L || ev.pointerId !== L.id) return; TOUCH.look = null; if (L.moved < 8 && performance.now() - L.t < 250 && Player.raise > 0.5){ const fk = focusKind(); if (fk === "rf" || fk === "mf") Cam.mfTarget = clamp(Cam.afTarget, 0.5, 120); } };
  zr.addEventListener("pointerup", lookEnd); zr.addEventListener("pointercancel", lookEnd);
  const old = $("#touch"); if (old) old.style.display = "none";
  applyTouchLayout();
}
function haptic(p){ try { if (S.custom.tHaptics !== "off" && navigator.vibrate) navigator.vibrate(p); } catch(e){} }
function applyTouchLayout(){ const b = document.body; b.classList.toggle("tLeft", S.custom.tHanded === "left"); b.classList.toggle("tBig", S.custom.tButtons === "large"); b.classList.toggle("tHuge", S.custom.tButtons === "huge"); }
function updateTouchUI(){
  const d = $("#tpad"); if (!d) return; const show = Game.started && !UI.open && !(typeof Ed !== "undefined" && Ed.rec && !$("#editor").classList.contains("hidden")) && $("#lightbox").classList.contains("hidden");
  d.style.display = show ? "" : "none"; if (!show) return;
  const $t = id => d.querySelector(id), raised = Player.raise > 0.5 || Input.touchRaise;
  $t("#tbRaise small").textContent = Input.touchRaise ? "Lower" : "Raise"; $t("#tbRaise").classList.toggle("on", !!Input.touchRaise);
  $t("#tbRun").classList.toggle("on", !!TOUCH.run); $t("#tbShoot").classList.toggle("ready", raised);
  const needWind = advanceMode() === "manual" && !isCocked(); $t("#tbWind").style.display = needWind ? "" : "none";
  TOUCH.actT = (TOUCH.actT || 0) - 0.1; if (TOUCH.actT <= 0){ TOUCH.actT = 0.4; let lab = null;
    if (ZONE.mode) lab = ZONE.mode === "roof" ? "Climb down" : "Step out"; else if (GP.ride) lab = "Get off";
    else { for (const { v, kind } of rideTargets()) if (Math.hypot(Player.x - v.x, Player.z - v.z) < (kind === "bus" ? 7 : 6)) lab = v.trolley ? "Ride trolley" : kind === "bus" ? "Board bus" : "Ride cable car";
      if (!lab && nearestShop()) lab = "Enter shop"; if (!lab && nearestRoof()) lab = "Climb up"; }
    const a = $t("#tbAct"); a.style.display = lab ? "" : "none"; if (lab) a.querySelector("small").textContent = lab; }
  const e = Cam.exp; if (e) $t(".dialread").textContent = `${fmtA(e.N)} · ${fmtShutter(e.t)}`;
  const portrait = innerHeight > innerWidth*1.05; $t("#tportrait").classList.toggle("on", portrait && !TOUCH.portraitOk);
}
(function(){ const base = gameplayUpdate; gameplayUpdate = function(dt){ base(dt); if (isTouch()) updateTouchUI(); }; })();
(function(){ const base = boot; boot = async function(){ await base(); buildTouchUI(); }; })();
(function(){ const base = renderMenu; renderMenu = function(...a){ const r = base(...a); if (isTouch()) applyTouchLayout(); return r; }; })();
(function(){ const base = menuSettings; menuSettings = function(){ const c = S.custom, seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  return `<div class="sectionhead">Touch controls</div>
    <div class="formrow"><label>Button size</label>${seg("tButtons",[["normal","Normal"],["large","Large"],["huge","Huge"]])}</div>
    <div class="formrow"><label>Joystick size</label>${seg("tJoy",[["small","Small"],["medium","Medium"],["large","Large"]])}<span class="spec">Put your thumb down anywhere on the left side to walk. Push to the edge to run.</span></div>
    <div class="formrow"><label>Swipe to look</label>${seg("tLook",[["low","Slow"],["normal","Normal"],["high","Fast"]])}<span class="spec">A quick tap on the right side focuses manual cameras on the centre of the frame.</span></div>
    <div class="formrow"><label>Layout</label>${seg("tHanded",[["right","Shutter on the right"],["left","Shutter on the left"]])}</div>
    <div class="formrow"><label>Vibration</label>${seg("tHaptics",[["on","On"],["off","Off"]])}</div>` + base(); }; })();
document.addEventListener("pointerdown", ev => { if (!document.body.classList.contains("dialOpen")) return; if (ev.target.closest && (ev.target.closest("#quickDial") || ev.target.closest("#tbDial"))) return; document.body.classList.remove("dialOpen"); }, true);

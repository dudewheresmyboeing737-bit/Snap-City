(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const V = SC.v51 = { built: false, groups: [], players: [], balls: [], folk: [], skaters: [], ducks: [], discs: [], sweepers: [], crews: [] };
  const rnd = (a, b) => a + Math.random() * (b - a), pick = a => a[(Math.random() * a.length) | 0];
  const mats = {}; const m = (c, r, mt, em) => mats[[c, r, mt, em].join("|")] || (mats[[c, r, mt, em].join("|")] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: r ?? .7, metalness: mt || 0, emissive: em ? lin(c) : 0x000000, emissiveIntensity: em || 0 }));
  const BOX = new THREE.BoxGeometry(1,1,1), CYL = new THREE.CylinderGeometry(.5,.5,1,12), SPH = new THREE.SphereGeometry(.5,12,8);
  const part = (g, geo, mm, x, y, z, sx, sy, sz) => { const o = new THREE.Mesh(geo, mm); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; g.add(o); return o; };
  const gy = (x, z) => { try{ return groundY(x, z); }catch(e){ return H(x, z) + .16; } };
  const custom = k => (typeof S !== "undefined" && S && S.custom) ? S.custom[k] : undefined;
  const raining = () => typeof S !== "undefined" && S && (S.rain || S.storm || S.snow);
  const person = (seed, seated) => SC.makePerson ? SC.makePerson(seed | 0, !!seated) : null;
  function place(root, p, x, z, face){ p.g.position.set(x, gy(x, z), z); p.g.rotation.y = face || 0; root.add(p.g); return p; }
  function newRoot(cx, cz){ const g = new THREE.Group(); G.scene.add(g); V.groups.push({ g, cx, cz }); return g; }

  function migrate(s){
    if (!s || !s.custom) return s;
    const c = s.custom;
    if (!c._sc51){ Object.assign(c, { cloudLife: "some", graphicsEnhance: "on", livingSky: "on", wetStreets: "on", streetDetail: "obsessive", fogPref: "random", windPref: "random" }); c._sc51 = 1; }
    if (!c.fogPref) c.fogPref = "random"; if (!c.windPref) c.windPref = "random";
    return s;
  }
  if (typeof defaultState === "function"){ const b = defaultState; window.defaultState = function(){ return migrate(b.apply(this, arguments)); }; }
  if (typeof loadState === "function"){ const b = loadState; window.loadState = function(){ return migrate(b.apply(this, arguments)); }; }
  function rollAtmos(){
    if (typeof S === "undefined" || !S) return; migrate(S);
    S.custom.fogAmount = S.custom.fogPref === "random" ? pick(["thin","normal","normal","thick"]) : S.custom.fogPref;
    S.custom.windStrength = S.custom.windPref === "random" ? pick(["calm","breezy","breezy","gale"]) : S.custom.windPref;
    S.custom.windDrama = ({ calm: "subtle", breezy: "natural", gale: "gusty" })[S.custom.windStrength] || "natural";
    try{ applyTime(); }catch(e){}
  }
  if (typeof startGame === "function"){ const b = startGame; window.startGame = function(){ const r = b.apply(this, arguments); try{ rollAtmos(); }catch(e){} return r; }; }

  if (typeof leaveZone === "function"){
    const base = leaveZone;
    window.leaveZone = function(){
      try{
        if (ZONE.mode === "roof" && ZONE.box){
          const b = ZONE.box, r = (World.roofs || []).find(o => Math.abs(o.x - b.x) < .01 && Math.abs(o.z - b.z) < .01);
          if (r && r.n){ let bx = r.fx + r.n[0] * 2.4, bz = r.fz + r.n[1] * 2.4; try{ const c = collidePoint(bx, bz, .4); bx = c[0]; bz = c[1]; }catch(e){} ZONE.back = { x: bx, z: bz }; }
        }
      }catch(e){}
      return base.apply(this, arguments);
    };
  }

  const DRY_ONLY = new Set(["sc_chalk","sc_yoga","sc_kite","sc_breakdance","sc_bake_sale","sc_street_food","sc_fashion","sc_gallery","sc_parade","sc_market_day","sc_open_mic","sc_sketch","sc_chess","sc_fortune","sc_selfie","sc_graduation","sc_newlyweds","sc_busker_duo","sc_film_crew","sc_mime","sc_birthday","sc_flower_cart"]);
  const WET_OK = ["sc_rain_dash","sc_argument","sc_delivery","sc_reunion","sc_lost_dog","sc_proposal"];
  function hookStories(){
    if (!SC.startStory || SC.startStory._wx) return;
    const base = SC.startStory;
    SC.startStory = function(id){
      const wet = raining();
      if (wet && DRY_ONLY.has(id)) id = pick(WET_OK);
      if (!wet && id === "sc_rain_dash") return null;
      return base.call(this, id);
    };
    SC.startStory._wx = true;
  }

  function court(c){
    const root = newRoot(c.x, c.z);
    if (c.kind === "basketball"){
      const team = [pick(["#c0362c","#2f7fc1","#e8b82e"]), pick(["#f2efe6","#1a1a1a","#3aa06b"])], n = 4 + ((Math.random() * 3) | 0), players = [];
      for (let k = 0; k < n; k++){ const p = person(c.x * 31 + k * 7, false); place(root, p, c.x + rnd(-5, 5), c.z + rnd(-10, 10)); part(p.g, BOX, m(team[k % 2], .7), 0, p.head.position.y - .5, 0, .4, .45, .24); players.push(Object.assign(p, { tx: p.g.position.x, tz: p.g.position.z, sp: rnd(2.5, 4) })); }
      const ball = part(root, SPH, m("#e36f2d", .6), c.x, gy(c.x, c.z) + 1, c.z, .24, .24, .24);
      V.balls.push({ kind: "basket", ball, players, holder: 0, t: 0, cx: c.x, cz: c.z, shot: null });
      for (let k = 0; k < 6; k++){ const p = person(c.x * 7 + k, true); place(root, p, c.x + rnd(-5, 5), c.z - 14.7 - (k % 3) * .6, 0); p.g.position.y += .35 + (k % 3) * .35; V.folk.push(Object.assign(p, { act: pick(["cheer","clap","watch","eat"]) })); }
    } else {
      const a = person(c.x * 13, false), b = person(c.z * 17 + 3, false);
      place(root, a, c.x, c.z - 11, 0); place(root, b, c.x, c.z + 11, Math.PI);
      for (const p of [a, b]) part(p.armR, BOX, m("#1a1a1a", .5), 0, -.62, .1, .06, .06, .5);
      const ball = part(root, SPH, m("#d9e84a", .5), c.x, gy(c.x, c.z) + 1, c.z, .09, .09, .09);
      V.balls.push({ kind: "tennis", ball, players: [a, b], t: 0, cx: c.x, cz: c.z, dir: 1 });
      for (let k = 0; k < 3; k++){ const p = person(c.z * 5 + k, false); place(root, p, c.x + 7.5, c.z + (k - 1) * 3, -Math.PI / 2); V.folk.push(Object.assign(p, { act: "watchTennis" })); }
    }
  }
  function vendor(root, x, z, kind){
    const g = new THREE.Group(); g.position.set(x, gy(x, z), z); root.add(g);
    part(g, BOX, m("#c9ccd0", .3, .6), 0, .75, 0, 1.6, .9, .8); for (const s of [-1, 1]){ const w = part(g, CYL, m("#1a1a1a", .9), s * .55, .25, .45, .5, .1, .5); w.rotation.x = Math.PI / 2; }
    part(g, CYL, m(kind === "icecream" ? "#f28cb1" : pick(["#e8b82e","#c0362c","#2f7fc1"]), .7), 0, 2.1, 0, 2.2, .1, 2.2); part(g, CYL, m("#2b2b2b"), 0, 1.6, 0, .06, 1.2, .06);
    const v = person(x * 3, false); v.g.position.set(0, 0, -.9); g.add(v.g); V.folk.push(Object.assign(v, { act: "vendor" }));
    for (let k = 0; k < 1 + ((Math.random() * 3) | 0); k++){ const p = person(x * 11 + k, false); p.g.position.set(rnd(-.3, .3), 0, 1.3 + k * .85); p.g.rotation.y = Math.PI; g.add(p.g); V.folk.push(Object.assign(p, { act: k ? pick(["phone","talk","wait"]) : "order" })); }
    try{ World.colliders.push({ x0: x - 1, x1: x + 1, z0: z - .6, z1: z + .6 }); }catch(e){}
  }
  function park(sp){
    const root = newRoot(sp.cx, sp.cz), cx = sp.cx, cz = sp.cz;
    for (let k = 0; k < 3; k++){ const x = cx + rnd(-26, 26), z = cz + (Math.random() < .5 ? -1 : 1) * rnd(8, 28); const bl = part(root, BOX, m(pick(["#c0362c","#2f7fc1","#e8b82e","#f2efe6"]), .9), x, gy(x, z) + .04, z, 2.2, .02, 1.8);
      for (let q = 0; q < 2 + (k % 2); q++){ const p = person(x * 7 + q, true); place(root, p, x - .6 + q * .7, z + (q % 2 ? .4 : -.4), q % 2 ? Math.PI : 0); p.g.position.y -= .35; V.folk.push(Object.assign(p, { act: pick(["eat","talk","read","laugh"]) })); }
      part(root, BOX, m("#8a6a44", .8), x, gy(x, z) + .15, z, .45, .25, .3); }
    const fx = cx + rnd(-10, 10), fz = cz + rnd(-28, -16), a = person(fx * 3, false), b = person(fz * 5, false);
    place(root, a, fx - 6, fz, Math.PI / 2); place(root, b, fx + 6, fz, -Math.PI / 2);
    V.discs.push({ disc: part(root, CYL, m("#e36f2d", .5), fx, gy(fx, fz) + 1.3, fz, .28, .03, .28), a, b, t: 0 });
    const pond = (World.ponds || []).find(p => Math.abs(p.x - cx) < 40 && Math.abs(p.z - cz) < 40);
    if (pond){ for (let k = 0; k < 5; k++){ const d = new THREE.Group(); part(d, SPH, m("#f2efe6", .6), 0, 0, 0, .35, .22, .5); part(d, SPH, m("#3a7a3a", .6), 0, .18, .22, .16, .16, .16); d.position.set(pond.x + rnd(-5, 5), gy(pond.x, pond.z) + .2, pond.z + rnd(-3, 3)); root.add(d); V.ducks.push({ d, px: pond.x, pz: pond.z, a: Math.random() * 6, r: rnd(1.5, 5) }); }
      const f = person(pond.x * 9, false); place(root, f, pond.x, pond.z + 6.2, Math.PI); V.folk.push(Object.assign(f, { act: "feed" })); }
    for (let k = 0; k < 4; k++){ const kid = person(cx * 5 + k, false); kid.g.scale.multiplyScalar(.62); place(root, kid, cx + rnd(-24, 24), cz + rnd(-24, 24)); V.folk.push(Object.assign(kid, { act: "play", home: { x: kid.g.position.x, z: kid.g.position.z }, root })); }
    const j = person(cx + 99, false); place(root, j, cx, cz); V.folk.push(Object.assign(j, { act: "jog", loop: { cx, cz, r: 30 }, u: Math.random() * 6 }));
    vendor(root, cx + 30, cz + (Math.random() < .5 ? -30 : 30), "hotdog");
  }
  function plaza(sp){
    const root = newRoot(sp.cx, sp.cz), cx = sp.cx, cz = sp.cz;
    for (let k = 0; k < 6; k++){ const p = person(cx * 3 + k, false); place(root, p, cx - 14 + (k % 3) * 2.2, cz + 14 + ((k / 3) | 0) * 2.2, 0); V.folk.push(Object.assign(p, { act: "taichi" })); }
    const tx = cx + 14, tz = cz + 14; part(root, BOX, m("#8a8680"), tx, gy(tx, tz) + .38, tz, 1, .76, 1); part(root, BOX, m("#f2efe6"), tx, gy(tx, tz) + .77, tz, .6, .02, .6);
    for (const s of [-1, 1]){ const p = person(tx * s, true); place(root, p, tx + s * .9, tz, s > 0 ? -Math.PI / 2 : Math.PI / 2); V.folk.push(Object.assign(p, { act: "chess" })); }
    const mus = person(cx * 17, false); place(root, mus, cx - 16, cz - 12, 0); part(mus.g, BOX, m("#8a5a2a"), .05, .95, .25, .34, .12, .5).rotation.z = .9; V.folk.push(Object.assign(mus, { act: "guitar" }));
    for (let k = 0; k < 4; k++){ const p = person(cx * 19 + k, false); place(root, p, cx - 16 + Math.cos(k) * 2.6, cz - 12 + 2.4 + Math.sin(k) * .6, Math.PI); V.folk.push(Object.assign(p, { act: pick(["clap","watch","phone"]) })); }
    vendor(root, cx + 24, cz - 8, "icecream");
  }
  function skatepark(sp){
    const root = newRoot(sp.cx, sp.cz), cx = sp.cx, cz = sp.cz;
    for (let k = 0; k < 5; k++){ const p = person(cx * 23 + k, false); const board = part(p.g, BOX, m(pick(["#c0362c","#1a1a1a","#e8b82e"]), .5), 0, .06, 0, .25, .04, .8); place(root, p, cx, cz); p.armL.rotation.z = .9; p.armR.rotation.z = -.9;
      V.skaters.push({ p, board, cx, cz, a: Math.random() * 6, r: rnd(8, 20), sp: rnd(.25, .45) * (Math.random() < .5 ? 1 : -1), hop: Math.random() * 6 }); }
    for (let k = 0; k < 5; k++){ const p = person(cx * 29 + k, false); place(root, p, cx - 20 + k * 2, cz + 26, Math.PI); V.folk.push(Object.assign(p, { act: pick(["cheer","phone","watch"]) })); }
  }
  function castle(sp){
    const root = newRoot(sp.cx, sp.cz), cx = sp.cx, cz = sp.cz;
    for (let k = 0; k < 6; k++){ const p = person(cx * 31 + k, false); place(root, p, cx + rnd(-18, 18), cz + rnd(-18, 18), Math.random() * 6); part(p.armR, BOX, m("#1a1a1a", .4), 0, -.55, .08, .14, .1, .1); V.folk.push(Object.assign(p, { act: pick(["photo","photo","point","walk"]), home: { x: p.g.position.x, z: p.g.position.z }, root })); }
    const guard = person(cx * 37, false); place(root, guard, cx, cz + (HALF - 6) + 1.2, 0); part(guard.head, CYL, m("#9aa0a6", .4, .6), 0, .08, 0, .34, .3, .34); part(guard.g, BOX, m("#b8bcc0", .4, .6), 0, guard.head.position.y - .5, 0, .46, .5, .3); part(guard.armR, BOX, m("#d9dde0", .3, .7), 0, -.2, .15, .04, 1.4, .04); V.folk.push(Object.assign(guard, { act: "guard" }));
  }
  function quietPlace(sp){
    const root = newRoot(sp.cx, sp.cz), cx = sp.cx, cz = sp.cz;
    if (sp.kind === "library"){ for (let k = 0; k < 5; k++){ const p = person(cx * 41 + k, true); place(root, p, cx + rnd(-28, 28), cz + (Math.random() < .5 ? -1 : 1) * rnd(12, 28), Math.random() * 6); p.g.position.y -= .35; V.folk.push(Object.assign(p, { act: "read" })); } }
    if (sp.kind === "cemetery"){ const a = person(cx * 43, false); place(root, a, cx + 8, cz + 6, Math.PI); part(a.armR, SPH, m("#c0362c", .6), 0, -.55, .1, .2, .2, .2); V.folk.push(Object.assign(a, { act: "mourn" }));
      const gd = person(cx * 47, false); place(root, gd, cx - 14, cz - 10, 1); part(gd.armR, CYL, m("#6b4a2e"), 0, -.6, .3, .03, 1.4, .03).rotation.x = 1.1; V.folk.push(Object.assign(gd, { act: "rake" })); }
    if (sp.kind === "sports"){ vendor(root, cx - 30, cz - 26, "hotdog"); }
  }

  function fireEscapes(){
    const roofs = (World.roofs || []).filter(r => r.n && r.top && Math.abs(r.x) < (NB + .5) * P && Math.abs(r.z) < (NB + .5) * P);
    const plat = [], rail = [], stair = [], ladder = [], MM = new THREE.Matrix4(), Q = new THREE.Quaternion(), E = new THREE.Euler(), Vv = new THREE.Vector3(), Sv = new THREE.Vector3();
    const push = (list, x, y, z, sx, sy, sz, ry, rx) => { E.set(rx || 0, ry, 0, "YXZ"); Q.setFromEuler(E); list.push(MM.compose(Vv.set(x, y, z), Q, Sv.set(sx, sy, sz)).clone()); };
    let n = 0;
    for (const r of roofs){
      let zone = ""; try{ zone = zoneOf(Math.round(r.x / P), Math.round(r.z / P)); }catch(e){}
      const base = H(r.fx, r.fz) + .16, floors = Math.floor((r.top - base - 4.4) / 3.2);
      if (zone === "vic" || floors < 2 || r.top - base > 30 || Math.random() > .3 || n > 50) continue;
      n++;
      const t = [r.n[1], -r.n[0]], ry = Math.atan2(r.n[0], r.n[1]), along = (Math.random() < .5 ? -1 : 1) * Math.max(0, (r.w || 8) / 2 - 2.2);
      const at = (a, out) => [r.fx + t[0] * a + r.n[0] * out, r.fz + t[1] * a + r.n[1] * out];
      for (let f = 1; f <= floors; f++){
        const y = base + 4.4 + (f - 1) * 3.2, [px, pz] = at(along, .6);
        push(plat, px, y, pz, 2.8, .06, 1.1, ry);
        SC.traversal?.addPlatform({x:px,z:pz,w:2.8,d:1.1,ry,bottom:y-.03,top:y+.03});
        const [rx, rz] = at(along, 1.12); push(rail, rx, y + .5, rz, 2.8, .04, .04, ry);
        for (const e of [-1, 1]){ const [ex, ez] = at(along + e * 1.4, .6); push(rail, ex, y + .5, ez, .04, .04, 1.1, ry); }
        for (let b = 0; b < 7; b++){ const [bx, bz] = at(along - 1.35 + b * .45, 1.12); push(rail, bx, y + .25, bz, .025, .5, .025, ry); }
        if (f < floors){ const [sx, sz] = at(along, .85); push(stair, sx, y + 1.6, sz, .7, .04, 3.6, ry + Math.PI / 2, (f % 2 ? 1 : -1) * .72); }
      }
      const [lx, lz] = at(along + 1.1, 1.0); push(ladder, lx, base + 3.2, lz, .45, 2.2, .04, ry);
      try{ const [cx, cz] = at(along, .6); World.colliders.push({ x0: cx - .2, x1: cx + .2, z0: cz - .2, z1: cz + .2, pole: true }); }catch(e){}
    }
    const inst = (list, mm) => { if (!list.length) return; const im = new THREE.InstancedMesh(BOX, mm, list.length); list.forEach((mt, i) => im.setMatrixAt(i, mt)); im.castShadow = true; G.scene.add(im); };
    const iron = m("#2b2f33", .6, .5);
    inst(plat, iron); inst(rail, iron); inst(stair, iron); inst(ladder, iron);
  }

  function crews(){
    const trucks = ((SC.z48 && SC.z48.veh) || []).filter(v => v.kind === "garbage");
    for (const v of trucks){ for (const s of [-1, 1]){ const p = person(Math.random() * 1e5, false); p.g.position.set(s * .7, .5, -4.1); p.g.rotation.y = Math.PI; v.g.add(p.g); part(p.g, BOX, m("#ff7a1a", .6, 0, .15), 0, p.head.position.y - .5, 0, .42, .42, .26); p.armL.rotation.x = p.armR.rotation.x = -1.4; V.crews.push({ p, v, s }); }
      part(v.g, BOX, m("#2b2f33", .6, .5), 0, .45, -4.0, 2.2, .08, .5); }
    if (!Life.cars.length) return;
    const streets = [...new Set(Life.cars.filter(c => !c.bus).map(c => Math.round((c.z - c.lane * 1.3) / P - .5)))].map(i => (i + .5) * P);
    const tail = new THREE.MeshStandardMaterial({ color: lin("#6a1414"), emissive: lin("#ff2a1a"), emissiveIntensity: 0 });
    for (let k = 0; k < 2 && streets.length; k++){
      const g = new THREE.Group(), body = m(pick(["#f2efe6","#e8b82e","#2f6b4a"]), .5, .2);
      part(g, BOX, body, 0, 1.3, .6, 2.1, 1.8, 3.2); part(g, BOX, m("#1b2430", .1, .4), 0, 1.7, 2.22, 1.9, .7, .05); part(g, BOX, body, 0, 1.0, -1.8, 2.0, 1.2, 1.8);
      part(g, SPH, m("#ff9a2e", .4, 0, 1.4), 0, 2.3, .6, .25, .2, .25);
      for (const s of [-1, 1]){ const w = part(g, CYL, m("#141414", .9), s * 1, .45, 1.2, .9, .3, .9); w.rotation.z = Math.PI / 2; const w2 = part(g, CYL, m("#141414", .9), s * 1, .45, -1.6, .9, .3, .9); w2.rotation.z = Math.PI / 2; }
      const brushes = []; for (const s of [-1, 1]){ const b = part(g, CYL, m("#c9a24a", .9), s * .95, .12, 2.35, .7, .08, .7); brushes.push(b); }
      if (SC.makePerson){ const d = person(Math.random() * 1e5, true); d.g.position.set(-.45, .7, .7); d.armL.rotation.x = d.armR.rotation.x = -1.1; g.add(d.g); }
      const lane = Math.random() < .5 ? 1 : -1, z = pick(streets) + lane * 1.3; let x = rnd(-300, 300), tries = 0;
      while (tries++ < 30 && Life.cars.some(o => Math.abs(o.z - z) < 1.8 && Math.abs(o.x - x) < ((o.len || 5) + 5) / 2 + 3)) x = rnd(-300, 300);
      G.scene.add(g);
      const c = { type: "car", special: "sweeper", len: 5.2, width: 2.2, tailMat: tail, g, lane, z, x, speed: 0, vmax: 2.6, heading: lane > 0 ? Math.PI / 2 : -Math.PI / 2, color: 0 };
      Life.cars.push(c); V.sweepers.push({ g, brushes, c });
    }
  }

  function tidyMenu(body){
    body.querySelectorAll("button").forEach(b => { if (/Restore visual defaults/i.test(b.textContent)){ const row = b.closest(".formrow,.sc-setting"); (row || b).remove(); } });
    body.querySelectorAll("[data-seg='fogAmount'],[data-seg='windStrength']").forEach(el => { const row = el.closest(".formrow,.sc-setting"); if (row) row.remove(); });
    body.querySelectorAll("details.sc-settings-section").forEach(d => { const n = d.querySelectorAll(".formrow,.sc-setting").length, sm = d.querySelector("summary small"); if (!n) d.remove(); else if (sm) sm.textContent = n; });
  }
  if (typeof menuSettings === "function"){
    const base = menuSettings;
    window.menuSettings = function(){
      migrate(S); const c = S.custom;
      const row = (key, label, opts, spec) => `<div class="formrow"><label>${label}</label><div class="seg" data-seg51="${key}">${opts.map(([v,l]) => `<button data-v="${v}" aria-pressed="${String(c[key])===v}">${l}</button>`).join("")}</div>${spec?`<span class="spec">${spec}</span>`:""}</div>`;
      return row("fogPref", "Fog density", [["random","Random"],["thin","Thin"],["normal","Normal"],["thick","Thick"]], "Random picks a new density each time you start and whenever the weather turns.") +
        row("windPref", "Wind", [["random","Random"],["calm","Calm"],["breezy","Breezy"],["gale","Gale"]], "How hard the wind blows: flags, trees, litter, umbrellas and rain. Random changes with the weather.") + base.apply(this, arguments);
    };
  }
  if (typeof wireMenu === "function"){
    const base = wireMenu;
    window.wireMenu = function(){
      const r = base.apply(this, arguments);
      document.querySelectorAll("#menubody [data-seg51] button").forEach(b => b.onclick = () => { S.custom[b.closest("[data-seg51]").dataset.seg51] = b.dataset.v; rollAtmos(); saveState(); renderMenu(); });
      return r;
    };
  }
  let clickedAt = 0;
  document.addEventListener("click", e => { if (e.target && e.target.closest && e.target.closest("#menubody")) clickedAt = performance.now(); }, true);
  const keyOf = b => { const h = b.closest("[data-seg],[data-sc-setting],[data-seg44],[data-seg51],[data-citysize]"); if (!h) return null; return (h.dataset.seg || h.dataset.scSetting || h.dataset.seg44 || h.dataset.seg51 || (h.hasAttribute("data-citysize") ? "citysize" : "")) + "=" + (b.dataset.v || b.dataset.value || b.textContent.trim()); };
  const labelsOf = body => [...body.querySelectorAll(".formrow > label, .sc-setting > label")].map(l => l.textContent.trim()).join("|");
  if (typeof renderMenu === "function"){
    const base = renderMenu;
    window.renderMenu = function(){
      const body = document.querySelector("#menubody");
      const smooth = body && typeof UI !== "undefined" && UI.menuTab === "settings" && V.lastTab === "settings" && performance.now() - clickedAt < 400;
      const old = smooth ? [...body.childNodes] : null, oldLabels = smooth ? labelsOf(body) : "", scroller = document.querySelector("#menu .body") || body, top = scroller ? scroller.scrollTop : 0;
      const r = base.apply(this, arguments);
      try{
        V.lastTab = UI.menuTab;
        const b2 = document.querySelector("#menubody");
        if (b2 && UI.menuTab === "settings") tidyMenu(b2);
        if (smooth && b2 && labelsOf(b2) === oldLabels){
          const pressed = new Map(); b2.querySelectorAll("button[aria-pressed]").forEach(b => { const k = keyOf(b); if (k) pressed.set(k, b.getAttribute("aria-pressed")); });
          b2.replaceChildren(...old);
          b2.querySelectorAll("button[aria-pressed]").forEach(b => { const k = keyOf(b); if (k && pressed.has(k)) b.setAttribute("aria-pressed", pressed.get(k)); });
          if (scroller) scroller.scrollTop = top;
        }
      }catch(e){}
      return r;
    };
  }

  function build(){
    if (V.built || typeof G === "undefined" || !G.scene || typeof World === "undefined" || !World.lots || !World.lots.length || typeof S === "undefined" || !S || !SC.makePerson) return;
    V.built = true;
    try{ for (const c of (World.courts || [])) court(c); }catch(e){ console.warn("[Snap City 51] courts", e); }
    try{ for (const sp of (World.specials || [])){ if (sp.kind === "park") park(sp); else if (sp.kind === "plaza") plaza(sp); else if (sp.kind === "skatepark") skatepark(sp); else if (sp.kind === "castle") castle(sp); else quietPlace(sp); } }catch(e){ console.warn("[Snap City 51] parks", e); }
    try{ fireEscapes(); }catch(e){ console.warn("[Snap City 51] fire escapes", e); }
  }
  let visT = 0, atmosT = 240, lastWet = null;
  function tick(dt, t){
    if ((visT -= dt) <= 0){ visT = 1; for (const r of V.groups) r.g.visible = Math.hypot(r.cx - Player.x, r.cz - Player.z) < 170; }
    const wet = raining();
    if (lastWet !== null && wet !== lastWet) rollAtmos(); lastWet = wet;
    if ((atmosT -= dt) <= 0){ atmosT = 240; if (custom("fogPref") === "random" || custom("windPref") === "random") rollAtmos(); }
    for (const B of V.balls){
      B.t += dt;
      if (B.kind === "basket"){
        for (const p of B.players){ const dx = p.tx - p.g.position.x, dz = p.tz - p.g.position.z, d = Math.hypot(dx, dz);
          if (d < .3){ p.tx = B.cx + rnd(-6, 6); p.tz = B.cz + rnd(-11, 11); } else { p.g.position.x += dx / d * p.sp * dt; p.g.position.z += dz / d * p.sp * dt; p.g.rotation.y = Math.atan2(dx, dz); }
          const sw = Math.sin(t * 9 + p.phase) * .7; p.armL.rotation.x = sw; p.armR.rotation.x = -sw; }
        const h = B.players[B.holder];
        if (B.shot){ B.shot.u += dt / 1.1; const u = Math.min(1, B.shot.u); B.ball.position.set(B.shot.x0 + (B.shot.x1 - B.shot.x0) * u, B.shot.y0 + (B.shot.y1 - B.shot.y0) * u + Math.sin(u * Math.PI) * 2.5, B.shot.z0 + (B.shot.z1 - B.shot.z0) * u); if (u >= 1){ B.shot = null; B.holder = (Math.random() * B.players.length) | 0; } }
        else { B.ball.position.set(h.g.position.x + .35, h.g.position.y + .2 + Math.abs(Math.sin(t * 7)) * .8, h.g.position.z + .2);
          if (B.t > rnd(1.5, 3)){ B.t = 0; if (Math.random() < .35){ const e = Math.random() < .5 ? -1 : 1; B.shot = { u: 0, x0: B.ball.position.x, y0: B.ball.position.y + .8, z0: B.ball.position.z, x1: B.cx, y1: gy(B.cx, B.cz) + 3, z1: B.cz + e * 11.6 }; h.armR.rotation.x = h.armL.rotation.x = -2.8; } else B.holder = (Math.random() * B.players.length) | 0; } }
      } else {
        const [a, b] = B.players, u = (B.t % 1.4) / 1.4, from = B.dir > 0 ? a : b, to = B.dir > 0 ? b : a;
        if (B.t % 1.4 < dt){ B.dir *= -1; }
        B.ball.position.set(from.g.position.x + (to.g.position.x - from.g.position.x) * u, from.g.position.y + 1.1 + Math.sin(u * Math.PI) * 1.6, from.g.position.z + (to.g.position.z - from.g.position.z) * u);
        for (const p of B.players){ p.g.position.x = B.cx + Math.sin(t * 1.3 + p.phase) * 3.5; p.armR.rotation.x = -1.2 + Math.sin(t * 4.5 + p.phase) * .8; }
      }
    }
    for (const d of V.discs){ d.t += dt; const u = (d.t % 2.4) / 2.4, fwd = Math.floor(d.t / 2.4) % 2 === 0, A = fwd ? d.a : d.b, Bp = fwd ? d.b : d.a;
      d.disc.position.set(A.g.position.x + (Bp.g.position.x - A.g.position.x) * u, A.g.position.y + 1.3 + Math.sin(u * Math.PI) * 1.2, A.g.position.z + (Bp.g.position.z - A.g.position.z) * u); d.disc.rotation.y += dt * 12;
      A.armR.rotation.x = u < .15 ? -1.8 : -.3; Bp.armR.rotation.x = u > .85 ? -1.8 : -.3; }
    for (const q of V.ducks){ q.a += dt * .2; q.d.position.x = q.px + Math.cos(q.a) * q.r; q.d.position.z = q.pz + Math.sin(q.a) * q.r * .6; q.d.rotation.y = -q.a; }
    for (const s of V.skaters){ s.a += dt * s.sp; const x = s.cx + Math.cos(s.a) * s.r, z = s.cz + Math.sin(s.a) * s.r * .8, hop = Math.max(0, Math.sin(t * 1.3 + s.hop)); s.p.g.position.set(x, gy(x, z) + (hop > .92 ? (hop - .92) * 12 : 0), z); s.p.g.rotation.y = -s.a + (s.sp > 0 ? Math.PI : 0); s.board.rotation.x = hop > .92 ? .4 : 0; }
    for (const p of V.folk){ const s = Math.sin(t * 1.6 + p.phase);
      switch (p.act){
        case "cheer": p.armL.rotation.x = p.armR.rotation.x = -2.6 + Math.max(0, s) * .5; break;
        case "clap": p.armL.rotation.x = p.armR.rotation.x = -1.2; p.armL.rotation.z = .3 + Math.max(0, Math.sin(t * 9 + p.phase)) * .3; p.armR.rotation.z = -p.armL.rotation.z; break;
        case "eat": p.armR.rotation.x = -1.1 - Math.max(0, s) * .8; break;
        case "talk": case "laugh": p.armR.rotation.x = -.6 + s * .35; p.head.rotation.y = Math.sin(t * .8 + p.phase) * .4; break;
        case "read": p.armL.rotation.x = p.armR.rotation.x = -1.2; p.head.rotation.x = .35; break;
        case "vendor": p.armL.rotation.x = p.armR.rotation.x = -.8 + Math.sin(t * 2 + p.phase) * .25; break;
        case "order": p.armR.rotation.x = -1.3 + s * .3; break;
        case "phone": p.armR.rotation.x = -1.8; p.head.rotation.x = .3; break;
        case "feed": p.armR.rotation.x = -1 + Math.max(0, Math.sin(t * 2 + p.phase)) * .6; p.head.rotation.x = .4; break;
        case "taichi": { const u = Math.sin(t * .6); p.armL.rotation.x = -1 + u * .6; p.armR.rotation.x = -1 - u * .6; p.armL.rotation.z = .4 + u * .3; p.armR.rotation.z = -.4 + u * .3; p.g.rotation.y = Math.sin(t * .3) * .3; break; }
        case "chess": p.armR.rotation.x = -.9 + (Math.sin(t * .4 + p.phase) > .9 ? -.6 : 0); p.head.rotation.x = .45; break;
        case "guitar": p.armR.rotation.x = -.9 + Math.sin(t * 7) * .25; p.armL.rotation.x = -1.3; break;
        case "play": { const h = p.home; p.g.position.x = h.x + Math.sin(t * .9 + p.phase) * 3; p.g.position.z = h.z + Math.cos(t * .7 + p.phase) * 2; p.g.rotation.y = t * .9 + p.phase; const sw = Math.sin(t * 10 + p.phase) * .8; p.armL.rotation.x = sw; p.armR.rotation.x = -sw; break; }
        case "jog": { p.u += dt * .1; const x = p.loop.cx + Math.cos(p.u) * p.loop.r, z = p.loop.cz + Math.sin(p.u) * p.loop.r; p.g.position.set(x, gy(x, z), z); p.g.rotation.y = -p.u; const sw = Math.sin(t * 10) * .8; p.armL.rotation.x = sw; p.armR.rotation.x = -sw; break; }
        case "photo": p.armL.rotation.x = p.armR.rotation.x = -1.6; p.head.rotation.x = -.1; break;
        case "point": p.armR.rotation.x = -1.6; p.armR.rotation.z = -.3; break;
        case "walk": { const h = p.home; p.g.position.x = h.x + Math.sin(t * .15 + p.phase) * 6; p.g.rotation.y = Math.cos(t * .15 + p.phase) > 0 ? Math.PI / 2 : -Math.PI / 2; break; }
        case "guard": p.head.rotation.y = Math.sin(t * .2) * .6; break;
        case "mourn": p.head.rotation.x = .5; p.armR.rotation.x = -.6; break;
        case "rake": p.armR.rotation.x = -.8 + Math.sin(t * 2 + p.phase) * .4; p.armL.rotation.x = -.9 + Math.sin(t * 2 + p.phase) * .4; break;
        case "watchTennis": p.head.rotation.y = Math.sin(t * (Math.PI / 1.4)) * .7; break;
        default: p.head.rotation.y = Math.sin(t * .4 + p.phase) * .4;
      }
    }
    for (const s of V.sweepers){ for (const b of s.brushes) b.rotation.y += dt * 14; }
    for (const c of V.crews){ c.p.head.rotation.y = Math.sin(t * .5 + c.s) * .5; }
  }
  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{
        if (!V.built) build();
        hookStories();
        if (!V.crewsDone && SC.z48 && SC.z48.built && Life.cars.length > 10){ V.crewsDone = true; crews(); }
        if (typeof S !== "undefined" && S) tick(dt, performance.now() / 1000);
      }catch(e){ console.warn("[Snap City 51]", e); }
      return r;
    };
  }
  const iv = setInterval(() => { try{ build(); if (V.built) clearInterval(iv); }catch(e){} }, 700);
})();

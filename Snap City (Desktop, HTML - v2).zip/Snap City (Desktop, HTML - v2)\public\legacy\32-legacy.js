(function(){
"use strict";
const CS131=window.CS131={coffee:0,currentShop:null,boughtHere:false,detailGroup:null,litter:[],special:[],enhanced:false};

addEventListener("error",ev=>{const e=document.querySelector("#loadmsg");if(e)e.textContent=`Boot error: ${ev.message||"unknown JavaScript error"}`;});
addEventListener("unhandledrejection",ev=>{const e=document.querySelector("#loadmsg");if(e)e.textContent=`Boot error: ${(ev.reason&&ev.reason.message)||ev.reason||"promise rejected"}`;});

{ const base=defaultState; defaultState=function(free){const s=base(free);s.custom=Object.assign({characterVariety:"max",specialVehicles:"on",streetDetail:"dense",coffeeSystem:"on",critiqueDepth:"deep",windDrama:"normal",menuTheme:"leather"},s.custom||{});return s;}; }

const SHOP_NAME_EXPANSION={
  cafe:["Café Cañon","Sixth Street Espresso","Camera Obscura Coffee","The Daily Grind","Café Vesuvio","Silver Halide Coffee"],
  books:["Dog-Eared Books","Northside Paperbacks","Fogbound Books"],
  bar:["The Red Room","Transit Lounge","The Last Stop","Afterimage Bar"],
  barber:["Valencia Barber Co.","Golden Razor","Mission Tonsorial"],
  market:["Sunset Market","Corner Produce","Pacific Pantry"],
  florist:["Night Bloom","Mission Flowers","Stem & Thorn"],
  records:["Needle Drop","Wax & Static","45 RPM","Northside Records"],
  tattoo:["Black Cat Tattoo","Lucky Dagger","Rose & Anchor"],
  arcade:["Quarter World","Neon Token","Final Continue"],
  dumpling:["Golden Dumpling","Steam House","Little Wok"]
};
for(const sh of SHOPS){const a=SHOP_NAME_EXPANSION[sh.id];if(a)sh.names.push(...a);}

Object.assign(LENS_FILTERS,{
  mist18:{n:"Black diffusion 1/8",stops:.15,p:34,d:"A restrained bloom around highlights; skin softens without turning to mush.",col:[1.02,1,.97],bw:[1,1,1],soft:true},
  mist14:{n:"Black diffusion 1/4",stops:.25,p:38,d:"Visible halation and softer micro-contrast for neon, portraits and wet streets.",col:[1.03,.99,.95],bw:[1,1,1],soft:true},
  tobacco:{n:"Tobacco grad",stops:.66,p:26,d:"A grubby warm cast that makes late afternoon feel older than it is.",col:[1.22,.92,.63],bw:[1,1,1]},
  cyan:{n:"Cyan night filter",stops:.5,p:24,d:"Cold green-blue shadows for streetlight and night work.",col:[.72,1.02,1.28],bw:[1,1,1]},
  dream:{n:"Dream star",stops:.5,p:42,d:"Diffusion and exaggerated hard-light character.",col:[1.04,.98,1.02],bw:[1,1,1],soft:true,star:true}
});
for(const k of ["mist18","mist14","tobacco","cyan","dream"]){const f=LENS_FILTERS[k],l=f.col[0]*.3+f.col[1]*.59+f.col[2]*.11;f.col=f.col.map(v=>v/l);}

function cs131RemixPeople(){
  if(!Life.people||!Life.people.length)return;
  const rnd=mulberry(13131), pick=a=>a[(rnd()*a.length)|0];
  const hairs=["short","long","bun","pony","afro","mohawk"], hats=[null,"beanie","cap","fedora","sunhat","beret","hardhat","headscarf"];
  const tops=BRIGHT.concat(NEUTRAL), bottoms=JEANS.concat(TROUSERS);
  for(const p of Life.people){
    if(!p.look||p.role||p.performer||p.pool)continue;
    const L=p.look, sig=(p.id||0)%23;
    if(S.custom.characterVariety!=="low"){
      if(rnd()<.48)L.hair=pick(hairs);
      if(rnd()<.30){L.hat=pick(hats);L.hatColor=pick(NEUTRAL.concat(BRIGHT));}
      if(rnd()<.16)L.acc.backpack=pick(NEUTRAL.concat(BRIGHT));
      if(rnd()<.14)L.acc.tote=pick(["#c9b28a","#26231f","#7a2e36","#3f5e7a"]);
      if(rnd()<.11)L.acc.camera="#1d1d1c";
      if(rnd()<.10)L.acc.cup=pick(["#f4f2ec","#8a5a36"]);
      if(rnd()<.08)L.acc.scarf=pick(BRIGHT.concat(NEUTRAL));
      if(rnd()<.055)L.acc.skate=pick(["#c0362c","#26231f","#e8b82e","#3aa06b"]);
      if(sig===2){L.outfit="business";L.top="#293447";L.bottom="#293447";L.acc.tie="#8a3b32";}
      else if(sig===5){L.outfit="coat";L.btype="coat";L.top="#7a2e36";L.skirt=L.top;L.skirtLen=.27;L.acc.scarf="#e8b82e";}
      else if(sig===8){L.outfit="tourist";L.acc.camera="#1d1d1c";L.acc.backpack="#3f5e7a";L.hat="sunhat";}
      else if(sig===11){L.outfit="skater";L.acc.skate="#26231f";L.hat="beanie";L.top=pick(BRIGHT);}
      else if(sig===14){L.hair="afro";L.top=pick(BRIGHT);L.bottom=pick(bottoms);}
      else if(sig===17){L.hat="headscarf";L.hatColor=pick(["#e8a33d","#8a3b32","#1e4f8a","#2d4a3c"]);L.top=pick(tops);}
      else if(sig===20){L.hair="mohawk";L.top="#151515";L.bottom="#151515";L.glasses=true;}
      p.top=L.top;p.vivid=!!L.vivid||BRIGHT.includes(L.top);p.hat=L.hat?L.hatColor:null;p.bag=!!(L.acc.tote||L.acc.backpack);
    }
  }
}

function cs131AddSpecialVehicles(){
  if(S.custom.specialVehicles==="off"||!World.scene||!Life.carLightMats||!Life.carLightMats.length)return;
  try{
    if(!CAR_TYPES.cyber){CAR_TYPES.cyber={L:5.65,W:2.02,clr:.34,belt:1.05,nose:.92,tail:1.0,wf:1.78,wr:-1.68,R:.42,cabin:[[-1.55,0],[-.55,1.03],[.66,.84],[1.45,0]],ch:.58,bed:true,bev:.015};CAR_PALETTES.cyber=["#a8adb0","#c5c9ca","#808588","#d0d3d3"];}
    const add=(type,color,z,lane,vmax,flags={})=>{const tm=CarMats.tailOff.clone(),g=buildCarGroup(type,lin(color),flags.opts||{},[Life.carLightMats[0],tm]);if(flags.fire){const r=new THREE.MeshBasicMaterial({color:0xff3344}),b=new THREE.MeshBasicMaterial({color:0x3388ff});const a=new THREE.Mesh(new THREE.BoxGeometry(.55,.11,.22),r),bb=new THREE.Mesh(new THREE.BoxGeometry(.55,.11,.22),b);a.position.set(-.36,2.78,.35);bb.position.set(.36,2.78,.35);g.add(a,bb);}World.scene.add(g);const c={type:"car",tailMat:tm,g,lane,z:z+lane*1.3,x:rand(-210,210),speed:0,vmax,taxi:false,heading:lane>0?Math.PI/2:-Math.PI/2,cyber:!!flags.cyber,firetruck:!!flags.fire};Life.cars.push(c);CS131.special.push(c);};
    for(let k=0;k<3;k++)add("cyber",CAR_PALETTES.cyber[k%4],((k-1+0.5)*P),k%2?1:-1,8.2,{cyber:true,opts:{darkRims:true}});
    for(let k=0;k<2;k++)add("boxtruck","#b3171b",((k?1.5:-0.5)*P),k?1:-1,8.8,{fire:true,opts:{boxCol:lin("#b3171b")}});
  }catch(err){console.warn("[v13.1] special vehicles skipped:",err);}
}

function cs131BuildStreetDetails(){
  if(CS131.detailGroup||!World.scene||S.custom.streetDetail==="low")return;
  try{
    const g=new THREE.Group();CS131.detailGroup=g;World.scene.add(g);const mat=c=>new THREE.MeshStandardMaterial({color:lin(c),roughness:.72,metalness:.12});
    const box=(x,y,z,sx,sy,sz,c,ry=0)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat(c));m.position.set(x,y,z);m.rotation.y=ry;m.castShadow=true;m.receiveShadow=true;g.add(m);};
    const cyl=(x,y,z,r,h,c)=>{const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,10),mat(c));m.position.set(x,y,z);m.castShadow=true;g.add(m);};
    const rnd=mulberry(131313), density=S.custom.streetDetail==="max"?1.35:1;
    for(let i=-NB;i<=NB;i++)for(let j=-NB;j<=NB;j++)for(let n=0;n<Math.ceil(2*density);n++){
      const side=(rnd()*4)|0,along=-HALF+4+rnd()*(HALF*2-8),off=HALF+1.25+rnd()*1.1,x=i*P+(side===0?-off:side===1?off:along),z=j*P+(side===2?-off:side===3?off:along),y=groundY(x,z),kind=(rnd()*7)|0;
      if(kind===0){cyl(x,y+.43,z,.17,.86,"#d6a21f");cyl(x,y+.83,z,.25,.08,"#b88410");}
      else if(kind===1){cyl(x,y+.48,z,.3,.92,rnd()<.5?"#263e34":"#303234");}
      else if(kind===2){box(x,y+.58,z,.38,1.16,.3,rnd()<.5?"#245b87":"#31594a");}
      else if(kind===3){cyl(x,y+.52,z,.055,1.04,"#5f6264");box(x,y+1.04,z,.24,.28,.16,"#35383b");}
      else if(kind===4){box(x,y+.04,z,1.25,.08,.09,"#777a78");for(let b=-1;b<=1;b++)cyl(x+b*.45,y+.34,z,.03,.6,"#777a78");}
      else if(kind===5)box(x,y+.38,z,.42,.76,.42,rnd()<.5?"#d56c2c":"#e8b82e",rnd()*Math.PI);
      else {box(x,y+.32,z,.6,.64,.06,"#e36f2d",rnd()*Math.PI);cyl(x-.2,y+.64,z,.035,.64,"#e9e6de");cyl(x+.2,y+.64,z,.035,.64,"#e9e6de");}
    }
  }catch(err){console.warn("[v13.1] street details skipped:",err);}
}

function cs131BuildLitter(){if(CS131.litter.length||!World.scene)return;try{const gm=new THREE.PlaneGeometry(.28,.18),mm=new THREE.MeshStandardMaterial({color:0xd7d0bf,side:THREE.DoubleSide,roughness:.9});for(let i=0;i<20;i++){const m=new THREE.Mesh(gm,mm.clone());m.rotation.x=-Math.PI/2;m.position.set(rand(-120,120),.03,rand(-120,120));World.scene.add(m);CS131.litter.push({m,v:rand(.4,1.2),spin:rand(-3,3),seed:rand(0,99)});}}catch(err){console.warn("[v13.1] litter skipped:",err);}}
function cs131UpdateLitter(dt){if(!CS131.litter.length||typeof WIND==="undefined")return;const drama=({low:.45,normal:1,high:1.8})[S.custom.windDrama]||1;for(const q of CS131.litter){const m=q.m,gust=(WIND.gust||0)*drama,wx=(WIND.x||0)*(.45+gust),wz=(WIND.z||0)*(.45+gust);m.position.x+=(wx*q.v+Math.sin(Game.t*.8+q.seed)*.12)*dt;m.position.z+=(wz*q.v+Math.cos(Game.t*.7+q.seed)*.1)*dt;m.rotation.z+=q.spin*dt*(.2+gust);m.position.y=.03+Math.abs(Math.sin(Game.t*1.8+q.seed))*.08*gust;if(Math.abs(m.position.x-Player.x)>150||Math.abs(m.position.z-Player.z)>150){m.position.x=Player.x+rand(-80,80);m.position.z=Player.z+rand(-80,80);}}}

{const baseEnter=enterShop,baseLeave=leaveZone,baseAction=enterAction;enterShop=function(sh){CS131.currentShop=sh;CS131.boughtHere=false;const r=baseEnter(sh),th=SHOPS[sh.theme];if(th&&th.id==="cafe"&&S.custom.coffeeSystem!=="off")toast(`Inside ${th.names[0]}. Enter again to buy a $4 coffee; after that Enter leaves.`,3000);return r;};leaveZone=function(){const r=baseLeave();CS131.currentShop=null;CS131.boughtHere=false;return r;};enterAction=function(){if(ZONE.mode==="shop"&&CS131.currentShop){const th=SHOPS[CS131.currentShop.theme];if(th&&th.id==="cafe"&&S.custom.coffeeSystem!=="off"&&!CS131.boughtHere){if(!S.free&&S.money<4){toast("Coffee is $4. The photographer's wallet says no.",1800);CS131.boughtHere=true;return;}if(!S.free)S.money-=4;CS131.coffee=90;CS131.boughtHere=true;saveState();toast("Hot coffee. Your hands settle a little faster for the next minute and a half.",2600);return;}}return baseAction();};const baseSk=sk;sk=function(k){const v=baseSk(k);return k==="steady"&&CS131.coffee>0?Math.min(4,v+1):v;};}

{const base=captureShot;captureShot=async function(...a){const rec=await base(...a);if(rec&&rec.meta){rec.meta.zone=ZONE.mode||null;rec.meta.wind=(typeof WIND!=="undefined")?Math.hypot(WIND.x||0,WIND.z||0):0;rec.meta.coffee=CS131.coffee>0;try{await DB.put(rec);}catch(e){}}return rec;};}
{const base=judgePhoto;judgePhoto=function(rec,statsOverride){const res=base(rec,statsOverride);if(!res||!res.critique||S.custom.critiqueDepth==="compact")return res;const m=rec.meta||{},add=[];if(m.zone==="roof")add.push(`The rooftop viewpoint turns the street into geometry and gives the frame a different social distance.`);if(m.wind>1.2)add.push(m.t>1/125?`The wind and this shutter speed make camera movement part of the sharpness problem.`:`The faster shutter gives useful insurance against the wind.`);if(m.filter&&m.filter!=="none"&&LENS_FILTERS[m.filter])add.push(`The ${LENS_FILTERS[m.filter].n} is visibly part of the photograph rather than a neutral accessory.`);if(m.feq<=28)add.push(`At ${Math.round(m.feq)}mm equivalent, foreground distance is composition; getting physically close changes the whole frame.`);else if(m.feq>=85)add.push(`At ${Math.round(m.feq)}mm equivalent, compression isolates gestures but can stack background clutter.`);if(m.coffee)add.push(`The steadier handling helps technically, but the moment still has to carry the photograph.`);if(add.length)res.critique=res.critique.concat(add.slice(0,S.custom.critiqueDepth==="deep"?3:1));return res;};}

{const base=menuSettings;menuSettings=function(){const c=S.custom,seg=(key,opts)=>`<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;return `<div class="sectionhead">Photographer's Cut</div><div class="formrow"><label>Character variety</label>${seg("characterVariety",[["low","Restrained"],["rich","Rich"],["max","Maximum"]])}</div><div class="formrow"><label>Street detail</label>${seg("streetDetail",[["low","Lean"],["dense","Dense"],["max","Obsessive"]])}</div><div class="formrow"><label>Special traffic</label>${seg("specialVehicles",[["on","Mixed in"],["off","Ordinary only"]])}</div><div class="formrow"><label>Wind drama</label>${seg("windDrama",[["low","Subtle"],["normal","Natural"],["high","Gusty"]])}</div><div class="formrow"><label>Café coffee</label>${seg("coffeeSystem",[["on","Buy it"],["off","Scenery only"]])}</div><div class="formrow"><label>Editor detail</label>${seg("critiqueDepth",[["compact","Compact"],["normal","Specific"],["deep","Deep"]])}</div>`+base();};}
{const base=renderMenu;renderMenu=function(...a){const r=base(...a);document.body.dataset.menuTheme=({leather:"nikon",chrome:"nikon"})[S.custom.menuTheme]||S.custom.menuTheme||"nikon";const row=document.querySelector('[data-seg="menuTheme"]');if(row&&!row.querySelector('[data-v="brass"]')){const b=document.createElement("button");b.dataset.v="brass";b.textContent="Brass & leather";b.setAttribute("aria-pressed",S.custom.menuTheme==="brass");b.onclick=()=>{S.custom.menuTheme="brass";saveState();renderMenu();};row.appendChild(b);}return r;};}
function cs131Status(){let el=document.getElementById("cs131Status");if(!el){el=document.createElement("div");el.id="cs131Status";document.body.appendChild(el);}if(CS131.coffee>0&&Game.started){el.textContent=`COFFEE · ${Math.ceil(CS131.coffee)}s · steadier hands`;el.classList.add("on");}else el.classList.remove("on");}
{const base=gameplayUpdate;gameplayUpdate=function(dt){base(dt);if(CS131.coffee>0)CS131.coffee=Math.max(0,CS131.coffee-dt);cs131UpdateLitter(dt);cs131Status();};}

{const base=boot;boot=async function(){await base();S.custom=Object.assign({characterVariety:"max",specialVehicles:"on",streetDetail:"dense",coffeeSystem:"on",critiqueDepth:"deep",windDrama:"normal"},S.custom||{});if(S.free){S.owned.filters=S.owned.filters||[];for(const k of Object.keys(LENS_FILTERS))if(k!=="none"&&!S.owned.filters.includes(k))S.owned.filters.push(k);}const run=()=>{try{cs131RemixPeople();}catch(e){console.warn("[v13.1] people remix skipped",e);}try{cs131AddSpecialVehicles();}catch(e){console.warn("[v13.1] vehicles skipped",e);}try{cs131BuildStreetDetails();cs131BuildLitter();}catch(e){console.warn("[v13.1] details skipped",e);}CS131.enhanced=true;console.log(`[Contact Sheet v13.1 SAFE] ready — ${Life.people.length} people, ${Life.cars.length} vehicles.`);};if("requestIdleCallback" in window)requestIdleCallback(run,{timeout:1200});else setTimeout(run,50);};}
})();

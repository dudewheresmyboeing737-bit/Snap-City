(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const L = SC.street47 = { built: false, shoppers: [], vendors: [], balc: [], lamps: [] };
  const rnd = (a, b) => a + Math.random() * (b - a), pick = a => a[(Math.random() * a.length) | 0];
  const mats = {}; const m = (c, r, mt, em) => mats[c + "|" + (em||0)] || (mats[c + "|" + (em||0)] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: r ?? .8, metalness: mt || 0, emissive: em ? lin(c) : 0x000000, emissiveIntensity: em || 0 }));
  const BOX = new THREE.BoxGeometry(1,1,1), SPH = new THREE.SphereGeometry(.5, 10, 8), CYL = new THREE.CylinderGeometry(.5, .5, 1, 10);
  const part = (g, geo, c, x, y, z, sx, sy, sz, mm) => { const o = new THREE.Mesh(geo, mm || m(c)); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; g.add(o); return o; };
  const gy = (x, z) => { try{ return groundY(x, z); }catch(e){ return 0; } };
  const blocked = (x, z, r) => { try{ const c = collidePoint(x, z, r || .3); return Math.abs(c[0]-x) + Math.abs(c[1]-z) > 1e-4; }catch(e){ return false; } };

  function migrate(s){
    if (!s || !s.custom) return s;
    const c = s.custom;
    if (!c._sc47){ Object.assign(c, { autoWeather: "on", exposureCoach: "off", filmAdvance: "manual", editorOverlays: "show", windowLife: "off" }); c._sc47 = 1; }

    c.perfectProgram = c.perfectExposureMode === "auto-perfect" ? "on" : "off";
    c.windDrama = ({ calm: "subtle", breezy: "natural", gale: "gusty" })[c.windStrength] || "natural";
    c.editorOverlays = "show"; c.windowLife = "off";
    return s;
  }
  if (typeof defaultState === "function"){ const b = defaultState; window.defaultState = function(){ return migrate(b.apply(this, arguments)); }; }
  if (typeof loadState === "function"){ const b = loadState; window.loadState = function(){ return migrate(b.apply(this, arguments)); }; }

  const DROP_KEYS = ["perfectProgram", "windDrama", "editorOverlays", "neighborhoodIdentity", "windowLife", "heavyTraffic"];
  const DROP_BUTTONS = /^(Apply perfect exposure now|Set recommended exposure)$/i;
  const RENAME = { "Perfect exposure": "Auto exposure", "Time scale": "Game speed (slow motion)", "Photorealism": "Photorealism pass", "Event notice": "Event alerts", "Event notices under the map": "Event list under the map", "Special traffic": "Emergency & concept vehicles" };
  function tidySettings(body){
    body.querySelectorAll("[data-seg],[data-sc-setting],[data-seg44]").forEach(el => {
      const k = el.dataset.seg || el.dataset.scSetting || el.dataset.seg44;
      if (DROP_KEYS.includes(k)){ const row = el.closest(".formrow,.sc-setting"); if (row) row.remove(); }
    });
    body.querySelectorAll("button").forEach(b => { if (DROP_BUTTONS.test(b.textContent.trim())){ const row = b.closest(".formrow,.sc-setting"); (row && row.querySelectorAll("button").length === 1 ? row : b).remove(); } });
    body.querySelectorAll(".formrow > label, .sc-setting > label").forEach(l => { const t = l.textContent.trim(); if (RENAME[t]) l.textContent = RENAME[t]; });
    body.querySelectorAll(".formrow, .sc-setting").forEach(r => { const l = r.querySelector("label"); if (l && !l.textContent.trim().replace("?","")) l.textContent = "Reset"; else if (!l && r.querySelector("button") && /Restore/.test(r.textContent)) r.insertAdjacentHTML("afterbegin", "<label>Reset</label>"); });
    body.querySelectorAll("details.sc-settings-section").forEach(d => { const n = d.querySelectorAll(".formrow,.sc-setting").length, sm = d.querySelector("summary small"); if (!n) d.remove(); else if (sm) sm.textContent = n; });
  }
  let menuMemory = { open: new Set(), scroll: 0, tab: null };
  if (typeof renderMenu === "function"){
    const base = renderMenu;
    window.renderMenu = function(){
      const body = document.querySelector("#menubody"), scroller = document.querySelector("#menu .body") || body;
      if (body && menuMemory.tab === (typeof UI !== "undefined" && UI.menuTab)){
        menuMemory.open = new Set([...body.querySelectorAll("details[open] > summary")].map(s => s.textContent.replace(/\d+$/, "").trim()));
        menuMemory.scroll = scroller ? scroller.scrollTop : 0;
      } else { menuMemory.open = new Set(); menuMemory.scroll = 0; }
      const r = base.apply(this, arguments);
      try{
        menuMemory.tab = UI.menuTab;
        const b2 = document.querySelector("#menubody");
        if (b2 && UI.menuTab === "settings") tidySettings(b2);
        if (b2 && menuMemory.open.size) b2.querySelectorAll("details").forEach(d => { const s = d.querySelector("summary"); if (s && menuMemory.open.has(s.textContent.replace(/\d+$/, "").trim())) d.open = true; });
        const sc2 = document.querySelector("#menu .body") || b2; if (sc2 && menuMemory.scroll) sc2.scrollTop = menuMemory.scroll;
      }catch(e){}
      return r;
    };
  }

  const CROWD_ACTS = [
    { phone: true, w: 3 }, { pose: "point", w: 2 }, { pose: "handsface", w: 1 }, { pose: "laugh", w: 1 }, { pose: "shrug", w: 1 },
    { pose: "clap", w: 1 }, { chat: true, w: 3 }, { wander: true, w: 3 }, { leave: true, w: 1 }, { pose: "cheer", w: 1 }, { pose: "fist", w: .5 }
  ];
  const STORY_ALT = { talk: ["point","laugh","shrug", null], cheer: ["clap","dance","handsup"], watch: ["point","handsface", null],
    dance: ["cheer","clap","handsup"], point: ["talk","shrug", null], wave: ["cheer","point"], give: ["point","talk"], take: ["laugh","talk"],
    hug: ["laugh","clap"], phone: ["point", null], surprised: ["handsface","laugh"], null: ["point","laugh","shrug"] };
  const wpick = list => { let t = 0; for (const a of list) t += a.w; let r = Math.random() * t; for (const a of list){ r -= a.w; if (r <= 0) return a; } return list[0]; };
  const face = (p, x, z) => { p.heading = Math.atan2(x - p.x, z - p.z); };
  function walkTo(p, tx, tz, sp, dt){
    const dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz); if (d < .2){ p.evMoving = false; return true; }
    const st = Math.min(d, sp * dt), nx = p.x + dx / d * st, nz = p.z + dz / d * st;
    if (blocked(nx, nz, .3)){ p.evMoving = false; return true; }
    p.heading = Math.atan2(dx, dz); p.x = nx; p.z = nz; p.y = gy(nx, nz); p.evMoving = true; p.evSpeed = sp; return false;
  }
  function liven(E, dt){
    if (!E || !E.ppl || E.done) return;
    const cx = E.x !== undefined ? E.x : (E.ppl[0] && E.ppl[0].x), cz = E.z !== undefined ? E.z : (E.ppl[0] && E.ppl[0].z);
    const story = String(E.type || "").startsWith("sc_") || !!E.story;
    E.ppl.forEach((p, i) => {
      if (!p || p.hidden) return;
      const st = p._lv47 || (p._lv47 = { next: rnd(1, 4), act: null, home: { x: p.x, z: p.z }, t: 0, alt: null, altT: 0 });
      st.t += dt; st.next -= dt;
      if (p.role && p.role !== "robber" && !story) return;
      if (story){
        if (st.alt && (st.altT -= dt) > 0) p.evPose = st.alt === "none" ? null : st.alt;
        else if (st.next <= 0){ st.next = rnd(2.5, 6); const alts = STORY_ALT[p.evPose] || STORY_ALT.null; st.alt = Math.random() < .6 ? (pick(alts) || "none") : null; st.altT = rnd(1.5, 3.5); }
        if (!p.evMoving && st.t > 2 && Math.random() < dt * .15){ const a = Math.random() * 6.28, tx = st.home.x + Math.cos(a) * rnd(.4, 1.6), tz = st.home.z + Math.sin(a) * rnd(.4, 1.6); if (!blocked(tx, tz)) st.step = { x: tx, z: tz }; }
        if (st.step && walkTo(p, st.step.x, st.step.z, .8, dt)){ st.step = null; if (cx !== undefined) face(p, cx, cz); }
        return;
      }
      if (p.evMoving && !st.target) return;
      if (p.evPose && !st.act) return;
      if (st.next <= 0 || !st.act){
        st.next = rnd(3.5, 9); st.act = wpick(CROWD_ACTS); st.target = null;
        if (st.act.wander){ const a = Math.random() * 6.28, r = rnd(1.5, 4); st.target = { x: st.home.x + Math.cos(a) * r, z: st.home.z + Math.sin(a) * r }; }
        if (st.act.leave){ const a = Math.atan2(p.x - cx, p.z - cz); st.target = { x: p.x + Math.sin(a) * rnd(8, 14), z: p.z + Math.cos(a) * rnd(8, 14) }; st.next = rnd(8, 14); }
        if (st.act.chat){ let best = null, bd = 1e9; for (const q of E.ppl){ if (q === p || !q || q.hidden) continue; const d = Math.hypot(q.x - p.x, q.z - p.z); if (d < bd){ bd = d; best = q; } } st.buddy = best; }
      }
      const a = st.act;
      p.act = a.phone ? "phone" : (p.act === "phone" ? "idle" : p.act);
      if (st.target){ if (!walkTo(p, st.target.x, st.target.z, a.leave ? 1.2 : .9, dt)) { p.evPose = null; return; } st.target = a.leave && st.next < 3 ? { x: st.home.x, z: st.home.z } : null; }
      if (a.chat && st.buddy){ face(p, st.buddy.x, st.buddy.z); p.evPose = Math.sin(st.t * 1.3 + i) > .4 ? "laugh" : (Math.sin(st.t * .7 + i) > .6 ? "point" : null); return; }
      if (cx !== undefined) face(p, cx, cz);
      p.evPose = a.pose || null;
    });
  }
  function hookStep(E){ if (E && typeof E.step === "function" && !E._lv47){ const step = E.step; E._lv47 = true; E.step = function(dt){ const r = step.apply(this, arguments); try{ liven(E, dt); }catch(e){} return r; }; } return E; }
  if (typeof startEvent === "function"){ const base = startEvent; window.startEvent = function(){ return hookStep(base.apply(this, arguments)); }; }

  function sweepEvents(){ try{ if (typeof EV !== "undefined" && EV.list) EV.list.forEach(hookStep); }catch(e){} }

  function shopFront(sh){
    const th = SHOPS[sh.theme] || {}, id = th.id, g = new THREE.Group(), n = sh.n, t = [n[1], -n[0]];
    const at = (along, out) => [sh.x + t[0] * along + n[0] * out, sh.z + t[1] * along + n[1] * out];
    const put = (obj, along, out, y) => { const p = at(along, out); obj.position.set(p[0], gy(p[0], p[1]) + (y || 0), p[1]); obj.rotation.y = Math.atan2(n[0], n[1]); g.add(obj); };
    const side = (Math.random() < .5 ? -1 : 1) * Math.min(sh.w / 2 - 1, 2.2);
    if (id === "market"){
      for (let k = 0; k < 3; k++){ const c = new THREE.Group(); part(c, BOX, "#8a6a44", 0, .35, 0, .9, .5, .6); for (let f = 0; f < 6; f++) part(c, SPH, pick(["#d23c2e","#e8b82e","#3aa06b","#e36f2d","#9acd32"]), -.3 + (f % 3) * .3, .66, -.12 + ((f / 3) | 0) * .24, .22, .2, .22); put(c, side + (k - 1) * 1, .6); }
    } else if (id === "florist"){
      for (let k = 0; k < 5; k++){ const b = new THREE.Group(); part(b, CYL, "", 0, .22, 0, .38, .44, .38, m("#6b7a80", .4, .5)); for (let f = 0; f < 5; f++) part(b, SPH, pick(["#f28cb1","#e8b82e","#f2efe6","#c0362c","#8a3fb5"]), rnd(-.12,.12), .55 + rnd(0,.2), rnd(-.12,.12), .16, .16, .16); put(b, side + (k - 2) * .55, .5); }
    } else if (id === "cafe" || id === "dumpling" || id === "bar"){
      const tb = new THREE.Group(); part(tb, CYL, "#e9e4d8", 0, .74, 0, .7, .04, .7); part(tb, CYL, "#2b2926", 0, .37, 0, .06, .74, .06);
      for (const s of [-1, 1]){ part(tb, BOX, "#2b2926", s * .6, .45, 0, .4, .05, .4); part(tb, BOX, "#2b2926", s * .78, .7, 0, .04, .5, .4); }
      put(tb, side, .9);
      if (SC.makePerson && Math.random() < .6){ const p = SC.makePerson((sh.x * 5) | 0, true), pp = at(side + .6, .9); p.g.position.set(pp[0], gy(pp[0], pp[1]), pp[1]); p.g.rotation.y = Math.atan2(n[0], n[1]) - Math.PI / 2; G.scene.add(p.g); L.shoppers.push(Object.assign(p, { act: pick(["sip","read","talk"]) })); }
      const board = new THREE.Group(); const b1 = part(board, BOX, "#1a1a1a", 0, .5, 0, .6, .9, .04); b1.rotation.x = .2; put(board, -side, 1.1);
    } else if (id === "records" || id === "books" || id === "video" || id === "pawn"){
      const bin = new THREE.Group(); part(bin, BOX, "#6b4a2e", 0, .45, 0, 1.4, .7, .6); for (let f = 0; f < 10; f++) part(bin, BOX, pick(["#c0362c","#2f7fc1","#e8b82e","#1a1a1a","#f2efe6","#3aa06b"]), -.6 + f * .13, .88, 0, .02, .3, .5); put(bin, side, .6);
    } else return null;
    g.userData.mergeStatic = true; G.scene.add(g); return g;
  }
  function newsstand(x, z, ry){
    const g = new THREE.Group(); g.position.set(x, gy(x, z), z); g.rotation.y = ry;
    part(g, BOX, "#2f5d3f", 0, 1.1, 0, 2.2, 2.2, 1.4); part(g, BOX, "#244a32", 0, 2.3, .2, 2.5, .15, 1.9);
    for (let k = 0; k < 8; k++) part(g, BOX, pick(["#f2efe6","#c0362c","#e8b82e","#2f7fc1"]), -.9 + (k % 4) * .6, .9 + ((k / 4) | 0) * .45, .72, .45, .35, .02);
    L.lamps.push(part(g, BOX, "", 0, 2.15, .75, 1.8, .06, .06, m("#fff4c8", .3, 0, .01)));
    if (SC.makePerson){ const p = SC.makePerson((x * 3) | 0, false); p.g.position.set(0, 0, 1.0); p.g.rotation.y = Math.PI; g.add(p.g); L.vendors.push(p); }
    g.userData.mergeStatic = true; G.scene.add(g);
    try{ World.colliders.push({ x0: x - 1.3, x1: x + 1.3, z0: z - 1.3, z1: z + 1.3 }); }catch(e){}
  }
  function foodTruck(x, z, ry, cart){
    const g = new THREE.Group(); g.position.set(x, gy(x, z), z); g.rotation.y = ry;
    if (cart){ part(g, BOX, "", 0, .75, 0, 1.6, .9, .8, m("#c9ccd0", .3, .6)); for (const s of [-1, 1]) part(g, CYL, "#1a1a1a", s * .55, .25, .45, .5, .1, .5).rotation.x = Math.PI / 2; part(g, CYL, pick(["#e8b82e","#c0362c","#2f7fc1"]), 0, 2.1, 0, 2.2, .1, 2.2); part(g, CYL, "#2b2b2b", 0, 1.6, 0, .06, 1.2, .06); }
    else { const col = pick(["#e36f2d","#2f7fc1","#e8b82e","#c8367a","#3aa06b","#f2efe6"]); part(g, BOX, col, 0, 1.6, 0, 2.3, 2.4, 5.2); part(g, BOX, "#1b2430", 1.16, 1.9, .3, .05, 1, 2.6); part(g, BOX, col, 1.4, 2.5, .3, .8, .06, 2.8).rotation.z = -.35; for (const s of [-1, 1]) for (const zz of [-1.7, 1.7]) part(g, CYL, "#1a1a1a", s * 1.1, .45, zz, .8, .3, .8).rotation.z = Math.PI / 2; }
    g.userData.mergeStatic = true; G.scene.add(g);
    if (SC.makePerson){
      const q = 2 + ((Math.random() * 3) | 0);
      for (let k = 0; k < q; k++){ const p = SC.makePerson((x * 7 + k * 13) | 0, false); p.g.position.set(cart ? 0 : 2.3, 0, (cart ? 1.2 : -.6) + k * .9); p.g.rotation.y = cart ? Math.PI : -Math.PI / 2; g.add(p.g); L.shoppers.push(Object.assign(p, { act: k === 0 ? "order" : pick(["phone","wait","talk"]) })); }
    }
    try{ const hw = cart ? 1 : 1.5, hl = cart ? 1 : 2.8; World.colliders.push({ x0: x - (Math.abs(Math.sin(ry)) > .5 ? hl : hw), x1: x + (Math.abs(Math.sin(ry)) > .5 ? hl : hw), z0: z - (Math.abs(Math.sin(ry)) > .5 ? hw : hl), z1: z + (Math.abs(Math.sin(ry)) > .5 ? hw : hl) }); }catch(e){}
  }

  function balconies(){
    const zoneAt = (x, z) => { try{ return zoneOf(Math.round(x / P), Math.round(z / P)); }catch(e){ return ""; } };

    const roofs = (World.roofs || []).filter(r => r.n && r.top && Math.abs(r.fx) < (NB + .5) * P && Math.abs(r.fz) < (NB + .5) * P && zoneAt(r.x, r.z) !== "vic");
    let count = 0;
    for (const r of roofs){
      if (count > 240 || Math.random() > .62) continue;
      const base = H(r.fx, r.fz) + .16, floors = Math.floor((r.top - base - 4.4) / 3.2); if (floors < 1) continue;
      const t = [r.n[1], -r.n[0]], ry = Math.atan2(r.n[0], r.n[1]), rail = pick(["#2b2f33","#e9e4d8","#5a3a2f"]);
      const n = 1 + ((Math.random() * Math.min(3, floors)) | 0);
      for (let k = 0; k < n; k++){
        const along = rnd(-r.w / 2 + 1.6, r.w / 2 - 1.6), y = base + 4.4 + (1 + ((Math.random() * floors) | 0)) * 3.2 - 3.2 + .2;
        const g = new THREE.Group(); g.position.set(r.fx + t[0] * along + r.n[0] * .02, y, r.fz + t[1] * along + r.n[1] * .02); g.rotation.y = ry;
        part(g, BOX, "#8a8680", 0, 0, .55, 2.4, .14, 1.1);
        part(g, BOX, "#1c232a", 0, 1.05, .03, 1, 2.0, .05);
        part(g, BOX, rail, 0, .95, 1.07, 2.4, .05, .05); for (const s of [-1, 1]) part(g, BOX, rail, s * 1.18, .95, .55, .05, .05, 1.05);
        for (let b = 0; b < 9; b++) part(g, BOX, rail, -1.1 + b * .275, .48, 1.07, .03, .9, .03);
        for (const s of [-1, 1]) part(g, BOX, rail, s * 1.18, .48, .55, .03, .9, 1.05);
        if (Math.random() < .7) for (let p = 0; p < 2; p++){ part(g, CYL, "#a0522d", -.8 + p * 1.5, .22, .85, .3, .3, .3); part(g, SPH, pick(["#3f5a34","#5a7a44","#c0362c","#e8b82e"]), -.8 + p * 1.5, .5, .85, .4, .35, .4); }
        if (Math.random() < .07){ part(g, BOX, "#dddddd", 0, 1.65, .9, 2.2, .01, .01); for (let c = 0; c < 4; c++) part(g, BOX, pick(["#f2efe6","#2f7fc1","#c0362c","#e8b82e"]), -.8 + c * .5, 1.4, .9, .35, .45, .02); }
        if (SC.makePerson && Math.random() < .72){
          const seated = Math.random() < .4, p = SC.makePerson((r.fx * 13 + k * 7) | 0, seated);
          p.g.position.set(rnd(-.5, .5), .07, seated ? .45 : .8); p.g.rotation.y = seated ? rnd(-.4, .4) : 0; g.add(p.g);
          if (seated) part(g, BOX, "#2b2926", p.g.position.x, .3, .38, .45, .05, .45);
          const act = seated ? pick(["read","sip","phone","guitar","knit","eat"]) : pick(["lean","water","phone","watch","pace","stretch","smoke","telescope","grill","paint","yoga","wave","shake"]);
          if (act === "water"){ const can = part(p.armR, BOX, "#3aa06b", 0, -.52, .1, .12, .16, .22); part(p.armR, CYL, "#3aa06b", 0, -.5, .28, .03, .3, .03).rotation.x = 1.1; }
          if (act === "guitar"){ const gt = part(p.g, BOX, "#8a5a2a", .05, .75, .25, .34, .12, .5); gt.rotation.z = .9; }
          if (act === "telescope"){ const ts = part(g, CYL, "#2b2b2b", p.g.position.x + .4, 1.3, .9, .07, .7, .07); ts.rotation.x = -1.1; part(g, CYL, "#2b2b2b", p.g.position.x + .4, .6, .75, .03, 1.2, .03); }
          if (act === "grill"){ part(g, SPH, "#1a1a1a", p.g.position.x + .55, .85, .7, .45, .35, .45); part(g, CYL, "#1a1a1a", p.g.position.x + .55, .4, .7, .04, .8, .04); }
          if (act === "paint"){ const ea = part(g, BOX, "#f2efe6", p.g.position.x + .55, 1.25, .7, .5, .6, .03); ea.rotation.y = -.6; part(g, BOX, "#6b4a2e", p.g.position.x + .55, .6, .7, .04, 1.2, .04); }
          if (act === "yoga"){ part(g, BOX, pick(["#8a3fb5","#2f7fc1","#3aa06b"]), p.g.position.x, .09, .55, .6, .02, 1.6); }
          if (act === "shake"){ part(p.armR, BOX, pick(["#c0362c","#2f7fc1","#e8b82e"]), 0, -.55, .3, .5, .02, .7); }
          if (act === "eat"){ part(p.g, CYL, "#f4f4f0", 0, .72, .35, .28, .02, .28); }
          if (act === "smoke"){ part(p.armR, BOX, "", 0, -.5, .06, .02, .02, .08, m("#ff7a3a", .4, 0, 1.2)); }
          L.balc.push(Object.assign(p, { act, px: p.g.position.x }));
        }
        g.userData.mergeStatic = true; G.scene.add(g); count++;
      }
    }
  }

  function build(){
    if (L.built || typeof G === "undefined" || !G.scene || typeof World === "undefined" || !World.lots || !World.lots.length || typeof S === "undefined" || !S || !SC.makePerson) return;
    L.built = true;
    try{
      const inside = sh => Math.abs(sh.x) < (NB + .5) * P && Math.abs(sh.z) < (NB + .5) * P;
      let n = 0; for (const sh of (World.shops || [])){ if (n > 60) break; if (inside(sh) && Math.random() < .5 && shopFront(sh)) n++; }
      const lots = (World.lots || []).filter(l => Math.abs(l.i) <= NB && Math.abs(l.j) <= NB);
      for (let k = 0; k < 4 && lots.length; k++){ const l = pick(lots), s = Math.random() < .5 ? -1 : 1; newsstand(l.cx + rnd(-20, 20), l.cz + s * (HALF + 3.1), s > 0 ? 0 : Math.PI); }
      for (let k = 0; k < 4 && lots.length; k++){ const l = pick(lots), s = Math.random() < .5 ? -1 : 1, cart = Math.random() < .45; foodTruck(l.cx + s * (HALF + (cart ? 3.1 : 6.3)), l.cz + rnd(-18, 18), s > 0 ? Math.PI / 2 : -Math.PI / 2, cart); }
      balconies();
    }catch(e){ console.warn("[Snap City 47] street life", e); }
  }
  function animate(t){
    const all = L.shoppers.concat(L.balc);
    for (const p of all){
      const s = Math.sin(t * 1.5 + p.phase);
      if (p.act === "sip"){ p.armR.rotation.x = -1 - Math.max(0, Math.sin(t * .7 + p.phase)) * 1.1; }
      else if (p.act === "read"){ p.armL.rotation.x = p.armR.rotation.x = -1.2; p.head.rotation.x = .35; }
      else if (p.act === "talk"){ p.armR.rotation.x = -.6 + s * .35; p.head.rotation.y = Math.sin(t * .8 + p.phase) * .4; }
      else if (p.act === "order"){ p.armR.rotation.x = -1.3 + s * .3; }
      else if (p.act === "phone"){ p.armR.rotation.x = -1.8; p.head.rotation.x = .3; }
      else if (p.act === "lean"){ p.armL.rotation.x = p.armR.rotation.x = -.9; p.g.rotation.x = .08; p.head.rotation.y = Math.sin(t * .3 + p.phase) * .6; }
      else if (p.act === "water"){ p.armR.rotation.x = -1 + s * .2; p.armR.rotation.z = -.3 - Math.max(0, s) * .4; p.head.rotation.x = .4; }
      else if (p.act === "pace"){ const u = Math.sin(t * .35 + p.phase); p.g.position.x = (p.px || 0) + u * .75; p.g.rotation.y = Math.cos(t * .35 + p.phase) > 0 ? Math.PI / 2 : -Math.PI / 2; p.armL.rotation.x = Math.sin(t * 4) * .3; p.armR.rotation.x = -Math.sin(t * 4) * .3; }
      else if (p.act === "guitar"){ p.armR.rotation.x = -.9 + Math.sin(t * 7 + p.phase) * .25; p.armL.rotation.x = -1.3; p.head.rotation.x = .25; }
      else if (p.act === "knit"){ p.armL.rotation.x = p.armR.rotation.x = -1.1 + Math.sin(t * 5 + p.phase) * .1; p.head.rotation.x = .35; }
      else if (p.act === "eat"){ p.armR.rotation.x = -1.1 - Math.max(0, s) * .8; }
      else if (p.act === "telescope"){ p.armR.rotation.x = -1.6; p.head.rotation.x = -.35; p.head.rotation.y = .3; }
      else if (p.act === "grill"){ p.armR.rotation.x = -1.1 + Math.sin(t * 2 + p.phase) * .3; p.head.rotation.x = .3; }
      else if (p.act === "paint"){ p.armR.rotation.x = -1.4 + Math.sin(t * 1.3 + p.phase) * .3; p.armR.rotation.z = Math.sin(t * .9 + p.phase) * .3; }
      else if (p.act === "yoga"){ const u = (Math.sin(t * .25 + p.phase) * .5 + .5); p.armL.rotation.z = u * 2.6; p.armR.rotation.z = -u * 2.6; p.g.rotation.x = u * .15; }
      else if (p.act === "wave"){ p.armR.rotation.x = -2.6; p.armR.rotation.z = -.4 + Math.sin(t * 6 + p.phase) * .5; }
      else if (p.act === "shake"){ p.armR.rotation.x = -1.3 + Math.sin(t * 9 + p.phase) * .3; }
      else if (p.act === "stretch"){ const u = Math.max(0, Math.sin(t * .4 + p.phase)); p.armL.rotation.x = p.armR.rotation.x = -3 * u; }
      else if (p.act === "smoke"){ const u = Math.max(0, Math.sin(t * .5 + p.phase)); p.armR.rotation.x = -.3 - u * 1.6; p.head.rotation.y = Math.sin(t * .2 + p.phase) * .5; }
      else p.head.rotation.y = Math.sin(t * .4 + p.phase) * .5;
    }
    for (const v of L.vendors){ v.armL.rotation.x = v.armR.rotation.x = -.8 + Math.sin(t * 2 + v.phase) * .25; v.head.rotation.y = Math.sin(t * .5 + v.phase) * .5; }
    const night = World.timeDef && (World.timeDef.id === "night" || World.timeDef.id === "blue");
    for (const l of L.lamps) l.material.emissiveIntensity = night ? 1.8 : 0;
  }

  function inBuilding(x, z){ for (const c of (World.colliders || [])){ if ((c.x1 - c.x0) > 8 && (c.z1 - c.z0) > 8 && x > c.x0 + .6 && x < c.x1 - .6 && z > c.z0 + .6 && z < c.z1 - .6) return true; } return false; }
  function vehicleGuard(){
    const list = [];
    try{ for (const c of Life.cars) list.push(c); }catch(e){}
    try{ if (typeof PLAY !== "undefined" && PLAY.veh) for (const k in PLAY.veh) list.push(PLAY.veh[k]); }catch(e){}
    try{ if (window.CS131 && CS131.special) for (const v of CS131.special) list.push(v); }catch(e){}
    for (const v of list){ if (!v || !v.g) continue; const x = v.g.position.x, z = v.g.position.z; const bad = inBuilding(x, z); if (bad && v.g.visible){ v.g.visible = false; v._hiddenByGuard = true; } else if (!bad && v._hiddenByGuard){ v.g.visible = true; v._hiddenByGuard = false; } }
  }
  let sweepT = 0;
  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{
        if (!L.built) build();
        if ((sweepT -= dt) <= 0){ sweepT = .5; sweepEvents(); vehicleGuard(); if (typeof S !== "undefined" && S) migrate(S); }
        animate(performance.now() / 1000);
      }catch(e){ console.warn("[Snap City 47]", e); }
      return r;
    };
  }
  const iv = setInterval(() => { try{ build(); if (L.built) clearInterval(iv); }catch(e){} }, 700);
})();

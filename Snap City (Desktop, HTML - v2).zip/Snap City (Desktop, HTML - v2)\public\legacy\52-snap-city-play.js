(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const K = SC.v52 = { built: false, swings: [], seesaws: [], rounds: [], sliders: [], kids: [], ducks: [], people: [], culled: [], cullReady: false };
  const rnd = (a, b) => a + Math.random() * (b - a), pick = a => a[(Math.random() * a.length) | 0];
  const mats = {}; const m = (c, r, mt) => mats[[c, r, mt].join("|")] || (mats[[c, r, mt].join("|")] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: r ?? .7, metalness: mt || 0 }));
  const BOX = new THREE.BoxGeometry(1,1,1), CYL = new THREE.CylinderGeometry(.5,.5,1,12), SPH = new THREE.SphereGeometry(.5,12,8);
  const part = (g, geo, mm, x, y, z, sx, sy, sz) => { const o = new THREE.Mesh(geo, mm); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; g.add(o); return o; };
  const gy = (x, z) => { try{ return groundY(x, z); }catch(e){ return H(x, z) + .16; } };
  const kid = (seed, seated) => { const p = SC.makePerson ? SC.makePerson(seed | 0, !!seated) : null; if (p) p.g.scale.multiplyScalar(rnd(.55, .7)); return p; };
  const adult = (seed, seated) => SC.makePerson ? SC.makePerson(seed | 0, !!seated) : null;

  function migrate(s){ if (s && s.custom){ s.custom.overlayLayers = { thirds:true, subject:true, leading:true, dof:true, clipping:true, motion:true, heatmap:true }; s.custom.editorOverlays = "on"; if (!s.custom.detailDistance) s.custom.detailDistance = "medium"; } return s; }
  if (typeof loadState === "function"){ const b = loadState; window.loadState = function(){ return migrate(b.apply(this, arguments)); }; }
  if (typeof defaultState === "function"){ const b = defaultState; window.defaultState = function(){ return migrate(b.apply(this, arguments)); }; }

  function playground(pg){
    const root = new THREE.Group(); root.position.set(pg.x, pg.y, pg.z); root.userData.mergeStatic = true; G.scene.add(root);
    const red = m("#c0362c", .5, .3), blue = m("#2f7fc1", .5, .3), yel = m("#e8b82e", .5, .2), steel = m("#9aa0a6", .4, .6);
    const sx = -4, sz = -3.2;
    for (const e of [-1, 1]){ const a = part(root, CYL, red, sx + e * 2.6, 1.3, sz - .7, .1, 2.8, .1); a.rotation.x = .25; const b = part(root, CYL, red, sx + e * 2.6, 1.3, sz + .7, .1, 2.8, .1); b.rotation.x = -.25; }
    part(root, CYL, red, sx, 2.65, sz, .12, 5.4, .12).rotation.z = Math.PI / 2;
    for (let k = 0; k < 3; k++){
      const pivot = new THREE.Group(); pivot.position.set(sx - 1.7 + k * 1.7, 2.65, sz); root.add(pivot);
      for (const e of [-1, 1]) part(pivot, CYL, steel, e * .25, -1.0, 0, .02, 2.0, .02);
      part(pivot, BOX, m("#1a1a1a", .8), 0, -2.0, 0, .6, .05, .25);
      let rider = null; if (Math.random() < .8){ rider = kid(pg.x * 7 + k, true); rider.g.position.set(0, -2.35, -.1); rider.armL.rotation.x = rider.armR.rotation.x = -2.6; pivot.add(rider.g); }
      K.swings.push({ pivot, rider, ph: Math.random() * 6, amp: rnd(.35, .7) });
    }
    const lx = 3.5, lz = -3;
    part(root, BOX, yel, lx, 1.5, lz, 1.4, .1, 1.4); for (const [dx, dz] of [[-.65,-.65],[.65,-.65],[-.65,.65],[.65,.65]]) part(root, CYL, blue, lx + dx, .75, lz + dz, .1, 1.5, .1);
    const roof = part(root, new THREE.ConeGeometry(1.1, .9, 4), red, lx, 2.9, lz, 1, 1, 1); roof.rotation.y = Math.PI / 4; for (const [dx, dz] of [[-.65,-.65],[.65,-.65],[-.65,.65],[.65,.65]]) part(root, CYL, blue, lx + dx, 2.0, lz + dz, .06, 1, .06);
    for (let k = 0; k < 5; k++) part(root, BOX, steel, lx - .8 - k * .01, .3 + k * .3, lz + .9, .6, .04, .1);
    const slide = part(root, BOX, yel, lx + 1.9, .8, lz, 3.0, .06, .7); slide.rotation.z = -.5; for (const e of [-1, 1]) { const r2 = part(root, BOX, yel, lx + 1.9, .95, lz + e * .37, 3.0, .2, .04); r2.rotation.z = -.5; }
    const slider = kid(pg.z * 3, false); slider.g.position.set(lx, 1.55, lz); root.add(slider.g); K.sliders.push({ p: slider, x0: lx, y0: 1.55, lz, t: Math.random() * 6, climb: lx - .8 });
    const ssx = 3.5, ssz = 3.2; part(root, BOX, steel, ssx, .3, ssz, .3, .6, .3);
    const beam = new THREE.Group(); beam.position.set(ssx, .62, ssz); root.add(beam); part(beam, BOX, blue, 0, 0, 0, 4.2, .1, .3);
    const riders = []; for (const e of [-1, 1]){ const k2 = kid(pg.x * 11 + e, true); k2.g.position.set(e * 1.8, .05, 0); k2.g.rotation.y = e > 0 ? -Math.PI / 2 : Math.PI / 2; k2.armL.rotation.x = k2.armR.rotation.x = -1.2; beam.add(k2.g); riders.push(k2); }
    K.seesaws.push({ beam, ph: Math.random() * 6 });
    const mg = new THREE.Group(); mg.position.set(-3.5, .1, 3.2); root.add(mg); part(mg, CYL, red, 0, .15, 0, 3, .12, 3); part(mg, CYL, steel, 0, .6, 0, .1, 1, .1);
    for (let k = 0; k < 4; k++){ const a = k / 4 * 6.283; const bar = part(mg, BOX, steel, Math.cos(a) * .75, .7, Math.sin(a) * .75, .05, .05, 1.5); bar.rotation.y = -a; }
    for (let k = 0; k < 2 + ((Math.random() * 2) | 0); k++){ const a = k / 3 * 6.283, c = kid(pg.x * 13 + k, true); c.g.position.set(Math.cos(a) * 1.05, .22, Math.sin(a) * 1.05); c.g.rotation.y = -a; c.armL.rotation.x = c.armR.rotation.x = -1.4; mg.add(c.g); }
    K.rounds.push({ mg, sp: rnd(.8, 1.6) });
    for (let k = 0; k < 2; k++){ const c = kid(pg.z * 17 + k, true); c.g.position.set(4.5 + (k ? .8 : -.6), -.2, 3 + (k ? .5 : -.4)); c.g.rotation.y = Math.random() * 6; root.add(c.g); K.kids.push({ p: c, act: "dig" }); }
    const nRun = pg.grove ? 7 : 4;
    for (let k = 0; k < nRun; k++){ const c = kid(pg.x * 19 + k * 3, false); root.add(c.g); K.kids.push({ p: c, act: "run", cx: rnd(-5, 5), cz: rnd(-4, 4), r: rnd(1.5, 4), sp: rnd(.8, 1.6) * (Math.random() < .5 ? 1 : -1), ph: Math.random() * 6, tag: k % 3 === 0 }); }
    for (let k = 0; k < (pg.grove ? 6 : 4); k++){ const a = adult(pg.x * 23 + k, k % 2 === 0); const edge = k % 4; a.g.position.set(edge === 0 ? -7.8 : edge === 1 ? 7.8 : rnd(-5, 5), 0, edge < 2 ? rnd(-4, 4) : (edge === 2 ? -6.3 : 6.3)); a.g.lookAt(root.position.x, root.position.y + a.g.position.y, root.position.z); root.add(a.g); if (k % 2 === 0) a.g.position.y -= .35; K.people.push({ p: a, act: pick(["watch","phone","watch","wave","coffee"]) }); }
  }

  function grove(pond){
    const root = new THREE.Group(); root.userData.mergeStatic = true; G.scene.add(root);
    const n = pond.grove ? 16 : 5;
    for (let k = 0; k < n; k++){
      const mother = k % 5 === 0 && pond.grove, d = new THREE.Group(), body = mother ? m("#6b5a3a", .8) : m(pick(["#f2efe6","#6b5a3a","#f2efe6"]), .7);
      part(d, SPH, body, 0, 0, 0, .38, .24, .55); part(d, SPH, mother ? m("#2f6a3a", .6) : body, 0, .2, .24, .18, .18, .18); part(d, BOX, m("#e89a2e", .6), 0, .18, .38, .08, .04, .12);
      d.position.set(pond.x, gy(pond.x, pond.z) + .2, pond.z); root.add(d);
      const ducklings = [];
      if (mother){ for (let q = 0; q < 4; q++){ const dl = new THREE.Group(); part(dl, SPH, m("#e8d06a", .8), 0, 0, 0, .16, .12, .2); part(dl, SPH, m("#e8d06a", .8), 0, .1, .1, .09, .09, .09); root.add(dl); ducklings.push(dl); } }
      K.ducks.push({ d, px: pond.x, pz: pond.z, rx: pond.rx - 1.2, rz: pond.rz - 1.2, a: Math.random() * 6, sp: rnd(.08, .22) * (Math.random() < .5 ? 1 : -1), ducklings, y: gy(pond.x, pond.z) + .2, dip: Math.random() * 20 });
    }
    if (!pond.grove || !SC.makePerson) return;
    const pr = Math.max(pond.rx, pond.rz) + 4;
    for (let k = 0; k < 10; k++){
      const a = Math.random() * 6.283, x = pond.x + Math.cos(a) * rnd(pr, pr + 16), z = pond.z + Math.sin(a) * rnd(pr * .8, pr + 14), act = pick(["nap","read","picnic","picnic","feed","talk","guitar","sketch"]);
      const seated = act !== "feed", p = adult(x * 13 + k, seated); p.g.position.set(x, gy(x, z) - (seated ? .35 : 0), z); p.g.lookAt(pond.x, p.g.position.y, pond.z); root.add(p.g);
      if (act === "nap"){ p.g.rotation.x = -1.35; p.g.position.y = gy(x, z) + .25; }
      if (act === "picnic"){ part(root, BOX, m(pick(["#c0362c","#2f7fc1","#e8b82e"]), .9), x + .6, gy(x, z) + .03, z, 2, .02, 1.6); const q = adult(x * 17, true); q.g.position.set(x + 1.2, gy(x, z) - .35, z + .4); q.g.lookAt(x, q.g.position.y, z); root.add(q.g); K.people.push({ p: q, act: "eat" }); }
      if (act === "guitar") part(p.g, BOX, m("#8a5a2a"), .05, .75, .25, .34, .12, .5).rotation.z = .9;
      K.people.push({ p, act });
    }
  }

  const CULL = { near: 90, medium: 150, far: 240 };
  function cullDist(){ const d = (typeof S !== "undefined" && S && S.custom.detailDistance) || "medium"; return CULL[d] || 150; }
  function mergeStatic(root){
    const buckets = new Map();
    for (const c of [...root.children]){ if (!c.isMesh || c.isInstancedMesh || !c.material || c.material.transparent || c.userData.keep) continue; if (!buckets.has(c.material)) buckets.set(c.material, []); buckets.get(c.material).push(c); }
    for (const [mat, list] of buckets){
      if (list.length < 2) continue;
      let n = 0; const geos = list.map(c => { c.updateMatrix(); let g = c.geometry.index ? c.geometry.toNonIndexed() : c.geometry.clone(); g.applyMatrix4(c.matrix); n += g.attributes.position.count; return g; });
      const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3); let o = 0;
      for (const g of geos){ pos.set(g.attributes.position.array, o * 3); if (g.attributes.normal) nor.set(g.attributes.normal.array, o * 3); o += g.attributes.position.count; g.dispose(); }
      const out = new THREE.BufferGeometry(); out.setAttribute("position", new THREE.BufferAttribute(pos, 3)); out.setAttribute("normal", new THREE.BufferAttribute(nor, 3)); out.computeBoundingSphere();
      const mesh = new THREE.Mesh(out, mat); mesh.castShadow = true; mesh.receiveShadow = true;
      for (const c of list) root.remove(c);
      root.add(mesh);
    }
  }
  function prepareCulling(){
    for (const o of G.scene.children) if (o.userData && o.userData.mergeStatic){ try{ mergeStatic(o); }catch(e){} }
    const E = (SC.island && SC.island.edge) || 500, skip = new Set();
    try{ for (const c of Life.cars) skip.add(c.g); }catch(e){}
    try{ for (const g of (SC.v51 && SC.v51.groups) || []) skip.add(g.g); }catch(e){}
    const box = new THREE.Box3(), sph = new THREE.Sphere();
    for (const o of G.scene.children){
      if (skip.has(o) || o.isLight || o.isInstancedMesh || o.isPoints || o.isSprite || o.userData._noCull) continue;
      if (!(o.isGroup || o.isMesh)) continue;
      box.setFromObject(o); if (box.isEmpty()) continue; box.getBoundingSphere(sph);
      if (sph.radius > 30) continue;
      if (Math.abs(sph.center.x) > E + 5 || Math.abs(sph.center.z) > E + 5) continue;
      if (sph.center.y > 60) continue;
      K.culled.push({ o, off: sph.center.clone().sub(o.position), r: sph.radius });
    }
    K.cullReady = true;
  }
  K.prepare = () => { if (!K.cullReady) prepareCulling(); };
  let cullT = 0;
  const cam = new THREE.Vector3();
  function cullTick(dt){
    if (!K.cullReady || (cullT -= dt) > 0) return; cullT = .4;
    cam.copy(G.cam.position); const D = cullDist();
    for (const c of K.culled){
      const x = c.o.position.x + c.off.x, z = c.o.position.z + c.off.z, far = Math.hypot(x - cam.x, z - cam.z) - c.r > D;
      if (far){ if (c.o.visible){ c.o.visible = false; c.o.userData._culled = true; } }
      else if (c.o.userData._culled){ c.o.visible = true; c.o.userData._culled = false; }
    }
  }

  if (typeof menuSettings === "function"){
    const base = menuSettings;
    window.menuSettings = function(){
      migrate(S); const c = S.custom;
      const row = `<div class="formrow"><label>Detail distance</label><div class="seg" data-seg44="detailDistance">${[["near","Near"],["medium","Medium"],["far","Far"]].map(([v,l]) => `<button data-v="${v}" aria-pressed="${c.detailDistance===v}">${l}</button>`).join("")}</div><span class="spec">How far away small things (people on balconies, props, stalls, boats near the shore) keep being drawn. Near is fastest.</span></div>`;
      return row + base.apply(this, arguments);
    };
  }

  function build(){
    if (K.built || typeof G === "undefined" || !G.scene || typeof World === "undefined" || !World.lots || !World.lots.length || !SC.makePerson) return;
    K.built = true;
    try{ for (const pg of (World.playgrounds || [])) playground(pg); }catch(e){ console.warn("[Snap City 52] playground", e); }
    try{ for (const p of (World.ponds || [])) grove(p); }catch(e){ console.warn("[Snap City 52] grove", e); }
  }
  function tick(dt, t){
    for (const s of K.swings){ s.pivot.rotation.x = Math.sin(t * 2.1 + s.ph) * s.amp; }
    for (const s of K.seesaws){ s.beam.rotation.z = Math.sin(t * 1.3 + s.ph) * .28; }
    for (const r of K.rounds){ r.mg.rotation.y += dt * r.sp; }
    for (const s of K.sliders){ s.t += dt; const u = (s.t % 5) / 5, p = s.p;
      if (u < .45){ const v = u / .45; p.g.position.set(s.climb, .3 + v * 1.25, s.lz + .9); p.g.rotation.y = Math.PI; const sw = Math.sin(t * 8) * .6; p.armL.rotation.x = -1.6 + sw; p.armR.rotation.x = -1.6 - sw; }
      else if (u < .55){ p.g.position.set(s.x0, s.y0, s.lz); p.g.rotation.y = -Math.PI / 2; p.armL.rotation.x = p.armR.rotation.x = -2.5; }
      else { const v = Math.min(1, (u - .55) / .25); p.g.position.set(s.x0 + .6 + v * 2.6, s.y0 - v * 1.35, s.lz); p.g.rotation.y = -Math.PI / 2; p.armL.rotation.x = p.armR.rotation.x = -2.8; } }
    for (const k of K.kids){ const p = k.p;
      if (k.act === "run"){ k.ph += dt * k.sp; const x = k.cx + Math.cos(k.ph) * k.r, z = k.cz + Math.sin(k.ph * (k.tag ? 1.7 : 1)) * k.r * .7; p.g.position.set(x, 0, z); p.g.rotation.y = Math.atan2(-Math.sin(k.ph) * k.sp, Math.cos(k.ph) * k.sp); const sw = Math.sin(t * 11 + k.ph) * .9; p.armL.rotation.x = sw; p.armR.rotation.x = -sw; }
      else { p.armR.rotation.x = -1.2 + Math.max(0, Math.sin(t * 3 + p.phase)) * .6; p.head.rotation.x = .45; } }
    for (const q of K.people){ const p = q.p, s = Math.sin(t * 1.6 + p.phase);
      if (q.act === "wave"){ p.armR.rotation.x = -2.6; p.armR.rotation.z = -.4 + Math.sin(t * 6 + p.phase) * .5; }
      else if (q.act === "phone"){ p.armR.rotation.x = -1.8; p.head.rotation.x = .3; }
      else if (q.act === "coffee" || q.act === "eat"){ p.armR.rotation.x = -1.1 - Math.max(0, s) * .8; }
      else if (q.act === "read" || q.act === "sketch"){ p.armL.rotation.x = p.armR.rotation.x = -1.2; p.head.rotation.x = .35; if (q.act === "sketch") p.armR.rotation.z = Math.sin(t * 3) * .2; }
      else if (q.act === "feed"){ p.armR.rotation.x = -1 + Math.max(0, Math.sin(t * 2 + p.phase)) * .6; p.head.rotation.x = .45; }
      else if (q.act === "guitar"){ p.armR.rotation.x = -.9 + Math.sin(t * 7) * .25; p.armL.rotation.x = -1.3; }
      else if (q.act === "talk" || q.act === "picnic"){ p.armR.rotation.x = -.6 + s * .35; p.head.rotation.y = Math.sin(t * .8 + p.phase) * .4; }
      else if (q.act !== "nap") p.head.rotation.y = Math.sin(t * .4 + p.phase) * .5; }
    for (const d of K.ducks){ d.a += dt * d.sp; const x = d.px + Math.cos(d.a) * d.rx, z = d.pz + Math.sin(d.a) * d.rz; d.d.position.set(x, d.y + Math.sin(t * 2 + d.dip) * .02, z); d.d.rotation.y = Math.atan2(-Math.sin(d.a) * d.sp, Math.cos(d.a) * d.sp);
      d.d.rotation.x = ((t + d.dip) % 12) < .8 ? .9 : 0;
      d.ducklings.forEach((dl, i) => { const b = d.a - Math.sign(d.sp) * (i + 1) * .09; dl.position.set(d.px + Math.cos(b) * d.rx, d.y - .05, d.pz + Math.sin(b) * d.rz); dl.rotation.y = d.d.rotation.y; }); }
  }

  const ready = () => {
    const w = SC;
    return K.built && (!w.street47 || w.street47.built) && (!w.z48 || w.z48.built) && (!w.sea50 || w.sea50.built) && (!w.v51 || w.v51.built) && (!w.city || w.city.built) && (!w.life || w.life.built);
  };
  if (typeof boot === "function"){
    const base = boot;
    window.boot = async function(){
      const r = await base.apply(this, arguments);
      const btns = ["#startCareer", "#startFree", "#continueBtn"].map(q => document.querySelector(q)).filter(Boolean);
      const msg = document.querySelector("#loadmsg"), finalMsg = msg ? msg.textContent : "Ready.", cont = document.querySelector("#continueBtn"), contShown = cont && !cont.classList.contains("hidden");
      btns.forEach(b => b.disabled = true); if (cont) cont.classList.add("hidden");
      try{ setLoad(0.93, "Filling the streets"); }catch(e){}
      const t0 = performance.now();
      while (!ready() && performance.now() - t0 < 25000){ try{ build(); }catch(e){} await new Promise(res => setTimeout(res, 150)); }
      try{ setLoad(0.97, "Tidying up"); }catch(e){}
      await new Promise(res => setTimeout(res, 30));
      try{ prepareCulling(); }catch(e){ console.warn("[Snap City 52] prepare", e); }
      try{ G.renderer.compile(G.scene, G.cam); }catch(e){}
      try{ setLoad(1, finalMsg); }catch(e){}
      btns.forEach(b => b.disabled = false); if (cont && contShown){ cont.classList.remove("hidden"); cont.focus(); }
      return r;
    };
  }
  if (typeof startGame === "function"){ const b = startGame; window.startGame = function(){ const r = b.apply(this, arguments); cullT = 0; return r; }; }
  let started = 0;
  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{
        if (!K.built) build();
        if (typeof S !== "undefined" && S && Game.started){ started += dt; if (!K.cullReady && started > 6) prepareCulling(); }
        cullTick(dt);
        tick(dt, performance.now() / 1000);
      }catch(e){ console.warn("[Snap City 52]", e); }
      return r;
    };
  }
  const iv = setInterval(() => { try{ build(); if (K.built) clearInterval(iv); }catch(e){} }, 700);
})();

(function(){
"use strict";
const CS147 = window.CS147 = { frame:0, lastRefl:0, lastCull:0, applied:false };

function leanDefaults(){
  if(!window.S || !S.custom) return;

  if(!S.custom._v147LeanApplied) S.custom._v147LeanApplied = true;
}

if(window.Refl && typeof Refl.render === 'function'){
  const _refl147 = Refl.render.bind(Refl);
  Refl.render = function(cam){
    const perf = window.S && S.custom && S.custom.renderQuality === 'performance';
    const liveCam = window.G && cam === G.cam;
    if(perf && liveCam){
      CS147.frame++;
      if((CS147.frame % 4) !== 0 && !(S.rain||S.storm)) return;
    }
    return _refl147(cam);
  };
}

function cheapDynamicShadows(){

  if(window.S && S.custom && (S.custom.renderQuality==='ultra' || S.custom.renderQuality==='cinematic')) return;
  try{
    if(typeof PI_ !== 'undefined' && PI_){
      Object.values(PI_).forEach(m=>{ if(m && m.isInstancedMesh){ m.castShadow=false; m.receiveShadow=true; } });
    }
    if(window.Life && Life.dogMeshes) Object.values(Life.dogMeshes).forEach(m=>{ if(m){ m.castShadow=false; } });
    if(window.CS142 && CS142.shopPeople) CS142.shopPeople.forEach(p=>p.g&&p.g.traverse(o=>{if(o.isMesh)o.castShadow=false;}));
    if(window.CS14 && CS14.windowPeople) CS14.windowPeople.forEach(p=>p.g&&p.g.traverse(o=>{if(o.isMesh)o.castShadow=false;}));
  }catch(e){}
}

function cullExtras(){
  try{
    if(window.CS145){
      while(CS145.acts && CS145.acts.length>8){ const a=CS145.acts.shift(); if(a&&a.g&&window.G) G.scene.remove(a.g); }
      while(CS145.events && CS145.events.length>1){ const a=CS145.events.shift(); if(a&&a.g&&window.G) G.scene.remove(a.g); }
      if(CS145.acts && CS145.acts.length>=8) CS145.ambientTimer=Math.max(CS145.ambientTimer||0,7);
      if(CS145.events && CS145.events.length>=1) CS145.eventTimer=Math.max(CS145.eventTimer||0,20);
    }
    if(window.CS146 && CS146.scenes){
      while(CS146.scenes.length>2){ const s=CS146.scenes.shift(); if(s&&s.g&&window.G) G.scene.remove(s.g); }
      for(const s of CS146.scenes){
        if(!s||!s.g) continue;
        const d=Math.hypot((s.x||s.g.position.x)-Player.x,(s.z||s.g.position.z)-Player.z);
        s.g.visible=d<75;
      }
    }
  }catch(e){}
}

function distanceSleep(){
  try{
    if(window.CS142 && CS142.shopPeople){
      for(const p of CS142.shopPeople){ if(!p.g)continue; const d=Math.hypot(p.g.position.x-Player.x,p.g.position.z-Player.z); p.g.visible=d<80; }
    }
    if(window.CS14 && CS14.windowPeople){
      for(const p of CS14.windowPeople){ if(!p.g)continue; const d=Math.hypot(p.g.position.x-Player.x,p.g.position.z-Player.z); p.g.visible=d<90; }
    }
  }catch(e){}
}

function leanSnow(){
  try{
    if(!window.Snow || !Snow.mesh || !Snow.mesh.geometry || !Snow.mesh.geometry.getAttribute) return;
    const pos=Snow.mesh.geometry.getAttribute('position');
    if(pos && S.custom.renderQuality==='performance' && pos.count>1600){
      Snow.mesh.geometry.setDrawRange(0,1600);
    } else if(pos) Snow.mesh.geometry.setDrawRange(0,pos.count);
  }catch(e){}
}

let acc=0;
if(typeof gameplayUpdate==='function'){
  const _gp147=gameplayUpdate;
  gameplayUpdate=function(dt){
    const r=_gp147.apply(this,arguments);
    acc+=dt;
    if(acc>0.35){ acc=0; leanDefaults(); cullExtras(); distanceSleep(); leanSnow(); }
    return r;
  };
}

function apply147(){
  if(CS147.applied)return; CS147.applied=true;
  leanDefaults();
  setTimeout(()=>{ cheapDynamicShadows(); leanSnow(); cullExtras(); },800);
  setTimeout(()=>{ cheapDynamicShadows(); },3500);
  console.log('[Contact Sheet v14.7 LEAN] performance pass active.');
}
setTimeout(apply147,50);
})();

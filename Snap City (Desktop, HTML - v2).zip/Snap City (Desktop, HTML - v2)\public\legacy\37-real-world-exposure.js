(function(){
  "use strict";
  const EXPOSURE_DEFAULTS = {
    perfectExposureMode:"off", exposurePriority:"balanced", protectHighlights:"on",
    exposureMetering:"center-weighted"
  };

  function ensureExposureSettings(){
    if(!window.S) return;
    S.custom = S.custom || {};
    for(const k in EXPOSURE_DEFAULTS) if(S.custom[k] === undefined) S.custom[k] = EXPOSURE_DEFAULTS[k];
  }
  function ev100(N, t, iso){ return Math.log2((100*N*N)/(iso*t)); }
  function status(error){
    if(error >= 3) return "severely under";
    if(error >= 1.25) return "under";
    if(error >= .35) return "slightly under";
    if(error > -.35) return "correct";
    if(error > -1.25) return "slightly over";
    if(error > -3) return "over";
    return "severely over";
  }
  function meterOffset(){
    const mode=(S.custom&&S.custom.exposureMetering)||"center-weighted";
    const sky=Cam&&Cam.skyFrac||0;

    if(mode === "spot") return 0;
    if(mode === "matrix") return sky*.28;
    return sky*.12;
  }
  function realMeterEV(){
    return sceneEV() + meterOffset();
  }
  function activeFilmBias(){
    const film=curFilm&&curFilm();

    return film && film.iso >= 640 && film.k !== "slide" ? .33 : 0;
  }
  function applyPerfectExposure(){
    if(!S || !S.custom || S.custom.perfectExposureMode !== "auto-perfect") return;
    const b=curBody(), st=S.set;
    if(!b || b.fx) return;
    const film=curFilm(), iso=Math.round(film.iso*Math.pow(2,st.push||0));

    const fStops=typeof filterStops === "function" ? filterStops() : 0;
    const target=realMeterEV() - fStops - activeFilmBias() + (S.custom.protectHighlights === "on" ? .33 : 0);
    const aList=apertures(), minA=aList[0], maxA=aList[aList.length-1];
    const priority=S.custom.exposurePriority || "balanced";
    const preferredT=priority === "freeze-motion" ? 1/250 : priority === "handheld" || priority === "shallow-depth" ? 1/60 : priority === "deep-depth" ? 1/30 : 1/125;
    let best=null, score=Infinity;
    for(const N of aList){
      for(const T of SHUTTERS){
        const t=typeof T === "number" ? T : T.t;
        if(!(t>0) || t<1/b.ts || t>1) continue;
        const e=ev100(N,t,iso), err=e-target;
        const shutterCost=Math.abs(Math.log2(t/preferredT));
        const apertureCost=priority === "shallow-depth" ? Math.max(0,Math.log2(N/minA)) : priority === "deep-depth" ? Math.max(0,Math.log2(maxA/N)) : 0;
        const q=Math.abs(err)*20 + shutterCost + apertureCost;
        if(q<score){score=q;best={N,t};}
      }
    }
    if(best){ st.mode="M"; st.A=best.N; st.T=best.t; }
  }

  const baseCompute=window.computeExposure;
  if(typeof baseCompute === "function"){
    window.computeExposure=function(){
      ensureExposureSettings();
      applyPerfectExposure();
      const e=baseCompute.apply(this,arguments);
      if(!e) return e;
      const metered=realMeterEV();
      const camera=ev100(e.N,e.t,e.iso);
      const compensation=Number(S.set.ev||0);
      const effectiveCamera=camera-compensation;

      const fStops=typeof filterStops === "function" ? filterStops() : 0;
      const error=effectiveCamera-(metered-fStops);
      e.sceneEV100=metered;
      e.cameraEV100=camera;
      e.effectiveCameraEV100=effectiveCamera;
      e.exposureErrorEV=error;

      let judged=error;
      if(e.flashOn && typeof curFlash === "function"){
        const fl=curFlash(), gn=fl && fl.gn || 0;
        const d=Math.max(0.5, (typeof Cam !== "undefined" && (Cam.afTarget || Cam.focus)) || 3);
        if(gn>0){
          const nIdeal=gn*Math.sqrt(e.iso/100)/d, flashErr=2*Math.log2(e.N/nIdeal);
          judged=-Math.log2(Math.pow(2,-error)+Math.pow(2,-flashErr));
          e.flashErrorEV=flashErr; e.flashDistance=d;
        }
      }
      e.subjectErrorEV=judged;
      e.exposureStatus=status(judged);
      e.exposureQuality=Math.max(0,Math.round(100-Math.abs(judged)*24));
      e.meteringMode=S.custom.exposureMetering;

      e.offset=-error;
      e.mult=Math.pow(2,e.offset);
      return e;
    };
  }

  function recommendedExposure(){
    const old=S.custom.perfectExposureMode;
    S.custom.perfectExposureMode="auto-perfect";
    applyPerfectExposure();
    S.custom.perfectExposureMode=old;
    const e=computeExposure();
    UI.hudT=0; saveState();
    toast(`Perfect exposure: ${fmtA(e.N)} · ${fmtShutter(e.t)} · ISO ${e.iso}. Meter ${e.sceneEV100.toFixed(1)} EV100.`,2600);
  }

  const oldMenu=window.menuSettings;
  if(typeof oldMenu === "function"){
    window.menuSettings=function(){
      ensureExposureSettings();
      const c=S.custom;
      const seg=(key,opts)=>`<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
      const panel=`<div class="sectionhead">Real-world Exposure</div>
      <div class="formrow"><label>Exposure meter</label>${seg("exposureMetering",[["matrix","Matrix"],["center-weighted","Center"],["spot","Spot"]])}<span class="spec">Measures reflected scene light in EV100. Center-weighted is the default street-photography meter.</span></div>
      <div class="formrow"><label>Perfect exposure</label>${seg("perfectExposureMode",[["off","Off"],["meter-assist","Meter assist"],["auto-perfect","Auto-perfect"]])}<span class="spec">Meter assist explains the reading. Auto-perfect selects a real equivalent aperture/shutter/ISO combination when the camera allows it.</span></div>
      <div class="formrow"><label>Creative priority</label>${seg("exposurePriority",[["balanced","Balanced"],["freeze-motion","Freeze motion"],["handheld","Hand-held"],["shallow-depth","Shallow depth"],["deep-depth","Deep focus"]])}</div>
      <div class="formrow"><label>Protect highlights</label>${seg("protectHighlights",[["on","On"],["off","Off"]])}<span class="spec">Biases the automatic recommendation about one-third stop darker to retain bright windows, lamps, and signs.</span></div>
      <div class="formrow"><button class="btn small" data-real-expfix>Apply perfect exposure now</button><span class="spec">Uses the current metered scene EV, loaded film speed, and this camera's usable aperture and shutter range.</span></div>`;
      return panel+oldMenu.apply(this,arguments);
    };
  }
  document.addEventListener("click",function(ev){
    const b=ev.target.closest && ev.target.closest("[data-real-expfix]");
    if(!b) return;
    ev.preventDefault(); ev.stopPropagation(); ensureExposureSettings(); recommendedExposure();
  },true);

  function meterHud(){
    let d=document.getElementById("realExposureMeter");
    if(!d){ d=document.createElement("div"); d.id="realExposureMeter"; document.body.appendChild(d); }
    if(!window.Game||!Game.started||!window.S||!window.Player||Player.raise<=.55||UI.open){ d.classList.remove("on"); return; }
    ensureExposureSettings();
    const e=Cam.exp||computeExposure();
    const assist=S.custom.perfectExposureMode;
    const visible=assist !== "off" || S.custom.exposureCoach !== "off";
    d.classList.toggle("on",visible);
    if(!visible || !e) return;
    const sign=e.exposureErrorEV>0?"+":"";
    const label=assist === "auto-perfect" ? "AUTO-PERFECT" : assist === "meter-assist" ? "METER ASSIST" : "EXPOSURE";
    d.innerHTML=`<b>${label}</b><span>Meter ${e.sceneEV100.toFixed(1)} EV100 · Camera ${e.cameraEV100.toFixed(1)} · ${sign}${e.exposureErrorEV.toFixed(1)} EV ${e.exposureStatus}</span><small>${e.meteringMode} metering · EC ${(S.set.ev||0)>0?"+":""}${Number(S.set.ev||0).toFixed(1)} · ${e.exposureQuality}% meter match</small>`;
  }
  const oldUpdate=window.gameplayUpdate;
  if(typeof oldUpdate === "function") window.gameplayUpdate=function(dt){ const r=oldUpdate.apply(this,arguments); try{meterHud();}catch(err){} return r; };
  ensureExposureSettings();
  console.info("[Contact Sheet] Real-world EV100 exposure patch loaded.");
})();

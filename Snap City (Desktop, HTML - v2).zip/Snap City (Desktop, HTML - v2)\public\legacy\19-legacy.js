const Game = { started:false, last:0, t:0, bellT:8, saveT:5, titleT:0, hintOn:true };
const Input = { keys:{}, locked:false, touch:false, drag:null, joy:{x:0,y:0,id:null}, look:null, rmb:false, zHeld:false, touchRaise:false };
const EYE_FOV = 70;

function setLoad(p, msg){ $("#loadbar b").style.width = Math.round(p*100)+"%"; if (msg) $("#loadmsg").textContent = msg; }
async function boot(){
  const saved = loadState();
  S = saved || defaultState(false);
  S.custom = Object.assign({}, defaultState(false).custom, S.custom);
  try { initRenderer(); } catch(e){ $("#loadmsg").textContent = "This browser couldn't start WebGL, which the game needs."; return; }
  setLoad(0.08, "Laying out the streets");
  await new Promise(r=>setTimeout(r, 30));
  buildWorld(G.scene, p=>setLoad(0.08+p*0.7));
  setLoad(0.8, "Filling the sidewalks"); await new Promise(r=>setTimeout(r, 20));
  buildLife(G.scene);
  initFlashLight();
  Game.lampLights = []; for (let i=0;i<6;i++){ const l = new THREE.PointLight(0xffc98a, 0, 34, 2); G.scene.add(l); Game.lampLights.push(l); }
  applyTime();
  buildHeldCam(); if (heldCam) heldCam.visible = false;
  setLoad(0.9, "Loading film"); await new Promise(r=>setTimeout(r, 20));
  try { G.renderer.compile(G.scene, G.cam); } catch(e){}
  initEditorEvents(); wireStaticUI(); wireInput(); initEssayUI(); applyGraphicsQuality(); polishWorldMaterials(); applyInteriorSettings();
  setLoad(1, saved ? `Welcome back${saved.name? ", "+saved.name : ""}. ${saved.frameCount} frames on your contact sheet.` : "Ready.");
  $("#startCareer").disabled = false; $("#startFree").disabled = false;
  if (saved){ $("#continueBtn").classList.remove("hidden"); $("#continueBtn").focus(); }
  initCapabilities();
  Game.last = performance.now(); requestAnimationFrame(loop);
}
async function initCapabilities(){
  if (!window.claude || !window.claude.use) return;
  try { UI.downloads = await window.claude.use("downloads"); } catch(e){ UI.downloads = null; }
  try { UI.sample = await window.claude.use("sample"); if (UI.sample){ const caps = await UI.sample.limits().catch(()=>null); UI.sampleImages = !!(caps && caps.images); } } catch(e){ UI.sample = null; }
}
function startGame(mode){
  Audio.init();
  if (mode === "career"){ if (loadState() && !confirm("Start a new career? Your money, gear and skills reset. Photos stay on your contact sheet.")) return; S = defaultState(false); }
  else if (mode === "free"){ const old = loadState(); S = defaultState(true); if (old){ S.frameCount = old.frameCount; S.name = old.name; } }
  saveState();
  { const sp = randomStart(); Player.x = sp.x; Player.z = sp.z; Player.yaw = sp.yaw; }
  Player.pitch = 0; Player.roll = 0;
  const L = curLens(); if (L && L.f2) Player.zoomF = L.f;
  applyTime(); buildHeldCam(); drawGrid(); applyHudPref();
  $("#title").classList.add("hidden"); $("#hud").classList.remove("hidden");
  if (Input.touch) $("#touch").classList.remove("hidden");
  setHint();
  Game.started = true;
  if (!Input.touch) requestLock();
  toast(S.free ? `Free Play: ${Object.keys(BODIES).length} cameras, unlimited money, all skills. Press 1 / 2 / 3 for Quick pick, Tab for your bag.` : "You start with a disposable camera and $250. Sell good frames to build your kit.", 4200);
  setTimeout(()=>toast(S.custom.arrowLook ? "Arrow keys look around. Space shoots, Z raises the camera. V switches to the mouse." : "Click the street to look with the mouse, or press V to look with the arrow keys.", 4200), 4400);
}
function setHint(){
  const h = $("#hint");
  if (!Game.hintOn){ h.classList.add("hidden"); return; }
  h.classList.remove("hidden");
  h.innerHTML = Input.touch ? "Tap Raise, then the shutter" : Input.locked ? `<kbd>Right mouse</kbd> raise · <kbd>Click</kbd> shoot · <kbd>Tab</kbd> camera bag · <kbd>P</kbd> photos · <kbd>H</kbd> hide`
    : `Click the street to look around · <kbd>Tab</kbd> camera bag · <kbd>P</kbd> photos`;
}
function canPointerLock(){ const c = $("#view"); return !!(c && c.requestPointerLock) && !(Input.lockDenied && !Input.lockEver); }
function requestLock(){ const c = $("#view"); try { const r = c.requestPointerLock && c.requestPointerLock(); if (r && r.catch) r.catch(()=>{ if (!Input.lockEver) Input.lockDenied = true; }); } catch(e){ if (!Input.lockEver) Input.lockDenied = true; } }

function wireStaticUI(){
  $("#startCareer").onclick = ()=>startGame("career");
  $("#startFree").onclick = ()=>startGame("free");
  $("#continueBtn").onclick = ()=>startGame("continue");
  $$("#menu .tabs button").forEach(b=>b.onclick=()=>{ UI.menuTab = b.dataset.tab; renderMenu(); });
  $$("[data-close]").forEach(b=>b.onclick=()=>onPanelClosed());
  $$("#gsort button").forEach(b=>b.onclick=()=>{ UI.sort = b.dataset.sort; renderSheet(); });
  $("#judgeAll").onclick = judgeAllUnjudged;
  $("#tmenu").onclick = ()=>openMenu();
  $("#tgal").onclick = ()=>openGallery();
  $("#lightbox").addEventListener("click", ev=>{ if (ev.target.classList.contains("img")) closeLightbox(); });
}

function wireInput(){
  const cv = $("#view");
  Input.touch = matchMedia("(pointer:coarse)").matches && ("ontouchstart" in window);
  document.addEventListener("pointerlockchange", ()=>{ Input.locked = document.pointerLockElement === cv; if (Input.locked){ Input.lockEver = true; Input.lockDenied = false; } else { Input.rmb = false; } setHint(); });
  document.addEventListener("pointerlockerror", ()=>{ if (!Input.lockEver) Input.lockDenied = true; });
  cv.addEventListener("contextmenu", e=>e.preventDefault());
  cv.addEventListener("mousedown", ev=>{
    if (!Game.started || UI.open || Input.touch) return;
    Audio.init();
    if (Input.locked){
      if (ev.button === 0) captureShot();
      if (ev.button === 2) Input.rmb = true;
      return;
    }
    if (ev.button === 2){ Input.rmb = true; return; }
    const lockAsk = canPointerLock();
    Input.drag = { x:ev.clientX, y:ev.clientY, moved:0, lockAsk };
    if (lockAsk) requestLock();
  });
  addEventListener("mouseup", ev=>{
    if (ev.button === 2) Input.rmb = false;
    if (ev.button === 0 && Input.drag && !Input.locked){ if (!Input.drag.lockAsk && Input.drag.moved < 6 && Game.started && !UI.open) captureShot(); }
    Input.drag = null;
  });
  addEventListener("mousemove", ev=>{
    if (!Game.started || UI.open) return;
    const sens = 0.0023 * (G.cam.fov/EYE_FOV);
    if (Input.locked){ look(ev.movementX*sens, ev.movementY*sens); }
    else if (Input.drag){ const dx = ev.clientX - Input.drag.x, dy = ev.clientY - Input.drag.y; Input.drag.moved += Math.abs(dx)+Math.abs(dy); Input.drag.x = ev.clientX; Input.drag.y = ev.clientY; look(dx*sens*1.4, dy*sens*1.4); }
  });
  cv.addEventListener("wheel", ev=>{ if (!Game.started || UI.open) return; ev.preventDefault(); wheel(ev.deltaY); }, { passive:false });
  addEventListener("keydown", onKey);
  addEventListener("keyup", ev=>{ Input.keys[ev.code] = false; if (ev.code === "KeyZ") Input.zHeld = false; });
  addEventListener("blur", ()=>{ Input.keys = {}; Input.rmb = false; Input.zHeld = false; });

  const joy = $("#joy"), knob = joy.firstElementChild;
  joy.addEventListener("pointerdown", ev=>{ Input.joy.id = ev.pointerId; joy.setPointerCapture(ev.pointerId); joyMove(ev); });
  const joyMove = ev => { if (ev.pointerId !== Input.joy.id) return; const r = joy.getBoundingClientRect(); let x = (ev.clientX - r.left - r.width/2)/(r.width/2), y = (ev.clientY - r.top - r.height/2)/(r.height/2); const l = Math.hypot(x,y); if (l > 1){ x/=l; y/=l; } Input.joy.x = x; Input.joy.y = y; knob.style.transform = `translate(${x*40}px,${y*40}px)`; };
  joy.addEventListener("pointermove", joyMove);
  const joyEnd = ev => { if (ev.pointerId !== Input.joy.id) return; Input.joy = {x:0,y:0,id:null}; knob.style.transform = ""; };
  joy.addEventListener("pointerup", joyEnd); joy.addEventListener("pointercancel", joyEnd);
  cv.addEventListener("pointerdown", ev=>{ if (ev.pointerType !== "touch" || !Game.started) return; Audio.init(); Input.look = { id:ev.pointerId, x:ev.clientX, y:ev.clientY }; });
  cv.addEventListener("pointermove", ev=>{ if (!Input.look || ev.pointerId !== Input.look.id) return; const s = 0.005*(G.cam.fov/EYE_FOV); look((ev.clientX-Input.look.x)*s, (ev.clientY-Input.look.y)*s); Input.look.x = ev.clientX; Input.look.y = ev.clientY; });
  const lookEnd = ev => { if (Input.look && ev.pointerId === Input.look.id) Input.look = null; };
  cv.addEventListener("pointerup", lookEnd); cv.addEventListener("pointercancel", lookEnd);
  $("#traise").onclick = ()=>{ Input.touchRaise = !Input.touchRaise; $("#traise").textContent = Input.touchRaise ? "Lower" : "Raise"; };
  $("#tshoot").onclick = ()=>{ Audio.init(); captureShot(); };
}
function look(dx, dy){ const k = ({ low:0.6, normal:1, high:1.6 })[(S && S.custom.mouseSensitivity) || "normal"] || 1; dx *= k; dy *= k; Player.yaw -= dx; Player.pitch = clamp(Player.pitch - dy, -1.35, 1.35); }
function wheel(dy){
  const L = curLens();
  if (L && L.f2){ Player.zoomF = clamp(Player.zoomF * Math.exp(-dy*0.0015), L.f, L.f2); return; }
  const fk = focusKind(); if (fk==="rf"||fk==="mf"||fk==="zone"){ Cam.mfTarget = null; S.set.focus = clamp(S.set.focus * Math.exp(dy*0.0015), 0.5, 120); saveState(); }
}
function cycle(arr, v, d){ const i = arr.indexOf(v); return arr[clamp((i<0?0:i)+d, 0, arr.length-1)]; }
function randomStart(){
  for (let t=0; t<60; t++){
    const i = Math.floor(Math.random()*(2*NB+1)) - NB, j = Math.floor(Math.random()*(2*NB+1)) - NB, side = Math.floor(Math.random()*4), along = rand(-HALF+5, HALF-5), off = HALF + rand(1.8, 2.8);
    const x = i*P + (side===0 ? -off : side===1 ? off : along), z = j*P + (side===2 ? -off : side===3 ? off : along);
    if (Math.abs(x - CABLE_X) < 6) continue;
    const [cx, cz] = collidePoint(x, z, 0.4); if (Math.hypot(cx-x, cz-z) > 0.01) continue;
    const alongX = side >= 2, dir = Math.random() < 0.5 ? 1 : -1;
    return { x, z, yaw: alongX ? (dir > 0 ? -Math.PI/2 : Math.PI/2) : (dir > 0 ? Math.PI : 0) };
  }
  return { x:16, z:-HALF-2.6, yaw:Math.PI/2 };
}
function onKey(ev){
  if (ev.target && (ev.target.tagName === "INPUT" || ev.target.tagName === "TEXTAREA")) { if (ev.key === "Escape") ev.target.blur(); return; }
  let k = ev.code;

  if (!$("#lightbox").classList.contains("hidden")){
    if (k === "Escape"){ closeLightbox(); } else if (k === "ArrowLeft") lbStep(-1); else if (k === "ArrowRight") lbStep(1);
    return;
  }
  if (UI.open){
    if (k === "Escape") closeAll();
    else if ((k === "Tab" || k === "KeyM") && UI.open === "#menu"){ ev.preventDefault(); onPanelClosed(); }
    else if (k === "KeyP" && UI.open === "#gallery") onPanelClosed();
    return;
  }
  if (!Game.started) return;
  if (["Tab","Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(k)) ev.preventDefault();
  if (ev.repeat && !["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","KeyI","KeyK","KeyU","KeyO","Comma","Period","BracketLeft","BracketRight"].includes(k)) { Input.keys[k] = true; return; }
  Input.keys[k] = true;
  Audio.init();
  if (S.custom.arrowLook && k.startsWith("Arrow")) return;
  { const alias = { KeyI:"ArrowUp", KeyK:"ArrowDown", KeyU:"ArrowLeft", KeyO:"ArrowRight" }[k]; if (alias) k = alias; }
  if (k === "KeyV"){ S.custom.arrowLook = !S.custom.arrowLook; saveState(); toast(S.custom.arrowLook ? "Arrow keys look around. Aperture I / K, shutter U / O." : "Mouse look. Arrow keys set aperture and shutter again.", 2400); return; }
  const st = S.set, b = curBody(), modes = modesFor(b);
  switch (k){
    case "Space": captureShot(); break;
    case "KeyZ": Input.zHeld = true; break;
    case "Tab": case "KeyM": openMenu(); break;
    case "KeyP": openGallery(); break;
    case "KeyB": (async()=>{ const id = CAP.lastId || (S.shotLog.length? S.shotLog[S.shotLog.length-1].id : null); const rec = id ? await DB.get(id) : null; if (rec) openEditor(rec); else toast("No frame to develop yet."); })(); break;
    case "KeyH": Game.hintOn = !Game.hintOn; setHint(); break;
    case "KeyR": { const i = modes.indexOf(st.mode); st.mode = modes[(i+1)%modes.length]; toast(({P:"Program: the camera picks everything",A:"Aperture priority",S:"Shutter priority",M:"Manual"})[st.mode], 1200); break; }
    case "ArrowUp": case "ArrowDown": {
      if (b.fx){ toast("This camera's aperture and shutter are fixed. Just shoot.", 1500); break; }
      if (st.mode === "P" || st.mode === "S"){ toast(st.mode==="P" ? "Aperture is automatic in P. Press R for another mode." : "In S the camera sets the aperture. Use ← →.", 1500); break; }
      const as = apertures(); st.A = cycle(as, snapA(st.A), k==="ArrowUp" ? -1 : 1); break; }
    case "ArrowLeft": case "ArrowRight": {
      if (!b.fx && (st.mode === "S" || st.mode === "M")){ const ts = SHUTTERS.filter(t=> t >= 1/b.ts - 1e-9); const cur = ts.reduce((a,t)=>Math.abs(Math.log(t/st.T))<Math.abs(Math.log(a/st.T))?t:a, ts[0]); st.T = cycle(ts, cur, k==="ArrowLeft" ? 1 : -1); }
      else if (b.mt) st.ev = clamp(Math.round((st.ev + (k==="ArrowRight"?1/3:-1/3))*3)/3, -3, 3);
      break; }
    case "BracketLeft": case "BracketRight": if (b.mt) st.ev = clamp(Math.round((st.ev + (k==="BracketRight"?1/3:-1/3))*3)/3, -3, 3); break;
    case "Comma": case "Period": { if (b.film){ toast("You can't push a disposable.", 1200); break; } { const r = curRoll(), full = b.frames || curFormat().frames; if (r.left < full){ toast(`Push and pull are decided for the whole roll. This one is rated ${r.push ? (r.push>0?"+":"")+r.push+" stop"+(Math.abs(r.push)>1?"s":"") : "at box speed"}; change it when you load the next.`, 3000); break; } } const [pl,ph] = pushRange(); st.push = clamp((st.push||0) + (k==="Period"?1:-1), pl, ph); curRoll().push = st.push; toast(`${curFilm().n} rated at ASA ${Math.round(curFilm().iso*Math.pow(2,st.push))}${st.push? ` (${st.push>0?"push":"pull"} ${Math.abs(st.push)})`:""}`, 1400); break; }
    case "KeyT": { const fk = focusKind(); if (b.af){ st.af = !st.af; if (!st.af) st.focus = Cam.focus; toast(st.af? "Autofocus" : "Manual focus: scroll to focus", 1200); }
      else if (fk==="rf"||fk==="mf"){ Cam.mfTarget = clamp(Cam.afTarget, 0.5, 120); }
      else if (fk==="zone") toast("Scale focusing: guess the distance and scroll to set it.", 1600);
      else toast("Fixed focus: everything from a couple of metres to infinity is roughly sharp.", 1600); break; }
    case "KeyX": if (sk("zone") && !b.ff){ const e = Cam.exp || computeExposure(); if (b.af) st.af = false; st.focus = clamp(hyperfocal(e.N), 0.5, 120); Cam.mfTarget = null; const [n] = dofRange(st.focus, e.N); toast(`Zone focus: ${fmtDist(st.focus)}, sharp from ${fmtDist(n)} to infinity`, 1800); } else toast("Learn Zone master to snap to hyperfocal.", 1400); break;
    case "KeyF": if (!curFlash().gn){ toast("No flash. Buy one in the camera bag, or use a camera with a built-in flash.", 1800); } else { st.flashOn = !st.flashOn; buildHeldCam(); toast(st.flashOn ? `${curFlash().name} on` : "Flash off", 900); } break;
    case "KeyG": { const g = ["none","thirds","golden","diagonal"]; S.custom.grid = g[(g.indexOf(S.custom.grid)+1)%g.length]; drawGrid(); toast("Grid: "+S.custom.grid, 900); break; }
    case "KeyN": { if (b.L){ toast("This camera has a built-in lens.", 1200); break; } const own = S.owned.lenses.filter(l=>mountFits(b, LENSES[l])); if (own.length < 2){ toast("No other lens in the bag fits this camera.", 1400); break; } const cur = S.lensByBody[S.body]; const nx = own[(own.indexOf(cur)+1)%own.length]; equip("lenses", nx); toast("Mounted the "+LENSES[nx].n, 1200); break; }
    case "KeyL": reloadFilm(); break;
    case "Digit1": case "Digit2": case "Digit3": case "Digit4": case "Digit5": setZone(k); break;
    case "Enter": case "NumpadEnter": enterAction(); break;
    case "KeyM": GP.multi = GP.multi ? 0 : 1; toast(GP.multi ? "Multiple exposure: the next two frames land on one negative." : "Multiple exposure off.", 2200); break;
    case "Escape": if (document.pointerLockElement) document.exitPointerLock(); break;
  }
  saveState();
}

const _fwd = new THREE.Vector3();
function updatePlayer(dt){
  const K = Input.keys;
  const want = Input.rmb || Input.zHeld || Input.touchRaise;
  Player.raised = want && Player.lensSwap <= 0;
  const quick = (1 + 0.45*sk("quick"))*(1 + 0.6*famOf());
  Player.raise = clamp(Player.raise + (Player.raised ? dt*8.5*quick : -dt*9), 0, 1);
  if (Player.lensSwap > 0) Player.lensSwap -= dt;

  if (S.custom.arrowLook){ const zoomK = Math.min(1, 45/Math.max(20, feqReal()*(Player.raise > 0.5 ? 1 : 0.6))); const ly = (K.ArrowLeft?1:0) - (K.ArrowRight?1:0), lp = (K.ArrowUp?1:0) - (K.ArrowDown?1:0);
    if (ly || lp){ Player.yaw += ly*dt*1.9*zoomK; Player.pitch = clamp(Player.pitch + lp*dt*1.3*zoomK, -1.35, 1.35); } }
  let mx = (K.KeyD?1:0) - (K.KeyA?1:0) + Input.joy.x, mz = (K.KeyW?1:0) - (K.KeyS?1:0) - Input.joy.y;
  const ml = Math.hypot(mx,mz); if (ml > 1){ mx/=ml; mz/=ml; }
  Player.crouch = clamp(Player.crouch + (K.KeyC ? dt*4 : -dt*4), 0, 1);
  const shift = K.ShiftLeft || K.ShiftRight;

  Player.breathing = false;
  if (Player.raise > 0.6 && shift && sk("breath") && Player.breath > 0){ Player.breathing = true; Player.breath = Math.max(0, Player.breath - dt/4); }
  else Player.breath = Math.min(1, Player.breath + dt/7);
  let speed = shift && Player.raise < 0.5 ? (S.custom.runSpeed === "fast" ? 8.2 : 7.0) : (S.custom.runSpeed === "fast" ? 2.8 : 2.5); if (Player.raise > 0.5) speed = 1.35; if (Player.crouch > 0.5) speed = 1.0;
  const fx = -Math.sin(Player.yaw), fz = -Math.cos(Player.yaw), rx = Math.cos(Player.yaw), rz = -Math.sin(Player.yaw);
  const tvx = (fx*mz + rx*mx)*speed, tvz = (fz*mz + rz*mx)*speed;
  const a = 1 - Math.exp(-dt*9); Player.vx = lerp(Player.vx, tvx, a); Player.vz = lerp(Player.vz, tvz, a);
  let nx = Player.x + Player.vx*dt, nz = Player.z + Player.vz*dt;
  if (GP.ride){ rideUpdate(dt); nx = Player.x; nz = Player.z; }
  else if (window.SnapCity?.solids) { if(ZONE.mode === "shop") [nx,nz]=zoneClamp(nx,nz); [nx,nz]=SnapCity.solids.move(nx,nz); }
  else if (ZONE.mode) [nx, nz] = zoneClamp(nx, nz);
  else [nx, nz] = collidePoint(nx, nz, 0.35);

  const cc = Life.cable; if (!GP.ride && cc && Math.abs(nx-cc.x) < 1.5 && Math.abs(nz-cc.z) < 4.6){ nx = Player.x; nz = Player.z; }
  if (!window.SnapCity?.solids && !GP.ride && !ZONE.mode && PLAYX.elev < 1.1) for (const c of Life.cars){ if (Math.abs(nx-c.x) < (c.bus ? 6 : 2.5) && Math.abs(nz-c.z) < (c.bus ? 1.5 : 1.25)){ nx = Player.x; nz = Player.z; break; } }
  if (!GP.ride) Player.speed = Math.hypot(nx-Player.x, nz-Player.z)/Math.max(dt,1e-4);
  Player.x = nx; Player.z = nz;
  Player.bob += dt*Player.speed*2.1;

  if (K.KeyQ) Player.roll = clamp(Player.roll + dt*0.5, -0.6, 0.6);
  else if (K.KeyE) Player.roll = clamp(Player.roll - dt*0.5, -0.6, 0.6);
  else if (Player.raise < 0.3) Player.roll *= Math.exp(-dt*6);

  const gy = GP.ride ? GP.ride.y - lerp(1.65, 1.05, Player.crouch) : standY(dt);
  const eye = lerp(1.65, 1.05, Player.crouch) - Player.raise*0.03;
  Player.yEye = (PLAYX.air || PLAYX.snap) ? gy + eye : lerp(Player.yEye ?? gy+eye, gy + eye, 1-Math.exp(-dt*12)); PLAYX.snap = false;
  const bobA = (1 - Player.raise*0.75) * Math.min(1, Player.speed/1.6) * (({ low:0.45, normal:1, high:1.5 })[S.custom.walkBob] || 1) * (GP.ride ? 0 : 1);
  const by = Math.abs(Math.sin(Player.bob))*0.045*bobA, bx = Math.cos(Player.bob)*0.02*bobA;
  G.cam.position.set(Player.x + rx*bx, Player.yEye + by, Player.z + rz*bx);

  const t = Game.t, sway = Player.raise * 0.0012 * Math.pow(0.7, sk("steady")) * (Player.breathing ? 0.3 : 1) * 30/Math.max(30, feqReal()) * 2;
  G.cam.rotation.set(Player.pitch + Math.sin(t*1.3)*sway, Player.yaw + Math.sin(t*0.9+1)*sway, Player.roll);

  const fovLens = 2*Math.atan(Math.tan(vfovLens()/2) * innerHeight/Math.max(1,VF.h)) * 180/Math.PI;
  const target = lerp((+(S.custom && S.custom.walkFov) || EYE_FOV), clamp(fovLens, 1, 120), smooth(0.35, 0.9, Player.raise));
  if (Math.abs(G.cam.fov - target) > 0.01){ G.cam.fov = target; G.cam.updateProjectionMatrix(); }

  if (heldCam && heldCam.userData.lens){ const L_ = curLens(); if (L_ && L_.f2){ const k = lensFocal()/heldCam.userData.f0, ln = heldCam.userData.lensLen*(0.55 + 0.45*k); heldCam.userData.lens.scale.z = ln/heldCam.userData.lensLen; heldCam.userData.lens.position.z = -heldCam.userData.dep/2 - ln/2; } }
  if (heldCam){ heldCam.visible = Player.raise < 0.75; heldCam.position.x = 0.12*(1-Player.raise); heldCam.position.y = -0.185 + Player.raise*0.15; heldCam.position.z = -0.42 + Player.raise*0.16; heldCam.rotation.x = -0.25*(1-Player.raise); heldCam.rotation.y = -0.12*(1-Player.raise); }
}

function renderLive(){
  const r = G.renderer, e = Cam.exp, b = curBody();
  Refl.render(G.cam); r.setRenderTarget(G.rtLive); r.render(G.scene, G.cam);
  const u = G.post.uniforms; G.quad.material = G.post;
  u.tColor.value = G.rtLive.texture; u.tDepth.value = G.rtLive.depthTexture; u.texel.value.set(1/G.rtLive.width, 1/G.rtLive.height);
  u.cNear.value = G.cam.near; u.cFar.value = G.cam.far; u.outScale.value = 1;
  u.tint.value = 0; u.soft.value = 0; setShafts(u, G.cam);
  u.exposure.value = expoScale(1); u.dofOn.value = 0;
  u.sat.value = 1; u.con.value = 1; u.mono.value = (typeof vfMono === "function" ? vfMono() : 0); u.warm.value = 0; u.fade.value = 0; u.vig.value = Game.started ? 0.12 : 0.3;
  r.setRenderTarget(null); r.render(G.postScene, G.postCam);
}
function updateLampLights(dt){
  const T = World.timeDef, p = G.cam.position, I = 70*(T ? T.lamps : 0);
  Game.lampT = (Game.lampT||0) - dt;
  if (Game.lampT <= 0){ Game.lampT = 0.5;

    const near = World.lamps.map(l=>[l, (l.x-p.x)**2 + (l.z-p.z)**2]).sort((a,b)=>a[1]-b[1]).slice(0, Game.lampLights.length).map(n=>n[0]);
    const taken = new Set(Game.lampLights.map(L=>L.userData.lamp).filter(l=>l && near.includes(l)));
    const free = near.filter(l=>!taken.has(l));
    Game.lampLights.forEach(L=>{ if (!L.userData.lamp || !near.includes(L.userData.lamp)){ L.userData.next = free.shift() || null; } });
  }
  Game.lampLights.forEach(L=>{
    const u = L.userData; u.cur = u.cur || 0;
    if (u.next !== undefined){ u.cur = Math.max(0, u.cur - dt*3); if (u.cur <= 0.001){ u.lamp = u.next; delete u.next; if (u.lamp) L.position.set(u.lamp.x, u.lamp.y, u.lamp.z); } }
    else u.cur = Math.min(1, u.cur + dt*1.5);
    L.intensity = (u.lamp && I > 0) ? I * u.cur : 0;
  });
}
function followLights(){
  const p = G.cam.position; if (Game.lampLights) updateLampLights(0.016);
  if (World.sky) World.sky.position.copy(p);
  if (World.sun && World.sunDir){
    const snap = 190/2048; const tx = Math.round(p.x/snap)*snap, tz = Math.round(p.z/snap)*snap;
    World.sun.target.position.set(tx, H(tx,tz), tz); World.sun.position.copy(World.sun.target.position).addScaledVector(World.sunDir, 300);
    World.sun.target.updateMatrixWorld();
  }
}
function titleCamera(dt){
  Game.titleT += dt*0.04;
  const a = Game.titleT;
  G.cam.position.set(6 + Math.sin(a)*4, H(6,-30)+1.7, -30 + Math.cos(a)*3);
  G.cam.rotation.set(0.02, -1.1 + Math.sin(a*0.7)*0.35, 0);
  G.cam.fov = 58; G.cam.updateProjectionMatrix();
}
function loop(now){
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, Math.max(0.001, (now - Game.last)/1000)); Game.last = now; Game.t += dt;

  if (UI.open && Game.started) return;
  if (!Game.started){
    titleCamera(dt); updateLife(dt, { pos:G.cam.position, fwd:new THREE.Vector3(0,0,-1), raised:false, speed:0 });
    followLights(); if (!Cam.exp) computeExposure(); renderLive(); return;
  }
  updatePlayer(dt);
  const wdt = Player.breathing ? dt*0.3 : dt;
  G.cam.updateMatrixWorld(); G.cam.getWorldDirection(_fwd);
  updateLife(wdt, { pos:G.cam.position, fwd:_fwd, raised:Player.raise > 0.5, speed:Player.speed });
  Rain.update(dt, G.cam.position);
  gameplayUpdate(dt);
  updateFocus(dt); computeExposure();
  followLights();

  const vfOn = Player.raise > 0.6;
  $("#vf").classList.toggle("hidden", !vfOn); $("#crosshair").classList.toggle("hidden", vfOn); $("#hud").classList.toggle("raised", vfOn);
  updateHUD(dt);
  renderLive();

  Game.bellT -= dt; const cc = Life.cable;
  if (Game.bellT <= 0 && cc){ Game.bellT = rand(7,14); const d = Math.hypot(cc.x - Player.x, cc.z - Player.z); if (d < 140) Audio.bell(1 - d/140); }
  Game.saveT -= dt; if (Game.saveT <= 0){ Game.saveT = 5; S.pos = { x:Player.x, z:Player.z, yaw:Player.yaw }; saveState(); }
}
function onShotTaken(rec){ UI.hudT = 0; }


(function(){
 'use strict';
 const SC=window.SnapCity=window.SnapCity||{};
 const T=SC.traversal={platforms:[],cells:new Map(),knights:[],built:false};
 const specialKind=pickSpecialKind;window.pickSpecialKind=function(rnd){World.specialUsed=World.specialUsed||{};if(!Object.keys(World.specialUsed).length){World.specialUsed.castle=1;return 'castle';}return specialKind(rnd);};
 const cell=(x,z)=>Math.floor(x/16)+','+Math.floor(z/16);
 function add(p){if(p.w<.55||p.d<.55||p.top-p.bottom<.04)return;T.platforms.push(p);const radius=Math.hypot(p.w,p.d)/2;
  for(let x=Math.floor((p.x-radius)/16);x<=Math.floor((p.x+radius)/16);x++)for(let z=Math.floor((p.z-radius)/16);z<=Math.floor((p.z+radius)/16);z++){const k=x+','+z;if(!T.cells.has(k))T.cells.set(k,[]);T.cells.get(k).push(p);}}
 T.addPlatform=add;
 const boxBase=box;window.box=function(key,x,y,z,w,h,d,color,ry=0,rx=0,rz=0){if(['plain','metal','civic'].includes(key)&&Math.abs(rx)<.01&&Math.abs(rz)<.01)add({x,z,w,d,ry,bottom:y-h/2,top:y+h/2});return boxBase.apply(this,arguments);};
 const facade=facadeBox;window.facadeBox=function(key,x,y,z,w,h,d,ry){add({x,z,w,d,ry,bottom:y,top:y+h});return facade.apply(this,arguments);};
 function inside(p,x,z,margin=0){const q=localXZ(p,x,z);return Math.abs(q[0])<=p.w/2+margin&&Math.abs(q[1])<=p.d/2+margin;}
 const surfaces=surfaceAt;window.surfaceAt=function(x,z,footY){let result=surfaces.apply(this,arguments);for(const p of T.cells.get(cell(x,z))||[]){if(p.top<=footY+.12&&p.top>result.y&&inside(p,x,z))result={y:p.top,on:p};}return result;};
 // No roof-sized movement box: only actual taller solids stop horizontal travel.
 const clampZone=zoneClamp;window.zoneClamp=function(x,z){if(ZONE.mode!=='roof')return clampZone(x,z);const foot=PLAYX.footY??ZONE.y;
  for(const p of T.cells.get(cell(x,z))||[]){if(p.top<=foot+.18||p.bottom>=foot+1.6)continue;if(inside(p,x,z,.18)&&!inside(p,Player.x,Player.z,.1))return [Player.x,Player.z];}return [x,z];};
 const stand=standY;window.standY=function(dt){
  if(ZONE.mode&&ZONE.mode!=='roof')return stand(dt);
  if(PLAYX.footY===null)PLAYX.footY=groundY(Player.x,Player.z);
  if(PLAYX.surf&&PLAYX.surf.vx!==undefined&&!PLAYX.air){Player.x+=(PLAYX.surf.vx||0)*dt;Player.z+=(PLAYX.surf.vz||0)*dt;}
  const previous=PLAYX.footY,s=surfaceAt(Player.x,Player.z,previous);
  if(!PLAYX.air&&s.y<previous-.16){PLAYX.air=true;PLAYX.vy=0;}
  if(PLAYX.air){PLAYX.vy-=13*dt;PLAYX.footY+=PLAYX.vy*dt;if(PLAYX.vy<=0&&previous>=s.y-.12&&PLAYX.footY<=s.y){PLAYX.footY=s.y;PLAYX.air=false;PLAYX.vy=0;PLAYX.surf=s.on;}}
  else {PLAYX.footY=s.y;PLAYX.surf=s.on;}
  PLAYX.elev=PLAYX.footY-groundY(Player.x,Player.z);
  if(PLAYX.elev>.3||PLAYX.air){ZONE.mode='roof';ZONE.y=PLAYX.footY;ZONE.box=null;}
  else if(ZONE.mode==='roof'){ZONE.mode=null;ZONE.box=null;if(ZONE.parapet)ZONE.parapet.visible=false;}
  return PLAYX.footY;
 };
 window.jump=function(){if(PLAYX.air)return;PLAYX.air=true;PLAYX.vy=({low:4.6,normal:7.8,high:9.2})[S.custom.jumpHeight]||7.8;if(SC.experiments?.moonJump)PLAYX.vy*=1.8;PLAYX.surf=null;if(ZONE.mode!=='shop'){ZONE.mode='roof';ZONE.y=PLAYX.footY;}};
 // Choose a real doorway/fire escape/gate from the current position, not the entry history.
 T.nearestEntrance=function(x,z){const candidates=[];
  for(const r of World.roofs||[])if(r.n&&Number.isFinite(r.fx))candidates.push({x:r.fx+r.n[0]*2.4,z:r.fz+r.n[1]*2.4});
  for(const r of World.shops||[])if(r.n)candidates.push({x:r.x+r.n[0]*1.5,z:r.z+r.n[1]*1.5});
  for(const sp of World.specials||[]){if(sp.kind==='castle')for(const [dx,dz]of [[1,0],[-1,0],[0,1],[0,-1]])candidates.push({x:sp.cx+dx*(HALF-3),z:sp.cz+dz*(HALF-3)});if(sp.kind==='library')candidates.push({x:sp.cx,z:sp.cz+12});}
  return candidates.sort((a,b)=>Math.hypot(a.x-x,a.z-z)-Math.hypot(b.x-x,b.z-z))[0]||{x,z};
 };
 const leave=leaveZone;window.leaveZone=function(){if(ZONE.mode!=='roof')return leave.apply(this,arguments);const entrance=T.nearestEntrance(Player.x,Player.z);
  // Clear roof mode before older exit wrappers can overwrite the chosen destination.
  ZONE.mode='platform';ZONE.box=null;ZONE.back=entrance;PLAYX.footY=groundY(entrance.x,entrance.z);PLAYX.elev=0;PLAYX.surf=null;PLAYX.vy=0;
  let [x,z]=collidePoint(entrance.x,entrance.z,.35);ZONE.back={x,z};const result=leave.apply(this,arguments);toast('Down at the nearest entrance.',1400);return result;
 };
 function knights(){if(T.built||!SC.makePerson||!World.specials?.length)return;T.built=true;
  const metal=new THREE.MeshStandardMaterial({color:0xaeb8c4,metalness:.65,roughness:.42}),dark=new THREE.MeshStandardMaterial({color:0x20252b}),red=new THREE.MeshStandardMaterial({color:0x9b2634});
  const cube=new THREE.BoxGeometry(1,1,1),cyl=new THREE.CylinderGeometry(.5,.5,1,10);
  function part(g,geo,mat,x,y,z,a,b,c){const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.scale.set(a,b,c);g.add(m);return m;}
  for(const sp of World.specials.filter(s=>s.kind==='castle'))for(let i=0;i<8;i++){
   const p=SC.makePerson(54000+i+Math.round(sp.cx*31+sp.cz),false),side=i%4,roams=i>=4,angle=side*Math.PI/2,nx=Math.sin(angle),nz=Math.cos(angle),tx=nz,tz=-nx;
   const point=(out,along)=>({x:sp.cx+nx*out+tx*along,z:sp.cz+nz*out+tz*along});
   const route=roams?[point(16,-8),point(19,0),point(HALF+2,0),point(HALF+2,13),point(HALF+2,0),point(19,0),point(16,8)]:[point(16,-9),point(21,-9),point(21,9),point(16,9)];
   // Pivot each leg at the hip for proper walking, with planted feet during pauses.
   const legs=p.g.children.slice(0,2).map(mesh=>{const pivot=new THREE.Group();pivot.position.y=.86;mesh.position.y-=.86;p.g.remove(mesh);pivot.add(mesh);p.g.add(pivot);return pivot;});
   part(p.head,cyl,metal,0,0,0,.35,.38,.35);part(p.head,cube,dark,0,.035,.177,.25,.045,.02);part(p.head,cube,red,0,.25,-.01,.06,.22,.19);
   part(p.g,cube,metal,0,1.15,0,.44,.58,.28);part(p.armL,cube,metal,0,-.28,.12,.32,.5,.05);part(p.armR,cube,metal,0,-.64,.14,.045,.75,.025);part(p.armR,cube,dark,0,-.27,.14,.2,.035,.045);
   p.g.name='Castle knight '+(roams?'street wanderer':'patrol');p.g.position.set(route[0].x,groundY(route[0].x,route[0].z),route[0].z);G.scene.add(p.g);T.knights.push({p,legs,route,index:1,pause:i*.3,speed:.75+i*.055,phase:i,roams,home:sp});
  }
 }
 const menu=renderMenu;window.renderMenu=function(){const result=menu.apply(this,arguments);document.querySelectorAll('[data-seg="roofParkour"]').forEach(e=>e.closest('.formrow')?.remove());return result;};
 T.updateKnights=function(dt){knights();for(const k of T.knights){const {p,route}=k;const target=route[k.index];let moved=0;if(k.pause>0)k.pause-=dt;else{const dx=target.x-p.g.position.x,dz=target.z-p.g.position.z,d=Math.hypot(dx,dz),step=Math.min(d,k.speed*dt);if(d<.2){k.index=(k.index+1)%route.length;k.pause=k.roams?1.5:2.5;}else{let x=p.g.position.x+dx/d*step,z=p.g.position.z+dz/d*step;[x,z]=collidePoint(x,z,.25);moved=Math.hypot(x-p.g.position.x,z-p.g.position.z);if(moved>step*2)moved=0;else{p.g.position.set(x,groundY(x,z),z);p.g.rotation.y=Math.atan2(dx,dz);}}}k.phase+=moved*7;const swing=moved>.001?Math.sin(k.phase)*.4:0;k.legs[0].rotation.x=swing;k.legs[1].rotation.x=-swing;p.armL.rotation.x=-swing*.6;p.armR.rotation.x=swing*.6;p.g.visible=Math.hypot(p.g.position.x-Player.x,p.g.position.z-Player.z)<140;}};
 const tick=gameplayUpdate;window.gameplayUpdate=function(dt){const result=tick.apply(this,arguments);T.updateKnights(dt);return result;};
})();

"use strict";

function lin(hex){ return new THREE.Color(hex).convertSRGBToLinear(); }

const SAVE_KEY = "snapcity.v1";
function defaultRoll(bodyId, stock){
  const b = BODIES[bodyId], fmt = FORMATS[b.fmt];
  const st = b.film || stock || (fmt.film==="120" ? "portra400" : fmt.film==="instant" ? "sx70" : "ultramax");
  return { stock:st, left: b.frames || fmt.frames };
}
function defaultState(free){
  const s = {
    v:2, free:!!free, name:"", money: free? 0 : 250, xp:0, level:1, skillPts: free? 12 : 0,
    skills:{}, owned:{ bodies:["disp"], lenses:[], flashes:["none"], films:[] },
    body:"disp", lensByBody:{}, flash:"none", rolls:{ disp: defaultRoll("disp") },
    set:{ mode:"P", A:5.6, T:1/250, push:0, ev:0, af:true, focus:4, flashOn:true, zoom:28 },
    custom:{ finish:"original", strap:"#c0362c", grid:"thirds", hud:"on", renderQuality:"balanced", reflections:"balanced", eventPins:"heard", sideCamera:"on", quickCamera:"on", sidePosition:"right", mouseSensitivity:"normal", walkBob:"normal", eventPace:"normal", eventNotify:"sound", interiorActivity:"lively", windowGlass:"balanced" },
    time:"golden", fog:false, frameCount:0, judgedBest:0, pos:null, shotLog:[]
  };
  for (const k in SKILLS) s.skills[k] = 0;
  if (free){
    s.owned.bodies = Object.keys(BODIES); s.owned.lenses = Object.keys(LENSES).filter(k=>!LENSES[k].fixed); s.owned.flashes = Object.keys(FLASHES);
    s.body = "m6"; s.flash = "none"; s.set.flashOn = false;
    for (const k in BODIES){ const b = BODIES[k]; if (b.kit) s.lensByBody[k] = b.kit; s.rolls[k] = defaultRoll(k, FORMATS[b.fmt].film==="135" ? "trix" : null); }
  }
  return s;
}
let S = null;
function loadState(){ try { const raw = (localStorage.getItem(SAVE_KEY) || localStorage.getItem("contactsheet.v2")); if (raw){ const s = JSON.parse(raw); if (s && s.v===2) return s; } } catch(e){} return null; }
let saveTimer = 0;
function saveState(){ clearTimeout(saveTimer); saveTimer = setTimeout(()=>{ try { localStorage.setItem(SAVE_KEY, JSON.stringify(S)); } catch(e){} }, 300); }
let sk = k => (S && S.skills[k]) || 0;
function curBody(){ return BODIES[S.body]; }
function curFormat(){ return FORMATS[curBody().fmt]; }
function curLens(){ const b = curBody(); if (b.L) return LENSES[b.L]; const id = S.lensByBody[S.body]; return id ? LENSES[id] : null; }
function curRoll(){ if (!S.rolls[S.body]) S.rolls[S.body] = defaultRoll(S.body); return S.rolls[S.body]; }
function curFilm(){ return FILMS[curRoll().stock] || FILMS.ultramax; }
function curFlash(){ const ext = FLASHES[S.flash] || FLASHES.none; const b = curBody(); if (ext.gn) return ext; if (b.fl) return { name:"Built-in flash", gn:b.fl, builtin:true }; return ext; }
function mountFits(body, lens){ if (!body.m || !lens.m) return false; return (MOUNT_COMPAT[body.m] || [body.m]).includes(lens.m); }
function levelXp(l){ return Math.round(120 * Math.pow(l, 1.35)); }

const DB = (() => {
  let db = null; const mem = new Map();
  const ready = new Promise(res => {
    try {
      const req = indexedDB.open("contactsheet", 1);
      req.onupgradeneeded = () => req.result.createObjectStore("photos", { keyPath:"id" });
      req.onsuccess = () => { db = req.result; res(); };
      req.onerror = () => res();
      req.onblocked = () => res();
    } catch(e){ res(); }
  });
  function tx(mode){ return db.transaction("photos", mode).objectStore("photos"); }
  const wrap = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  return {
    ready,
    async put(p){ await ready; if (!db){ mem.set(p.id, p); return; } try { await wrap(tx("readwrite").put(p)); } catch(e){ mem.set(p.id,p); } },
    async get(id){ await ready; if (!db || mem.has(id)) return mem.get(id); return wrap(tx("readonly").get(id)); },
    async all(){ await ready; let arr = []; if (db){ try { arr = await wrap(tx("readonly").getAll()); } catch(e){} } return arr.concat([...mem.values()]); },
    async del(id){ await ready; mem.delete(id); if (db){ try { await wrap(tx("readwrite").delete(id)); } catch(e){} } },
    persistent(){ return !!db; }
  };
})();

let toastT = 0;
function toast(msg, ms=2200){ const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(()=>t.classList.remove("show"), ms); }

const Audio = (() => {
  let ctx = null, amb = null, master = null;
  function init(){
    if (ctx) return;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain(); master.gain.value = 0.8; master.connect(ctx.destination);

      const len = ctx.sampleRate * 4, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
      let last = 0; for (let i=0;i<len;i++){ const w = Math.random()*2-1; last = (last + 0.02*w)/1.02; d[i] = last*3.2; }
      const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
      const f = ctx.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 500;
      amb = ctx.createGain(); amb.gain.value = 0.18; src.connect(f); f.connect(amb); amb.connect(master); src.start();
    } catch(e){ ctx = null; }
  }
  function noiseBurst(t0, dur, freq, q, gain){
    const len = Math.max(1, Math.floor(ctx.sampleRate*dur)), buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
    for (let i=0;i<len;i++) d[i] = (Math.random()*2-1) * Math.pow(1 - i/len, 3);
    const s = ctx.createBufferSource(); s.buffer = buf;
    const f = ctx.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain(); g.gain.value = gain; s.connect(f); f.connect(g); g.connect(master); s.start(t0);
  }
  function tone(t0, freq, dur, gain, type="sine"){
    const o = ctx.createOscillator(); o.type = type; o.frequency.value = freq;
    const g = ctx.createGain(); g.gain.setValueAtTime(gain, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0+dur);
    o.connect(g); g.connect(master); o.start(t0); o.stop(t0+dur+0.05);
  }
  return {
    init,
    shutter(kind, t, body){
      if (!ctx) return; const n = ctx.currentTime;
      if (kind === "silent") return;
      if (kind === "digital"){ tone(n, 1800, 0.05, 0.08, "square"); tone(n+0.06, 1400, 0.06, 0.06, "square"); return; }
      if (kind === "leaf"){ noiseBurst(n, 0.03, 5200, 2, 0.5); noiseBurst(n+Math.max(.012,t), 0.03, 4800, 2, 0.35); return; }
      const slr = body && body.t === "SLR";
      noiseBurst(n, 0.035, 2600, 1.2, slr ? .68 : .38);
      if (slr) noiseBurst(n, .06, 640, .8, .55);
      noiseBurst(n+Math.max(.025,t), .045, 1900, 1.2, slr ? .65 : .3);
    },
    advance(){ if (!ctx) return; const n = ctx.currentTime + 0.25; for (let i=0;i<5;i++) noiseBurst(n+i*0.035, 0.03, 900, 3, 0.25); },
    bell(vol){ if (!ctx || vol < 0.02) return; const n = ctx.currentTime; tone(n, 1245, 1.2, 0.18*vol, "triangle"); tone(n, 2490, 0.8, 0.06*vol); tone(n+0.28, 1245, 1.0, 0.15*vol, "triangle"); },
    flutter(){ if (!ctx) return; const n = ctx.currentTime; for (let i=0;i<14;i++) noiseBurst(n+i*0.04+Math.random()*0.02, 0.05, 700+Math.random()*500, 1, 0.22); },
    hey(){ if (!ctx) return; const n = ctx.currentTime; tone(n, 220, 0.25, 0.1, "sawtooth"); },
    setAmb(v){ if (amb) amb.gain.value = v * (Audio.ambK ?? 1); },
    master: () => master,
    ctx: () => ctx
  };
})();

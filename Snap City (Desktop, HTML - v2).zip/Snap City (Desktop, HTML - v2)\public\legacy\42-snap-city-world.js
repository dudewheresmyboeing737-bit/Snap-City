(function(){
 'use strict';
 const SC=window.SnapCity;
 const palettes={
   morning:{top:'#6a859d',bot:'#dcc6ad',sun:'#ffe6c4',sky:'#bbd0d5',gnd:'#656576'},
   noon:{top:'#4b82a8',bot:'#c9dcd9',sun:'#fff0cd',sky:'#b5cfde',gnd:'#77798b'},
   golden:{top:'#5c7194',bot:'#eec194',sun:'#ffb877',sky:'#b4c3d5',gnd:'#5b5574'},
   blue:{top:'#202e58',bot:'#8283a7',sun:'#aaa7d3',sky:'#798cba',gnd:'#363453'},
   night:{top:'#080e24',bot:'#283b5e',sun:'#91adc8',sky:'#587293',gnd:'#24233e'}
 };
 for(const t of TIMES)Object.assign(t,palettes[t.id]);
 const baseInit=initRenderer;initRenderer=function(){
   baseInit();
   G.post.uniforms.scStyle={value:1};
   G.post.fragmentShader=G.post.fragmentShader.replace('varying vec2 vUv;',`uniform float scStyle; varying vec2 vUv;`)
    .replace('gl_FragColor = vec4(clamp(col,0.0,1.0)*accW, 1.0);',`
      if(scStyle > .5){
        float lum=dot(col,vec3(.2126,.7152,.0722));
        col += vec3(-.018,.004,.024)*(1.0-lum)*.65;
        float steps=scStyle>1.5?31.0:127.0;
        vec2 cell=mod(floor(gl_FragCoord.xy),2.0);
        float bayer=(cell.x<.5?(cell.y<.5?0.0:3.0):(cell.y<.5?2.0:1.0))/4.0-.375;
        col=floor(clamp(col,0.0,1.0)*steps+.5+bayer*.65)/steps;
      }
      gl_FragColor = vec4(clamp(col,0.0,1.0)*accW,1.0);`);
   G.post.needsUpdate=true;
 };
 const baseResize=resize;resize=function(){
   baseResize();if(!S||!G.rtLive)return;
   if(S.custom.psxStyle==='classic'){const scale=Math.min(1,720/innerWidth);G.rtLive.setSize(Math.round(innerWidth*scale),Math.round(innerHeight*scale));G.rtLive.texture.magFilter=THREE.NearestFilter;}
 };
 const baseRender=renderLive;renderLive=function(){
   if(G.post?.uniforms.scStyle)G.post.uniforms.scStyle.value=S.custom.psxStyle==='clean'?0:S.custom.psxStyle==='classic'?2:1;
   return baseRender();
 };
 const baseApply=applyTime;applyTime=function(light){
   const r=baseApply(light);if(!World.timeDef)return r;

   const t=World.timeDef,k=({clear:.55,normal:1,heavy:1.8})[S.custom.fogAmount]||1;
   const base=S.storm?.013:S.rain?.009:Math.min(.0045,t.fogD);
   World.scene.fog.density=S.fog?Math.max(base,.014)*k:base;
   World._fogBase=World.scene.fog.density;
   if(S.storm){World.sun.intensity=t.sunI*.14;World.hemi.intensity=t.hemiI*.68;World.skyMat.uniforms.top.value.copy(lin('#29384b'));World.skyMat.uniforms.bot.value.copy(lin('#607182'));World.scene.fog.color.copy(lin('#677a8b'));}
   return r;
 };
 titleCamera=function(dt){
   Game.titleT+=dt*.035;const a=Game.titleT;
   G.cam.position.set(43+Math.sin(a)*1.6,H(43,-63)+2.05,-63+Math.cos(a)*1.5);
   G.cam.rotation.set(-.025,.42+Math.sin(a*.45)*.12,0);G.cam.fov=66;G.cam.updateProjectionMatrix();
 };
 const basePeople=buildPeopleMeshes;buildPeopleMeshes=function(scene){basePeople(scene);for(const mesh of Object.values(PI_)){if(mesh.material){mesh.material.flatShading=true;mesh.material.needsUpdate=true;}}};
 const stories=[
  {id:'sc_contact',name:'the contact-sheet exchange',n:2,d:150,pose:['talk','point'],mood:['smile','curious'],prop:'prints',cue:'Two photographers compare a contact sheet outside the lab.'},
  {id:'sc_water',name:'water on the picket line',n:3,d:180,pose:['give','take','cheer'],mood:['smile','surprised','smile'],prop:'water',cue:'A shopkeeper brings water to the people on the corner.'},
  {id:'sc_letter',name:'a letter from home',n:1,d:135,pose:['phone'],mood:['sad'],prop:'letter',cue:'Someone has stopped walking to read a letter twice.'},
  {id:'sc_shoelace',name:'the shoelace lesson',n:2,d:130,pose:['kneel','watch'],mood:['smile','curious'],prop:'none',cue:'A parent kneels to help with a stubborn shoelace.'},
  {id:'sc_signfold',name:'the carefully folded sign',n:2,d:160,pose:['give','watch'],mood:['thoughtful','sad'],prop:'sign',cue:'After the march, a protester folds their sign to take home.'},
  {id:'sc_umbrella',name:'an umbrella for two',n:2,d:165,pose:['hug','wave'],mood:['smile','laugh'],prop:'umbrella',cue:'Two strangers share the last dry patch under an umbrella.'},
  {id:'sc_film',name:'the dropped roll',n:2,d:140,pose:['kneel','point'],mood:['surprised','smile'],prop:'film',cue:'A roll of film escapes a pocket. A stranger spots it.'},
  {id:'sc_cleaner',name:'the cleaner and the slogan',n:1,d:170,pose:['watch'],mood:['thoughtful'],prop:'sign',cue:'A street cleaner pauses to read a slogan before removing it.'},
  {id:'sc_window',name:'a wave through the glass',n:2,d:140,pose:['wave','wave'],mood:['laugh','smile'],prop:'none',cue:'Someone in the window recognizes someone on the street.'},
  {id:'sc_flowers',name:'flowers after closing',n:2,d:150,pose:['give','take'],mood:['smile','surprised'],prop:'flowers',cue:'A florist gives the last bouquet away instead of throwing it out.'},
  {id:'sc_reunion',name:'the station reunion',n:3,d:190,pose:['hug','hug','cheer'],mood:['laugh','smile','smile'],prop:'suitcase',cue:'A suitcase hits the pavement. Someone has finally come home.'},
  {id:'sc_mirror',name:'the shop-window rehearsal',n:1,d:135,pose:['pose'],mood:['curious'],prop:'none',cue:'A passerby rehearses a serious face in a shop window.'},
  {id:'sc_break',name:'the last five minutes of lunch',n:2,d:170,pose:['phone','watch'],mood:['tired','thoughtful'],prop:'lunch',cue:'Two workers share a quiet lunch on the loading steps.'},
  {id:'sc_album',name:'an old photograph',n:2,d:180,pose:['give','take'],mood:['sad','smile'],prop:'prints',cue:'An older resident shows a neighbor a photograph of this street long ago.'},
  {id:'sc_coin',name:'the busker’s smallest tip',n:2,d:140,pose:['give','bow'],mood:['smile','laugh'],prop:'coin',cue:'A busker gives a theatrical bow for a very small tip.'},
  {id:'sc_lastbus',name:'one more passenger',n:2,d:145,pose:['run','wave'],mood:['surprised','laugh'],prop:'suitcase',cue:'A passenger runs for the bus. Someone holds the door.'},
  {id:'sc_nightmarket',name:'the lantern night market',n:6,d:240,major:true,night:true,pose:['talk','give','take','cheer','watch','wave'],mood:['smile','smile','laugh','smile','curious','smile'],prop:'market',cue:'The night market opens under a string of paper lanterns.'},
  {id:'sc_roofshow',name:'the sidewalk fashion show',n:6,d:240,major:true,pose:['pose','pose','point','cheer','watch','wave'],mood:['smile','curious','laugh','smile','surprised','smile'],prop:'runway',cue:'A clothing shop rolls a red carpet straight onto the sidewalk.'},
  {id:'sc_brass',name:'the second-line band',n:6,d:240,major:true,pose:['cheer','dance','dance','clap','wave','cheer'],mood:['laugh','smile','laugh','smile','smile','laugh'],prop:'band',cue:'A neighborhood band has turned the corner. The audience is becoming a parade.'},
  {id:'sc_mural',name:'the mural unveiling',n:5,d:240,major:true,pose:['point','cheer','clap','watch','wave'],mood:['smile','surprised','laugh','curious','smile'],prop:'mural',cue:'A painted canvas unfolds. The whole block gathers to see it.'},
  {id:'sc_printsale',name:'the open-air print fair',n:6,d:240,major:true,pose:['give','take','talk','point','watch','wave'],mood:['smile','surprised','smile','curious','smile','laugh'],prop:'gallery',cue:'Prints go up on a clothesline. The street becomes a gallery.'},
  {id:'sc_dance',name:'the last dance before rain',n:6,d:210,major:true,pose:['dance','dance','clap','cheer','watch','wave'],mood:['laugh','smile','laugh','smile','smile','surprised'],prop:'band',cue:'A record starts playing. A whole corner remembers how to dance.'}
 ];
 SC.stories=stories;
 for(const d of stories)EVENTS[d.id]={name:d.name,w:d.major?.45:.65,bonus:d.major?16:10,night:!!d.night};
 const sharedMat={};const geo=new THREE.BoxGeometry(1,1,1);
 function mat(c){return sharedMat[c]||(sharedMat[c]=new THREE.MeshStandardMaterial({color:lin(c),roughness:.8,flatShading:true}));}
 function propBox(g,x,y,z,w,h,d,c){const m=new THREE.Mesh(geo,mat(c));m.position.set(x,y,z);m.scale.set(w,h,d);g.add(m);return m;}
 function storyProps(d,spot){
   const g=new THREE.Group();g.position.set(spot.x,groundY(spot.x,spot.z),spot.z);g.rotation.y=Math.atan2(spot.out[0],spot.out[1]);
   const paper='#e8dfbe',dark='#294454',amber='#e4a552';
   if(['prints','letter','sign','film','water','flowers','coin','lunch'].includes(d.prop)){
     const w=d.prop==='sign'?.72:d.prop==='letter'?.22:.48;
     const m=propBox(g,0,1.02,.18,w,.025,.3,paper);m.rotation.z=-.08;
     if(d.prop==='prints')for(let i=0;i<6;i++)propBox(g,-.16+(i%3)*.15,1.038,.11+Math.floor(i/3)*.15,.12,.006,.11,dark);
     if(d.prop==='water')for(let i=0;i<3;i++)propBox(g,-.2+i*.2,1.14,.2,.08,.22,.08,'#81bdc9');
     if(d.prop==='flowers')for(let i=0;i<5;i++)propBox(g,-.2+i*.1,1.22+Math.sin(i)*.05,.1,.09,.1,.09,i%2?'#e88c8a':'#e9c25e');
     if(d.prop==='film')propBox(g,.1,.05,.65,.08,.09,.08,'#e2b745');
   }
   if(d.prop==='suitcase'){propBox(g,.7,.35,.3,.48,.6,.22,'#ae6448');propBox(g,.7,.69,.3,.22,.08,.04,dark);}
   if(d.major){
     if(d.prop==='market'){for(let i=-1;i<=1;i++){propBox(g,i*2.5,.78,-.25,1.9,.12,.85,'#886b58');propBox(g,i*2.5,2.1,-.25,2.1,.12,1.1,i%2?'#bb604f':'#4a8181');for(const x of [-.8,.8])propBox(g,i*2.5+x,1.05,-.5,.06,2.1,.06,dark);}}
     else if(d.prop==='runway')propBox(g,0,.028,.25,6,.035,.9,'#9d3949');
     else if(d.prop==='mural'||d.prop==='gallery'){for(const x of [-3,3])propBox(g,x,1.6,-.9,.07,3.2,.07,dark);propBox(g,0,2.65,-.9,6.1,.025,.025,paper);for(let i=0;i<7;i++){propBox(g,-2.6+i*.86,2.15,-.88,.7,.82,.02,paper);propBox(g,-2.6+i*.86,2.15,-.86,.57,.64,.01,['#b46862','#628d91','#bfa675','#677d99'][i%4]);}}
     else {propBox(g,-2,.25,-.8,.8,.5,.5,dark);propBox(g,2,.25,-.8,.8,.5,.5,dark);}
   }
   G.scene.add(g);return g;
 }
 const nativeEvent=startEvent;
 startEvent=function(type){
   const d=stories.find(s=>s.id===type);if(!d)return nativeEvent(type);
   const spot=evSpot(15,d.major?70:42),people=evPool(d.n);if(!spot||!people)return null;
   const originals=people.map(p=>({skin:p.look.skin,expression:p.scExpression,scale:p.scale}));
   people.forEach((p,i)=>{const x=(i-(people.length-1)/2)*(d.major?1.05:.85);evPlace(p,spot.x+spot.along[0]*x,spot.z+spot.along[1]*x,Math.atan2(-spot.out[0],-spot.out[1]),type);p.scExpression=d.mood[i];if(type==='sc_shoelace'&&i===1)p.scale=.69;});
   const props=storyProps(d,spot),E={type,t:0,ppl:people,done:false,x:spot.x,z:spot.z,info:EVENTS[type],props,cleaned:false};
   E.step=function(dt){
     const phase=this.t/d.d;
     people.forEach((p,i)=>{
       p.evPose=phase<.12?'watch':phase>.86?'wave':d.pose[i];
       p.scExpression=phase<.12?'curious':d.mood[i];
       const q=people[(i+1)%people.length];if(people.length>1)evFace(p,q);
       if(d.pose[i]==='dance'){p.evY=Math.max(0,Math.sin(this.t*3+i)*.05);}
       if(d.pose[i]==='run')p.evPose='wave';
       if(d.pose[i]==='phone')p.act='phone';
       if(d.pose[i]==='kneel')p.evPose='kneel';
     });
     if(d.prop==='sign')props.rotation.x=Math.sin(this.t*.9)*.035;
     if(this.t>=d.d){this.done=true;G.scene.remove(props);people.forEach((p,i)=>{p.scExpression=originals[i].expression;p.scale=originals[i].scale;});this.cleaned=true;}
   };
   if(S.custom.eventPopups==='on')toast(d.cue,d.major?4200:2800);
   return E;
 };
 SC.startStory=function(id){const E=startEvent(id);if(E)EV.list.push(E);return E;};
 let storyTimer=28;
 const baseUpdate=gameplayUpdate;gameplayUpdate=function(dt){
   const r=baseUpdate(dt);storyTimer-=dt;
   if(storyTimer<=0&&S.custom.streetMoments!=='off'){
     storyTimer=S.custom.streetMoments==='subtle'?65:38;
     const active=EV.list.filter(e=>e.type.startsWith('sc_')).length;
     if(active<2){const d=pick(stories.filter(x=>!x.night||S.time==='night'||S.time==='blue'));SC.startStory(d.id);}
   }
   return r;
 };
 function landmarks(){
   const group=new THREE.Group();group.name='Snap City rooftops';const parts=[];
   function add(x,y,z,w,h,d,c){parts.push({g:new THREE.BoxGeometry(w,h,d),m:TM(x,y,z),c:lin(c)});}

   for(let [x,z,sign] of [[-264,-264,'MARINER'],[264,-264,'NORTH LIGHT'],[264,264,'FRAME WORKS'],[-264,264,'AFTER HOURS']]){
     const roof=(World.roofs||[]).reduce((a,r)=>!a||Math.hypot(r.x-x,r.z-z)<Math.hypot(a.x-x,a.z-z)?r:a,null);
     if(!roof)continue;const y=roof.top+2; x=roof.x;z=roof.z;
     add(x,y,z,13,4,10,'#556678');add(x,y+3,z,9,2,7,'#697b89');
     for(const dx of [-4,4])add(x+dx,y+5,z,.3,5,.3,'#354553');
     const c=document.createElement('canvas');c.width=512;c.height=96;const ctx=c.getContext('2d');ctx.fillStyle='#162936';ctx.fillRect(0,0,512,96);ctx.strokeStyle='#e1b968';ctx.strokeRect(8,8,496,80);ctx.fillStyle='#f5d697';ctx.textAlign='center';ctx.font='bold 46px monospace';ctx.fillText(sign,256,65);
     const tex=new THREE.CanvasTexture(c);tex.encoding=THREE.sRGBEncoding;tex.magFilter=THREE.NearestFilter;
     const m=new THREE.Mesh(new THREE.PlaneGeometry(11,2.1),new THREE.MeshBasicMaterial({map:tex,side:THREE.DoubleSide}));m.position.set(x,y+7,z);group.add(m);
   }

   const roofs=(World.roofs||[]).filter(r=>r.w>6&&r.d>5);
   for(let i=0;i<Math.min(20,roofs.length);i++){const roof=roofs[Math.floor(i*roofs.length/20)],x=roof.x,z=roof.z,y=roof.top+1.2;add(x,y,z,4,2.4,3,'#56646b');add(x,y+2.5,z,2.8,2.6,2.8,i%2?'#817562':'#556977');}
   const merged=mergeParts(parts);const mesh=new THREE.Mesh(merged,new THREE.MeshStandardMaterial({vertexColors:true,roughness:.84,flatShading:true}));mesh.castShadow=true;group.add(mesh);G.scene.add(group);parts.forEach(p=>p.g.dispose());SC.landmarks=group;
 }
 const baseWorld=buildWorld;buildWorld=function(scene,progress){baseWorld(scene,progress);landmarks();};
})();

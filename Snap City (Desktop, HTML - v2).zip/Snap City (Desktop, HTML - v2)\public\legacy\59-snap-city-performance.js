(function(){
"use strict";
const SC = window.SnapCity = window.SnapCity || {};
const LAYER = typeof REFL_LAYER !== "undefined" ? REFL_LAYER : 7;
const PERF = SC.perf = {
  enabled: true, frozen: [], cursor: 0, scanId: 0, scanT: 1.2, carT: 0,
  thawed: 0, reflTagged: 0, checkPerFrame: 12000, carReflectDist: 45, reflectPeople: true
};

function roadMats(){
  const s = new Set();
  try { if (World.mats){ if (World.mats.road) s.add(World.mats.road); if (World.mats.walk) s.add(World.mats.walk); } } catch(e){}
  return s;
}
function peopleParts(){
  const s = new Set();
  try { for (const k in PI_) if (PI_[k]) s.add(PI_[k]); } catch(e){}
  return s;
}
function movingRoots(){
  const s = new Set();
  try { for (const c of (Life.cars || [])) if (c && c.g) s.add(c.g); } catch(e){}
  try { if (Life.cable && Life.cable.g) s.add(Life.cable.g); } catch(e){}
  try { if (G.cam) s.add(G.cam); if (typeof heldCam !== "undefined" && heldCam) s.add(heldCam); } catch(e){}
  try { if (Rain && Rain.mesh) s.add(Rain.mesh); } catch(e){}
  return s;
}
function faint(o){
  const mats = Array.isArray(o.material) ? o.material : [o.material];
  return mats.every(m => !m || (m.transparent && m.opacity < 0.3));
}
function reflWorthy(o, ctx){
  if (o.isLight) return true;
  if (o === World.sky) return true;
  if (!o.isMesh) return false;
  if (ctx.people.has(o)) return PERF.reflectPeople;
  const mats = Array.isArray(o.material) ? o.material : [o.material];
  if (mats.some(m => ctx.road.has(m))) return false;
  if (faint(o)) return false;
  if (o.isInstancedMesh) return true;
  const g = o.geometry; if (!g) return false;
  if (!g.boundingSphere) g.computeBoundingSphere();
  if (!g.boundingSphere) return false;
  return g.boundingSphere.radius * o.matrixWorld.getMaxScaleOnAxis() >= 3.2;
}

function snapshot(o, into){
  const a = into || new Float64Array(10), p = o.position, q = o.quaternion, s = o.scale;
  a[0]=p.x; a[1]=p.y; a[2]=p.z; a[3]=q.x; a[4]=q.y; a[5]=q.z; a[6]=q.w; a[7]=s.x; a[8]=s.y; a[9]=s.z;
  return a;
}
function unchanged(o, a){
  const p = o.position, q = o.quaternion, s = o.scale;
  return a[0]===p.x && a[1]===p.y && a[2]===p.z && a[3]===q.x && a[4]===q.y && a[5]===q.z && a[6]===q.w && a[7]===s.x && a[8]===s.y && a[9]===s.z;
}
function markDynamic(o){
  o.traverse(c => {
    const u = c.userData;
    if (u._scF){ c.matrixAutoUpdate = true; u._scF = 0; }
    u._scDyn = true; u._rt = 1;
  });
}
function freeze(o){
  o.updateMatrix(); o.matrixAutoUpdate = false; o.userData._scF = 1;
  o.userData._scS = snapshot(o, o.userData._scS);
  PERF.frozen.push(o);
}
function thaw(o){ o.matrixAutoUpdate = true; o.userData._scF = 0; o.userData._scDyn = true; PERF.thawed++; }

function walk(o, parentVisible, ctx){
  const u = o.userData; u._scSeen = ctx.id;
  if (ctx.moving.has(o)){ markDynamic(o); return; }
  const vis = parentVisible && o.visible;
  if (!u._rt){ u._rt = 1; if (reflWorthy(o, ctx)){ o.layers.enable(LAYER); PERF.reflTagged++; } }
  if (PERF.enabled && o.matrixAutoUpdate && !u._scDyn && !u._scF && !o.isLight && !o.isCamera){
    if (u._scS && unchanged(o, u._scS)) freeze(o);
    else u._scS = snapshot(o, u._scS);
  }
  const ch = o.children;
  for (let i = 0; i < ch.length; i++) walk(ch[i], vis, ctx);
}

function scan(){
  if (!window.G || !G.scene || !window.World) return;
  const ctx = { id: ++PERF.scanId, road: roadMats(), people: peopleParts(), moving: movingRoots() };
  walk(G.scene, true, ctx);
  const keep = [];
  for (const o of PERF.frozen){ if (o.userData._scF && o.userData._scSeen === ctx.id && !o.matrixAutoUpdate) keep.push(o); else if (o.userData._scF){ o.userData._scF = 0; } }
  PERF.frozen = keep; if (PERF.cursor >= keep.length) PERF.cursor = 0;
}

function watchdog(){
  const list = PERF.frozen, n = list.length; if (!n) return;
  let budget = Math.min(n, PERF.checkPerFrame), i = PERF.cursor % n;
  while (budget-- > 0 && list.length){
    if (i >= list.length) i = 0;
    const o = list[i];
    if (o.matrixAutoUpdate || !o.userData._scF || !unchanged(o, o.userData._scS)){
      if (o.userData._scF) thaw(o);
      list[i] = list[list.length - 1]; list.pop();
      continue;
    }
    i++;
  }
  PERF.cursor = i;
}

function updateCarReflections(){
  const px = Player.x, pz = Player.z, r2 = PERF.carReflectDist * PERF.carReflectDist;
  for (const c of (Life.cars || [])){
    if (!c || !c.g) continue;
    const dx = c.g.position.x - px, dz = c.g.position.z - pz, near = dx*dx + dz*dz < r2;
    if (c._reflNear === near) continue;
    c._reflNear = near;
    c.g.traverse(o => { if (!o.isMesh) return; if (near && !faint(o)) o.layers.enable(LAYER); else o.layers.disable(LAYER); });
  }
}

PERF.disable = function(){ PERF.enabled = false; for (const o of PERF.frozen){ o.matrixAutoUpdate = true; o.userData._scF = 0; } PERF.frozen = []; };
PERF.enable = function(){ PERF.enabled = true; G.scene.traverse(o => { o.userData._scDyn = false; o.userData._scS = null; }); PERF.scanT = 0; };
PERF.scanNow = scan;
PERF.stats = function(){
  let objects = 0, auto = 0, refl = 0;
  G.scene.traverse(o => { objects++; if (o.matrixAutoUpdate) auto++; if (o.layers.test({ mask: 1 << LAYER })) refl++; });
  return { objects, autoUpdating: auto, frozen: PERF.frozen.length, thawed: PERF.thawed, reflectionLayer: refl, scans: PERF.scanId };
};

const baseRender = renderLive;
window.renderLive = function(){
  const sc = window.G && G.scene;
  if (!sc || !sc.autoUpdate) return baseRender.apply(this, arguments);
  try { if (!PERF.scanId && window.World && World.lots && World.lots.length) scan(); watchdog(); } catch(e){}
  sc.updateMatrixWorld();
  sc.autoUpdate = false;
  try { return baseRender.apply(this, arguments); }
  finally { sc.autoUpdate = true; }
};

const baseGameplay = gameplayUpdate;
window.gameplayUpdate = function(dt){
  const r = baseGameplay.apply(this, arguments);
  try {
    const now = performance.now() / 1000, rdt = Math.min(1, Math.max(0, now - (PERF.lastT || now))); PERF.lastT = now;
    PERF.carT -= rdt; if (PERF.carT <= 0){ PERF.carT = 0.5; updateCarReflections(); }
    PERF.scanT -= rdt; if (PERF.scanT <= 0){ PERF.scanT = 2; scan(); }
  } catch(e){ console.warn("[Snap City] performance pass skipped:", e); }
  return r;
};
})();

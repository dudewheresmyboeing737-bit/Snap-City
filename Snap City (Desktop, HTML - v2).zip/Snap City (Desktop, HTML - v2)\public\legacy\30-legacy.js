(function(){
"use strict";
const CS146 = window.CS146 = { scenes:[], timer:22, ready:false };
function rr(a,b){ return a + Math.random()*(b-a); }
function chance(p){ return Math.random() < p; }
function mm(c,r=.76,m=0.03,e=0){ return new THREE.MeshStandardMaterial({ color: lin(c), roughness:r, metalness:m, emissive:e?lin(c):0, emissiveIntensity:e }); }
function human(seed, palette){
  const rnd = (typeof mulberry !== 'undefined') ? mulberry(seed) : Math.random;
  const g = new THREE.Group();
  const skin = ['#f3ceb2','#dba57a','#bd7f57','#925d3e','#6f452d','#4f2f20'][((rnd()*6)|0)];
  const topc = palette&&palette.top || ['#263b4e','#6e4b3d','#324f45','#7c6858','#3a3a42','#94623a'][((rnd()*6)|0)];
  const botc = palette&&palette.bottom || ['#1f2124','#36435d','#4f473d','#191a1c'][((rnd()*4)|0)];
  const torso = new THREE.Mesh(new THREE.BoxGeometry(.36,.58,.22), mm(topc)); torso.position.y=1.02; g.add(torso);
  const pelvis = new THREE.Mesh(new THREE.BoxGeometry(.28,.12,.18), mm(botc)); pelvis.position.y=.69; g.add(pelvis);
  for(const sx of [-1,1]){ const leg=new THREE.Mesh(new THREE.BoxGeometry(.13,.7,.15), mm(botc)); leg.position.set(sx*.09,.35,0); g.add(leg); const arm=new THREE.Mesh(new THREE.CylinderGeometry(.048,.055,.56,8), mm(topc)); arm.position.set(sx*.23,.98,0); arm.rotation.z=sx*.08; g.add(arm); }
  const head = new THREE.Mesh(new THREE.SphereGeometry(.16,12,9), mm(skin,.72)); head.position.y=1.45; g.add(head);
  if(rnd()<.76){ const hair=new THREE.Mesh(new THREE.SphereGeometry(.17,10,7,0,Math.PI*2,0,Math.PI*.58), mm(['#15120f','#3e2a1d','#65452c','#aa895d','#787878'][((rnd()*5)|0)],.7)); hair.position.y=1.53; g.add(hair); }
  return g;
}
function signProp(txt, col){ const g=new THREE.Group(); const p=new THREE.Mesh(new THREE.BoxGeometry(.34,.48,.03), mm(col||'#d8ceb6',.86)); p.position.y=1.1; g.add(p); const stick=new THREE.Mesh(new THREE.CylinderGeometry(.012,.012,.68,8), mm('#8a6f4b',.82)); stick.position.y=.62; g.add(stick); return g; }
function phoneProp(){ const p=new THREE.Mesh(new THREE.BoxGeometry(.08,.13,.01), mm('#111',.4,.2)); p.position.set(.12,1.02,.18); return p; }
function bottleProp(){ const p=new THREE.Mesh(new THREE.CylinderGeometry(.03,.025,.16,8), mm('#8fd0e8',.45,.05,.15)); p.position.set(.12,1.02,.18); return p; }
function broomProp(){ const g=new THREE.Group(); const stick=new THREE.Mesh(new THREE.CylinderGeometry(.012,.012,.8,8), mm('#9b7a58',.82)); stick.position.y=.76; g.add(stick); const br=new THREE.Mesh(new THREE.BoxGeometry(.14,.05,.04), mm('#c9b16d',.76)); br.position.y=.38; g.add(br); return g; }
function benchProp(){ const g=new THREE.Group(); const seat=new THREE.Mesh(new THREE.BoxGeometry(.72,.06,.24), mm('#5e4738',.84)); seat.position.set(0,.48,0); g.add(seat); const back=new THREE.Mesh(new THREE.BoxGeometry(.72,.26,.05), mm('#5e4738',.84)); back.position.set(0,.63,-.1); g.add(back); for(const sx of [-.26,.26]){ const leg=new THREE.Mesh(new THREE.BoxGeometry(.05,.48,.05), mm('#4a4a4d',.64,.1)); leg.position.set(sx,.24,0); g.add(leg);} return g; }
function awningProp(){ const g=new THREE.Group(); const top=new THREE.Mesh(new THREE.BoxGeometry(1.3,.08,.5), mm('#26364c',.72)); top.position.set(0,2.2,0); g.add(top); for(const sx of [-.58,.58]){ const pole=new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,2.2,8), mm('#87704d',.72)); pole.position.set(sx,1.1,.18); g.add(pole);} return g; }
const DETAILS = [
  { key:'fold_sign', label:'A protester carefully folds a sign instead of tossing it away.', sound:'crowd', make(x,z){ const g=new THREE.Group(); const p=human(101,{top:'#55614e',bottom:'#2b2d31'}); const s=signProp('CARE','#d7cfc0'); s.rotation.z=.18; s.position.set(.1,0,0); g.add(p,s); g.position.set(x,H(x,z),z); return {g, life:24}; }},
  { key:'water_outside', label:'A shop owner offers water to people outside the business.', sound:'crowd', make(x,z){ const g=new THREE.Group(); const a=human(203,{top:'#7a5d47',bottom:'#2a2f36'}), b=human(204,{top:'#44607e',bottom:'#202328'}); a.position.x=-.28; b.position.x=.28; a.add(bottleProp()); g.add(a,b); g.position.set(x,H(x,z),z); return {g, life:26}; }},
  { key:'organizer_curb', label:'An exhausted organizer sits on a curb reading messages on a phone.', sound:'hum', make(x,z){ const g=new THREE.Group(); const p=human(311,{top:'#3c3d47',bottom:'#1f2125'}); p.position.y=-.18; p.rotation.x=.05; p.add(phoneProp()); const bench=benchProp(); bench.scale.set(.72,.6,.7); bench.position.set(0,-.14,0); g.add(p); g.position.set(x,H(x,z),z); return {g, life:28}; }},
  { key:'parent_sign', label:'A parent explains a protest sign to a child.', sound:'crowd', make(x,z){ const g=new THREE.Group(); const a=human(412,{top:'#734d55',bottom:'#2a2d31'}), c=human(413,{top:'#c7854d',bottom:'#3b3d44'}); c.scale.set(.68,.68,.68); c.position.set(.34,0,0); const s=signProp('HOPE','#e6ddcc'); s.position.set(-.1,0,0); g.add(a,c,s); g.position.set(x,H(x,z),z); return {g, life:24}; }},
  { key:'street_cleaner', label:'A street cleaner pauses to read a slogan before removing it.', sound:'hum', make(x,z){ const g=new THREE.Group(); const p=human(509,{top:'#b48e33',bottom:'#30343a'}); const broom=broomProp(); broom.position.set(.18,-.08,.12); const s=signProp('LISTEN','#ddd3bf'); s.scale.set(.7,.7,.7); s.position.set(-.24,0,0); g.add(p,broom,s); g.position.set(x,H(x,z),z); return {g, life:25}; }},
  { key:'awkward_awning', label:'A protester and counter-protester share an awkward dry spot under one awning.', sound:'thunder', make(x,z){ const g=new THREE.Group(); const a=human(611,{top:'#c45e44',bottom:'#22252a'}), b=human(612,{top:'#4465a4',bottom:'#22252a'}); a.position.x=-.24; b.position.x=.24; const aw=awningProp(); g.add(aw,a,b); g.position.set(x,H(x,z),z); return {g, life:30}; }},
  { key:'sign_return', label:'A handmade sign appears again in a window far from the original protest.', sound:'gasp', make(x,z){ const g=new THREE.Group(); const s=signProp('WE REMEMBER','#d9cdb4'); s.scale.set(.85,.85,.85); g.add(s); g.position.set(x,H(x,z)+1.4,z); return {g, life:32}; }}
];
function spawnDetail(){
  if(!window.G || !G.scene || CS146.scenes.length>2) return;
  const d = DETAILS[(Math.random()*DETAILS.length)|0];
  const px = Player.x + rr(-28,28), pz = Player.z + rr(-28,28);
  const built = d.make(px,pz); if(!built||!built.g) return;
  built.kind = d.key; built.label = d.label; built.sound = d.sound; built.x = px; built.z = pz;
  G.scene.add(built.g); CS146.scenes.push(built);
  if(chance(0.8) && S.custom && S.custom.eventPopups==='on' && S.custom.eventNotify==='clue') toast(d.label, 2400);
  try{ if(d.sound) SND.play(d.sound, px, pz, 0.7); }catch(e){}
}
function updateDetails(dt){
  CS146.timer -= dt;
  if(CS146.timer<=0){ CS146.timer = rr(38,78); spawnDetail(); }
  CS146.scenes = CS146.scenes.filter(s=>{
    s.life -= dt;
    if(s.g){
      const fade = Math.max(0, Math.min(1, s.life/6));
      s.g.traverse(o=>{ if(o.material && 'opacity' in o.material){ o.material.transparent = fade<1; o.material.opacity = fade; } });
    }
    if(s.life<=0){ try{ G.scene.remove(s.g); }catch(e){} return false; }
    return true;
  });
}
if(typeof gameplayUpdate==='function'){
  const _gp146 = gameplayUpdate;
  gameplayUpdate = function(dt){ const r = _gp146.apply(this, arguments); try{ updateDetails(dt); }catch(e){} return r; };
}
console.log('[Contact Sheet v14.6] long-shutter movement fix and tiny details active.');
})();

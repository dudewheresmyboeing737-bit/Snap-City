import { cameraEv100 } from "./exposure";

export type ExposurePriority = "balanced" | "freeze-motion" | "handheld" | "shallow-depth" | "deep-depth";

export interface CameraExposureLimits {
  apertureValues: readonly number[];
  shutterValues: readonly number[];
  isoValues: readonly number[];
}

export interface PerfectExposureRequest {
  targetSceneEv100: number;
  priority: ExposurePriority;
  protectHighlights: boolean;
  filmBiasEv?: number;
  limits: CameraExposureLimits;
}

export interface PerfectExposureResult {
  aperture: number;
  shutterSeconds: number;
  iso: number;
  cameraEv100: number;
  errorEv: number;
}

function preferredShutter(priority: ExposurePriority): number {
  switch (priority) {
    case "freeze-motion": return 1 / 250;
    case "handheld": return 1 / 60;
    case "shallow-depth": return 1 / 60;
    case "deep-depth": return 1 / 30;
    default: return 1 / 125;
  }
}

export function findPerfectExposure(request: PerfectExposureRequest): PerfectExposureResult {
  const targetEv100 = request.targetSceneEv100 - (request.filmBiasEv ?? 0) + (request.protectHighlights ? 0.33 : 0);
  let best: PerfectExposureResult | undefined;
  let bestScore = Number.POSITIVE_INFINITY;

  for (const aperture of request.limits.apertureValues) {
    for (const shutterSeconds of request.limits.shutterValues) {
      for (const iso of request.limits.isoValues) {
        const ev = cameraEv100(aperture, shutterSeconds, iso);
        const errorEv = ev - targetEv100;
        const shutterPenalty = Math.abs(Math.log2(shutterSeconds / preferredShutter(request.priority)));
        const isoPenalty = Math.max(0, Math.log2(iso / 100)) * 0.18;
        const aperturePenalty = request.priority === "shallow-depth" ? Math.max(0, Math.log2(aperture / 2)) : request.priority === "deep-depth" ? Math.max(0, Math.log2(16 / aperture)) : 0;
        const score = Math.abs(errorEv) * 20 + shutterPenalty + isoPenalty + aperturePenalty;
        if (score < bestScore) {
          bestScore = score;
          best = { aperture, shutterSeconds, iso, cameraEv100: ev, errorEv };
        }
      }
    }
  }
  if (!best) throw new Error("No camera exposure combinations were supplied.");
  return best;
}

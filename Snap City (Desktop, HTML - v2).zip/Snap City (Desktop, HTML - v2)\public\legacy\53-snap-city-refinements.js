/* Snap City: quieter defaults, coherent controls, traversal and opt-in experiments. */
(function(){
 'use strict';
 const SC=window.SnapCity=window.SnapCity||{};
 const defaults={tHaptics:'off',eventNotify:'none',eventPins:'off',masterVol:'half',eventPopups:'off',editorPersonality:'on',exposurePriority:'balanced',hudAccent:'amber'};
 function migrate(s){if(!s||!s.custom)return s;if(!s.custom._sc53){Object.assign(s.custom,defaults);if(s.custom.eventNotify==='clue')s.custom.eventNotify='sound';s.custom._sc53=1;}return s;}
 for(const name of ['defaultState','loadState']){const base=window[name];window[name]=function(){return migrate(base.apply(this,arguments));};}
 const start=startGame;window.startGame=function(){const result=start.apply(this,arguments);migrate(S);saveState();return result;};
 const leave=leaveZone;window.leaveZone=function(){
  if(ZONE.mode==='roof'&&ZONE.box){
   const b=ZONE.box, roof=(World.roofs||[]).find(r=>Math.abs(r.x-b.x)<.2&&Math.abs(r.z-b.z)<.2);
   if(roof){const tangent=[roof.n[1],-roof.n[0]], along=clamp((Player.x-roof.fx)*tangent[0]+(Player.z-roof.fz)*tangent[1],-roof.w/2+.7,roof.w/2-.7);
    let x=roof.fx+tangent[0]*along+roof.n[0]*1.5,z=roof.fz+tangent[1]*along+roof.n[1]*1.5;
    [x,z]=collidePoint(x,z,.4);ZONE.back={x,z};
   }
  }
  return leave.apply(this,arguments);
 };
 // These are session-only, so experiments can never poison a saved game.
 const dev=SC.experiments={autoFPS:false,threshold:20,moonJump:false,slowCity:false,rainbowSun:false};
 let last=0,samples=0,elapsed=0,low=0,recovery=0,level=0,restore=null,sunColor=null;
 function resetQuality(){if(restore){Object.assign(S.custom,restore);restore=null;applyGraphicsQuality();}level=0;low=0;recovery=0;}
 function downgrade(){
  if(!restore)restore={renderQuality:S.custom.renderQuality,graphicsPreset:S.custom.graphicsPreset,reflections:S.custom.reflections};
  if(level===0){S.custom.renderQuality='performance';S.custom.graphicsPreset='low';S.custom.reflections='balanced';applyGraphicsQuality();level=1;}
  else if(level<3)level++;
  if(G.renderer){const scale=level===1?.85:level===2?.65:.5;G.renderer.setPixelRatio(scale);if(G.rtLive)G.rtLive.setSize(Math.max(1,Math.floor(innerWidth*scale)),Math.max(1,Math.floor(innerHeight*scale)));}
 }
 const save=saveState;window.saveState=function(){if(!restore)return save.apply(this,arguments);const active={};for(const k in restore){active[k]=S.custom[k];S.custom[k]=restore[k];}try{return save.apply(this,arguments);}finally{Object.assign(S.custom,active);}};
 const tick=gameplayUpdate;window.gameplayUpdate=function(dt){
  const result=tick.apply(this,arguments),now=performance.now();
  if(dev.rainbowSun&&World.sun){if(!sunColor)sunColor=World.sun.color.clone();World.sun.color.setHSL((now/18000)%1,.55,.65);}else if(sunColor&&World.sun){World.sun.color.copy(sunColor);sunColor=null;}
  const gap=last?(now-last)/1000:0;last=now;
  if(!dev.autoFPS||document.hidden||!Game.started||gap>1||gap<=0){samples=elapsed=low=recovery=0;return result;}
  samples++;elapsed+=gap;
  if(elapsed>=2){const fps=samples/elapsed;dev.fps=Math.round(fps);low=fps<dev.threshold?low+elapsed:0;recovery=fps>dev.threshold+12?recovery+elapsed:0;samples=elapsed=0;
   if(low>=4&&level<3){downgrade();low=0;}else if(recovery>=20&&restore){resetQuality();}
  }
  return result;
 };
 document.addEventListener('visibilitychange',()=>{last=0;samples=elapsed=low=recovery=0;});
 const life=updateLife;window.updateLife=function(dt,pl){return life.call(this,dev.slowCity?dt*.3:dt,pl);};
 const leap=jump;window.jump=function(){const airborne=PLAYX.air,result=leap.apply(this,arguments);if(dev.moonJump&&!airborne&&PLAYX.air)PLAYX.vy*=1.8;return result;};
 const menu=renderMenu;window.renderMenu=function(){const result=menu.apply(this,arguments);if(UI.menuTab!=='settings')return result;
  const body=document.getElementById('menubody');
  for(const key of ['exposurePriority','hudAccent','difficultyProfile','currentEditor','steadiness','carVariety','editorPersonality'])body.querySelectorAll('[data-seg="'+key+'"], [data-seg44="'+key+'"]').forEach(e=>e.closest('.formrow')?.remove());
  const vehicles=body.querySelector('[data-seg="vehicleVariety"]');if(vehicles){vehicles.closest('.formrow').querySelector('label').textContent='Vehicle variety & details';const help=document.createElement('span');help.className='spec';help.textContent='Normal keeps familiar body styles and simpler trim. Maximum adds unusual silhouettes and accessories. Reopen the game to regenerate traffic.';vehicles.closest('.formrow').appendChild(help);for(const b of vehicles.querySelectorAll('button'))b.onclick=()=>{S.custom.vehicleVariety=b.dataset.v;S.custom.carVariety=b.dataset.v==='max'?'high':'normal';saveState();renderMenu();};}
  let events=[...body.querySelectorAll('details')].find(e=>e.querySelector('summary')?.textContent.startsWith('Events'))||body;
  const row=document.createElement('div');row.className='formrow';row.innerHTML='<label><input type="checkbox" id="scEventPopups"> Center-screen event descriptions</label><span class="spec">Optional written clues. The side feed and its map flashes remain separate.</span>';events.appendChild(row);const check=row.querySelector('input');check.checked=S.custom.eventPopups==='on';check.onchange=()=>{S.custom.eventPopups=check.checked?'on':'off';saveState();};
  let section=[...body.querySelectorAll('details')].find(e=>e.querySelector('summary')?.textContent.startsWith('Develop'))||body;
  const opts=[['autoFPS','Automatic FPS safeguard','Reduce rendering resolution and shadows after sustained low FPS; restore after sustained recovery.'],['moonJump','Moon jumps','Extra jump height.'],['slowCity','Slow-motion city','Slow people and traffic while you explore normally.'],['rainbowSun','Rainbow sunlight','Cycle the sunlight through unusual colours.']];
  for(const [key,title,help]of opts){
   const row=document.createElement('div');row.className='formrow';row.dataset.scExperiment=key;
   row.innerHTML='<label>'+title+'</label><div class="seg" role="group" aria-label="'+title+'"><button type="button" data-v="off">Off</button><button type="button" data-v="on">On</button></div><span class="spec">'+help+' Session only; starts off.</span>';
   const buttons=row.querySelectorAll('button');
   const sync=()=>buttons.forEach(b=>b.setAttribute('aria-pressed',String(dev[key]===(b.dataset.v==='on'))));
   for(const button of buttons)button.onclick=()=>{dev[key]=button.dataset.v==='on';if(key==='autoFPS'&&!dev[key])resetQuality();sync();};
   sync();section.appendChild(row);
  }
  const fps=document.createElement('div');fps.className='formrow';fps.innerHTML='<label>FPS safeguard threshold <input aria-label="FPS safeguard threshold" type="number" min="10" max="60" step="1" value="'+dev.threshold+'"></label><span class="spec">Default 20 FPS. Changes require four seconds of low performance; menu pauses and hidden tabs are ignored.</span>';fps.querySelector('input').onchange=e=>{dev.threshold=clamp(Number(e.target.value)||20,10,60);e.target.value=dev.threshold;low=recovery=0;};section.appendChild(fps);
  for(const section of body.querySelectorAll('details')){const small=section.querySelector('summary small');if(small)small.textContent=section.querySelectorAll('.formrow').length;}
  return result;
 };
 let selected=null,until=0;
 document.addEventListener('click',e=>{const b=e.target.closest('[data-event-index]');if(!b)return;const f=SC.life?.feed[Number(b.dataset.eventIndex)];if(f){selected=f.E;until=performance.now()+8000;}});
 const map=drawMinimap;window.drawMinimap=function(){map.apply(this,arguments);if(!selected||performance.now()>until||selected.done)return;
  const ex=selected.px??selected.x??selected.ppl?.[0]?.x,ez=selected.pz??selected.z??selected.ppl?.[0]?.z;if(!Number.isFinite(ex)||!Number.isFinite(ez))return;
  const c=document.getElementById('minimap'),ctx=c.getContext('2d'),w=c.width,s=w/240,dx=ex-Player.x,dz=ez-Player.z;
  let x=(dx*Math.cos(Player.yaw)-dz*Math.sin(Player.yaw))*s,y=(dx*Math.sin(Player.yaw)+dz*Math.cos(Player.yaw))*s;
  const max=w/2-14,d=Math.hypot(x,y);if(d>max){x*=max/d;y*=max/d;}
  const pulse=(Math.sin(performance.now()*.012)+1)/2;ctx.save();ctx.translate(w/2,w/2);ctx.fillStyle='rgba(255,192,72,'+(.15+.35*pulse)+')';ctx.strokeStyle='#ffe1a0';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,8+9*pulse,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.restore();
 };
 const pickVehicle=pickCarType;window.pickCarType=function(r){if(typeof S!=='undefined'&&S?.custom?.vehicleVariety==='normal'){const familiar=['sedan','hatch','suv','van','pickup','wagon','beetle','classic'];return familiar[Math.floor(r()*familiar.length)];}return pickVehicle(r);};
 // New silhouettes use the existing shared geometry/material pipeline.
 const variants={microvan:{base:'van',L:3.3,W:1.55,wf:1.05,wr:-1.03,cabin:[[-1.6,0],[-1.55,1],[.6,1],[1.4,0]],ch:1.1},lowrider:{base:'classic',clr:.09,L:5.5,W:2.02,R:.27},stretch:{base:'sedan',L:7.2,wf:2.6,wr:-2.6,cabin:[[-2.55,0],[-2,1],[1.8,1],[2.4,0]]},dunebuggy:{base:'convertible',L:3.3,W:1.8,clr:.45,R:.5,wf:1.1,wr:-1.1},hotrod:{base:'vintage',L:3.9,clr:.25,R:.43,wf:1.3,wr:-1.25,cabin:[[-1.25,0],[-.9,1],[-.25,1],[.2,0]],ch:.58}};
 for(const [name,v]of Object.entries(variants)){const {base,...props}=v;CAR_TYPES[name]={...CAR_TYPES[base],...props};CAR_TYPE_WEIGHTS.push([name,.8]);CAR_PALETTES[name]=['#d04499','#53b6ae','#dabd47','#56357e','#dd692d','#eee6d7'];}
})();

const _drawMinimapBase = drawMinimap;
drawMinimap = function(){
  _drawMinimapBase();
  if (!S || S.custom.eventPins === "off" || S.custom.hud === "off") return;
  const c = $("#minimap"), x = c.getContext("2d"), W = c.width, R = 120, s = (W/2)/R;
  const fx = -Math.sin(Player.yaw), fz = -Math.cos(Player.yaw), rx = Math.cos(Player.yaw), rz = -Math.sin(Player.yaw);
  for (const E of EV.list){
    if (E.px === undefined || (S.custom.eventPins === "heard" && !E.heard)) continue;
    const dx = E.px - Player.x, dz = E.pz - Player.z; let px = (dx*rx + dz*rz)*s, py = -(dx*fx + dz*fz)*s;
    const max = W/2 - 18, mag = Math.hypot(px, py), off = mag > max; if (off){ px *= max/mag; py *= max/mag; }
    const rare = !!E.info.rare, pulse = 0.5 + 0.5*Math.sin(performance.now()*0.007);
    x.save(); x.beginPath(); x.arc(W/2, W/2, W/2-2, 0, Math.PI*2); x.clip(); x.translate(W/2, W/2);
    x.fillStyle = "rgba(10,10,9,.72)"; x.strokeStyle = rare ? "#fff0bd" : "#e8a33d"; x.lineWidth = 3; x.beginPath(); x.arc(px, py, 6 + pulse*3, 0, Math.PI*2); x.fill(); x.stroke();
    x.fillStyle = rare ? "#fff0bd" : "#e8a33d"; x.beginPath(); x.arc(px, py, 3, 0, Math.PI*2); x.fill(); x.restore();
  }
};

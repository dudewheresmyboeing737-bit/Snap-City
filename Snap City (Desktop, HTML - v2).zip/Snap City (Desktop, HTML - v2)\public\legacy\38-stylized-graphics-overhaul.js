(function () {
  "use strict";

  const CS_GFX = window.CS_GFX = window.CS_GFX || {
    version: 1,
    initialized: false,
    clouds: [],
    birds: [],
    windowLights: [],
    wetStreaks: [],
    mistCards: [],
    facadeDetails: [],
    lastPalette: "",
    fps: {
      last: performance.now(),
      frames: 0,
      value: 0
    }
  };

  const GFX_DEFAULTS = {
    graphicsPreset: "high",
    atmosphereStrength: "cinematic",
    wetStreets: "on",
    livingSky: "on",
    facadeDetail: "rich",
    crowdPresentation: "rich",
    performanceOverlay: "off",
    cinematicBloom: "on",
    stylizedPalette: "on"
  };

  const PALETTES = {
    morning: {
      skyTop: "#657f9f",
      skyHorizon: "#efd4aa",
      fog: "#aebdca",
      ambient: "#9fb5c7",
      ground: "#5e6874",
      warm: "#ffc77c",
      cool: "#a8cce0",
      window: "#ffd297",
      mistOpacity: 0.13
    },
    noon: {
      skyTop: "#5c86af",
      skyHorizon: "#d4e0e5",
      fog: "#c0d0da",
      ambient: "#c3d7de",
      ground: "#7a8282",
      warm: "#ffe3a3",
      cool: "#b3d8e8",
      window: "#ffe4b2",
      mistOpacity: 0.05
    },
    golden: {
      skyTop: "#7e7ea1",
      skyHorizon: "#f2ad7e",
      fog: "#c69d9c",
      ambient: "#d5a797",
      ground: "#71615b",
      warm: "#ffb657",
      cool: "#a9a7d0",
      window: "#ffcf84",
      mistOpacity: 0.08
    },
    blue: {
      skyTop: "#263b62",
      skyHorizon: "#8a92ad",
      fog: "#6e7b9d",
      ambient: "#7182a4",
      ground: "#3c4658",
      warm: "#f5af63",
      cool: "#738bb8",
      window: "#ffc078",
      mistOpacity: 0.18
    },
    night: {
      skyTop: "#081221",
      skyHorizon: "#26354f",
      fog: "#24354b",
      ambient: "#34445e",
      ground: "#202a36",
      warm: "#f5a853",
      cool: "#5877aa",
      window: "#ffbf76",
      mistOpacity: 0.24
    }
  };

  function opt(name) {
    return S && S.custom ? S.custom[name] : undefined;
  }

  function ensureSettings() {
    if (!window.S) return;

    S.custom = S.custom || {};

    for (const key in GFX_DEFAULTS) {
      if (S.custom[key] === undefined) {
        S.custom[key] = GFX_DEFAULTS[key];
      }
    }
  }

  function paletteName() {
    if (!window.S) return "noon";

    if (S.time === "morning") return "morning";
    if (S.time === "golden") return "golden";
    if (S.time === "blue") return "blue";
    if (S.time === "night") return "night";

    return "noon";
  }

  function activePalette() {
    return PALETTES[paletteName()] || PALETTES.noon;
  }

  function hexColor(value) {
    return new THREE.Color(value);
  }

  function presetConfig() {
    const preset = opt("graphicsPreset") || "high";

    if (preset === "low") {
      return {
        clouds: 3,
        birds: 8,
        mist: 2,
        streaks: 16,
        windowDetails: 20,
        maxPixelRatio: 1,
        shadowScale: 0.5
      };
    }

    if (preset === "medium") {
      return {
        clouds: 5,
        birds: 14,
        mist: 4,
        streaks: 30,
        windowDetails: 38,
        maxPixelRatio: 1.25,
        shadowScale: 0.75
      };
    }

    if (preset === "ultra") {
      return {
        clouds: 18,
        birds: 54,
        mist: 18,
        streaks: 150,
        windowDetails: 220,
        maxPixelRatio: 2,
        shadowScale: 2
      };
    }

    return {
      clouds: 7,
      birds: 22,
      mist: 6,
      streaks: 50,
      windowDetails: 64,
      maxPixelRatio: 1.5,
      shadowScale: 1
    };
  }

  function setRendererQuality() {
    if (!window.G || !G.renderer) return;

    const config = presetConfig();
    const ratio = Math.min(window.devicePixelRatio || 1, config.maxPixelRatio);

    G.renderer.setPixelRatio(ratio);

    if (G.renderer.shadowMap) {
      G.renderer.shadowMap.enabled = opt("graphicsPreset") !== "low";
      G.renderer.shadowMap.autoUpdate = true;
    }

    if ("toneMappingExposure" in G.renderer) {
      const time = paletteName();
      const rainPenalty = S && S.rain ? -0.08 : 0;
      const nightPenalty = time === "night" ? -0.12 : 0;

      G.renderer.toneMappingExposure = 1 + rainPenalty + nightPenalty;
    }
  }

  function applyPalette() {
    if (!window.G || !G.scene || !window.S || opt("stylizedPalette") === "off") return;

    const palette = activePalette();
    const rain = !!S.rain;
    const fog = !!S.fog;
    const storm = !!S.storm;
    const key = [
      paletteName(),
      rain,
      fog,
      storm,
      opt("stylizedPalette")
    ].join(":");

    if (CS_GFX.lastPalette === key) return;

    CS_GFX.lastPalette = key;

    const fogColor = hexColor(
      storm ? "#344356" :
      rain ? blendHex(palette.fog, "#4f6574", 0.42) :
      fog ? palette.fog :
      palette.fog
    );

    const fogDensity =
      storm ? 0.022 :
      rain ? 0.016 :
      fog ? 0.020 :
      paletteName() === "night" ? 0.010 :
      0.006;

    if (G.scene.fog) {
      G.scene.fog.color.copy(fogColor);

      if ("density" in G.scene.fog) {
        G.scene.fog.density = fogDensity;
      }
    } else {
      G.scene.fog = new THREE.FogExp2(fogColor, fogDensity);
    }

    if (G.scene.background) {
      G.scene.background = hexColor(palette.skyTop);
    }

    const lights = findLights();

    if (lights.ambient) {
      lights.ambient.color.copy(hexColor(palette.ambient));
      lights.ambient.intensity =
        paletteName() === "night" ? 0.48 :
        paletteName() === "blue" ? 0.62 :
        rain ? 0.72 :
        0.86;
    }

    if (lights.hemi) {
      lights.hemi.color.copy(hexColor(palette.cool));
      lights.hemi.groundColor.copy(hexColor(palette.ground));
      lights.hemi.intensity =
        paletteName() === "night" ? 0.52 :
        paletteName() === "blue" ? 0.7 :
        0.9;
    }

    if (lights.directional) {
      lights.directional.color.copy(
        hexColor(
          paletteName() === "night"
            ? "#809bc7"
            : palette.warm
        )
      );

      lights.directional.intensity =
        paletteName() === "night" ? 0.18 :
        paletteName() === "blue" ? 0.35 :
        rain ? 0.48 :
        paletteName() === "golden" ? 1.2 :
        0.9;
    }

    recolorWindows(palette);
  }

  function findLights() {
    const result = {
      ambient: null,
      hemi: null,
      directional: null
    };

    if (!window.G || !G.scene) return result;

    G.scene.traverse(function (object) {
      if (object.isAmbientLight && !result.ambient) {
        result.ambient = object;
      }

      if (object.isHemisphereLight && !result.hemi) {
        result.hemi = object;
      }

      if (object.isDirectionalLight && !result.directional) {
        result.directional = object;
      }
    });

    return result;
  }

  function blendHex(a, b, mix) {
    const colorA = new THREE.Color(a);
    const colorB = new THREE.Color(b);

    colorA.lerp(colorB, mix);

    return "#" + colorA.getHexString();
  }

  function recolorWindows(palette) {
    if (!CS_GFX.windowLights.length) return;

    const nightBoost =
      paletteName() === "night" ? 1.8 :
      paletteName() === "blue" ? 1.45 :
      paletteName() === "golden" ? 1.15 :
      0.55;

    for (const entry of CS_GFX.windowLights) {
      const flicker = entry.seed % 5 === 0 ? 0.78 : 1;
      const warm = new THREE.Color(palette.window);

      entry.material.color.copy(warm);
      entry.material.emissive.copy(warm);
      entry.material.emissiveIntensity = nightBoost * flicker;
    }
  }

  function makeCloudTexture() {
    const canvas = document.createElement("canvas");

    canvas.width = 256;
    canvas.height = 256;

    const ctx = canvas.getContext("2d");
    const gradient = ctx.createRadialGradient(
      128, 128, 6,
      128, 128, 122
    );

    gradient.addColorStop(0, "rgba(255,255,255,0.84)");
    gradient.addColorStop(0.42, "rgba(230,235,244,0.46)");
    gradient.addColorStop(1, "rgba(190,205,220,0)");

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;

    return texture;
  }

  function createClouds() {
    if (!window.G || !G.scene || CS_GFX.clouds.length) return;
    if (opt("livingSky") === "off") return;

    const config = presetConfig();
    const texture = makeCloudTexture();

    for (let index = 0; index < config.clouds; index += 1) {
      const material = new THREE.SpriteMaterial({
        map: texture,
        transparent: true,
        depthWrite: false,
        opacity: 0.16 + Math.random() * 0.13,
        color: "#d9e4ed"
      });

      const cloud = new THREE.Sprite(material);

      cloud.position.set(
        -180 + Math.random() * 360,
        52 + Math.random() * 52,
        -170 + Math.random() * 340
      );

      const size = 38 + Math.random() * 88;
      cloud.scale.set(size, size * (0.38 + Math.random() * 0.22), 1);

      G.scene.add(cloud);

      CS_GFX.clouds.push({
        sprite: cloud,
        speed: 0.55 + Math.random() * 1.2,
        drift: Math.random() * Math.PI * 2,
        baseY: cloud.position.y,
        phase: Math.random() * Math.PI * 2
      });
    }
  }

  function createBirds() {
    if (!window.G || !G.scene || CS_GFX.birds.length) return;
    if (opt("livingSky") === "off") return;

    const config = presetConfig();

    const geometry = new THREE.BufferGeometry();
    const vertices = new Float32Array([
      -0.55, 0, 0,
       0, 0.16, 0,
       0.55, 0, 0,
       0, -0.05, 0
    ]);

    geometry.setAttribute(
      "position",
      new THREE.BufferAttribute(vertices, 3)
    );

    const material = new THREE.LineBasicMaterial({
      color: "#202833",
      transparent: true,
      opacity: 0.7
    });

    for (let index = 0; index < config.birds; index += 1) {
      const bird = new THREE.LineLoop(geometry, material.clone());

      bird.position.set(
        -110 + Math.random() * 220,
        18 + Math.random() * 60,
        -100 + Math.random() * 200
      );

      const scale = 0.35 + Math.random() * 0.9;
      bird.scale.setScalar(scale);

      G.scene.add(bird);

      CS_GFX.birds.push({
        object: bird,
        speed: 2.1 + Math.random() * 2.8,
        radius: 30 + Math.random() * 115,
        centerX: -20 + Math.random() * 40,
        centerZ: -20 + Math.random() * 40,
        phase: Math.random() * Math.PI * 2,
        height: bird.position.y,
        flap: Math.random() * Math.PI * 2
      });
    }
  }

  function createMistCards() {
    if (!window.G || !G.scene || CS_GFX.mistCards.length) return;
    if (opt("atmosphereStrength") === "off") return;

    const config = presetConfig();
    const texture = makeCloudTexture();

    for (let index = 0; index < config.mist; index += 1) {
      const material = new THREE.SpriteMaterial({
        map: texture,
        transparent: true,
        depthWrite: false,
        opacity: 0.08,
        color: "#92a9b7"
      });

      const sprite = new THREE.Sprite(material);

      sprite.position.set(
        -80 + Math.random() * 160,
        2.5 + Math.random() * 5,
        -75 + Math.random() * 150
      );

      const scale = 22 + Math.random() * 54;
      sprite.scale.set(scale, scale * 0.26, 1);

      G.scene.add(sprite);

      CS_GFX.mistCards.push({
        sprite,
        baseOpacity: 0.05 + Math.random() * 0.07,
        phase: Math.random() * Math.PI * 2,
        drift: 0.5 + Math.random() * 0.8
      });
    }
  }

  function createWetStreaks() {
    if (!window.G || !G.scene || CS_GFX.wetStreaks.length) return;
    if (opt("wetStreets") === "off") return;

    const config = presetConfig();

    const geometry = new THREE.PlaneGeometry(1, 1);

    for (let index = 0; index < config.streaks; index += 1) {
      const isWarm = Math.random() > 0.48;
      const material = new THREE.MeshBasicMaterial({
        color: isWarm ? "#f1ab65" : "#87b2d2",
        transparent: true,
        opacity: 0.06 + Math.random() * 0.12,
        depthWrite: false,
        blending: THREE.AdditiveBlending
      });

      const mesh = new THREE.Mesh(geometry, material);

      mesh.rotation.x = -Math.PI / 2;
      mesh.position.set(
        -95 + Math.random() * 190,
        0.026 + Math.random() * 0.008,
        -95 + Math.random() * 190
      );

      mesh.scale.set(
        0.16 + Math.random() * 0.42,
        1.6 + Math.random() * 6.8,
        1
      );

      mesh.rotation.z = (Math.random() - 0.5) * 0.22;

      G.scene.add(mesh);

      CS_GFX.wetStreaks.push({
        mesh,
        baseOpacity: material.opacity,
        phase: Math.random() * Math.PI * 2,
        warm: isWarm
      });
    }
  }

  function addFacadeAccents() {
    if (!window.G || !G.scene || CS_GFX.facadeDetails.length) return;
    if (opt("facadeDetail") === "lean") return;
    if (!World || !World.shops) return;

    const max =
      opt("facadeDetail") === "obsessive"
        ? World.shops.length
        : Math.min(World.shops.length, 42);

    const awningColors = [
      "#9d473d",
      "#365f77",
      "#506044",
      "#cc9253",
      "#6f4f7b",
      "#41444b"
    ];

    for (let index = 0; index < max; index += 1) {
      const shop = World.shops[index];
      if (!shop || !shop.n) continue;

      const awningMaterial = new THREE.MeshStandardMaterial({
        color: awningColors[index % awningColors.length],
        roughness: 0.72,
        metalness: 0.05
      });

      const awning = new THREE.Mesh(
        new THREE.BoxGeometry(
          Math.min(shop.w * 0.68, 2.4),
          0.12,
          0.62
        ),
        awningMaterial
      );

      const normal = shop.n;
      const side = [normal[1], -normal[0]];

      awning.position.set(
        shop.x + normal[0] * 0.22,
        shop.gy + 2.35,
        shop.z + normal[1] * 0.22
      );

      awning.rotation.y = shop.ry || 0;

      G.scene.add(awning);

      const signMaterial = new THREE.MeshBasicMaterial({
        color: index % 3 === 0 ? "#e5ae65" : "#d9cfbd",
        transparent: true,
        opacity: 0.65
      });

      const sign = new THREE.Mesh(
        new THREE.PlaneGeometry(
          Math.min(shop.w * 0.42, 1.35),
          0.28
        ),
        signMaterial
      );

      sign.position.set(
        shop.x + normal[0] * 0.245 + side[0] * 0.02,
        shop.gy + 2.78,
        shop.z + normal[1] * 0.245 + side[1] * 0.02
      );

      sign.rotation.y = shop.ry || 0;

      G.scene.add(sign);

      CS_GFX.facadeDetails.push(awning, sign);

      if (CS_GFX.windowLights.length < presetConfig().windowDetails) {
        CS_GFX.windowLights.push({
          material: signMaterial,
          seed: index
        });
      }
    }
  }

  function improveCrowdPresentation() {
    if (!window.Life || !Life.people) return;
    if (opt("crowdPresentation") === "lean") return;

    const palettes = [
      ["#344d68", "#d6b07c"],
      ["#72535a", "#c7c4bb"],
      ["#3f5945", "#d29a58"],
      ["#5a5c76", "#d7d0c2"],
      ["#7a443c", "#b8b8b4"],
      ["#2e3540", "#9c7862"]
    ];

    Life.people.forEach(function (person, index) {
      if (!person || !person.g || person.g.userData.csGfxStyled) return;

      person.g.userData.csGfxStyled = true;

      const colors = palettes[index % palettes.length];

      person.g.traverse(function (part) {
        if (!part.isMesh || !part.material || !part.material.color) return;

        const lowerName = (part.name || "").toLowerCase();

        if (
          lowerName.includes("torso") ||
          lowerName.includes("shirt") ||
          lowerName.includes("coat") ||
          lowerName.includes("body")
        ) {
          part.material.color.lerp(new THREE.Color(colors[0]), 0.44);
        }

        if (
          lowerName.includes("head") ||
          lowerName.includes("hand") ||
          lowerName.includes("face")
        ) {
          part.material.color.lerp(new THREE.Color(colors[1]), 0.12);
        }
      });

      if (index % 6 === 0 && opt("crowdPresentation") === "rich") {
        addUmbrella(person, index);
      }
    });
  }

  function addUmbrella(person, index) {
    if (!person || !person.g) return;

    const umbrella = new THREE.Group();

    const canopy = new THREE.Mesh(
      new THREE.ConeGeometry(0.38, 0.16, 10, 1, true),
      new THREE.MeshStandardMaterial({
        color: [
          "#323c50",
          "#75595a",
          "#405b49",
          "#485b75"
        ][index % 4],
        roughness: 0.78,
        side: THREE.DoubleSide
      })
    );

    canopy.rotation.x = Math.PI;
    canopy.position.y = 2.05;

    const shaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.012, 0.012, 0.85, 5),
      new THREE.MeshStandardMaterial({
        color: "#332d29",
        roughness: 0.48,
        metalness: 0.25
      })
    );

    shaft.position.y = 1.63;

    umbrella.add(canopy, shaft);

    umbrella.position.set(
      (index % 2 ? 0.12 : -0.12),
      0,
      0
    );

    person.g.add(umbrella);
  }

  function updateClouds(time) {
    if (opt("livingSky") === "off") return;

    const palette = activePalette();

    for (const cloud of CS_GFX.clouds) {
      cloud.sprite.position.x += cloud.speed * 0.003;
      cloud.sprite.position.z += Math.sin(time * 0.0001 + cloud.drift) * 0.003;
      cloud.sprite.position.y =
        cloud.baseY +
        Math.sin(time * 0.00023 + cloud.phase) * 1.6;

      if (cloud.sprite.position.x > 200) {
        cloud.sprite.position.x = -200;
      }

      cloud.sprite.material.color.copy(
        hexColor(
          paletteName() === "night"
            ? "#485875"
            : paletteName() === "golden"
              ? "#d6a58f"
              : "#dbe6ed"
        )
      );

      cloud.sprite.material.opacity =
        S.rain
          ? 0.2 + Math.sin(time * 0.0003 + cloud.phase) * 0.03
          : 0.1 + Math.sin(time * 0.0003 + cloud.phase) * 0.025;
    }
  }

  function updateBirds(time) {
    if (opt("livingSky") === "off") return;

    const visible =
      paletteName() !== "night" &&
      !(S.rain && opt("graphicsPreset") === "low");

    for (const bird of CS_GFX.birds) {
      bird.object.visible = visible;

      if (!visible) continue;

      const angle = time * 0.00012 * bird.speed + bird.phase;

      bird.object.position.x =
        bird.centerX +
        Math.cos(angle) * bird.radius;

      bird.object.position.z =
        bird.centerZ +
        Math.sin(angle * 0.72) * bird.radius * 0.48;

      bird.object.position.y =
        bird.height +
        Math.sin(angle * 2.3) * 1.8;

      bird.object.rotation.y = -angle + Math.PI / 2;

      const flap = 0.65 + Math.sin(time * 0.008 * bird.speed + bird.flap) * 0.36;

      bird.object.scale.y = flap;
    }
  }

  function updateMist(time) {
    const palette = activePalette();

    const base =
      opt("atmosphereStrength") === "subtle" ? 0.55 :
      opt("atmosphereStrength") === "cinematic" ? 1 :
      0;

    for (const mist of CS_GFX.mistCards) {
      const rainBoost = S.rain ? 1.65 : 1;
      const fogBoost = S.fog ? 1.9 : 1;
      const nightBoost = paletteName() === "night" ? 1.35 : 1;

      mist.sprite.material.color.copy(hexColor(palette.fog));
      mist.sprite.material.opacity =
        mist.baseOpacity *
        (S.fog ? 1 : S.rain ? .25 : 0) * base *
        rainBoost *
        fogBoost *
        nightBoost *
        (0.78 + Math.sin(time * 0.00042 + mist.phase) * 0.2);

      mist.sprite.position.x += Math.sin(time * 0.0001 + mist.phase) * 0.0015;
    }
  }

  function updateWetStreaks(time) {
    const wet =
      opt("wetStreets") === "on" &&
      (S.rain || S.fog || paletteName() === "blue" || paletteName() === "night");

    for (const streak of CS_GFX.wetStreaks) {
      streak.mesh.visible = wet;

      if (!wet) continue;

      const pulse = 0.68 + Math.sin(time * 0.0011 + streak.phase) * 0.22;
      const palette = activePalette();

      streak.mesh.material.color.copy(
        hexColor(streak.warm ? palette.warm : palette.cool)
      );

      streak.mesh.material.opacity =
        streak.baseOpacity *
        pulse *
        (S.rain ? 1.35 : 0.72);
    }
  }

  function updateFacadeAccents(time) {
    const palette = activePalette();
    const visibility =
      paletteName() === "night" ? 1 :
      paletteName() === "blue" ? 0.84 :
      paletteName() === "golden" ? 0.56 :
      0.22;

    for (const entry of CS_GFX.windowLights) {
      const flicker =
        entry.seed % 7 === 0
          ? 0.86 + Math.sin(time * 0.004 + entry.seed) * 0.12
          : 1;

      entry.material.color.copy(hexColor(palette.window));
      entry.material.opacity = visibility * flicker;
    }
  }

  function createPerformanceOverlay() {
    let element = document.getElementById("csGraphicsPerf");

    if (!element) {
      element = document.createElement("div");
      element.id = "csGraphicsPerf";
      document.body.appendChild(element);
    }

    return element;
  }

  function updatePerformanceOverlay(now) {
    const element = createPerformanceOverlay();

    if (!window.SnapCity?.debugEnabled || opt("performanceOverlay") !== "on" || !Game || !Game.started) {
      element.classList.remove("on");
      return;
    }

    CS_GFX.fps.frames += 1;

    const delta = now - CS_GFX.fps.last;

    if (delta >= 500) {
      CS_GFX.fps.value = Math.round(
        (CS_GFX.fps.frames * 1000) / delta
      );

      CS_GFX.fps.frames = 0;
      CS_GFX.fps.last = now;
    }

    const info = G && G.renderer ? G.renderer.info : null;

    element.classList.add("on");
    element.innerHTML =
      `<b>VISUAL DEBUG</b>` +
      `<span>${CS_GFX.fps.value || "—"} FPS · ${opt("graphicsPreset")}</span>` +
      `<span>${info ? info.render.calls : "—"} draw calls · ${info ? info.render.triangles.toLocaleString() : "—"} triangles</span>` +
      `<span>${Life && Life.people ? Life.people.length : 0} people · ${CS_GFX.birds.length} birds</span>`;
  }

  function applySettingsButtonHandlers() {
    document.addEventListener("click", function (event) {
      const button =
        event.target.closest &&
        event.target.closest("[data-cs-gfx-reset]");

      if (!button) return;

      ensureSettings();

      Object.assign(S.custom, GFX_DEFAULTS);

      setRendererQuality();
      applyPalette();
      saveState();
      renderMenu();

      toast("Visual settings restored.", 1600);
    }, true);
  }

  function installSettingsMenu() {
    if (typeof menuSettings !== "function") return;

    const previous = menuSettings;

    window.menuSettings = function () {
      ensureSettings();

      const c = S.custom;

      const segment = function (key, options) {
        return (
          `<div class="seg" data-seg="${key}">` +
          options.map(function (entry) {
            const value = entry[0];
            const label = entry[1];

            return (
              `<button data-v="${value}" aria-pressed="${c[key] === value}">` +
              `${label}` +
              `</button>`
            );
          }).join("") +
          `</div>`
        );
      };

      const block =
        `<div class="sectionhead">Visual Direction</div>` +

        `<div class="formrow">` +
        `<label>Graphics preset</label>` +
        segment("graphicsPreset", [
          ["low", "Low"],
          ["medium", "Medium"],
          ["high", "High"],
          ["ultra", "Ultra"]
        ]) +
        `<span class="spec">Controls atmospheric layers, sky life, wet-street detail, and rendering resolution.</span>` +
        `</div>` +

        `<div class="formrow">` +
        `<label>Atmosphere</label>` +
        segment("atmosphereStrength", [
          ["off", "Off"],
          ["subtle", "Subtle"],
          ["cinematic", "Cinematic"]
        ]) +
        `<span class="spec">Adds coordinated fog color, low mist, cloud depth, and weather-driven air perspective.</span>` +
        `</div>` +

        `<div class="formrow">` +
        `<label>Wet streets</label>` +
        segment("wetStreets", [
          ["on", "On"],
          ["off", "Off"]
        ]) +
        `<span class="spec">Adds stylized window and streetlight reflection streaks that become strongest in rain, fog, blue hour, and night.</span>` +
        `</div>` +

        `<div class="formrow">` +
        `<label>Living sky</label>` +
        segment("livingSky", [
          ["on", "On"],
          ["off", "Off"]
        ]) +
        `<span class="spec">Adds drifting cloud layers and distant stylized birds without external assets.</span>` +
        `</div>` +

        `<div class="formrow">` +
        `<label>Facade detail</label>` +
        segment("facadeDetail", [
          ["lean", "Lean"],
          ["rich", "Rich"],
          ["obsessive", "Obsessive"]
        ]) +
        `<span class="spec">Adds storefront awnings, sign plates, warm windows, and small architectural accents.</span>` +
        `</div>` +

        `<div class="formrow">` +
        `<label>Crowd presentation</label>` +
        segment("crowdPresentation", [
          ["lean", "Lean"],
          ["rich", "Rich"]
        ]) +
        `<span class="spec">Adds stronger pedestrian color blocking and occasional umbrellas for a more photographable street.</span>` +
        `</div>` +

        `<div class="formrow">` +
        `<label>Visual Debug</label>` +
        segment("performanceOverlay", [
          ["off", "Off"],
          ["on", "On"]
        ]) +
        `<span class="spec">Shows FPS, draw calls, triangles, people, and birds while testing the new visual layer.</span>` +
        `</div>` +

        `<div class="formrow">` +
        `<button class="btn small alt" data-cs-gfx-reset>Restore visual defaults</button>` +
        `<span class="spec">Restores the recommended High/Cinematic visual profile.</span>` +
        `</div>`;

      return block + previous.apply(this, arguments);
    };
  }

  function wrapMenuWiring() {
    if (typeof wireMenu !== "function") return;

    const previous = wireMenu;

    window.wireMenu = function () {
      const result = previous.apply(this, arguments);

      const body = document.querySelector("#menubody");

      if (!body) return result;

      body.querySelectorAll(
        '[data-seg="graphicsPreset"] button,' +
        '[data-seg="atmosphereStrength"] button,' +
        '[data-seg="wetStreets"] button,' +
        '[data-seg="livingSky"] button,' +
        '[data-seg="facadeDetail"] button,' +
        '[data-seg="crowdPresentation"] button,' +
        '[data-seg="performanceOverlay"] button'
      ).forEach(function (button) {
        button.onclick = function () {
          const group = button.closest("[data-seg]");
          const key = group.dataset.seg;

          ensureSettings();

          S.custom[key] = button.dataset.v;

          setRendererQuality();
          applyPalette();
          saveState();
          renderMenu();
        };
      });

      return result;
    };
  }

  function update(now) {
    if (!CS_GFX.initialized || !window.S) return;

    applyPalette();
    updateClouds(now);
    updateBirds(now);
    updateMist(now);
    updateWetStreaks(now);
    updateFacadeAccents(now);
    updatePerformanceOverlay(now);
  }

  function initialize() {
    if (CS_GFX.initialized) return;
    if (!window.G || !G.scene || !window.S) return;

    ensureSettings();
    setRendererQuality();
    applyPalette();
    createClouds();
    createBirds();
    createMistCards();
    createWetStreaks();
    addFacadeAccents();
    improveCrowdPresentation();

    CS_GFX.initialized = true;

    console.info(
      "[Contact Sheet] Stylized cinematic graphics layer initialized."
    );
  }

  function attachToGameLoop() {
    if (typeof gameplayUpdate !== "function") return;

    const previous = gameplayUpdate;

    window.gameplayUpdate = function (dt) {
      const result = previous.apply(this, arguments);

      try {
        if (!CS_GFX.initialized) {
          initialize();
        }

        update(performance.now());
      } catch (error) {
        console.warn(
          "[Contact Sheet graphics] Optional update skipped:",
          error
        );
      }

      return result;
    };
  }

  function attachToBoot() {
    if (typeof boot !== "function") return;

    const previous = boot;

    window.boot = async function () {
      const result = await previous.apply(this, arguments);

      try {
        ensureSettings();

        requestAnimationFrame(function () {
          initialize();
        });
      } catch (error) {
        console.warn(
          "[Contact Sheet graphics] Initialization skipped:",
          error
        );
      }

      return result;
    };
  }

  ensureSettings();
  installSettingsMenu();
  wrapMenuWiring();
  applySettingsButtonHandlers();
  attachToGameLoop();
  attachToBoot();

  console.info(
    "[Contact Sheet] Stylized Cinematic Graphics Overhaul patch loaded."
  );
})();
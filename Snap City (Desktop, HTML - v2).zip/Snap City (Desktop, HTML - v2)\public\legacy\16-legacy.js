const GP = { loadT:0, beatT:0, lastWarn:-1, ride:null, envT:0, lightT:0, flash:0 };

function famOf(id){ const n = (S && S.fam && S.fam[id || S.body]) || 0; return 1 - Math.exp(-n/70); }
function famLabel(id){ const f = famOf(id); return f < 0.12 ? "new to you" : f < 0.45 ? "getting used to it" : f < 0.8 ? "comfortable" : "second nature"; }
function famBump(){ S.fam = S.fam || {}; const n = S.fam[S.body] = (S.fam[S.body]||0) + 1, b = curBody();
  const msg = { 20:`The ${b.n} is starting to make sense in your hands.`, 70:`You can work the ${b.n} without looking at it now.`, 180:`The ${b.n} is second nature. You stopped thinking about it.` }[n];
  if (msg) setTimeout(()=>toast(msg, 3400), 1200); }

const ZONES = { Digit1:1.5, Digit2:2, Digit3:3, Digit4:5, Digit5:1000 };
function setZone(code){
  const b = curBody(), fk = focusKind(); if (fk === "fixed"){ toast("Fixed focus: nothing to set.", 1200); return; }
  if (b.af) S.set.af = false;
  const d = ZONES[code] === 1000 ? 120 : ZONES[code]; S.set.focus = d; Cam.mfTarget = null;
  const e = Cam.exp || computeExposure(), [n, f] = dofRange(d, e.N);
  toast(`Focus preset ${ZONES[code]===1000 ? "∞" : fmtDist(d)} · sharp from ${fmtDist(n)} to ${f===Infinity ? "∞" : fmtDist(f)} at ${fmtA(e.N)}`, 2200);
}
function dofText(e){ const [n, f] = dofRange(Cam.focus, e.N); return `sharp ${fmtDist(n)}–${f===Infinity ? "∞" : fmtDist(f)}`; }

const SND = {
  ctx:null, out:null, nbuf:null,
  init(){ if (this.ctx) return true; const c = Audio.ctx && Audio.ctx(); if (!c) return false; this.ctx = c; this.out = c.createGain(); this.out.gain.value = 0.9; this.out.connect(c.destination);
    const len = c.sampleRate*2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0); for (let i=0;i<len;i++) d[i] = Math.random()*2-1; this.nbuf = b; return true; },
  node(x, z, vol){ const c = this.ctx, p = c.createPanner(); p.panningModel = "HRTF"; p.distanceModel = "inverse"; p.refDistance = 5; p.rolloffFactor = 1.1; p.maxDistance = 500;
    if (p.positionX){ p.positionX.value = x; p.positionY.value = 1.6; p.positionZ.value = z; } else p.setPosition(x, 1.6, z);
    const g = c.createGain(); g.gain.value = vol; g.connect(p); p.connect(this.out); return g; },
  listen(){ if (!this.ctx) return; const l = this.ctx.listener, cp = G.cam.getWorldPosition(new THREE.Vector3()), f = new THREE.Vector3(0,0,-1).applyQuaternion(G.cam.getWorldQuaternion(new THREE.Quaternion()));
    if (l.positionX){ l.positionX.value = cp.x; l.positionY.value = cp.y; l.positionZ.value = cp.z; l.forwardX.value = f.x; l.forwardY.value = f.y; l.forwardZ.value = f.z; l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0; }
    else { l.setPosition(cp.x, cp.y, cp.z); l.setOrientation(f.x, f.y, f.z, 0, 1, 0); } },
  env(g, t0, a, d){ g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(a, t0 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d); },
  noise(dest, t0, dur, type, freq, q){ const c = this.ctx, s = c.createBufferSource(); s.buffer = this.nbuf; s.loop = true; const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q||1; s.connect(f); f.connect(dest); s.start(t0); s.stop(t0 + dur); return f; },
  osc(dest, t0, dur, type, freq){ const c = this.ctx, o = c.createOscillator(); o.type = type; o.frequency.value = freq; o.connect(dest); o.start(t0); o.stop(t0 + dur); return o; },
  play(kind, x, z, vol=1){
    if (!this.init()) return; const c = this.ctx, t = c.currentTime, out = this.node(x, z, vol);
    const g = () => { const n = c.createGain(); n.connect(out); return n; };
    if (kind === "siren"){ const e = g(); e.gain.value = 0.18; const o = this.osc(e, t, 3.2, "sawtooth", 700); o.frequency.setValueAtTime(650, t); o.frequency.linearRampToValueAtTime(980, t+0.8); o.frequency.linearRampToValueAtTime(650, t+1.6); o.frequency.linearRampToValueAtTime(980, t+2.4); o.frequency.linearRampToValueAtTime(650, t+3.2); }
    else if (kind === "bark"){ for (let k=0;k<2+(Math.random()*2|0);k++){ const t0 = t + k*0.28, e = g(); this.env(e, t0, 0.5, 0.18); this.noise(e, t0, 0.2, "bandpass", 650+Math.random()*250, 3); const o = this.osc(e, t0, 0.18, "square", 320); o.frequency.exponentialRampToValueAtTime(180, t0+0.15); } }
    else if (kind === "horn"){ const e = g(); this.env(e, t, 0.14, 0.9); this.osc(e, t, 0.9, "square", 330); this.osc(e, t, 0.9, "square", 415); }
    else if (kind === "shout"){ for (let k=0;k<2;k++){ const t0 = t + k*0.45, e = g(); this.env(e, t0, 0.25, 0.4); const o = this.osc(e, t0, 0.42, "sawtooth", 190 + Math.random()*90); o.frequency.linearRampToValueAtTime(260 + Math.random()*80, t0+0.2); const f = c.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = 900; f.Q.value = 2; } }
    else if (kind === "applause"){ for (let k=0;k<60;k++){ const t0 = t + Math.random()*2.6, e = g(); this.env(e, t0, 0.35*Math.random()+0.1, 0.05); this.noise(e, t0, 0.06, "highpass", 1500 + Math.random()*1500, 0.8); } }
    else if (kind === "music"){ const notes = [392, 440, 494, 523, 587, 523, 494, 440]; notes.forEach((f0, k)=>{ const t0 = t + k*0.24, e = g(); this.env(e, t0, 0.13, 0.22); const lp = c.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 1600; lp.connect(e); this.osc(lp, t0, 0.23, "sawtooth", f0); this.osc(lp, t0, 0.23, "sawtooth", f0*1.26); }); const d = g(); for (let k=0;k<4;k++){ this.env(d, t + k*0.48, 0.3, 0.12); } this.noise(d, t, 1.9, "lowpass", 140, 1); }
    else if (kind === "chant"){ for (let k=0;k<4;k++){ const t0 = t + k*0.5, e = g(); this.env(e, t0, 0.22, 0.35); this.noise(e, t0, 0.35, "bandpass", 700, 1.5); this.osc(e, t0, 0.35, "sawtooth", 210); } }
    else if (kind === "skate"){ const e = g(); e.gain.value = 0.2; this.noise(e, t, 1.6, "lowpass", 260, 0.8); const k = g(); this.env(k, t+1.55, 0.6, 0.08); this.noise(k, t+1.55, 0.08, "bandpass", 1800, 2); }
    else if (kind === "thunder"){ const e = g(); e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(0.9, t+0.08); e.gain.exponentialRampToValueAtTime(0.0001, t+3.5); this.noise(e, t, 3.6, "lowpass", 110, 0.7); }
    else if (kind === "crowd"){ const e = g(); e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(0.25, t+0.6); e.gain.exponentialRampToValueAtTime(0.0001, t+3); this.noise(e, t, 3.1, "bandpass", 550, 0.6); }
    else if (kind === "gasp"){ const e = g(); this.env(e, t, 0.2, 0.6); this.noise(e, t, 0.6, "bandpass", 1200, 1.2); }
    else if (kind === "beat"){ const e = g(); this.env(e, t, 0.35, 0.18); this.osc(e, t, 0.2, "sine", 58); const e2 = g(); this.env(e2, t+0.2, 0.22, 0.15); this.osc(e2, t+0.2, 0.18, "sine", 52); }
    else if (kind === "hum"){ const e = g(); this.env(e, t, 0.2, 1.2); const o = this.osc(e, t, 1.2, "sawtooth", 120); o.frequency.exponentialRampToValueAtTime(40, t+1.1); }
  }
};

function rollTension(dt){
  const r = curRoll(); if (!r) return;
  if (Player.raise > 0.6 && r.left > 0 && r.left <= 3){
    GP.beatT -= dt; if (GP.beatT <= 0){ GP.beatT = 0.75 + r.left*0.22; SND.play("beat", G.cam.position.x, G.cam.position.z, 0.6); }
    if (GP.lastWarn !== r.left){ GP.lastWarn = r.left; toast(r.left === 1 ? "Last frame on the roll." : `${r.left} frames left.`, 1300); }
  } else if (Player.raise < 0.3) GP.lastWarn = -1;
}

const EVENTS = {
  argument: { w:3, name:"the argument", bonus:10 }, dogrun: { w:2, name:"the runaway dog", bonus:10 }, skater: { w:3, name:"the skater's trick", bonus:8 },
  siren: { w:2, name:"the fire engine tearing past", bonus:8 }, fender: { w:1.4, name:"the fender bender", bonus:10 }, proposal: { w:0.9, name:"a marriage proposal", bonus:18 },
  performer: { w:1.1, name:"a very strange street performance", bonus:12 }, parade: { w:0.3, rare:true, name:"a brass band marching through", bonus:20 },
  blackout: { w:0.3, rare:true, night:true, name:"the blackout", bonus:16 }, storm: { w:0.3, rare:true, name:"the storm", bonus:14 }, fog: { w:0.35, rare:true, day:true, name:"the fog rolling in", bonus:10 },
};
const EV = { list:[], t:20 };
function evPool(n){ const f = Life.people.filter(p=>p.pool && !p.busy); return f.length >= n ? f.slice(0, n) : null; }
function evSpot(minD, maxD){
  for (let k=0;k<50;k++){ const i = Math.round(Player.x/P) + (Math.random()*3|0) - 1, j = Math.round(Player.z/P) + (Math.random()*3|0) - 1;
    if (Math.abs(i) > NB || Math.abs(j) > NB) continue;
    const side = Math.random()*4|0, along = rand(-HALF+6, HALF-6), off = HALF + 2.3;
    const x = i*P + (side===0 ? -off : side===1 ? off : along), z = j*P + (side===2 ? -off : side===3 ? off : along), d = Math.hypot(x - Player.x, z - Player.z);
    if (d < minD || d > maxD || Math.abs(x - CABLE_X) < 5) continue;
    return { x, z, along: side >= 2 ? [1,0] : [0,1], out: side===0 ? [-1,0] : side===1 ? [1,0] : side===2 ? [0,-1] : [0,1] };
  }
  return null;
}
function evPlace(p, x, z, h, tag){ Object.assign(p, { hidden:false, busy:true, x, z, heading:h, eventTag:tag, evPose:null, evMoving:false, evY:0, aware:0, act:"idle" }); p.y = groundY(x, z); }
function evRelease(p){ Object.assign(p, { hidden:true, busy:false, eventTag:null, evPose:null, evMoving:false, evY:0 }); }
function evWalk(p, tx, tz, sp, dt){ const dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz); if (d < 0.15){ p.evMoving = false; return true; }
  p.heading = angLerp(p.heading, Math.atan2(dx, dz), Math.min(1, dt*6)); const st = Math.min(d, sp*dt); p.x += dx/d*st; p.z += dz/d*st; p.y = groundY(p.x, p.z); p.evMoving = true; p.evSpeed = sp; return false; }
function evFace(p, q){ p.heading = Math.atan2(q.x - p.x, q.z - p.z); }
function startEvent(type){
  const E = { type, t:0, ppl:[], done:false, info:EVENTS[type] };
  const near = evSpot(22, 75); if (near){ E.x = near.x; E.z = near.z; }
  if (type === "argument" || type === "fender"){
    const ps = evPool(2); if (!ps || !near) return null; const [a, b] = ps, ax = near.along;
    evPlace(a, near.x - ax[0]*5, near.z - ax[1]*5, Math.atan2(ax[0], ax[1]), type); evPlace(b, near.x + ax[0]*5, near.z + ax[1]*5, Math.atan2(-ax[0], -ax[1]), type);
    E.ppl = ps; E.x = near.x; E.z = near.z; E.ax = ax;
    E.step = (dt) => { const t = E.t, [a, b] = E.ppl;
      if (t < 3){ evWalk(a, E.x - ax[0]*0.9, E.z - ax[1]*0.9, 1.6, dt); evWalk(b, E.x + ax[0]*0.9, E.z + ax[1]*0.9, 1.6, dt); if (type === "fender" && t < dt*1.5) SND.play("horn", E.x, E.z, 1.4); }
      else if (t < 13){ evFace(a, b); evFace(b, a); a.evMoving = b.evMoving = false; const who = Math.floor(t/1.4) % 2; a.evPose = who ? "point" : "shout"; b.evPose = who ? "shout" : "handsup"; if (Math.floor(t/1.4) !== Math.floor((t-dt)/1.4)) SND.play("shout", E.x, E.z, 1.1); }
      else if (t < 20){ b.evPose = null; evWalk(b, E.x + ax[0]*14, E.z + ax[1]*14, 1.7, dt); a.evPose = t < 16 ? "point" : "handsface"; evFace(a, b); }
      else E.done = true; };
  }
  else if (type === "proposal"){
    const ps = evPool(5); if (!ps || !near) return null; const [a, b, ...crowd] = ps, ax = near.along, o = near.out;
    evPlace(a, near.x - ax[0]*6, near.z - ax[1]*6, Math.atan2(ax[0], ax[1]), type); evPlace(b, near.x - ax[0]*6 + o[0]*0.6, near.z - ax[1]*6 + o[1]*0.6, Math.atan2(ax[0], ax[1]), type);
    crowd.forEach((c, k) => evPlace(c, near.x + ax[0]*(2.5 + k*0.7) - o[0]*0.8, near.z + ax[1]*(2.5 + k*0.7) - o[1]*0.8, 0, type));
    E.ppl = ps; E.step = (dt) => { const t = E.t;
      if (t < 5){ evWalk(a, near.x, near.z, 1.1, dt); evWalk(b, near.x + o[0]*0.9, near.z + o[1]*0.9, 1.1, dt); }
      else if (t < 19){ evFace(a, b); evFace(b, a); a.evMoving = b.evMoving = false; a.evPose = t < 15 ? "kneel" : "hug"; b.evPose = t < 8 ? "handsface" : t < 15 ? "handsface" : "hug";
        if (t > 8 && t - dt <= 8) SND.play("gasp", near.x, near.z, 1); if (t > 12 && t - dt <= 12) SND.play("applause", near.x, near.z, 1.3); if (t > 15 && t - dt <= 15) SND.play("applause", near.x, near.z, 1.5);
        crowd.forEach(c => { evFace(c, a); c.evPose = t > 12 ? "clap" : "handsface"; }); }
      else if (t < 24){ a.evPose = b.evPose = "hug"; crowd.forEach(c => c.evPose = null); }
      else E.done = true; };
  }
  else if (type === "performer"){
    const ps = evPool(5); if (!ps || !near) return null; const [a, ...crowd] = ps;
    evPlace(a, near.x, near.z, 0, type); crowd.forEach((c, k) => { const an = k/crowd.length*Math.PI*1.4 - 0.7 + Math.atan2(-near.out[0], -near.out[1]); evPlace(c, near.x + Math.sin(an)*2.4, near.z + Math.cos(an)*2.4, 0, type); evFace(c, a); });
    E.ppl = ps; E.step = (dt) => { const t = E.t; a.evPose = "dance"; a.heading += dt*(Math.sin(t*0.7) > 0 ? 5 : -1.5); crowd.forEach((c, k) => c.evPose = (Math.sin(t*0.9 + k) > 0.2) ? "clap" : null);
      if (Math.floor(t/2) !== Math.floor((t-dt)/2)) SND.play("music", near.x, near.z, 1); if (Math.floor(t/7) !== Math.floor((t-dt)/7)) SND.play("applause", near.x, near.z, 0.9); if (t > 32) E.done = true; };
  }
  else if (type === "skater"){
    const ps = Life.people.filter(p=>p.pool && !p.busy && p.look.acc.skate); if (!ps.length || !near) return null; const a = ps[0], ax = near.along;
    evPlace(a, near.x - ax[0]*22, near.z - ax[1]*22, Math.atan2(ax[0], ax[1]), type); a.look.anim = "skate"; E.ppl = [a];
    E.step = (dt) => { const t = E.t; if (t < 6){ evWalk(a, near.x + ax[0]*6, near.z + ax[1]*6, 4.6, dt); a.evMoving = false; a.evY = (t > 4.4 && t < 5.0) ? Math.sin((t-4.4)/0.6*Math.PI)*0.55 : 0; a.evPose = (t > 4.3 && t < 5.1) ? "ollie" : null; if (t > 3.0 && t - dt <= 3.0) SND.play("skate", a.x, a.z, 1.3); }
      else if (t < 11){ evWalk(a, near.x + ax[0]*30, near.z + ax[1]*30, 4.2, dt); a.evMoving = false; a.evPose = null; a.evY = 0; } else E.done = true; };
  }
  else if (type === "parade"){
    const ps = evPool(8); if (!ps || !near) return null; const ax = near.along, o = near.out;
    ps.forEach((p, k) => evPlace(p, near.x - ax[0]*(30 + (k>>1)*1.6) + o[0]*((k&1) ? 0.6 : -0.6), near.z - ax[1]*(30 + (k>>1)*1.6) + o[1]*((k&1) ? 0.6 : -0.6), Math.atan2(ax[0], ax[1]), type));
    E.ppl = ps; E.step = (dt) => { const t = E.t; ps.forEach((p, k) => { evWalk(p, near.x + ax[0]*(40 - (k>>1)*1.6) + o[0]*((k&1) ? 0.6 : -0.6), near.z + ax[1]*(40 - (k>>1)*1.6) + o[1]*((k&1) ? 0.6 : -0.6), 1.1, dt); p.evPose = "band"; });
      if (Math.floor(t/1.95) !== Math.floor((t-dt)/1.95)) SND.play("music", ps[0].x, ps[0].z, 1.8); if (t > 62) E.done = true; };
  }
  else if (type === "dogrun"){
    const d = Life.dogs.find(d => { const dd = Math.hypot(d.x - Player.x, d.z - Player.z); return dd > 15 && dd < 70 && !d.free; }); if (!d) return null;
    const a = rand(0, 6.28); d.free = { tx: d.x + Math.sin(a)*16, tz: d.z + Math.cos(a)*16, t:0 }; E.dog = d; d.owner.evPose = null;
    E.step = (dt) => { const t = E.t; if (!d.free){ E.done = true; return; } if (t < 9){ d.free.tx += Math.sin(t*1.7)*dt*6; } else { d.free.tx = d.owner.x; d.free.tz = d.owner.z; }
      d.owner.evPose = t < 9 ? "shout" : null; d.owner.pause = Math.max(d.owner.pause||0, 0.5);
      if (Math.floor(t/1.3) !== Math.floor((t-dt)/1.3) && t < 10) SND.play("bark", d.x, d.z, 1.2); if (t > 3 && t - dt <= 3) SND.play("shout", d.owner.x, d.owner.z, 1);
      if (t > 14 || (t > 9 && Math.hypot(d.x - d.owner.x, d.z - d.owner.z) < 1.2)){ d.free = null; d.owner.evPose = null; E.done = true; } };
  }
  else if (type === "siren"){
    const zs = Math.round((Player.z/P) - 0.5)*P + P/2 + (Math.random()<0.5 ? 0 : -P), dir = Math.random()<0.5 ? 1 : -1;
    const v = GP.truck || (GP.truck = makeTruck()); v.visible = true; E.v = { x: Player.x - dir*140, z: zs, dir };
    E.step = (dt) => { const t = E.t; E.v.x += dir*13*dt; v.position.set(E.v.x, H(E.v.x, E.v.z) + 0.02, E.v.z); v.rotation.y = dir > 0 ? Math.PI/2 : -Math.PI/2;
      const fl = Math.floor(t*6) % 2; v.userData.bar[0].material.emissiveIntensity = fl ? 8 : 0.3; v.userData.bar[1].material.emissiveIntensity = fl ? 0.3 : 8;
      if (Math.floor(t/3.2) !== Math.floor((t-dt)/3.2)) SND.play("siren", E.v.x, E.v.z, 1.6);
      for (const p of Life.people){ if (!p.hidden && Math.abs(p.z - E.v.z) < 12 && Math.abs(p.x - E.v.x) < 30){ p.headYaw = clamp(Math.atan2(Math.sin(Math.atan2(E.v.x - p.x, E.v.z - p.z) - p.heading), Math.cos(Math.atan2(E.v.x - p.x, E.v.z - p.z) - p.heading)), -1.3, 1.3); } }
      if (t > 22){ v.visible = false; E.done = true; } };
    GP.sirenEv = E;
  }
  else if (type === "blackout"){ E.step = (dt) => { World.blackout = E.t < 50; if (E.t < dt*1.5){ SND.play("hum", Player.x, Player.z, 0.8); applyTime(true); } if (E.t > 50){ World.blackout = false; applyTime(true); E.done = true; } }; }
  else if (type === "storm"){ const was = !!S.rain; S.rain = true; applyTime(); E.next = 3; E.step = (dt) => { E.next -= dt; if (E.next <= 0){ E.next = rand(6, 14); GP.flash = 0.18; setTimeout(()=>SND.play("thunder", Player.x + rand(-80,80), Player.z + rand(-80,80), 1.5), rand(300, 1800)); } if (E.t > 150){ S.rain = was; applyTime(); E.done = true; } }; }
  else if (type === "fog"){ const was = !!S.fog; S.fog = true; applyTime(); E.step = (dt) => { if (E.t > 180){ S.fog = was; applyTime(); E.done = true; } }; }
  return E;
}
function makeTruck(){
  const g = buildCarGroup("pickup", lin("#b3171b"), {}, [Life.carLightMats[0], CarMats.tailOff]); g.scale.set(1.15, 1.25, 1.35);
  const mk = c => new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.25), new THREE.MeshStandardMaterial({ color:lin(c), emissive:lin(c), emissiveIntensity:1 }));
  const r = mk("#ff2020"), b = mk("#2040ff"); r.position.set(-0.35, 1.95, 0.4); b.position.set(0.35, 1.95, 0.4); g.add(r, b); g.userData.bar = [r, b]; g.visible = false; World.scene.add(g); return g;
}
function eventsUpdate(dt){
  EV.t -= dt;
  if (EV.t <= 0 && EV.list.length < 2 && Game.started){
    EV.t = rand(28, 55) * (({ calm:1.7, normal:1, busy:0.5 })[S.custom.eventPace] || 1);
    const T = World.timeDef || TIMES[2], night = T.id === "night" || T.id === "blue";
    const playing = EV.list.some(x => EVENTS[x.type] && EVENTS[x.type].play);
    const opts = Object.entries(EVENTS).filter(([k, e]) => !(e.play && playing) && !(e.rare && S.rareDone && S.rareDone[k]) && !(e.night && !night) && !(e.day && night) && !EV.list.some(x=>x.type===k));
    let tot = opts.reduce((a,[,e])=>a+e.w, 0), x = Math.random()*tot, pick_ = null; for (const [k, e] of opts){ if ((x -= e.w) < 0){ pick_ = k; break; } }
    if (pick_){ const E = startEvent(pick_); if (E){ EV.list.push(E); if (EVENTS[pick_].rare){ S.rareDone = S.rareDone || {}; S.rareDone[pick_] = 1; saveState(); } } }
  }
  for (const E of EV.list){ E.t += dt; E.step(dt);
    const ex = E.v ? E.v.x : E.dog ? E.dog.x : E.x, ez = E.v ? E.v.z : E.dog ? E.dog.z : E.z;
    if (ex !== undefined){ E.px = ex; E.pz = ez; const d = Math.hypot(ex - Player.x, ez - Player.z);
      if (!E.heard && d < 100 && E.t > 1){ E.heard = true; if (S.custom.eventPopups === "on" && (S.custom.eventNotify === "clue" || S.custom.eventNotify === "none")){ const rel = Math.atan2(Math.sin(Math.atan2(-(ex-Player.x), -(ez-Player.z)) - Player.yaw), Math.cos(Math.atan2(-(ex-Player.x), -(ez-Player.z)) - Player.yaw)); const where = Math.abs(rel) < 0.6 ? "ahead" : Math.abs(rel) > 2.4 ? "behind you" : rel > 0 ? "to your left" : "to your right"; const what = ({ argument:"raised voices", fender:"a horn and shouting", proposal:"a gasp, then applause", performer:"music and clapping", skater:"skateboard wheels", parade:"a brass band", dogrun:"frantic barking", siren:"a siren" })[E.type]; if (what) toast(`You hear ${what} ${where}.`, 2600); } } } if (E.done){ for (const p of E.ppl) evRelease(p); if (E.type === "skater") for (const p of E.ppl) p.look.anim = "walk"; } }
  EV.list = EV.list.filter(E => !E.done);
  if (GP.flash > 0){ GP.flash -= dt; World.hemi.intensity = (World.timeDef.hemiI||1)*(GP.flash > 0 ? 6 : 0.82); }
}
function activeEventTags(){ const s = {}; for (const E of EV.list){ s[E.type] = 1; } if (World.blackout) s.blackout = 1; return s; }

function rideTargets(){ const out = []; if (Life.cable) out.push({ v:Life.cable, kind:"cable" }); for (const c of Life.cars) if (c.bus) out.push({ v:c, kind:"bus" }); return out; }
function toggleRide(){
  if (GP.ride){ const v = GP.ride.v; const side = GP.ride.side || [1,0];
    let x = Player.x + side[0]*1.6, z = Player.z + side[1]*1.6; [x, z] = collidePoint(x, z, 0.4); Player.x = x; Player.z = z; GP.ride = null; toast("You step off.", 1000); return; }
  for (const { v, kind } of rideTargets()){
    const d = Math.hypot(Player.x - v.x, Player.z - v.z);
    if (d < (kind === "bus" ? 7 : 6)){
      if (kind === "cable"){ const sx = (Player.x > v.x) ? 1.5 : -1.5; GP.ride = { v, kind, lx: sx, lz: clamp((Player.z - v.z)*(v.dir||1), -2.4, 2.4), floor:0.75, eye:1.6 }; toast("You grab the pole and hang off the side of the tram. Press Enter to hop off whenever you like.", 3200); }
      else { GP.ride = { v, kind, lx: 0.85, lz: 1.8, floor:1.0, eye:1.2 }; toast("You take a window seat on the city bus. Shoot through the glass; press Enter to hop off whenever you like.", 3200); }
      return;
    }
  }
  toast("Nothing to ride here. Find the tram or a city bus.", 1600);
}
function rideUpdate(dt){
  const R_ = GP.ride, v = R_.v; let hx, hz, vx, vz, h;
  if (R_.kind === "cable"){ h = v.dir > 0 ? 0 : Math.PI; hx = v.x; hz = v.z; vx = v.vx||0; vz = v.vz||0; }
  else { h = v.heading; hx = v.x; hz = v.z; vx = v.vx||0; vz = v.vz||0; }
  const rx = Math.cos(h), rz = -Math.sin(h), fx = Math.sin(h), fz = Math.cos(h);
  Player.x = hx + rx*R_.lx + fx*R_.lz; Player.z = hz + rz*R_.lx + fz*R_.lz; Player.vx = vx; Player.vz = vz; Player.speed = Math.hypot(vx, vz);
  R_.side = [rx*Math.sign(R_.lx||1), rz*Math.sign(R_.lx||1)];
  R_.y = H(hx, hz) + R_.floor + R_.eye;
}
function glassAmount(){ return (GP.ride && GP.ride.kind === "bus") || (typeof ZONE !== "undefined" && ZONE.mode === "shop") ? 1 : 0; }

function gameplayUpdate(dt){
  if (!Game.started) return;
  if (S.flow !== false){ S.clock = ((S.clock ?? clockOf(S.time)) + dt*10/3600) % 24; GP.lightT -= dt; if (GP.lightT <= 0){ GP.lightT = 3; GP.envT -= 3; applyTime(GP.envT > 0); if (GP.envT <= 0) GP.envT = 30; } }
  if (GP.loadT > 0) GP.loadT -= dt;
  if (INT.u) INT.u.uTime.value += dt;
  SND.init(); SND.listen();
  { const gf = document.getElementById("glassfx"); if (gf) gf.style.opacity = glassAmount(); }
  rollTension(dt);
  eventsUpdate(dt);
}

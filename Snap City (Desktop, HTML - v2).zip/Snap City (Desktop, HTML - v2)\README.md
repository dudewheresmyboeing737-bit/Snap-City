# Snap City

**The city never poses. Be ready.**

## Play

Unzip this folder and open **Snap-City.html** in Chrome, Edge, or Firefox with hardware acceleration enabled. No installation or internet connection is needed for the game. Keep the same browser and file location for your local save. Export photographs you want to keep; browser storage is not a backup.

**Start New** begins a career with a disposable 35mm camera and $250. **Free Play** unlocks all equipment and skills, with unlimited spending.

## People notice you, and a rival photographer

- **Being seen.** A raised camera pointed at someone is now noticed from several metres away instead of about 2 m: about 7.5 m for an SLR with a normal lens, a little farther with long lenses, about 6 m for rangefinders, and about 5.5 m for compacts and the disposable. The Ghost and Streetwise skills shrink the radius. People facing you notice fastest; people walking away rarely do. Shooting from the hip is only noticed up close, so a 28 mm means working fast or from the hip, while a 90 mm lets you shoot from outside the circle.
- **Reactions** follow personality: cheerful people wave, posers pose, grumpy people wave you off, shy people turn away, anxious people cover their face, curious people stare. Shy, grumpy and anxious walkers turn around and hurry away from you. Anyone who has spotted you stays wary for 45 seconds and notices twice as fast. A "Spotted" tag appears under the viewfinder when it happens.
- **Judging** now names the reaction: covering the face costs the most (-18), then a wave-off (-15), turning away (-12) and staring (-10). A pose or a wave costs little (-5/-6), but the frame counts as a portrait, not a candid. Settings → People notice the camera: Realistic (new) or Relaxed (the old 2 m behaviour).
- **The rival.** A photographer from the Evening Ledger walks the city with a camera on a strap, and it comes up to their eye when they shoot. Now and then the rival goes after one of your briefs that has been open for three minutes or more. The rival only makes progress while that brief's light and weather hold, heads for its district when you are not looking, and files after 7 to 12 minutes of street time. File first and you win it; otherwise the brief is gone. Brief cards and the HUD brief show when the rival is on it, how long they need, and where they are. The Photo Desk tab keeps score and has an On/Off switch.
- **Checked** in headless Chromium: at 4 to 5 m people noticed a raised camera within about a second and reacted by mood. Walkers who turned away reversed direction. At 14 m no one noticed. A frame of someone covering their face got the new critique. The rival picked a brief, filed it, removed it from the board and recorded the loss. The rival's camera renders at chest height and comes up to the eye when they shoot. No JavaScript errors.

## Photo Desk briefs, fairer pay, and a faster city

- **Photo Desk briefs.** A new Photo Desk tab (Tab menu) holds three briefs at a time: walking the dog, the tram, a busker with an audience, birds, a peak gesture, eye contact, umbrellas in the rain, blue hour, golden hour, morning commute, fog, street stories, taxis, and three depth layers. Many are tied to a district. Each has a minimum score, a cash and XP reward, and a deadline measured in street time. Pin one to keep it on the HUD above your money, with live checks for district direction and distance, time of day, and weather. Pass replaces a brief after a minute. The first judged frame shot after a brief arrives that meets it is filed and paid. Free Play earns XP only. The HUD brief can be hidden in the tab.
- **Open-market pay.** Frames under 50 no longer sell. Pay rises steeply with quality: 50 = $5, 60 = $15, 70 = $45, 80 = $95, 90 = $165 (before the Earnings setting). The desk pays half for another frame of the same kind of subject on the same street and a quarter for the same person again (last 12 sales). The lightbox explains reduced or refused sales and filed briefs.
- **Shutter no longer fires on the click that captures the mouse.** Clicking the street to capture the mouse only captures it. If the browser refuses pointer lock, click-to-shoot drag mode still works.
- **The disposable winds.** The FunSaver now needs its thumbwheel turned between frames like the other manual-advance cameras, so repeated clicks no longer create accidental double exposures. The Holga and Diana keep their intentional multiple exposures.
- **Exposure advice matches the camera.** Fixed-exposure cameras suggest shade, flash, and flash range instead of stopping down. Program cameras suggest compensation. Manual cameras suggest a specific shutter speed or aperture within the body and lens limits. The advice also notices a daylight flash that caused overexposure and a lens already wide open.
- **Reflections.** Wet-road and water reflections render only large objects, lights, the sky, instanced detail, people, and cars within 45 m, instead of the entire scene. Balanced mode no longer skips every other reflection frame in rain. Customize → Reflections High renders everything. Photographs always use full reflections.
- **Pedestrians.** Distant people (over 25, 45, and 90 m, or behind you) update their walking simulation every second, third, or fourth frame with accumulated time. Poses still update every frame. People in events, performers, and people crossing the street always update fully. Ground-height lookups use a spatial grid instead of checking every lot.
- **Static scene matrices.** Objects that stop moving stop recalculating their transforms. A watchdog checks every frozen object each frame and unfreezes anything that moves, permanently. Cars, the tram, the camera, and rain are never frozen. The scene transform pass also runs once per frame instead of twice.
- **Measured.** In headless Chromium, 14,200 scene objects dropped to about 2,100 transform updates per frame, and the scene transform pass took about half as long. The reflection pass used 145 to 180 draw calls, down from the full scene count. Pedestrian updates took about 20% less time. On a cloud Tesla T4, rain no longer caused a sustained frame-rate drop, and reflections of cars and buildings still show on wet roads. The cloud FPS figures were too noisy to quote precisely. There was no JavaScript error in any test.

## Solid streets, character expansion, and camera title

- Replaced invisible whole-lot barriers and the artificial map-edge clamp with height-aware collisions for generated structures and props. Swept movement prevents running through narrow obstacles. People, knights, parked and moving cars, street hydrants, poles, bins and benches block walking; jumping above an obstacle remains possible. Open ground is accessible. This does not generate new land beyond the existing island.
- Added all 50 requested character archetypes, mixed among ordinary pedestrians. They use different headgear, outfits, equipment and silhouettes, including horns, armor, wings, robes, fins, masks and tools. Their existing walking, street activities and photographic subject behavior remain intact. Ghosts and mermaids are stylized street characters with ordinary pedestrian collision.
- Camera-themed title screen: Nikon F illustration, film perforations, exposure markings and responsive layout. The illustration is embedded in the standalone game.
- Fixed manual rain selection: valid weather revisions, immediate precipitation visibility, and a per-frame visibility correction. Selecting weather manually disables automatic weather changes; turn Weather changes back on to resume them. The world is paused while menus are open, so animated rainfall resumes when returning to the street.
- Validation: all 50 costume builders, title art, collision clearance, people, vehicles, hydrants, free map access, and rain On/Off passed in headless Chromium with no JavaScript errors. Deterministic tests cover fast movement through narrow obstacles and collision-cell boundaries. Long hardware play sessions have not been tested.

## Free rooftop traversal and castle patrols

- Rooftop movement no longer clamps you inside the building you climbed. Jumping is continuous rather than teleporting to a selected roof. Move while airborne to cross gaps; land on lower roofs, building ledges, fire-escape platforms, benches and vehicles. Walking off an unsupported edge makes you fall. Taller solid structures still block passage.
- Press Enter while elevated to descend at the nearest doorway, fire escape entrance, or castle gate. The original entry point is no longer used.
- Removed the obsolete roof-to-roof parkour toggle; free traversal is built in.
- The first special lot is a castle, ensuring the city has one. Eight armored knights patrol it: four stay in the grounds and four pass through gates to mingle on surrounding sidewalks. Walking animation stops during their pauses.
- Checks passed: free edges, continuous jump, lower-roof landing, falls, taller-wall collision, nearest entrance, and actual castle patrol routes. Browser run: one castle, eight knights, four reaching the street, no JavaScript errors.

## September 28 refinement update

- Quiet defaults: vibration off, event alert audio off, automatic event pins never, master volume half. Applied once to existing saves; later preferences are retained.
- Removed Creative priority, HUD accent colour, Profile, Active editor, and the duplicate handheld-steadiness setting. Photo Desk combines all five editorial perspectives. Steadiness uses the skill; Reduced shake remains an explicit accessibility bypass (existing preference retained).
- Compact corner street label. Center-screen event descriptions have their own checkbox, off by default. Click a side-feed event to pulse its area on the minimap for eight seconds, even with automatic pins disabled. Off-map targets flash at the map edge in their direction.
- Climbing down after rooftop hopping exits at the current building's street-facing edge.
- Vehicle variety & details combines body selection and accessories. Reopen the game to regenerate traffic after changing it. Storefront glass controls transparency; Wet-street reflections controls reflection resolution.
- More blank masonry and varied window spacing. Wider body proportions, fourteen hair styles, more dyed hair and unusual outfits. Additional microvans, dune buggies, hot rods and stretched cars.
- Settings → Develop adds Moon jumps, Slow-motion city, Rainbow sunlight, and Automatic FPS safeguard. All start off each session. The safeguard defaults to 20 FPS, waits for sustained low performance, reduces quality in stages, and restores the original settings after sustained recovery. Temporary reductions are not saved. This can help rendering load but cannot guarantee a particular frame rate.
- Vibration calls the browser's vibration API on supported devices; ordinary desktop computers generally provide no vibration hardware.

Validation: production build and standalone generation passed; headless Chromium loaded without JavaScript errors. Browser assertions covered defaults, removed settings, roof descent, event-feed interaction, body/hair variety and vehicle definitions. The deterministic FPS test covers staged reductions, recovery, save isolation and background-tab exclusion. Actual vibration and physical-device performance were not tested.

## Island update — September 2026

- Model-specific shutter sounds restored. Quiet fixed-lens cameras use leaf sounds; rangefinders and SLRs with focal-plane shutters use curtain sounds. SLRs add mirror slap. Closing sounds follow exposure duration without slowing the simulation.
- Special cars now spawn on streets instead of block centres. Full vehicle footprints are checked against buildings before movement; cars turn around at the waterfront instead of wrapping across the map.
- Walking and running animation follows actual displacement, including event actors. Stationary actors no longer cycle a running gesture.
- Unsupported air conditioners, fire escapes and laundry above low alley walls removed. Alley lighting now has posts and connecting wire; back doors stay on service walls.
- Ocean surrounds all four sides. The waterfront has a promenade, seawalls following the terrain, rocks, four moving boats and twelve occasional jumping-fish locations. The minimap shows the coastline. The accessible boundary meets the visible seawall.
- New character accessories: headphones, scarves, satchels, cameras and bouquets. Uncommon samurai-inspired costumes, cowboys, sailors, wizards and explorers; an alien can occur very rarely, at most one per city.
- **Settings → Develop:** Visual Debug, nearby collision bounds, world coordinates and pause road traffic. Diagnostics require an explicit click and start off each session, including when continuing an old save.

## What's changed

- PSX Enhanced, PSX Classic, and Clean presentation options; revised light palettes and faceted characters.
- Camera-themed workbench with individual original illustrations for all 42 retained 35mm bodies and rewritten descriptions. Medium-format and instant equipment removed. Half-frame and XPan use 35mm film and remain.
- Quick pick: three distinct loaded bodies for wide (under 40mm), normal (40–70mm), and tele (over 70mm). Set them in Gear. Keys **1 / 2 / 3** switch; each body retains its roll and exposure settings. Career ranks cost **180 / 360 XP**; Free Play starts mastered. **Alt + 1–5** selects focus zones.
- Responsive photo processing uses 1080px output and fewer rendering passes. Fine detail uses 1500px. Capture requests are serialized and rendering state is restored on errors.
- Manual fog persists independently of precipitation. Storms include rain, lightning, and delayed thunder. Automatic weather is optional.
- Expanded developed blocks, anchored rooftop silhouettes, more expressive faces, and 22 additional street stories, including six larger gatherings.
- 100 short, attributed quotations by 49 photographers. One appears on startup; immediate repeats are avoided. Click the credit for its source.

## Update 2 — a living, fictional city

- **Fictional city, new every session.** No real-world references. Street and district names are dealt from a pool of invented names, and the layout is re-seeded each time. 121 blocks (was 49).
- **Architecture.** Art Deco, bay-window flats, stucco, glass towers, cast-iron fronts and boarded-up derelicts; stepped tower tops, bay columns, corner turrets; walkable service alleys through many blocks.
- **Not just shops.** Libraries, fire stations, police, post offices, churches, schools, clinics, community halls, theatres, gyms, galleries and museums. Shop types no longer repeat along a street.
- **Inside shops.** Deeper rooms, bigger windows, a counter with a clerk, and customers who eat, sip, read, browse and wait. Coffee and drinks are ordered at the counter only.
- **Street life.** 30 more street stories; "Frequent" now starts one every 12–22 s (up to four at once). An event feed under the map shows what started, how far and which direction. A map key explains the symbols.
- **Getting around.** Hop on and off buses and trams whenever you like.
- **Exposure.** Filters (ND, colour, polarizer) now count in the exposure reading and in auto-exposure; flash photos are judged on flash + ambient light at the focus distance.
- **Gear.** Every lens has a description; lenses, flashes and filters have drawings.
- **Cars and people.** Rarer paint colours, stripes, spoilers, bull bars, racks and more; wider clothing and hair palettes. The belt ring on some pedestrians is gone.
- **Settings.** Regrouped into clear categories; new options for start weather, event notices, map key, location label, minimap size, centre dot, interface size, people in shops and car details. Defaults: medium quality, photo preview on, random start weather.
- **Performance.** City geometry is split into large chunks so off-screen areas are skipped.

## Update 3 — busier streets, fewer collisions

- **Low graphics by default** (applied once to existing saves; change anytime). New **City size** setting: Compact (25 blocks), Standard (49, default), Large (81) — the biggest performance lever.
- **Fixes:** traffic no longer teleports onto other cars mid-city; walkers and cyclists slide along buildings instead of through them; turrets, bays and civic steps stay clear of the sidewalk path; parked cars get more room and never block alley mouths (bollards keep cars out); the market arch spans the street with its pillars on the curbs.
- **Variety:** pocket parks, car parks, vacant lots and gaps between buildings; mansard, gabled, garden and domed roofs; more building widths.
- **Construction:** up to four building sites with turning cranes, scaffolding, crews in hard hats and night work lamps, plus road works with cones and a worker.
- **Alleys:** murals, fire escapes, AC units, back doors with lamps, bins and bags, pallets, laundry lines, bike racks, a cook or smoker on break, and the odd cat.
- **Skills:** Speed loader, Bulk loader, Storm chaser, Street sense (mastered in Free Play).
- **Weather:** new Sky options — Overcast, Drizzle, Sunshower (with matching light levels for the meter).
- **Customisation:** date stamp on photos, photo border (film rebate / white print), HUD accent colour, construction crews and alley people on/off.
- **Settings:** aligned rows, filler text removed, every setting filed into a category.

## Update 4 — settings in one clear place

- **One coherent settings list.** The Settings tab is grouped into ten fixed categories, in a deliberate order: Camera & film, Camera HUD & controls, Movement & controls, Weather & time, City & street life, Graphics & performance, Events & notices, Sound, Accessibility, and Rules & economy. Every option is assigned to a category explicitly instead of by loose keyword matching.
- **Film and weather are separated.** Film advance, grain, halation, light leaks, exposure and editing live under **Camera & film**; rain, fog, wind and the speed of the day live under **Weather & time**. No option appears in two categories.
- **Nothing is lost.** Folded-away sections now persist on every settings render, and the lightbox analysis-overlay toggles stay in the panel.

## Update 4 — tidy-up

- **Fixes:** market arch sign fits its board; car-park cars sit on the tarmac; rails follow the road and are one instanced mesh; parks and car parks are walkable (park entrance, driveway gap); vehicles are hidden if they ever end up inside a building.
- **No cut-out people:** flat figures removed from shop interiors, shop windows and upper windows. People on balconies, at café tables, in queues and inside shops are all 3D.
- **Events:** every crowd member picks from filming, pointing, chatting, laughing, drifting off and coming back; story roles vary their gestures and shift position.
- **New:** balconies (plants, laundry, people reading, leaning, watering), storefront displays (fruit, flowers, café tables, record bins), newsstands, food trucks and hot-dog carts with queues.
- **Settings:** one Auto exposure control (the two "apply/recommended exposure" buttons and Perfect Program are gone); one Wind control; editor overlays always on; window silhouettes removed. The menu keeps your open sections and scroll position when you change something.
- **Defaults:** weather changes on its own, exposure coach off, film advance "By camera" (mechanical cameras need winding; motors wind themselves). Winding takes a fifth of a second, and pressing the shutter on an unwound camera flicks the lever for you.

## Update 5 — no clipping, more to photograph

- **Guards:** people stop their run cycle if they aren't actually moving; traffic keeps a gap sized to both vehicles' lengths; any vehicle that ends up inside a building is hidden until it's back on the street.
- **Vehicles:** more pickups, vans and box trucks, plus tractors, garbage trucks, cement mixers (spinning drums), flatbeds with crates, ice-cream vans, school buses, motorbikes with riders and, rarely, a tank.
- **People:** more skin tones, very short and very tall people, face width and head shape, eye spacing and shape, broader shoulders; faces drift through smiles, thoughtful looks, tiredness and surprise.
- **Sky and spectacle:** a local plane towing a banner, airliners with contrails, hot-air balloons on clear days, fireworks at night, a rainbow when rain clears, and a bubble artist in a park.
- **Balconies:** far more of them (plants, laundry, people).
- **Camera:** camera sound follows the body: leaf shutter or focal-plane, with mirror slap on SLRs; the back of the held camera is plain.
- **Settings:** hover tooltips and "?" markers removed (the description is on screen); strap colour removed.

## Update 6 — seaside, skyline and open spaces

- **Sea:** bluer water with visible, drifting swell; pulsing foam where it meets the sea wall; swell lines rolling in.
- **On the water:** cargo ships, a ferry and a tanker on the horizon; a surfer riding the swell; now and then a fish jumps near where you're standing, with splash rings.
- **Promenade:** benches facing the water, couples holding hands, people reading or watching, anglers at the rail.
- **Open blocks (open on all four sides):** parks with ponds and playgrounds, plazas with fountains, a castle with gates on every side, a domed library, sports courts with a running track, a glasshouse, a cemetery.
- **Less "New York":** downtown is a small core; the rest mixes rowhouses and low mixed streets, and towers are rarer and shorter.
- **Rooftops:** AC units, satellite dishes, antennas, solar panels, water towers, roof gardens, chimneys, rooftop bars with umbrellas and string lights, and billboards.
- **Traffic:** semis, tankers, dump trucks, army trucks, APCs, tanks and limousines join the traffic.
- **Birds and more:** geese in V formation, pelicans skimming the sea, a circling hawk, sparrows that scatter when you walk up, a rare flock of parrots; occasional tumbleweeds.
- **Dogs and trees:** chihuahuas, Great Danes, dalmatians, golden retrievers, beagles, bulldogs, shibas and Bernese join the breeds; birch, maple, pine, willow, oak, ginkgo and magnolia join the trees.
- **Fixes:** street-lamp lights no longer stutter or jump between houses (they fade between lamps); nobody runs on the spot; alley dressing only where real walls flank the lane.

## Update 7 — fixes and characters

- **Buildings on slopes:** the ground floor now sits at the high end of the frontage with a stone plinth on the downhill side, so windows no longer sink into the pavement.
- **Plazas and courts:** paving lines and court surfaces follow the ground instead of being long flat strips that rose out of it on slopes.
- **The sea:** the two landmarks that ended up standing in the water are gone; 13 small craft now circle close to the island (sailboats, speedboats with wakes, yachts, kayakers paddling, fishing trawlers) as well as the ships on the horizon.
- **Drivers:** tractors have a farmer at the wheel; tanks have a commander in the hatch.
- **Balconies:** about 60% of eligible buildings, with people reading, sipping, watering plants (with a can), pacing, stretching, smoking and leaning on the rail.
- **Rare characters:** lumberjacks, scuba divers, astronauts, knights, pirates (with a parrot), beekeepers, mimes, bear mascots, ninjas and chefs join the samurai, cowboys, sailors, wizards, explorers and the very rare alien.
- **Settings:** "Trucks & tanks" merged into "Unusual vehicles"; clearer names for the two event settings and the emergency-vehicle setting; the unlabelled reset row has a label; sea and sky options have their own section.

## Update 8 — parks that play, a whale, and a cleaner codebase

- **Parks and courts:** basketball games with a real ball and shots at the hoop, tennis rallies, fans cheering, picnics, frisbee, kids playing, a jogger, people feeding ducks, hot-dog and ice-cream carts with queues; tai chi, chess and a busker in plazas; a skatepark with skaters; tourists and a guard at the castle; readers, a mourner and a gardener in the quieter places.
- **Sea:** a rare whale breach (with a tourist grabbing the shot and a notice under the map), dolphins, a jet ski, buoys with blinking lights; promenade people fish, paint, fly kites, eat ice cream, use tripods and binoculars, and walk or jog along the front (far fewer couples).
- **Roofs:** stepping off a roof drops you in front of the building you're on, not where you climbed up. Fire escapes on older buildings.
- **Streets:** street sweepers; garbage trucks carry their crew. Lamp posts, signal poles, tree trunks and other posts are solid.
- **Weather-aware events:** outdoor shows, markets, yoga, kites and so on don't start in rain (a rain-dash or similar starts instead); bubbles and tumbleweeds wait for dry weather; fireworks are night-only.
- **Lenses:** Nikkor 200mm f/4 and 300mm f/4.5, FD 200mm f/2.8 and 300mm f/5.6, Pentax-M 200mm f/4, Zuiko 200mm f/4, Super-Takumar 200mm f/4.
- **Fixes:** tram rails sit exactly on the road surface; glass-fronted edge buildings start their window grid at the pavement; the glass dome (and its stray bars) is replaced by a skatepark; ambient walkers can't wander off into the sea; a new career no longer starts with Steady hands mastered (handheld steadiness is now just a feel setting).
- **Settings:** Fog density and Wind have a Random option (default); Event alerts has "No sound"; Restore visual defaults removed; changing a setting no longer redraws the whole panel. New defaults: clouds Some, photorealism pass On, living sky On, wet streets On, street detail Obsessive.
- **Code:** comments removed from all scripts, styles and markup.

## Update 9 — performance, people, playgrounds

- **Performance:** props, stalls, balconies, benches and playground pieces are merged into far fewer objects, and small things beyond a set distance stop being drawn (new setting: Detail distance, Near / Medium / Far). In testing this cut draw calls by about three quarters in a busy view. All of this happens during loading: the Start buttons only unlock once the whole city (people, props, boats, playgrounds) is built and prepared.
- **People:** new hairstyles (braids, dreadlocks, buzz cut, curls, twin buns, top knot, bob), more glasses, and everyday hats (beanies, caps, fedoras, sun hats, berets).
- **Shade grove:** one park per city is a grove — dozens of shade trees, a big duck pond with an island, ducks and ducklings, and people napping, reading, picnicking, sketching and playing guitar in the shade.
- **Playgrounds:** swings (with kids swinging), a slide kids climb and slide down, a seesaw, a spinning roundabout, a sandpit, kids running and playing tag, and parents watching.
- **Menu styles:** Leica (chrome, red dot), Nikon (black & yellow), Canon (black & red), Olympus (silver & blue), Pentax (black & green), Kodak (yellow & red), Darkroom and Plain.
- **Settings:** the editor analysis overlay toggles are gone; all overlays always show.

## Update 10 — incidents and fixes

- **Rain:** plain rain was being drawn so faint (and in the fog's own colour) that it only showed during storms. It's now clearly visible day and night, with slightly longer streaks.
- **Roofs:** climbing onto a roof no longer throws you straight back off (the roof's edge trim was being treated as a wall).
- **Cars:** a car's solid shape now comes from its body only, so headlight beams no longer block you.
- **Menu style:** Nikon is the default (applied once to existing saves; change it any time).
- **New events:** car crashes at nearby junctions (screech, crunch, broken glass, hazard lights, arguing drivers, onlookers filming, the police arriving) and, very rarely, an alien saucer that beams people up while the crowd points, films or runs — more likely at night. Both appear in the event list under the map and can be switched off under Events & notices.

## Update 11 — shoreline, alleys, facades, roofs

- **Walk on water** is now a setting (Movement & controls), off by default; the island's edge stops you otherwise. People, events and crowds always stay on land.
- **Alleys:** doors, lamps, AC units, fire escapes and washing lines are only placed where a real building wall stands behind them (checked after the whole city is built), so nothing floats over the lanes.
- **Facades:** every building except the bay-window rowhouses sits on a stone base course that wraps all four sides, so window rows never run into the ground on slopes or side walls.
- **Roofs:** mansard and gabled roofs leave a walkable ledge, so climbing onto those roofs no longer pushes you off the edge.

## Controls

WASD moves; mouse looks after clicking the street. V toggles arrow-key looking. Right mouse or Z raises the camera; left mouse or Space shoots. Tab opens the camera bag. P opens photographs. L reloads. See Controls for the full set.

## Development

Requires Node.js and npm. Run `npm install`, then `npm run dev`. `npm run build` creates the served build in `dist`; `npm run standalone` rebuilds the self-contained HTML. `npm run release` builds both. The active gameplay remains classic JavaScript with typed gear and utility modules; this is not a Godot or Android port.

Camera art is editable SVG, generated by `scripts/build-camera-art.py`. Quotes are generated by `scripts/build-quotes.py`. See CAMERA-REFERENCES.md and QUOTE-SOURCES.md for sources. Illustrations are stylized interpretations, not engineering-exact replicas. Existing gear behavior is a simulation rather than a complete emulation of every real camera's controls.

## Validation

Production TypeScript/Vite build and Chromium smoke checks cover all seven menu tabs, 35mm catalog constraints, Free Play unlocks, Quick pick roll/settings retention, XP costs, old-save migration, weather transitions, stable fog, lightning, event cleanup, and JPEG storage without duplicate captures. Software-rendered test timings are not representative of hardware-accelerated play. Android performance and a native port remain future work.

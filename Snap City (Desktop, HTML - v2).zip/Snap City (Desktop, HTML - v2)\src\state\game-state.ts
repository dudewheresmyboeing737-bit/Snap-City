import type {
  CameraKit,
  CapturedPhoto,
  GameSettings,
  WeatherKind
} from "../types/game";

export interface PlayerState {
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  isMoving: boolean;
}

export interface WorldState {
  elapsedSeconds: number;
  day: number;
  timeOfDay: number;
  weather: WeatherKind;
  activeLocationId: string;
}

export interface GameState {
  running: boolean;
  paused: boolean;
  player: PlayerState;
  world: WorldState;
  settings: GameSettings;
  activeCameraKit: CameraKit | null;
  portfolio: CapturedPhoto[];
}

export function createGameState(settings: GameSettings): GameState {
  return {
    running: false,
    paused: false,
    player: {
      x: 0,
      y: 1.7,
      z: 0,
      yaw: 0,
      pitch: 0,
      isMoving: false
    },
    world: {
      elapsedSeconds: 0,
      day: 1,
      timeOfDay: 9.5,
      weather: "clear",
      activeLocationId: "default"
    },
    settings,
    activeCameraKit: null,
    portfolio: []
  };
}

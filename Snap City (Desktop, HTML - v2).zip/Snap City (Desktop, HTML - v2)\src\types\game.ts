export type WeatherKind =
  | "clear"
  | "overcast"
  | "fog"
  | "rain"
  | "snow"
  | "golden-hour"
  | "night";

export type EditorVerdict =
  | "reject"
  | "maybe"
  | "keeper"
  | "portfolio";

export type PerfectExposureMode = "off" | "meter-assist" | "auto-perfect";
export type ExposurePriority = "balanced" | "freeze-motion" | "handheld" | "shallow-depth" | "deep-depth";

export interface GameSettings {
  masterVolume: number;
  musicVolume: number;
  effectsVolume: number;
  mouseSensitivity: number;
  fieldOfView: number;
  qualityPreset: "low" | "medium" | "high" | "ultra";
  showEditorOverlays: boolean;
  enableDynamicEvents: boolean;
  reduceMotion: boolean;
  perfectExposureMode: PerfectExposureMode;
  exposurePriority: ExposurePriority;
  protectHighlights: boolean;
}

export interface CameraKit {
  id: string;
  name: string;
  focalLengthMm: number;
  apertureMin: number;
  apertureMax: number;
  shutterSpeedMin: number;
  shutterSpeedMax: number;
  isoMin: number;
  isoMax: number;
}

export interface PhotoScore {
  composition: number;
  light: number;
  timing: number;
  subject: number;
  technical: number;
  total: number;
}

export interface CapturedPhoto {
  id: string;
  capturedAt: string;
  locationId: string;
  weather: WeatherKind;
  cameraKitId: string;
  score: PhotoScore;
  verdict?: EditorVerdict;
  imageDataUrl?: string;
}

export interface SaveGame {
  version: number;
  settings: GameSettings;
  selectedCameraKitId: string;
  credits: number;
  reputation: number;
  portfolio: CapturedPhoto[];
}

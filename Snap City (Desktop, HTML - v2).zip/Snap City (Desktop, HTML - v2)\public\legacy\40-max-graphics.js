(function(){
  "use strict";

  const MAX_GRAPHICS = {

    renderQuality: "ultra",
    reflections: "high",
    graphicsEnhance: "on",
    weatherPolish: "on",

    graphicsPreset: "ultra",
    atmosphereStrength: "cinematic",
    wetStreets: "on",
    livingSky: "on",
    facadeDetail: "obsessive",
    crowdPresentation: "rich",
    cinematicBloom: "on",
    stylizedPalette: "on",

    architectureDetail: "cinematic",

    streetDetail: "max",
    characterVariety: "max",
    vehicleVariety: "max",
    faceVariety: "max",
    specialVehicles: "on",
    peopleDensity: "full",
    trafficDensity: "full",
    streetcars: "8",
    birdLife: "normal",
    cloudLife: "some",
    windowLife: "on",
    neonAmount: "lots",
    stringLights: "on",
    litterOn: "on"
  };
  window.CS_MAX_GRAPHICS = MAX_GRAPHICS;

  function applyMax(s){
    if(!s) return s;
    s.custom = s.custom || {};
    Object.assign(s.custom, MAX_GRAPHICS);

    s.custom._v145Applied = true;
    s.custom._v147LeanApplied = true;
    s.custom._maxGraphicsApplied = true;
    return s;
  }

  if(typeof defaultState === "function"){
    const baseDefaultState = defaultState;
    window.defaultState = function(){
      return applyMax(baseDefaultState.apply(this, arguments));
    };
  }

  function refresh(){
    try{ applyGraphicsQuality(); }catch(e){}
    try{ polishWorldMaterials(); }catch(e){}
    try{ applyInteriorSettings(); }catch(e){}
  }

  if(typeof boot === "function"){
    const baseBoot = boot;
    window.boot = async function(){

      let needsUpgrade = true;
      try{ const raw = loadState(); needsUpgrade = !(raw && raw.custom && raw.custom._maxGraphicsApplied); }catch(e){}
      const result = await baseBoot.apply(this, arguments);
      try{
        if(needsUpgrade && typeof S !== "undefined" && S && S.custom){
          applyMax(S);
          refresh();
          saveState();
          console.info("[Contact Sheet] Graphics set to maximum.");
        }
      }catch(e){ console.warn("[Contact Sheet] Max graphics skipped:", e); }
      return result;
    };
  }

  if(typeof gameplayUpdate === "function"){
    const baseUpdate = gameplayUpdate;
    let checked = false;
    window.gameplayUpdate = function(){
      if(!checked && typeof S !== "undefined" && S && S.custom){
        checked = true;
        if(!S.custom._maxGraphicsApplied){
          applyMax(S);
          refresh();
          try{ saveState(); }catch(e){}
          console.info("[Contact Sheet] Graphics set to maximum.");
        }
      }
      return baseUpdate.apply(this, arguments);
    };
  }
})();

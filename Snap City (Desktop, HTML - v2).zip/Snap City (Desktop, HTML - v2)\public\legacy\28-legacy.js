(function(){
"use strict";
const STORM = window.CS144Storm = { t:6+Math.random()*10, flash:0, flashPeak:0, lastBolt:0, overlay:null, activeWas:false, baseFog:null };

function stormOverlay(){
  if(STORM.overlay) return STORM.overlay;
  const e=document.createElement('div'); e.id='stormFlash';
  e.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:28;background:rgba(220,235,255,1);opacity:0;mix-blend-mode:screen;transition:opacity .08s linear;';
  document.body.appendChild(e); STORM.overlay=e; return e;
}
function thunderSound(distance=0.5){
  try{
    const ctx=Audio.ctx&&Audio.ctx(), master=Audio.master&&Audio.master(); if(!ctx||!master)return;
    const dur=2.2+distance*2.5, len=Math.floor(ctx.sampleRate*dur), buf=ctx.createBuffer(1,len,ctx.sampleRate), d=buf.getChannelData(0);
    let low=0;
    for(let i=0;i<len;i++){
      const t=i/ctx.sampleRate, env=Math.exp(-t*(0.85+distance*.55));
      low=(low+(Math.random()*2-1)*0.045)/1.045;
      d[i]=(low*4.2+(Math.random()*2-1)*0.12)*env;
    }
    const s=ctx.createBufferSource(); s.buffer=buf;
    const lp=ctx.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=260+220*(1-distance);
    const g=ctx.createGain(); g.gain.value=.25+.22*(1-distance); s.connect(lp); lp.connect(g); g.connect(master); s.start();
  }catch(e){}
}
function triggerLightning(){
  const dist=.15+Math.random()*.85;
  STORM.flash=.16+Math.random()*.13; STORM.flashPeak=STORM.flash; STORM.lastBolt=performance.now();
  const o=stormOverlay(); o.style.opacity=String(.55+Math.random()*.35);
  setTimeout(()=>{ if(o) o.style.opacity='0'; }, 90+Math.random()*80);
  setTimeout(()=>thunderSound(dist), 350+dist*2200);
  if(Math.random()<.35) setTimeout(()=>{ const q=stormOverlay(); q.style.opacity='.38'; setTimeout(()=>q.style.opacity='0',65); }, 120+Math.random()*130);
}
function stormApplyVisuals(){
  if(!window.S||!window.World||!World.timeDef)return;
  const T=World.timeDef;
  if(S.storm){
    S.rain=true;
    if(World.sun) World.sun.intensity = Math.max(0.03, T.sunI*.14) + (STORM.flash>0 ? 5.5*(STORM.flash/STORM.flashPeak) : 0);
    if(World.hemi) World.hemi.intensity = T.hemiI*.58 + (STORM.flash>0 ? 1.5*(STORM.flash/STORM.flashPeak) : 0);
    if(World.scene&&World.scene.fog) World.scene.fog.density=Math.max(World.scene.fog.density, .0095);
    if(World.skyMat&&World.skyMat.uniforms){
      const gray=new THREE.Color('#39424e'), dark=new THREE.Color('#151b24');
      World.skyMat.uniforms.top.value.copy(gray);
      World.skyMat.uniforms.bot.value.copy(dark);
      World.skyMat.uniforms.sunAmt.value=STORM.flash>0?1.8:.04;
    }
  }
}
function updateStorm(dt){
  if(!window.S)return;
  if(!S.storm){
    if(STORM.activeWas){ STORM.activeWas=false; STORM.flash=0; try{applyTime();}catch(e){} }
    return;
  }
  STORM.activeWas=true;
  STORM.t-=dt;
  if(STORM.t<=0){ triggerLightning(); STORM.t=4+Math.random()*13; }
  if(STORM.flash>0) STORM.flash=Math.max(0,STORM.flash-dt);
  stormApplyVisuals();
}

if(typeof menuTime==='function'){
  const baseTime144=menuTime;
  menuTime=function(){
    let h=baseTime144();
    h += `<div class="formrow"><label>Thunderstorm</label><div class="seg" data-storm><button data-v="0" aria-pressed="${!S.storm}">Off</button><button data-v="1" aria-pressed="${!!S.storm}">Storm</button></div><span class="spec">Heavy rain, gusty atmosphere, lightning flashes and delayed thunder. Lightning can briefly change the exposure of the whole street.</span></div>`;
    return h;
  };
}
if(typeof wireMenu==='function'){
  const baseWire144=wireMenu;
  wireMenu=function(){
    const r=baseWire144.apply(this,arguments), body=document.querySelector('#menubody'), st=body&&body.querySelector('[data-storm]');
    if(st) st.querySelectorAll('button').forEach(b=>b.onclick=()=>{ S.storm=b.dataset.v==='1'; if(S.storm){S.rain=true;Audio.init&&Audio.init();} applyTime(); saveState(); renderMenu(); });
    return r;
  };
}

if(typeof sceneEV==='function'){
  const baseEV144=sceneEV;
  sceneEV=function(){ let ev=baseEV144.apply(this,arguments); if(S&&S.storm){ev-=2.1; if(STORM.flash>0)ev+=3.8*(STORM.flash/STORM.flashPeak);} return ev; };
}

if(typeof gameplayUpdate==='function'){
  const baseGame144=gameplayUpdate;
  gameplayUpdate=function(dt){ const r=baseGame144.apply(this,arguments); try{updateStorm(dt);}catch(e){} return r; };
}

let autoStormT=45+Math.random()*75;
if(typeof gameplayUpdate==='function'){
  const autoBase144=gameplayUpdate;
  gameplayUpdate=function(dt){
    const r=autoBase144.apply(this,arguments);
    if(S&&S.custom&&false  ){ autoStormT-=dt; if(autoStormT<=0){ autoStormT=70+Math.random()*150; if(Math.random()<.09){S.storm=true;S.rain=true;saveState();toast('The sky darkens. Thunder rolls somewhere beyond the hills.',2600);} } }
    return r;
  };
}

try{ if(window.CS142_DESC) CS142_DESC['Thunderstorm']='Adds heavy rain, lightning, thunder and much darker storm light.'; }catch(e){}

console.log('[Contact Sheet v14.4] thunderstorms enabled.');
})();

const Smoke = {
  max:1600, i:0, pts:null,
  init(scene){
    const n = this.max; this.p = new Float32Array(n*3); this.v = new Float32Array(n*3); this.age = new Float32Array(n).fill(99); this.life = new Float32Array(n).fill(1); this.s0 = new Float32Array(n); this.a0 = new Float32Array(n);
    this.size = new Float32Array(n); this.alpha = new Float32Array(n); this.shade = new Float32Array(n*3).fill(-1); this.rise = new Float32Array(n).fill(0.18); this.grow = new Float32Array(n).fill(1.6);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(this.p, 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute("aSize", new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute("aAlpha", new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute("aShade", new THREE.BufferAttribute(this.shade, 3).setUsage(THREE.DynamicDrawUsage));
    const mat = new THREE.ShaderMaterial({ transparent:true, depthWrite:false, uniforms:{ uScale:{value:500}, uCol:{value:new THREE.Color(0.6,0.6,0.6)} },
      vertexShader:`attribute float aSize; attribute float aAlpha; attribute vec3 aShade; uniform float uScale; varying float vA; varying vec3 vS; void main(){ vS = aShade; vec4 mv = modelViewMatrix*vec4(position,1.0); gl_Position = projectionMatrix*mv; gl_PointSize = aSize*uScale/max(0.15,-mv.z); vA = aAlpha; }`,
      fragmentShader:`uniform vec3 uCol; varying float vA; varying vec3 vS; void main(){ vec2 d = gl_PointCoord - 0.5; float r = dot(d,d)*4.0; if (r > 1.0) discard; float a = vA*(1.0-r)*(1.0-r); gl_FragColor = vec4(vS.x < 0.0 ? uCol : vS, a); }` });
    this.pts = new THREE.Points(g, mat); this.pts.frustumCulled = false; this.pts.renderOrder = 5;
    const sz = new THREE.Vector2();
    this.pts.onBeforeRender = (r, sc, cam) => { const rt = r.getRenderTarget(); const h = rt ? rt.height : r.getDrawingBufferSize(sz).y; mat.uniforms.uScale.value = h/(2*Math.tan((cam.fov||60)*Math.PI/360)); };
    scene.add(this.pts);
  },
  emit(x,y,z, vx,vy,vz, size, life, alpha, shade, rise, grow){ const k = this.i = (this.i+1) % this.max; if (shade){ this.shade[k*3] = shade.r; this.shade[k*3+1] = shade.g; this.shade[k*3+2] = shade.b; } else this.shade[k*3] = -1; this.rise[k] = rise ?? 0.18; this.grow[k] = grow ?? 1.6; this.p[k*3]=x; this.p[k*3+1]=y; this.p[k*3+2]=z; this.v[k*3]=vx; this.v[k*3+1]=vy; this.v[k*3+2]=vz; this.age[k]=0; this.life[k]=life; this.s0[k]=size; this.a0[k]=alpha; },
  update(dt){
    if (!this.pts) return;
    const T = World.timeDef || TIMES[2], c = this.pts.material.uniforms.uCol.value;
    c.copy(lin(T.fog)).multiplyScalar(T.id==="night" ? 0.35 : T.id==="blue" ? 0.55 : 0.95);
    for (let k=0;k<this.max;k++){
      const a = this.age[k] += dt; if (a > this.life[k]){ this.alpha[k] = 0; continue; }
      const f = Math.exp(-dt*1.2);
      this.v[k*3] = this.v[k*3]*f + (typeof WIND !== "undefined" ? WIND.x : 0.12)*dt; this.v[k*3+2] += (typeof WIND !== "undefined" ? WIND.z : 0)*dt; this.v[k*3+1] = this.v[k*3+1]*f + this.rise[k]*dt; this.v[k*3+2] *= f;
      this.p[k*3] += this.v[k*3]*dt; this.p[k*3+1] += this.v[k*3+1]*dt; this.p[k*3+2] += this.v[k*3+2]*dt;
      const u = a/this.life[k]; this.size[k] = this.s0[k]*(1 + a*this.grow[k]); this.alpha[k] = this.a0[k]*Math.min(1, a*5)*(1-u)*(1-u);
    }
    const g = this.pts.geometry; g.attributes.position.needsUpdate = true; g.attributes.aSize.needsUpdate = true; g.attributes.aAlpha.needsUpdate = true; g.attributes.aShade.needsUpdate = true;
  }
};

const BREEDS = [
  ["labrador",3,{s:1,len:1,leg:1,g:1.05,sn:1,ear:"flop",tail:"thick",c:["#d9b77a","#1a1a1a","#5a3a22","#e8d2a0"]}],
  ["shepherd",1.5,{s:1.08,len:1.05,leg:1.05,g:1,sn:1.25,ear:"prick",tail:"thick",c:["#8a5a2a"],c2:"#1e1a16"}],
  ["dachshund",1.5,{s:0.62,len:1.6,leg:0.42,g:0.95,sn:1.15,ear:"flop",tail:"thin",c:["#7a3e1e","#1e1a16"]}],
  ["corgi",1.5,{s:0.66,len:1.3,leg:0.5,g:1.1,sn:0.95,ear:"prick",tail:"stub",c:["#c9803a"],c2:"#f2ebe0"}],
  ["poodle",1,{s:0.75,len:0.9,leg:1.15,g:1.1,sn:1.1,ear:"flop",tail:"curl",fl:1.25,c:["#f2ebe0","#1a1a1a","#c98e5a"]}],
  ["husky",1,{s:1.02,len:1,leg:1,g:1.05,sn:1,ear:"prick",tail:"curl",fl:1.1,c:["#8f8f8f"],c2:"#f2f0ea"}],
  ["pug",1,{s:0.5,len:0.85,leg:0.75,g:1.3,sn:0.35,ear:"flop",tail:"curl",c:["#d9b98a"],c2:"#1e1a16"}],
  ["whippet",1,{s:0.85,len:1.05,leg:1.35,g:0.72,sn:1.35,ear:"flop",tail:"thin",c:["#9a9591","#e8e0d4","#6a5040"]}],
  ["terrier",1.5,{s:0.55,len:0.95,leg:0.8,g:1,sn:0.9,ear:"prick",tail:"stub",fl:1.15,c:["#f2f0ea","#d9c9a3"]}],
  ["pitbull",1.2,{s:0.9,len:1,leg:0.95,g:1.3,sn:0.85,ear:"flop",tail:"thin",c:["#6f6a66","#e8dcc8","#8a5a3a"]}],
  ["chihuahua",1,{s:0.36,len:0.85,leg:0.95,g:0.85,sn:0.7,ear:"prick",tail:"thin",c:["#d9b98a","#1e1a16","#f2ebe0"]}],
  ["greatdane",0.6,{s:1.45,len:1.1,leg:1.3,g:0.9,sn:1.2,ear:"flop",tail:"thin",c:["#4a4a52","#c9a36a","#1a1a1a"]}],
  ["dalmatian",0.8,{s:1.0,len:1.05,leg:1.1,g:0.9,sn:1.1,ear:"flop",tail:"thin",c:["#f4f2ec"],c2:"#1a1a1a"}],
  ["golden",1.5,{s:1.0,len:1.05,leg:1,g:1.05,sn:1.1,ear:"flop",tail:"thick",fl:1.15,c:["#d9a24a","#e8c07a"]}],
  ["beagle",1.2,{s:0.7,len:1,leg:0.85,g:1,sn:1,ear:"flop",tail:"thin",c:["#8a5a2a"],c2:"#f2ebe0"}],
  ["bulldog",0.9,{s:0.62,len:0.9,leg:0.6,g:1.45,sn:0.4,ear:"flop",tail:"stub",c:["#e8dcc8","#c98e5a"]}],
  ["shiba",0.9,{s:0.72,len:0.95,leg:0.95,g:1,sn:0.95,ear:"prick",tail:"curl",fl:1.1,c:["#c9803a"],c2:"#f2ebe0"}],
  ["bernese",0.6,{s:1.2,len:1.05,leg:1,g:1.2,sn:1,ear:"flop",tail:"thick",fl:1.2,c:["#1a1a1a"],c2:"#b86a3a"}],
  ["mutt",2,{s:0.8,len:1,leg:0.95,g:1,sn:1,ear:"flop",tail:"thick",c:["#3a2a1c","#c9a36a","#e8e0d4","#6b4a2e"]}],
];
const DPI = {};
function dressDog(d, r){
  const name = wpick(BREEDS.map(b=>[b[0],b[1]]), r), b = BREEDS.find(x=>x[0]===name)[2];
  Object.assign(d, { breed:name, size:b.s*(0.92+r()*0.16), len:b.len, leg:b.leg, g:b.g, sn:b.sn, ear:b.ear, tail:b.tail, fl:b.fl||1 });
  d.color = b.c[(r()*b.c.length)|0]; d.c2 = b.c2 || d.color; d.collar = ["#c0362c","#2f7fc1","#e8b82e","#1a1a1a","#3aa06b"][(r()*5)|0];
  d.wx = 0; d.wz = 0; d.wT = 0; d.still = 0; d.speed = 0; d.phase = r()*6; d.x = d.owner.x; d.z = d.owner.z; d.heading = d.owner.heading||0;
}
function buildDogMeshes(scene){
  const r = mulberry(555); Life.dogs.forEach(d => dressDog(d, r));
  const N = Math.max(1, Life.dogs.length), fur = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.95 }), shiny = new THREE.MeshStandardMaterial({ color:0xffffff, roughness:0.35 });
  const limb = lathe([[0,0.04],[0.7,0.02],[1,-0.06],[0.96,-0.4],[0.8,-0.9],[0.55,-1],[0,-1.02]], 8);
  const mk = (name, g, mat, count, shadow) => { const m = new THREE.InstancedMesh(g, mat, count); m.instanceMatrix.setUsage(THREE.DynamicDrawUsage); m.castShadow = !!shadow; m.receiveShadow = true; m.frustumCulled = false; scene.add(m); PI_[name] = m; for (let i=0;i<count;i++) m.setMatrixAt(i, HIDE); return m; };
  const sph = new THREE.SphereGeometry(1, 12, 9).toNonIndexed();
  mk("d_body", sph, fur, N, true); mk("d_chest", sph, fur, N, true); mk("d_head", sph, fur, N, true); mk("d_neck", limb, fur, N, false);
  mk("d_snout", new THREE.CylinderGeometry(0.8,1,1,10).rotateX(Math.PI/2).translate(0,0,0.5).toNonIndexed(), fur, N, false);
  mk("d_nose", new THREE.SphereGeometry(1,8,6).toNonIndexed(), shiny, 3*N, false);
  mk("d_earF", new THREE.SphereGeometry(1,8,6).translate(0,-0.8,0).toNonIndexed(), fur, 2*N, false);
  mk("d_earP", new THREE.ConeGeometry(1,1,6).translate(0,0.5,0).toNonIndexed(), fur, 2*N, false);
  mk("d_leg", limb, fur, 4*N, true); mk("d_tail", limb, fur, N, false); mk("d_collar", new THREE.TorusGeometry(1,0.22,5,12).toNonIndexed(), shiny, N, false);
  mk("leash", new THREE.CylinderGeometry(1,1,1,5).toNonIndexed(), shiny, 4*N, false);
  const c = new THREE.Color(), set = (n,i,h) => { (PCOL[n] = PCOL[n] || [])[i] = lin(h); };
  Life.dogs.forEach((d,i)=>{ set("d_body",i,d.color); set("d_chest",i,d.c2===d.color?d.color:d.c2); set("d_head",i,d.color); set("d_neck",i,d.color); set("d_snout",i,d.breed==="pug"||d.breed==="shepherd"?d.c2:d.color);
    for (let k=0;k<3;k++) set("d_nose",3*i+k,"#141210"); for (let k=0;k<2;k++){ set("d_earF",2*i+k,d.breed==="shepherd"?d.c2:d.color); set("d_earP",2*i+k,d.breed==="shepherd"?d.c2:d.color); }
    for (let k=0;k<4;k++) set("d_leg",4*i+k, d.breed==="husky"||d.breed==="corgi" ? d.c2 : d.color); set("d_tail",i,d.color); set("d_collar",i,d.collar);
    for (let k=0;k<4;k++) set("leash",4*i+k, d.collar); });
  for (const k of ["d_body","d_chest","d_head","d_neck","d_snout","d_nose","d_earF","d_earP","d_leg","d_tail","d_collar","leash"]){ PI_[k].setColorAt(0, c.set(0x808080)); PI_[k].count = 0; }
}
const _dA = new THREE.Vector3(), _dB = new THREE.Vector3(), _dB2 = new THREE.Vector3(), _dq = new THREE.Quaternion(), _up = new THREE.Vector3(0,1,0);
function updateDogs(dt, pl){
  const t = Life.t;
  Life.dogs.forEach((d,i)=>{
    const o = d.owner, fx = Math.sin(o.heading), fz = Math.cos(o.heading), lx = -Math.cos(o.heading), lz = Math.sin(o.heading);
    d.wT -= dt; if (d.wT <= 0){ d.wT = 1.5 + Math.random()*3; d.wx = (Math.random()-0.5)*1.2; d.wz = (Math.random()-0.3)*1.0; }
    const ahead = o.moving ? 0.7 : 0.3;
    const tx = d.free ? d.free.tx : o.x + fx*(ahead + d.wz) + lx*(0.75 + d.wx*0.5), tz = d.free ? d.free.tz : o.z + fz*(ahead + d.wz) + lz*(0.75 + d.wx*0.5);
    let dx = tx - d.x, dz = tz - d.z; const dd = Math.hypot(dx, dz);
    const want = dd > 0.12 ? (d.free ? Math.min(dd*2, 4.6) : Math.min(dd*2.2, Math.max(1.3, (o.speed||1)*1.6))) : 0;
    d.speed = lerp(d.speed, want, Math.min(1, dt*4));
    if (dd > 0.01){ d.x += dx/dd*d.speed*dt; d.z += dz/dd*d.speed*dt; }

    const hx = o.handL ? o.handL.x : o.x, hz = o.handL ? o.handL.z : o.z; let ex = d.x - hx, ez = d.z - hz; const el = Math.hypot(ex, ez), LL = 1.9;
    if (el > LL && !d.free){ d.x = hx + ex/el*LL; d.z = hz + ez/el*LL; }
    d.y = groundY(d.x, d.z);
    if (d.speed > 0.15) d.heading = angLerp(d.heading, Math.atan2(dx, dz), Math.min(1, dt*6));
    d.still = d.speed < 0.2 ? d.still + dt : 0;
    d.phase += d.speed * dt * 9 / Math.max(0.5, d.size*d.leg);
    poseDog(d, i, t, Math.hypot(pl.pos.x - d.x, pl.pos.z - d.z));
  });
}
function poseDog(d, i, t, dist){
  const [base, bodyF, headF, tmp, neckF] = FR, s = d.size, g = d.g, fl = d.fl;
  if (dist > 150) return;
  base.makeRotationY(d.heading).setPosition(d.x, d.y, d.z); base.scale(_ps.set(s,s,s));
  const legH = 0.34*d.leg, sitting = d.still > 3 && ((i + Math.floor(t/12)) % 2 === 0), sniff = d.still > 0.6 && !sitting;
  const trot = Math.min(1, d.speed/1.2), ph = d.phase, sw = Math.sin(ph)*0.55*trot;
  const bodyY = legH + 0.12*g - (sitting ? 0.1*d.leg : 0) + Math.abs(Math.cos(ph))*0.015*trot;
  jf(bodyF, base, 0, bodyY, 0, sitting ? -0.42 : 0, 0, 0);
  const bl = 0.33*d.len;
  sp("d_body", i, bodyF, 0, 0, 0, 0.15*g*fl, 0.14*g*fl, bl*fl);
  sp("d_chest", i, bodyF, 0, 0.02, bl*0.62, 0.135*g*fl, 0.16*g*fl, 0.15*g*fl);

  const headDown = sniff ? 0.9 + Math.sin(t*3+i)*0.1 : sitting ? -0.15 : 0.1;
  jf(neckF, bodyF, 0, 0.07*g, bl*0.8, -2.3 + headDown, 0, 0);
  sp("d_neck", i, neckF, 0, 0, 0, 0.07*g*fl, 0.18, 0.07*g*fl);
  jf(headF, neckF, 0, -0.18, 0, 2.3 - headDown*0.6, Math.sin(t*0.7+i)*0.25*(1-trot), 0);
  const hr = 0.095*(0.9 + 0.2*g);
  sp("d_head", i, headF, 0, 0.02, 0.02, hr*fl, hr*0.92*fl, hr*1.05*fl);
  const snl = 0.12*d.sn; sp("d_snout", i, headF, 0, -0.01, hr*0.7, 0.042*g, 0.04*g, snl);
  sp("d_nose", 3*i, headF, 0, 0.005, hr*0.7 + snl, 0.02, 0.018, 0.015);
  sp("d_nose", 3*i+1, headF, -hr*0.45, hr*0.35, hr*0.72, 0.014, 0.014, 0.01); sp("d_nose", 3*i+2, headF, hr*0.45, hr*0.35, hr*0.72, 0.014, 0.014, 0.01);
  for (const k of [0,1]){ const sx = k ? 1 : -1;
    if (d.ear === "flop"){ sp("d_earF", 2*i+k, headF, sx*hr*0.85, hr*0.55, -hr*0.1, 0.022, 0.065*(0.8+0.3*d.len), 0.045, 0, 0, sx*(0.15 + trot*Math.sin(ph*2)*0.2)); }
    else { sp("d_earP", 2*i+k, headF, sx*hr*0.5, hr*0.75, -hr*0.15, 0.035, 0.085, 0.02, 0, 0, -sx*0.25); }
  }
  sp("d_collar", i, neckF, 0, -0.03, 0, 0.075*g*fl, 0.075*g*fl, 0.075*g*fl, Math.PI/2);

  const lp = [[-1, 1, sw],[1, 1, -sw],[-1, -1, -sw],[1, -1, sw]];
  lp.forEach(([sx, sz, a], k) => {
    const rear = sz < 0; let rx = a, yy = legH + 0.03, zz = sz*bl*0.72;
    if (sitting && rear){ rx = -1.35; yy = legH*0.55; }
    if (sitting && !rear){ rx = 0.42; }
    jf(tmp, base, sx*0.075*g, bodyY - 0.03, zz*(sitting && rear ? 0.7 : 1), rx, 0, 0);
    sp("d_leg", 4*i+k, tmp, 0, 0, 0, 0.034*g*(fl>1?1.3:1), (sitting && rear) ? legH*0.6 : bodyY - 0.03, 0.034*g*(fl>1?1.3:1));
  });
  const wag = Math.sin(t*(d.still>0.5 ? 14 : 8) + i)*(d.tail==="stub" ? 0.2 : 0.55);
  const tl = d.tail === "stub" ? 0.06 : d.tail === "curl" ? 0.16 : 0.26, tr = d.tail === "thick" ? 0.03 : d.tail === "curl" ? 0.035*fl : 0.016;
  sp("d_tail", i, bodyF, 0, 0.05*g, -bl*0.95, tr, tl, tr, d.tail==="curl" ? 2.8 : sitting ? 1.7 : 2.25, 0, wag);

  const o = d.owner;
  if (o.handL && !d.free){
    _dA.copy(o.handL); _dB.set(0, -0.03, 0).applyMatrix4(neckF);
    const span = _dA.distanceTo(_dB), sag = Math.max(0.03, (2.1 - span)*0.35);
    let px = _dA.x, py = _dA.y, pz = _dA.z;
    for (let k=1;k<=4;k++){
      const u = k/4, nx = lerp(_dA.x,_dB.x,u), ny = lerp(_dA.y,_dB.y,u) - 4*u*(1-u)*sag, nz = lerp(_dA.z,_dB.z,u);
      const vx = nx-px, vy = ny-py, vz = nz-pz, len = Math.hypot(vx,vy,vz) || 0.001;
      _dq.setFromUnitVectors(_up, _pv.set(vx/len, vy/len, vz/len));
      _pm.compose(_dB2.set((px+nx)/2, (py+ny)/2, (pz+nz)/2), _dq, _ps.set(0.006, len, 0.006));
      spM("leash", 4*i+k-1, _pm);
      px = nx; py = ny; pz = nz;
    }
  }
}

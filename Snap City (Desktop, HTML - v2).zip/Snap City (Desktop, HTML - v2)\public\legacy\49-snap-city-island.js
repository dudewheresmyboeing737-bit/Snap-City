(function(){
  'use strict';
  const SC=window.SnapCity=window.SnapCity||{};
  const E=(NOUT+.5)*P+20, SEA=-1.4;
  const I=SC.island={edge:E,built:false,boats:[],fish:[],accessories:[],time:0};
  SC.debugEnabled=false;
  const dev={colliders:false,coordinates:false,pauseTraffic:false};
  const box=new THREE.BoxGeometry(1,1,1), sphere=new THREE.SphereGeometry(.5,10,8), cyl=new THREE.CylinderGeometry(.5,.5,1,10); const cone=new THREE.ConeGeometry(.5,1,10);
  const materials=new Map();
  function mat(c){if(!materials.has(c))materials.set(c,new THREE.MeshStandardMaterial({color:lin(c),roughness:.78}));return materials.get(c);}
  function part(g,geo,c,x,y,z,w,h,d){const o=new THREE.Mesh(geo,mat(c));o.position.set(x,y,z);o.scale.set(w,h,d);g.add(o);return o;}
  const r=mulberry(4949), pick=a=>a[Math.floor(r()*a.length)];
  let solids=[],solidCount=-1;
  function refreshSolids(){if(solidCount!==World.colliders.length){solidCount=World.colliders.length;solids=World.colliders.filter(c=>!c.car&&c.x1-c.x0>5&&c.z1-c.z0>5);}}
  function streetZ(z){return clamp((Math.round(z/P-.5)+.5)*P,(-NOUT+.5)*P,(NOUT-.5)*P);}
  SC.vehicleClear=function(c,x,z){const half=(c.len||4.6)/2+.25,w=(c.width||2.6)/2+.15;return !solids.some(b=>x+half>b.x0&&x-half<b.x1&&z+w>b.z0&&z-w<b.z1);};
  function prepareCars(){
    refreshSolids();
    for(const c of Life.cars){
      if(c._islandRoute)continue;
      const type=c.g.userData.vehicle, def=CAR_TYPES[type];
      c.len=c.len||(def?def.L:c.bus?12:4.6);c.width=c.width||(def?def.W:2.6);
      c._street=streetZ(c.z-c.lane*1.3);c.z=c._street+c.lane*1.3;c.heading=c.lane>0?Math.PI/2:-Math.PI/2;
      c.x=clamp(c.x,-E+18,E-18);c._islandRoute=true;

      if(!SC.vehicleClear(c,c.x,c.z)||Life.cars.some(o=>o!==c&&o._islandRoute&&Math.abs(o.z-c.z)<.5&&Math.abs(o.x-c.x)<((o.len||5)+c.len)/2+2)){
        for(let x=-E+22;x<E-22;x+=c.len+3){if(SC.vehicleClear(c,x,c.z)&&!Life.cars.some(o=>o!==c&&o._islandRoute&&Math.abs(o.z-c.z)<.5&&Math.abs(o.x-x)<((o.len||5)+c.len)/2+2)){c.x=x;break;}}
      }
      c.g.position.set(c.x,H(c.x,c.z)+.02,c.z);c.g.rotation.y=c.heading;
    }
  }
  SC.advanceVehicle=function(c,dt){
    if(dev.pauseTraffic){c.speed=0;return;}
    const dir=c.lane>0?1:-1, end=E-13;
    if(c._turn){
      const turn=c._turn;const next=Math.min(Math.PI,turn.a+Math.min(c.speed||2,2)*dt/1.3);
      const nx=turn.x+turn.dir*1.3*Math.sin(next), nz=c._street+turn.dir*1.3*Math.cos(next);
      if(Life.cars.some(o=>o!==c&&!o.off&&Math.abs(o.x-nx)<((o.len||5)+c.len)/2+1&&Math.abs(o.z-nz)<1.8)){c.speed=0;return;}
      turn.a=next;c.x=nx;c.z=nz;c.heading=turn.dir*Math.PI/2+next;
      if(next===Math.PI){c.lane=-turn.dir;c.z=c._street+c.lane*1.3;c.heading=c.lane>0?Math.PI/2:-Math.PI/2;c._turn=null;c.speed=1;}
      return;
    }
    let nx=clamp(c.x+dir*c.speed*dt,-end,end);
    for(const other of Life.cars){if(other===c||other.off||Math.abs(other.z-c.z)>1.8)continue;
      const gap=((other.len||5)+c.len)/2+.6, distance=(other.x-c.x)*dir;
      if(distance>0&&(other.x-nx)*dir<gap){nx=c.x+dir*Math.max(0,distance-gap);c.speed=0;}
    }
    const front=nx+dir*((c.len||5)/2+.4),rear=c.x-dir*((c.len||5)/2+.4),w=(c.width||2.6)/2+.15;
    if(solids.some(b=>Math.max(front,rear)>b.x0&&Math.min(front,rear)<b.x1&&c.z+w>b.z0&&c.z-w<b.z1)){c.speed=0;return;}
    c.x=nx;
    if(Math.abs(nx)>=end-.01)c._turn={x:dir*end,dir,a:0};
  };

  function instanced(geo,color,items){const mesh=new THREE.InstancedMesh(geo,mat(color),items.length),o=new THREE.Object3D();items.forEach((p,k)=>{o.position.set(...p.slice(0,3));o.scale.set(...p.slice(3,6));o.rotation.set(p[8]||0,p[6]||0,p[7]||0);o.updateMatrix();mesh.setMatrixAt(k,o.matrix);});mesh.instanceMatrix.needsUpdate=true;mesh.frustumCulled=false;G.scene.add(mesh);return mesh;}
  function coast(){
    const walls=[],caps=[],rocks=[],posts=[],wallVerts=[];
    const verts=[],uv=[];
    for(let side=0;side<4;side++){
      const coords=(u,v)=>side===0?[u,v]:side===1?[v,u]:side===2?[u,-v]:[-v,u];
      const n=Math.ceil(E*2/4),step=E*2/n;
      for(let k=0;k<n;k++){
        const u=-E+(k+.5)*step,[x,z]=coords(u,E-0.5),height=H(x,z);
        walls.push([x,(height+SEA)/2,z,side%2?1:step+.08,height-SEA+1.7,side%2?step+.08:1]);
        const [x0,z0]=coords(u-step/2,E-.5),[x1,z1]=coords(u+step/2,E-.5),h0=H(x0,z0),h1=H(x1,z1),slope=Math.atan2(h1-h0,step),length=Math.hypot(step,h1-h0)+.03;
        caps.push([x,(h0+h1)/2+1,z,side%2?1.3:length,.18,side%2?length:1.3,0,side%2?0:slope,side%2?-slope:0]);
        for(const offset of [-.5,.5]){
          const [ax,az]=coords(u-step/2,E-.5+offset),[bx,bz]=coords(u+step/2,E-.5+offset);
          wallVerts.push(ax,SEA-3,az,bx,h1+.94,bz,bx,SEA-3,bz,ax,SEA-3,az,ax,h0+.94,az,bx,h1+.94,bz);
        }
        const [rx,rz]=coords(u,E+2+r()*3);rocks.push([rx,SEA+.4,rz,2+r()*3,1.4+r()*1.3,2+r()*3,r()*3]);
        if(k%6===0)posts.push([x,height+1.15,z,.3,1.7,.3]);
        const a=coords(u-step/2,E-7),b=coords(u+step/2,E-7),c=coords(u+step/2,E),d=coords(u-step/2,E);
        for(const q of [a,c,b,a,d,c]){verts.push(q[0],H(q[0],q[1])+.045,q[1]);uv.push(q[0]/4,q[1]/4);}
      }
    }
    const wallGeo=new THREE.BufferGeometry();wallGeo.setAttribute('position',new THREE.Float32BufferAttribute(wallVerts,3));wallGeo.computeVertexNormals();const wallMat=mat('#827e73').clone();wallMat.side=THREE.DoubleSide;G.scene.add(new THREE.Mesh(wallGeo,wallMat));instanced(box,'#d6ccb6',caps);instanced(sphere,'#525f61',rocks);instanced(cyl,'#303d43',posts);
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.computeVertexNormals();const pm=mat('#b7a78b').clone();pm.side=THREE.DoubleSide;G.scene.add(new THREE.Mesh(geo,pm));

    const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d');ctx.fillStyle='#657f90';ctx.fillRect(0,0,128,128);
    for(let k=0;k<70;k++){ctx.strokeStyle=k%2?'#91aaba':'#45687d';ctx.globalAlpha=.35;ctx.beginPath();const y=r()*128;ctx.moveTo(0,y);ctx.bezierCurveTo(30,y-5,70,y+5,128,y);ctx.stroke();}
    const tex=new THREE.CanvasTexture(canvas);tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(500,500);World.water.material.map=tex;World.water.material.roughness=.32;World.water.material.needsUpdate=true;I.waveTexture=tex;
  }
  function boat(side,sail){const g=new THREE.Group();g.name=sail?'Coastal sailboat':'Fishing boat';
    const hull=part(g,sphere,sail?'#efe5ce':'#375c72',0,.35,0,3.5,1.5,8);hull.scale.z=sail?9:8;
    part(g,box,'#a37c4f',0,.85,0,2.7,.15,6);
    if(sail){part(g,cyl,'#ded8c9',0,5,0,.13,9,.13);const geom=new THREE.BufferGeometry();geom.setAttribute('position',new THREE.Float32BufferAttribute([.12,1,0,.12,9,0,3.4,1,0],3));geom.computeVertexNormals();const m=mat('#fff2d3').clone();m.side=THREE.DoubleSide;g.add(new THREE.Mesh(geom,m));}
    else{part(g,box,'#e8e1cf',0,1.8,-.8,2.1,1.7,2.4);part(g,box,'#263c49',0,2,-2.03,1.7,.65,.03);part(g,cyl,'#bd6937',0,3.3,-.6,.15,2,.15);}
    const wake=part(g,sphere,'#adc8c7',0,0,-6,3,.045,6);wake.material=mat('#adc8c7').clone();wake.material.transparent=true;wake.material.opacity=.38;
    G.scene.add(g);I.boats.push({g,side,phase:r()*6.28,speed:.008+r()*.004});
  }
  function fish(side,k){const g=new THREE.Group();part(g,sphere,'#82b7bd',0,0,0,.16,.24,.65);const tail=part(g,box,'#4c8e9a',0,0,-.32,.03,.25,.18);tail.rotation.x=.6;const u=(r()-.5)*E*1.5,v=E+8+r()*12;g.position.set(side%2?v:u,SEA,side%2?u:v);if(side>1){if(side%2)g.position.x*=-1;else g.position.z*=-1;}g.rotation.y=r()*6.28;G.scene.add(g);I.fish.push({g,x:g.position.x,z:g.position.z,phase:k*2.7,period:22+r()*19});}

  let alienAssigned=false;
  SC.drawAccessories=function(p,index,head,torso,left,right,dist){
    if(!p.look||p.pool||p.role||p.performer)return;
    if(p._islandAccessory===undefined){
      const rng=mulberry((World.seed^((index+1)*2654435761))>>>0),chance=rng();
      let kind=chance<.008?'samurai':chance<.02?'cowboy':chance<.03?'sailor':chance<.04?'wizard':chance<.055?'explorer':chance<.066?'lumberjack':chance<.073?'scuba':chance<.078?'astronaut':chance<.084?'knight':chance<.091?'pirate':chance<.095?'beekeeper':chance<.1?'mime':chance<.104?'mascot':chance<.109?'ninja':chance<.114?'chef':null;
      if(!alienAssigned&&chance>.9996){kind='alien';alienAssigned=true;}
      if(!kind&&chance<.27)kind=['headphones','scarf','satchel','camera','flowers'][Math.floor(rng()*5)];
      if(!kind){p._islandAccessory=null;return;}
      if(['samurai','cowboy','sailor','explorer','wizard','alien','lumberjack','scuba','astronaut','knight','pirate','beekeeper','mime','mascot','ninja','chef'].includes(kind))p.look.hat=null;
      if(kind==='alien')p.look.hair=null;
      const root=new THREE.Group(),headG=new THREE.Group(),bodyG=new THREE.Group(),handG=new THREE.Group();for(const g of [headG,bodyG,handG]){g.matrixAutoUpdate=false;root.add(g);}root.name='Accessory: '+kind;root.userData.theme=kind;G.scene.add(root);
      const color=['#8d4537','#376670','#c5a35d','#735789'][Math.floor(rng()*4)];
      if(kind==='cowboy'){part(headG,cyl,'#997347',0,.14,0,.64,.05,.48);part(headG,cyl,'#997347',0,.25,-.02,.32,.2,.29);part(bodyG,box,'#ae4732',0,.3,.14,.19,.13,.05);}
      if(kind==='samurai'){part(headG,sphere,'#30343c',0,.12,-.01,.42,.26,.4);for(const s of [-1,1]){const horn=part(headG,cyl,'#d8b655',s*.17,.28,0,.035,.25,.035);horn.rotation.z=-s*.55;part(bodyG,box,'#653a37',s*.25,.18,0,.23,.13,.36);}for(let j=0;j<3;j++)part(bodyG,box,'#653a37',0,.2-j*.12,.16,.41,.09,.06);const sheath=part(bodyG,box,'#353039',-.24,-.2,-.16,.06,.9,.07);sheath.rotation.z=-.45;}
      if(kind==='alien'){part(headG,sphere,'#82a28c',0,.045,.02,.4,.44,.36);for(const s of [-1,1]){const eye=part(headG,sphere,'#111d22',s*.1,.06,.18,.12,.17,.035);eye.rotation.z=s*.3;}part(bodyG,box,'#8a9eab',0,.15,.12,.35,.4,.06);}
      if(kind==='wizard'){const hat=new THREE.Mesh(new THREE.ConeGeometry(.25,.6,10),mat('#635781'));hat.position.y=.36;headG.add(hat);part(headG,cyl,'#635781',0,.09,0,.6,.04,.5);part(handG,cyl,'#785b40',0,-.3,0,.04,1.2,.04);part(handG,sphere,'#9bc9d2',0,.32,0,.15,.15,.15);}
      if(kind==='sailor'||kind==='explorer'){part(headG,cyl,kind==='sailor'?'#eee9dc':'#b49863',0,.18,0,.4,.14,.36);part(headG,cyl,kind==='sailor'?'#364c63':'#b49863',0,.11,0,.52,.025,.44);}
      if(kind==='headphones'){for(const s of [-1,1])part(headG,sphere,color,s*.2,0,0,.1,.2,.15);part(headG,box,color,0,.19,0,.42,.045,.08);}
      if(kind==='scarf'){part(bodyG,box,color,0,.35,.05,.31,.1,.25);part(bodyG,box,color,.1,.1,.18,.13,.4,.035);}
      if(kind==='satchel'||kind==='explorer'){part(bodyG,box,color,-.25,-.15,0,.19,.28,.24);const strap=part(bodyG,box,'#58473b',0,.13,.155,.035,.62,.025);strap.rotation.z=-.5;}
      if(kind==='camera'){part(bodyG,box,'#303638',0,.06,.21,.2,.12,.09);const lens=part(bodyG,cyl,'#1b2024',0,.06,.29,.08,.09,.08);lens.rotation.x=Math.PI/2;}
      if(kind==='flowers'){for(let j=0;j<5;j++){part(handG,cyl,'#587451',(j-2)*.035,.04,0,.012,.35,.012);part(handG,sphere,['#e3ac71','#bb6075','#e9dacc'][j%3],(j-2)*.045,.22+r()*.04,0,.09,.09,.09);}}

      if(kind==='lumberjack'){part(headG,sphere,'#c0362c',0,.13,-.01,.43,.26,.41);part(bodyG,box,'#b3312b',0,.12,0,.46,.5,.3);for(let j=0;j<3;j++)part(bodyG,box,'#1a1a1a',0,.3-j*.18,.155,.47,.04,.01);for(let j=0;j<3;j++)part(bodyG,box,'#1a1a1a',-.16+j*.16,.12,.155,.04,.5,.01);part(handG,cyl,'#7a5a3a',0,-.1,0,.05,.9,.05);part(handG,box,'#b8bcc0',.08,.33,0,.2,.14,.03);}
      if(kind==='scuba'){part(headG,box,'#1b2430',0,.03,.19,.34,.14,.06);part(headG,box,'#e8b82e',0,.03,0,.44,.05,.42);const sn=part(headG,cyl,'#e8b82e',.19,.2,.12,.035,.36,.035);part(bodyG,box,'#15171a',0,.12,0,.46,.55,.3);for(const s of [-1,1])part(bodyG,cyl,'#e8b82e',s*.08,.18,-.24,.14,.5,.14);part(handG,box,'#1a1a1a',0,-.12,.08,.14,.06,.32);}
      if(kind==='astronaut'){const h=part(headG,sphere,'#f2f2ee',0,.05,0,.56,.56,.56);part(headG,sphere,'#1b2430',0,.06,.16,.4,.3,.24);part(bodyG,box,'#f2f2ee',0,.12,0,.5,.58,.34);part(bodyG,box,'#e9e6de',0,.2,-.25,.42,.5,.18);part(bodyG,box,'#2f7fc1',-.1,.3,.175,.1,.06,.01);part(bodyG,box,'#c0362c',.1,.3,.175,.1,.06,.01);}
      if(kind==='knight'){part(headG,cyl,'#9aa0a6',0,.07,0,.46,.42,.46);part(headG,box,'#1a1a1a',0,.08,.23,.26,.035,.01);part(headG,cone,'#c0362c',0,.36,-.05,.06,.2,.06);part(bodyG,box,'#b8bcc0',0,.12,0,.5,.56,.34);part(handG,box,'#d9dde0',0,.35,0,.05,1.0,.02);part(handG,box,'#8a6a2a',0,-.15,0,.26,.05,.05);}
      if(kind==='pirate'){part(headG,cyl,'#1a1a1a',0,.2,0,.52,.14,.46);for(const s of [-1,1]){const w=part(headG,box,'#1a1a1a',s*.2,.24,0,.06,.16,.34);w.rotation.z=s*.5;}part(headG,box,'#1a1a1a',.09,.05,.2,.1,.08,.02);part(bodyG,box,'#7a1f1f',0,.12,.02,.47,.52,.3);part(bodyG,sphere,'#3aa06b',.24,.38,0,.12,.16,.12);part(bodyG,sphere,'#c0362c',.24,.47,.03,.08,.08,.08);part(handG,box,'#b8bcc0',0,.25,0,.04,.6,.02);}
      if(kind==='beekeeper'){part(headG,cyl,'#f2efe6',0,.2,0,.62,.04,.62);part(headG,cyl,'#e8e4da',0,.05,0,.5,.34,.5);part(bodyG,box,'#f2efe6',0,.12,0,.5,.56,.32);part(handG,box,'#e8b82e',0,-.05,0,.2,.14,.16);}
      if(kind==='mime'){part(headG,sphere,'#1a1a1a',0,.17,-.02,.4,.12,.4);part(bodyG,box,'#f2efe6',0,.12,0,.46,.52,.3);for(let j=0;j<4;j++)part(bodyG,box,'#1a1a1a',0,.34-j*.13,.155,.47,.045,.01);}
      if(kind==='mascot'){part(headG,sphere,'#8a5a36',0,.1,0,.82,.78,.78);for(const s of [-1,1])part(headG,sphere,'#8a5a36',s*.3,.45,0,.22,.22,.12);part(headG,sphere,'#e8d2a0',0,.02,.34,.3,.22,.14);part(headG,sphere,'#111',0,.06,.42,.08,.06,.05);part(bodyG,box,'#8a5a36',0,.1,0,.62,.66,.46);}
      if(kind==='ninja'){part(headG,sphere,'#15171a',0,.06,0,.46,.5,.46);part(headG,box,'#e9d0b0',0,.08,.22,.24,.06,.02);part(bodyG,box,'#15171a',0,.12,0,.47,.56,.32);part(handG,box,'#b8bcc0',0,.35,0,.03,.8,.02);}
      if(kind==='chef'){part(headG,cyl,'#f7f7f4',0,.28,0,.38,.34,.38);part(headG,sphere,'#f7f7f4',0,.47,0,.44,.18,.44);part(bodyG,box,'#f7f7f4',0,.12,0,.47,.54,.31);part(handG,cyl,'#b8bcc0',0,.02,.1,.3,.03,.3);}
      const entry={root,headG,bodyG,handG,kind,p};p._islandAccessory=entry;I.accessories.push(entry);
    }
    const a=p._islandAccessory;if(!a)return;a.root.visible=!p.hidden&&dist<65;a.headG.matrix.copy(head);a.bodyG.matrix.copy(torso);a.handG.matrix.copy(left);
  };

  let debugGroup=null,debugTimer=0;
  function clearDebug(){if(debugGroup){G.scene.remove(debugGroup);debugGroup.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material)o.material.dispose();});debugGroup=null;}}
  function debugTick(dt){
    let label=document.getElementById('scDevCoordinates');
    if(dev.coordinates){if(!label){label=document.createElement('div');label.id='scDevCoordinates';label.style.cssText='position:fixed;top:86px;left:14px;background:#101922e8;color:#bce8bf;padding:9px;font:12px monospace;pointer-events:none;z-index:80';document.body.appendChild(label);}label.textContent=`x ${Player.x.toFixed(1)} · z ${Player.z.toFixed(1)} · island ±${E.toFixed(0)} m`;}
    else if(label)label.remove();
    if(!dev.colliders){clearDebug();return;}
    debugTimer-=dt;if(debugTimer>0)return;debugTimer=.5;clearDebug();debugGroup=new THREE.Group();debugGroup.name='Develop collision bounds';
    for(const c of World.colliders){const x=(c.x0+c.x1)/2,z=(c.z0+c.z1)/2;if(Math.hypot(x-Player.x,z-Player.z)>55)continue;const bb=new THREE.Box3(new THREE.Vector3(c.x0,H(x,z),c.z0),new THREE.Vector3(c.x1,H(x,z)+3,c.z1));debugGroup.add(new THREE.Box3Helper(bb,0x4fffa0));}G.scene.add(debugGroup);
  }
  document.addEventListener('click',e=>{const b=e.target.closest('[data-seg="performanceOverlay"] button');if(b){SC.debugEnabled=b.dataset.v==='on';if(!SC.debugEnabled)document.getElementById('csGraphicsPerf')?.classList.remove('on');}},true);
  const menuBase=renderMenu;
  window.renderMenu=function(){const result=menuBase.apply(this,arguments);if(UI.menuTab!=='settings')return result;
    const body=document.getElementById('menubody');let section=[...body.querySelectorAll('details')].find(d=>d.querySelector('summary')?.textContent.startsWith('Develop'));
    if(!section){section=document.createElement('details');section.className='sc-settings-section';section.innerHTML='<summary>Develop</summary>';body.appendChild(section);}
    section.querySelector('summary').innerHTML='Develop <small>4</small>';
    section.querySelectorAll('[data-scdev-row]').forEach(el=>el.remove());
    const overlay=section.querySelector('[data-seg="performanceOverlay"]');if(overlay)overlay.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v===(SC.debugEnabled?'on':'off'))));
    for(const [key,title,help] of [['colliders','Collision bounds','Show nearby collision boxes.'],['coordinates','World coordinates','Show your position and the coastline distance.'],['pauseTraffic','Pause road traffic','Hold vehicles in place to inspect clearance.']]){const row=document.createElement('div');row.className='formrow';row.dataset.scdevRow=key;row.innerHTML=`<label>${title}</label><div class="seg"><button data-v="off">Off</button><button data-v="on">On</button></div><span class="spec">${help} Session only; starts off.</span>`;for(const b of row.querySelectorAll('button')){b.setAttribute('aria-pressed',String(dev[key]===(b.dataset.v==='on')));b.onclick=()=>{dev[key]=b.dataset.v==='on';row.querySelectorAll('button').forEach(x=>x.setAttribute('aria-pressed',String(dev[key]===(x.dataset.v==='on'))));debugTimer=0;if(!dev.colliders)clearDebug();};}section.appendChild(row);}
    return result;
  };
  const bootBase=boot;window.boot=async function(){await bootBase.apply(this,arguments);S.custom.performanceOverlay='off';SC.debugEnabled=false;};
  const lifeBase=updateLife;window.updateLife=function(dt,pl){prepareCars();for(const a of I.accessories)a.root.visible=false;return lifeBase.apply(this,arguments);};
  function build(){if(I.built||!G.scene||!World.water)return;I.built=true;coast();for(let s=0;s<4;s++){boat(s,s%2===0);for(let j=0;j<3;j++)fish(s,s*3+j);}World.landmarks=[];}
  const gameBase=gameplayUpdate;window.gameplayUpdate=function(dt){const result=gameBase.apply(this,arguments);build();I.time+=dt;const t=I.time;
    if(I.waveTexture){I.waveTexture.offset.x=t*.004;I.waveTexture.offset.y=t*.0015;}
    for(const b of I.boats){const u=Math.sin(t*b.speed+b.phase)*E*.8,v=E+55+(b.side%2)*35,dir=Math.cos(t*b.speed+b.phase)>0?1:-1;let x=u,z=v;if(b.side%2){x=v;z=u;}if(b.side>1){if(b.side%2)x=-x;else z=-z;}b.g.position.set(x,SEA+.12+Math.sin(t*1.2+b.phase)*.12,z);b.g.rotation.set(Math.sin(t*.8+b.phase)*.035,b.side%2?(dir>0?0:Math.PI):(dir>0?Math.PI/2:-Math.PI/2),Math.sin(t+b.phase)*.03);}
    for(const f of I.fish){const cycle=(t+f.phase)%f.period,jump=cycle<1.3;f.g.visible=jump;if(jump){const u=cycle/1.3;f.g.position.set(f.x+u*1.8,SEA+Math.sin(u*Math.PI)*1.9,f.z);f.g.rotation.z=(.5-u)*2;}}
    debugTick(dt);return result;
  };
})();

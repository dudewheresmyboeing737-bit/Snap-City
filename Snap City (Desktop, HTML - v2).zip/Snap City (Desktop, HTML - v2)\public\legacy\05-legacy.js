const REFL_LAYER = 7;
const Refl = {
  rt:null, cam:new THREE.PerspectiveCamera(), mat:new THREE.Matrix4(), mats:[], layer:REFL_LAYER,
  _p:new THREE.Vector3(), _fwd:new THREE.Vector3(), _up:new THREE.Vector3(), _tgt:new THREE.Vector3(), _n:new THREE.Vector3(0,1,0),
  _plane:new THREE.Plane(), _cp:new THREE.Vector4(), _q:new THREE.Vector4(), uniforms:{ tRefl:{value:null}, reflMat:{value:new THREE.Matrix4()}, reflOn:{value:0} },
  setup(){
    this.rt = new THREE.WebGLRenderTarget(640, 360, { type: G.halfFloat ? THREE.HalfFloatType : THREE.UnsignedByteType, minFilter:THREE.LinearFilter, magFilter:THREE.LinearFilter });
    this.uniforms.tRefl.value = this.rt.texture;
    for (const [mat, amt] of [[World.mats.road, 1.0], [World.mats.walk, 0.45]]){
      mat.onBeforeCompile = (sh) => {
        sh.uniforms.tRefl = this.uniforms.tRefl; sh.uniforms.reflMat = this.uniforms.reflMat; sh.uniforms.reflOn = this.uniforms.reflOn;
        sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nuniform mat4 reflMat; varying vec4 vRefl;").replace("#include <fog_vertex>", "#include <fog_vertex>\nvRefl = reflMat * modelMatrix * vec4(transformed, 1.0);");
        sh.fragmentShader = sh.fragmentShader.replace("#include <common>", "#include <common>\nuniform sampler2D tRefl; uniform float reflOn; varying vec4 vRefl;").replace("#include <tonemapping_fragment>", `
          if (reflOn > 0.5){
            vec2 ruv = vRefl.xy / vRefl.w; float gloss = clamp(1.0 - roughnessFactor*2.2, 0.0, 1.0);
            vec2 j = vec2(0.0, 0.004 + 0.02*(1.0-gloss));
            vec3 rc = (texture2D(tRefl, ruv).rgb*2.0 + texture2D(tRefl, ruv + j).rgb + texture2D(tRefl, ruv - j).rgb + texture2D(tRefl, ruv + j*2.0).rgb)/5.0;
            float fres = 0.08 + 0.92*pow(1.0 - clamp(dot(normalize(vViewPosition), normal), 0.0, 1.0), 4.0);
            gl_FragColor.rgb += rc * fres * (0.25 + 0.75*gloss) * ${amt.toFixed(2)};
          }
          #include <tonemapping_fragment>`);
      };
      mat.needsUpdate = true;
    }
  },
  render(src){
    const on = !!S.rain; this.uniforms.reflOn.value = on ? 1 : 0; if (!on) return;
    if (!this.rt) this.setup();
    const r = G.renderer, cam = this.cam;
    src.updateMatrixWorld(true);
    const y0 = H(Player.x, Player.z) + 0.02;
    const p = this._p.setFromMatrixPosition(src.matrixWorld), fwd = this._fwd.set(0,0,-1).transformDirection(src.matrixWorld), up = this._up.set(0,1,0).transformDirection(src.matrixWorld);
    cam.fov = src.fov; cam.aspect = src.aspect; cam.near = src.near; cam.far = src.far; cam.updateProjectionMatrix();
    cam.position.set(p.x, 2*y0 - p.y, p.z);
    const tgt = this._tgt.copy(p).add(fwd); tgt.y = 2*y0 - tgt.y; cam.up.set(up.x, -up.y, up.z); cam.lookAt(tgt); cam.updateMatrixWorld(true);
    if ((S.custom && S.custom.reflections === "high") || src !== G.cam) cam.layers.enableAll(); else cam.layers.set(REFL_LAYER);

    const plane = this._plane.set(this._n.set(0,1,0), -y0).applyMatrix4(cam.matrixWorldInverse);
    const cp = this._cp.set(plane.normal.x, plane.normal.y, plane.normal.z, plane.constant), pm = cam.projectionMatrix, q = this._q.set(0,0,0,0);
    q.x = (Math.sign(cp.x) + pm.elements[8]) / pm.elements[0]; q.y = (Math.sign(cp.y) + pm.elements[9]) / pm.elements[5]; q.z = -1.0; q.w = (1.0 + pm.elements[10]) / pm.elements[14];
    cp.multiplyScalar(2.0 / cp.dot(q)); pm.elements[2] = cp.x; pm.elements[6] = cp.y; pm.elements[10] = cp.z + 1.0; pm.elements[14] = cp.w;
    this.uniforms.reflMat.value.set(0.5,0,0,0.5, 0,0.5,0,0.5, 0,0,0.5,0.5, 0,0,0,1).multiply(pm).multiply(cam.matrixWorldInverse);
    const hv = heldCam ? heldCam.visible : false; if (heldCam) heldCam.visible = false; const rv = Rain.mesh.visible; Rain.mesh.visible = false;
    const sau = r.shadowMap.autoUpdate; r.shadowMap.autoUpdate = false;
    this.uniforms.reflOn.value = 0; this.uniforms.tRefl.value = this.dummy || (this.dummy = new THREE.DataTexture(new Uint8Array(4), 1, 1));
    const prev = r.getRenderTarget(), ac = r.autoClear; r.autoClear = true;
    r.setRenderTarget(this.rt); r.render(World.scene, cam); r.setRenderTarget(prev); r.autoClear = ac;
    r.shadowMap.autoUpdate = sau; this.uniforms.reflOn.value = 1; this.uniforms.tRefl.value = this.rt.texture; if (heldCam) heldCam.visible = hv; Rain.mesh.visible = rv;
  }
};

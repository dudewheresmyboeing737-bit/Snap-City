function scatterCity(h){
  const { box, rnd, R, RP } = h, col = c => lin(c);
  const B = (x,y,z,sx,sy,sz,c,ry=0,key="plain") => box(key, x, y, z, sx, sy, sz, col(c), ry);
  const C = (x,y,z,r,hh,c) => pushGeom("plain", PRIM.cyl, M(x, y, z, 0, r, hh, r), col(c));
  const Sp = (x,y,z,r,c,sy=1) => pushGeom("plain", PRIM.sph0, M(x, y, z, 0, r*2, r*2*sy, r*2), col(c));
  const pick = a => a[(rnd()*a.length)|0];
  const brands = ["#c0362c","#2f7fc1","#e8b82e","#3aa06b","#f2efe6","#26231f","#e36f2d","#8a3fb5"];

  const K = [
    ["gutter",3,(x,y,z,r)=>{ for (let k=0;k<6;k++) B(x+R(-.4,.4),y+.01,z+R(-.4,.4),R(.05,.1),.01,R(.04,.08),pick(["#8a5a2a","#a8741c","#6b4a2e","#c98e5a"]),R(0,3)); }],
    ["gutter",2,(x,y,z)=>C(x,y+.04,z,.033,.12,pick(brands))], ["gutter",1,(x,y,z,r)=>{ B(x,y+.035,z,.07,.07,.24,pick(["#3a5a2a","#6b3f14","#d8d2c0"]),r); }],
    ["gutter",2,(x,y,z)=>C(x,y+.05,z,.04,.1,pick(["#f2efe6","#e9d9b0","#b35a3a"]))], ["gutter",1,(x,y,z,r)=>B(x,y+.01,z,.3,.01,.22,"#e9e6de",r)],
    ["gutter",1,(x,y,z,r)=>B(x,y+.03,z,.4,.05,.4,"#c9a26a",r)], ["gutter",1,(x,y,z,r)=>B(x,y+.02,z,.18,.04,.12,"#f2efe6",r)],
    ["gutter",2,(x,y,z)=>{ for (let k=0;k<5;k++) B(x+R(-.2,.2),y+.005,z+R(-.2,.2),.03,.01,.008,"#e9e6de"); }], ["gutter",1,(x,y,z,r)=>B(x,y+.01,z,.12,.01,.08,pick(brands),r)],
    ["gutter",1,(x,y,z,r)=>B(x,y+.02,z,.25,.02,.18,"#dfe3e6",r)], ["gutter",1,(x,y,z,r)=>{ B(x,y+.015,z,.2,.03,.05,"#f2d02b",r); }], ["gutter",1,(x,y,z)=>Sp(x,y+.03,z,.03,"#c9a26a")],
    ["gutter",1,(x,y,z,r)=>{ B(x,y+.02,z,.6,.02,.05,"#26231f",r); B(x,y+.08,z,.02,.1,.4,"#1a1a1a",r+1); }], ["gutter",1,(x,y,z,r)=>B(x,y+.005,z,.12,.005,.08,"#9ad0e8",r)],
    ["walk",2,(x,y,z)=>{ Sp(x,y+.02,z,.035,"#4a3020",.7); Sp(x+.03,y+.04,z,.028,"#523522",.7); Sp(x+.01,y+.06,z,.02,"#4a3020",.8); }],
    ["walk",2,(x,y,z)=>{ for (let k=0;k<6;k++) B(x+R(-.8,.8),y+.002,z+R(-.8,.8),.03,.003,.03,"#3a3a38"); }],
    ["walk",1,(x,y,z,r)=>{ for (let k=0;k<6;k++) B(x+Math.sin(r)*k*.5,y+.003,z+Math.cos(r)*k*.5,.45,.004,.45,pick(["#f28cb1","#5cc4ff","#ffd24a","#7cff6a"]),r); }],
    ["walk",1,(x,y,z)=>{ for (let k=0;k<3;k++) B(x+R(-.3,.3),y+.004,z+R(-.3,.3),.06,.004,.2,"#f2efe6",R(0,3)); }],
    ["walk",1,(x,y,z,r)=>{ B(x,y+.35,z,.05,.7,.05,"#1a1a1a",r); B(x,y+.35,z+.4,.05,.7,.05,"#1a1a1a",r); B(x,y+.72,z+.2,.05,.05,.45,"#1a1a1a",r); }],
    ["curb",2,(x,y,z,r)=>{ C(x,y+.3,z,.14,.6,pick(["#e8b82e","#c0362c","#f2efe6"])); Sp(x,y+.62,z,.12,"#c0362c"); B(x,y+.4,z,.34,.08,.08,"#c9c9c4",r); }],
    ["curb",2,(x,y,z)=>{ C(x,y+.6,z,.03,1.2,"#6b6f73"); B(x,y+1.25,z,.16,.3,.12,"#8e9396"); }],
    ["curb",1,(x,y,z,r)=>{ C(x,y+1.4,z,.035,2.8,"#8e9396"); B(x,y+2.8,z,.9,.2,.03,"#2f6b3a",r); B(x,y+2.5,z,.4,.5,.02,pick(["#f2efe6","#c0362c"]),r); }],
    ["curb",1,(x,y,z,r)=>{ B(x,y+.55,z,.5,1.1,.4,"#1e3a8a",r); B(x,y+1.12,z,.52,.1,.42,"#23408f",r); }],
    ["curb",2,(x,y,z,r)=>{ C(x,y+.45,z,.28,.9,pick(["#2d4a3c","#26282c","#3a3f46"])); C(x,y+.92,z,.3,.05,"#1a1a1a"); }],
    ["curb",1,(x,y,z,r)=>{ B(x,y+.5,z,.5,1.0,.55,"#2f7fc1",r); B(x+.6*Math.cos(r),y+.5,z-.6*Math.sin(r),.5,1.0,.55,"#3aa06b",r); B(x+1.2*Math.cos(r),y+.5,z-1.2*Math.sin(r),.5,1.0,.55,"#26282c",r); }],
    ["curb",1,(x,y,z,r)=>{ B(x,y+.5,z,.45,.9,.45,pick(["#c0362c","#2f7fc1","#e8b82e","#26231f"]),r); B(x,y+.75,z,.36,.3,.02,"#cfe0f0",r); }],
    ["curb",2,(x,y,z)=>{ for (let k=0;k<(1+rnd()*3|0);k++) { C(x+k*.5,y+.28,z,.12,.56,"#ff6a1c"); B(x+k*.5,y+.02,z,.34,.04,.34,"#1a1a1a"); } }],
    ["curb",1,(x,y,z,r)=>{ B(x,y+.5,z,1.6,.25,.05,"#ff6a1c",r); B(x,y+.5,z,1.6,.06,.06,"#f2efe6",r); B(x-.7*Math.cos(r),y+.25,z+.7*Math.sin(r),.05,.5,.4,"#1a1a1a",r); B(x+.7*Math.cos(r),y+.25,z-.7*Math.sin(r),.05,.5,.4,"#1a1a1a",r); }],
    ["curb",1,(x,y,z,r)=>{ B(x,y+.5,z,1.9,1.0,1.1,"#2d5a3c",r); B(x,y+1.02,z,1.9,.05,1.12,"#26231f",r); }],
    ["wall",2,(x,y,z,r)=>{ B(x,y+.5,z,1.9,1.0,.28,pick(["#e9e6de","#c9b28a","#b8c9d9"]),r); for (let k=0;k<4;k++) B(x+R(-.8,.8),y+R(.2,.9),z,.1,.1,.3,"#9aa4a8",r); }],
    ["wall",1,(x,y,z,r)=>{ B(x,y+.25,z,1.8,.5,.8,pick(["#6b4a2e","#7a2e36","#3f5e7a","#8a7a62"]),r); B(x,y+.55,z-.3*Math.cos(r),1.8,.5,.2,pick(["#6b4a2e","#7a2e36"]),r); }],
    ["wall",1,(x,y,z,r)=>{ B(x,y+.3,z,.6,.45,.45,"#26231f",r); B(x,y+.3,z+.23*Math.cos(r),.5,.36,.01,"#3a4a55",r); B(x,y+.62,z,.4,.18,.3,"#c9a26a",r); }],
    ["wall",2,(x,y,z,r)=>{ for (let k=0;k<(2+rnd()*3|0);k++) B(x+R(-.4,.4),y+.2+k*.34,z+R(-.2,.2),R(.4,.6),.32,R(.4,.5),"#c9a26a",r+R(-.2,.2)); }],
    ["wall",1,(x,y,z,r)=>{ B(x,y+.6,z,.6,1.2,.25,"#8a7a62",r); B(x,y+1.25,z,.4,.1,.26,"#1a1a1a",r); }],
    ["wall",2,(x,y,z,r)=>{ B(x,y+.25,z,1.1,.5,.35,"#6b4a2e",r); for (let k=0;k<6;k++) Sp(x+R(-.45,.45),y+.6,z+R(-.12,.12),.09,pick(["#e2405a","#f2c230","#f28cb1","#b98ee8","#3f6a2e"])); }],
    ["wall",1,(x,y,z,r)=>{ B(x,y+.45,z,.5,.9,.03,pick(["#1e2320","#f2efe6"]),r+.3); }],
    ["wall",1,(x,y,z,r)=>{ C(x,y+.36,z,.3,.03,"#c9c9c4"); C(x,y+.18,z,.03,.36,"#26231f"); for (const s of [-1,1]) B(x+s*.5,y+.23,z,.35,.03,.35,"#c9c9c4",r); }],
    ["wall",1,(x,y,z,r)=>{ B(x,y+.45,z,.7,.9,.45,"#b9bcc0",r); B(x,y+.9,z,.72,.04,.47,"#8e9396",r); for (let k=0;k<3;k++) B(x+R(-.25,.25),y+.95,z,.2,.18,.2,pick(brands),r); }],
    ["wall",1,(x,y,z,r)=>{ B(x,y+.15,z,.4,.3,.4,pick(["#c0362c","#2f7fc1","#26231f"]),r); }], ["wall",1,(x,y,z,r)=>B(x,y+.07,z,1.2,.14,.9,"#a8865a",r)],
    ["wall",1,(x,y,z,r)=>{ B(x,y+.02,z,1.4,.04,.08,"#1a1a1a",r); B(x,y+.35,z,.05,.7,.05,"#1a1a1a",r); C(x+.5,y+.12,z,.12,.02,"#1a1a1a"); C(x-.5,y+.12,z,.12,.02,"#1a1a1a"); }],
    ["wall",1,(x,y,z,r)=>{ for (const s of [-.5,.5]) pushGeom("plain", PRIM.cyl, M(x+s*Math.cos(r), y+.34, z-s*Math.sin(r), 0, .34, .03, .34), col("#1a1a1a")); B(x,y+.55,z,1.0,.04,.05,pick(brands),r); }],
  ];
  const tot = K.reduce((a,k)=>a+k[1],0), choose = where => { const L = K.filter(k=>k[0]===where); let t = L.reduce((a,k)=>a+k[1],0)*rnd(); for (const k of L){ if ((t -= k[1]) < 0) return k; } return L[0]; };
  World.camps = [];
  for (let bi=-NB; bi<=NB; bi++) for (let bj=-NB; bj<=NB; bj++){
    const cx = bi*P, cz = bj*P;
    for (let side=0; side<4; side++){
      const n = [[0,-1],[0,1],[-1,0],[1,0]][side], t = [n[1], -n[0]], ry = Math.atan2(n[0], n[1]);
      for (let a = -HALF + 3; a < HALF - 3; a += R(3, 7)){
        const at = (off) => [cx + n[0]*off + t[0]*a, cz + n[1]*off + t[1]*a];
        const u = rnd();
        if (u < 0.45){ const [x, z] = at(HALF + 3.85 + R(0, 0.3)); const k = choose("gutter"); k[2](x, H(x, z) + 0.01, z, R(0, 6.28)); }
        else if (u < 0.62){ const [x, z] = at(HALF + 3.4); const k = choose("curb"); k[2](x, groundY(x, z), z, ry); }
        else if (u < 0.78){ const [x, z] = at(HALF + 0.55); const k = choose("wall"); k[2](x, groundY(x, z), z, ry); }
        else if (u < 0.9){ const [x, z] = at(HALF + R(1.2, 3)); const k = choose("walk"); k[2](x, groundY(x, z), z, R(0, 6.28)); }
        else if (u < 0.915 && World.camps.length < 14){ const [x, z] = at(HALF + 0.7); const y = groundY(x, z);
          B(x, y + 0.03, z, 1.9, 0.06, 0.9, pick(["#3f5e7a","#6b4a2e","#2d4a3c","#7a2e36"]), ry); B(x + t[0]*1.3, y + 0.35, z + t[1]*1.3, 0.8, 0.7, 0.5, "#c9a26a", ry);
          B(x - t[0]*1.4, y + 0.45, z - t[1]*1.4, 0.7, 0.9, 0.45, "#b9bcc0", ry); B(x - t[0]*1.4, y + 0.95, z - t[1]*1.4, 0.72, 0.3, 0.47, pick(["#3a3a36","#4a4238"]), ry);
          World.camps.push({ x: x + n[0]*0.35, z: z + n[1]*0.35, ry, n }); }
      }
    }
  }
}
function spawnExtras(stay, rnd, R, RP){
  for (const c of (World.camps||[])) stay(c.x, c.z, Math.atan2(c.n[0], c.n[1]), "sitground", { role:"homeless", smoke: rnd() < 0.4, phoneSit: rnd() < 0.2 });
  for (const s of (World.stoops||[])){ if (rnd() > 0.28) continue; const q = stay(s.x, s.z, s.ry, "sit", { smoke: rnd() < 0.5, phoneSit: rnd() < 0.5 }); q.seatH = Math.max(0.3, s.y - groundY(s.x, s.z)); }
}

(function(){ const base = buildLife; buildLife = function(scene){ const r = base(scene);
  const colors = [["#e36f2d","#f2e6c9"], ["#2f6b3a","#f2e6c9"], ["#e8b82e","#26231f"], ["#1e4f8a","#f2e6c9"]];
  for (let k=0;k<8;k++){ const [c1, c2] = colors[k % colors.length], z = ((k % 6) - 3 + 0.5)*P, lane = k % 2 ? -1 : 1;
    const tm = CarMats.tailOff.clone(), g = buildCarGroup("bus", lin(c1), { twoTone: lin(c2) }, [Life.carLightMats[0], tm]);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 4.2, 6), new THREE.MeshStandardMaterial({ color:0x1a1a1a })); pole.position.set(0, 3.6, -2.5); pole.rotation.x = -1.1; g.add(pole);
    const band = new THREE.Mesh(new THREE.BoxGeometry(2.58, 0.3, 11.0), new THREE.MeshStandardMaterial({ color:lin(c2), roughness:0.5 })); band.position.y = 0.72; g.add(band);
    g.scale.set(1, 1.05, 1.05); scene.add(g);
    Life.cars.push({ type:"car", bus:true, trolley:true, tailMat:tm, g, lane, z: z + lane*1.3, x: R_(-200, 200), speed:0, vmax:6, taxi:false, heading: lane>0 ? Math.PI/2 : -Math.PI/2, stopT:0, lastStop:null }); }
  return r; }; })();
function R_(a, b){ return a + Math.random()*(b - a); }

const BINDABLE = [["KeyW","Walk forward"],["KeyS","Walk back"],["KeyA","Step left"],["KeyD","Step right"],["ShiftLeft","Run"],["KeyC","Crouch"],["KeyZ","Raise camera"],["Space","Shoot (raised) / jump (lowered)"],["Enter","Board, enter a shop, climb a roof"],["KeyR","Exposure mode"],["KeyT","Focus"],["KeyX","Hyperfocal"],["KeyF","Flash"],["KeyM","Multiple exposure"],["KeyJ","Wait / plant feet"],["KeyL","Reload film"],["KeyN","Next lens"],["KeyG","Grid"],["KeyQ","Tilt left"],["KeyE","Tilt right"],["KeyV","Arrow-key look"],["KeyH","Hide HUD"],["Tab","Camera bag"],["KeyP","Contact sheet"],["KeyB","Darkroom (last frame)"],["KeyI","Aperture −"],["KeyK","Aperture +"],["KeyU","Shutter −"],["KeyO","Shutter +"]];
function keyFor(code){ const b = (S && S.custom.binds) || {}; for (const d in b) if (b[d] === code) return d; if (b[code] && b[code] !== code) return null; return code; }
for (const type of ["keydown","keyup"]) addEventListener(type, ev => {
  if (!ev.isTrusted || !S) return;
  if (type === "keydown" && UI.bindWait){ ev.preventDefault(); ev.stopImmediatePropagation(); if (ev.code !== "Escape"){ S.custom.binds = S.custom.binds || {}; for (const d in S.custom.binds) if (S.custom.binds[d] === ev.code) delete S.custom.binds[d]; S.custom.binds[UI.bindWait] = ev.code; saveState(); } UI.bindWait = null; renderMenu(); return; }
  const m = keyFor(ev.code); if (m === ev.code) return;
  ev.preventDefault(); ev.stopImmediatePropagation(); if (m) dispatchEvent(new KeyboardEvent(type, { code:m, key:ev.key, repeat:ev.repeat, shiftKey:ev.shiftKey, bubbles:true }));
}, true);
(function(){ const base = menuKeys; menuKeys = function(){ const b = (S.custom.binds)||{};
  const rows = BINDABLE.map(([code, label]) => `<tr><td>${label}</td><td><button class="keycap${UI.bindWait===code?" listening":""}" data-bind="${code}">${UI.bindWait===code ? "press a key…" : (b[code] || code).replace(/^Key|^Digit/,"")}</button></td></tr>`).join("");
  return `<div class="sectionhead">Your controls</div><p class="note">Click a key, then press the new one. Escape cancels. Keys you move are freed from their old job.</p><table class="keys rebinding">${rows}</table><p><button class="btn small alt" data-bindreset>Reset all keys</button></p>` + base(); }; })();
addEventListener("click", ev => { const b = ev.target.closest && ev.target.closest("[data-bind]"); if (b){ ev.preventDefault(); UI.bindWait = b.dataset.bind; renderMenu(); return; } const r = ev.target.closest && ev.target.closest("[data-bindreset]"); if (r){ S.custom.binds = {}; saveState(); renderMenu(); } }, true);

(function(){ const base = buildHeldCam; buildHeldCam = function(){ base(); if (!heldCam || !heldCam.userData.dims) return;
  const { w, h, dep, lensX, t, look } = heldCam.userData.dims, g = heldCam, b = curBody();
  const M_ = (c, r=0.5, m=0.2, e) => { const x = new THREE.MeshStandardMaterial({ color:lin(c), roughness:r, metalness:m }); if (e){ x.emissive = lin(e); x.emissiveIntensity = 0.6; } return x; };
  const add = (geo, mat, x, y, z, rx=0, ry=0, rz=0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x,y,z); m.rotation.set(rx,ry,rz); m.renderOrder = 10; g.add(m); return m; };
  const chrome = M_("#cfd2d4", 0.25, 0.9), black = M_("#111", 0.6, 0.2), glass = M_("#0b1216", 0.05, 0.7), back = dep/2 + 0.002;
  const acc = look ? look[3] : "#9a9a9a";

  if (t === "SLR" || t === "Rangefinder" || t === "Panoramic"){
    add(new THREE.CylinderGeometry(0.009, 0.009, 0.006, 16), chrome, -w*0.38, h*0.5 + 0.004, 0.002);
    add(new THREE.BoxGeometry(0.032, 0.003, 0.008), chrome, w*0.3, h*0.5 + 0.008, 0.01, 0, 0.5, 0);
    add(new THREE.CylinderGeometry(0.004, 0.004, 0.002, 12), M_("#f2efe6", 0.4, 0, "#f2efe6"), w*0.39, h*0.5 + 0.002, 0.01);
    add(new THREE.BoxGeometry(w*0.4, 0.003, 0.012), M_(acc, 0.4, 0.4), 0, h*0.5 + 0.002, -dep*0.1);
    for (const s of [-1,1]) add(new THREE.CylinderGeometry(0.003, 0.003, 0.008, 8).rotateZ(Math.PI/2), chrome, s*(w/2 + 0.003), h*0.25, 0);
  }
  if (t === "SLR"){ add(new THREE.BoxGeometry(0.022, 0.012, 0.002), M_(acc, 0.4, 0.6), 0, h*0.66, -0.012); }
  if (t === "Rangefinder"){ add(new THREE.BoxGeometry(0.018, 0.012, 0.002), M_("#e9e6de", 0.3, 0.1), -w*0.1, h*0.36, -dep/2 - 0.001); }
  if (t === "Point & shoot" || t === "Toy"){ add(new THREE.CylinderGeometry(0.004, 0.004, 0.004, 12), M_(acc === "#c0362c" ? "#c0362c" : "#d8d2c4", 0.4, 0.3), w*0.32, h/2 + 0.002, 0); }
  if (t === "Medium format" && b.m === "V"){ add(new THREE.BoxGeometry(w*1.02, h*0.9, 0.04), black, 0, 0, back + 0.02); add(new THREE.BoxGeometry(w*0.9, 0.004, 0.03), chrome, 0, h*0.45, back + 0.02); add(new THREE.CylinderGeometry(0.012, 0.012, 0.01, 16).rotateZ(Math.PI/2), chrome, w/2 + 0.006, 0, back + 0.02); }
  if (t === "TLR"){ const hood = add(new THREE.BoxGeometry(w*0.9, 0.05, dep*0.9), M_("#1a1a1a", 0.8, 0.1), 0, h/2 + 0.025, 0); add(new THREE.CylinderGeometry(0.012, 0.012, 0.012, 16).rotateZ(Math.PI/2), chrome, w/2 + 0.007, 0, 0); }
  if (t === "Disposable"){ for (let k=0;k<3;k++) add(new THREE.BoxGeometry(w*1.005, 0.006, dep*1.005), M_(["#c0362c","#26231f","#2f7fc1"][k], 0.6, 0), 0, -h*0.3 + k*0.012, 0); add(new THREE.CylinderGeometry(0.01, 0.01, 0.006, 16), M_("#26231f"), w*0.35, h/2 + 0.003, back - 0.01); }
  if (t === "Instant"){ add(new THREE.BoxGeometry(0.1, 0.012, 0.16), M_("#6b4a2e", 0.9, 0), 0, -0.007, 0); }
}; })();

const V8EVENTS = { rescue:{ w:0.9, play:true, name:"the ladder rescue", bonus:20 }, heist:{ w:0.9, play:true, name:"the heist that went sideways", bonus:18 }, nuptials:{ w:0.8, play:true, name:"a wedding that did not go to plan", bonus:16 },
  freeze:{ w:0.7, play:true, name:"the moment the street froze", bonus:16 }, bubbles:{ w:0.8, play:true, name:"the bubble artist", bonus:12 }, yoga:{ w:0.6, play:true, name:"sidewalk yoga", bonus:10 }, preacher:{ w:0.7, play:true, name:"the street-corner prophet", bonus:10 } };
Object.assign(EVENTS, V8EVENTS); for (const k in V8EVENTS) BASE_W[k] = V8EVENTS[k].w;
EVENTS.fire.w = BASE_W.fire = 0.4; EVENTS.robbery.w = BASE_W.robbery = 0.35; EVENTS.wedding.w = BASE_W.wedding = 0.35;
const LINES = []; function hoseLine(a, b, sag){ const pts = []; for (let k=0;k<=8;k++){ const u = k/8; pts.push(new THREE.Vector3(lerp(a.x,b.x,u), lerp(a.y,b.y,u) - Math.sin(u*Math.PI)*sag, lerp(a.z,b.z,u))); } const g = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 16, 0.035, 6), new THREE.MeshStandardMaterial({ color:lin("#d8c9a3"), roughness:0.8 })); World.scene.add(g); LINES.push(g); return g; }
function startV8(type){
  const near = evSpot(28, 85); if (!near) return null;
  const st = streetFor(near), ax = near.along, o = near.out, E = { type, t:0, ppl:[], done:false, info:EVENTS[type], x:near.x, z:near.z, play:true, props:[] };
  const face = (p, x, z) => { p.heading = Math.atan2(x - p.x, z - p.z); }, pickv = a => a[(Math.random()*a.length)|0];
  const cleanup = () => { for (const m of E.props) World.scene.remove(m); };
  if (type === "rescue"){
    const crew = roleActors("fire", 3), vic = genActors(1)[0], crowd = genActors(5).slice(1); if (crew.length < 3 || !vic) return null; E.ppl = crew.concat([vic], crowd);
    const win = { x: near.x - o[0]*2.35 + ax[0]*rand(-5,5), z: near.z - o[1]*2.35 + ax[1]*rand(-5,5) }, winY = 3.4 + (1 + (Math.random()*2|0))*3.3;
    evPlace(vic, win.x - o[0]*0.3, win.z - o[1]*0.3, Math.atan2(o[0], o[1]), type); vic.evY = winY; vic.evPose = "cheer";
    crowd.forEach((p, k) => evPlace(p, near.x + o[0]*2.5 + ax[0]*(k*1.3 - 2), near.z + o[1]*2.5 + ax[1]*(k*1.3 - 2), 0, type));
    const eng = vehicle("engine"), dir = Math.random() < 0.5 ? 1 : -1, park = { x: st.x + ax[0]*2, z: st.z + ax[1]*2 }; eng.x = park.x - st.ax*dir*150; eng.z = park.z - st.az*dir*150;
    const hyd = { x: near.x + o[0]*3.4 + ax[0]*dir*9, z: near.z + o[1]*3.4 + ax[1]*dir*9 }; let ladder = null, hose = null; const dur = rand(150, 190), useHydrant = Math.random() < 0.7;
    E.step = (dt) => { const t = E.t, G_ = groundY(win.x, win.z);
      vic.heading = Math.atan2(o[0], o[1]); vic.evPose = t < 95 ? (Math.floor(t*2) % 2 ? "cheer" : "handsup") : vic.evPose;
      if (t < 60 && Math.random() < 0.5) Smoke.emit(win.x + rand(-0.5,0.5), G_ + winY + 1.6, win.z + rand(-0.5,0.5), o[0]*0.4, 0.9, o[1]*0.4, 0.8, 8, 0.35, SMOKE_DARK, 0.25, 0.9);
      crowd.forEach((p, k) => { face(p, win.x, win.z); p.headPitch = -0.45; p.evPose = t < 90 ? pickv(["point", null, "handsface"]) && (k % 3 === 0 ? "point" : k % 3 === 1 ? "handsface" : null) : t > 150 && t < 165 ? "clap" : null; });
      if (t > 10 && t < 45 && Math.floor(t/3.2) !== Math.floor((t-dt)/3.2)) SND.play("siren", eng.x, eng.z, 1.5);
      if (t > 15 && t < dur - 20){ vehDrive(eng, park.x, park.z, dt, 13); vehLights(eng, true, t); }
      if (t > 45 && t < dur - 22){
        const [c1, c2, c3] = crew; if (c1.hidden){ crew.forEach((p, k) => evPlace(p, eng.x + st.az*1.4*(k%2?1:-1), eng.z - st.ax*1.4*(k%2?1:-1), 0, type)); }
        if (useHydrant){ if (evWalk(c3, hyd.x, hyd.z, 2.2, dt)){ face(c3, eng.x, eng.z); c3.evPose = "hose"; if (!hose){ hose = hoseLine(new THREE.Vector3(hyd.x, groundY(hyd.x, hyd.z) + 0.5, hyd.z), new THREE.Vector3(eng.x, groundY(eng.x, eng.z) + 0.6, eng.z), 0.3); E.props.push(hose); const hy = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.6, 10), new THREE.MeshStandardMaterial({ color:lin("#e8b82e") })); hy.position.set(hyd.x, groundY(hyd.x, hyd.z) + 0.3, hyd.z); World.scene.add(hy); E.props.push(hy); } } }
        if (!ladder && t > 55){ ladder = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.08, 1), new THREE.MeshStandardMaterial({ color:lin("#c9c9c4"), metalness:0.8, roughness:0.3 })); World.scene.add(ladder); E.props.push(ladder); }
        if (ladder){ const base_ = new THREE.Vector3(eng.x, groundY(eng.x, eng.z) + 3.2, eng.z), top = new THREE.Vector3(win.x + o[0]*0.6, G_ + winY, win.z + o[1]*0.6), ext = clamp((t - 55)/12, 0, 1), tip = base_.clone().lerp(top, ext), mid = base_.clone().lerp(tip, 0.5), len = base_.distanceTo(tip);
          ladder.position.copy(mid); ladder.scale.set(1, 1, Math.max(0.1, len)); ladder.lookAt(tip);
          if (ext >= 1){ const up = clamp((t - 70)/14, 0, 1), down = clamp((t - 95)/16, 0, 1), u = up*(1 - down), pos = base_.clone().lerp(top, u);
            c1.x = pos.x; c1.z = pos.z; c1.evY = pos.y - groundY(pos.x, pos.z) - 0.4; c1.evPose = "radio"; face(c1, win.x, win.z);
            if (t > 84 && t < 95){ vic.evPose = "hug"; } if (t > 95){ vic.x = c1.x + o[0]*0.3; vic.z = c1.z + o[1]*0.3; vic.evY = Math.max(0, c1.evY + 0.2); vic.evPose = "hug"; }
            if (down >= 1){ c1.evY = 0; vic.evY = 0; vic.evPose = t < 125 ? "handsface" : null; if (t > 111 && t - dt <= 111) SND.play("applause", near.x, near.z, 1.4); } } }
        if (c2 && evWalk(c2, near.x + o[0]*1.2, near.z + o[1]*1.2, 2.4, dt)){ face(c2, win.x, win.z); c2.evPose = t < 100 ? "point" : "radio"; } }
      if (t > dur - 22){ crew.forEach(p => { p.evY = 0; if (!p.hidden && evWalk(p, eng.x, eng.z, 2.4, dt)) { p.hidden = true; p.busy = true; } }); if (ladder){ World.scene.remove(ladder); ladder = null; } }
      if (t > dur - 12){ vehDrive(eng, park.x + st.ax*dir*200, park.z + st.az*dir*200, dt, 9); vehLights(eng, false, t); }
      if (t > dur){ eng.g.visible = false; vic.evY = 0; cleanup(); E.done = true; } };
  }
  else if (type === "heist"){
    const robbers = roleActors("robber", 2), cops = roleActors("police", 2 + (Math.random()*3|0)), crowd = genActors(4); if (robbers.length < 2 || cops.length < 2) return null; E.ppl = robbers.concat(cops, crowd);
    const plot = pickv(["copsleave","bystander","moneyburst","dogchase","falsealarm","standoff"]), dir = Math.random() < 0.5 ? 1 : -1, door = { x: near.x - o[0]*1.9, z: near.z - o[1]*1.9 };
    const p1 = vehicle("police1"), park = { x: st.x - st.ax*dir*3, z: st.z - st.az*dir*3 }; p1.x = park.x - st.ax*dir*150; p1.z = park.z - st.az*dir*150;
    crowd.forEach((p, k) => evPlace(p, near.x + ax[0]*(k*2 - 3) + o[0]*1.2, near.z + ax[1]*(k*2 - 3) + o[1]*1.2, 0, type));
    const cash = [new THREE.Color(0.35, 0.6, 0.35), new THREE.Color(0.5, 0.75, 0.45)], dur = rand(120, 170), run = { x: near.x + ax[0]*dir*55, z: near.z + ax[1]*dir*55 };
    E.step = (dt) => { const t = E.t, [r1, r2] = robbers;
      if (plot !== "falsealarm" && t > 1 && t < 40){ robbers.forEach((p, k) => { if (p.hidden){ evPlace(p, door.x, door.z, 0, type); p.look.anim = "jog"; } p.evPose = "run"; }); }
      if (Math.floor(t/1.1) !== Math.floor((t-dt)/1.1) && t < 30) SND.play("bell", door.x, door.z, 0.7);
      if (plot === "moneyburst" && t > 6 && t < 10) for (let k=0;k<6;k++) Smoke.emit(r1.x, r1.y + 1.1, r1.z, rand(-1.5,1.5), rand(1,3), rand(-1.5,1.5), 0.07, 6, 0.95, cash[k%2], -1.4, 0);
      if (plot === "moneyburst" && t > 8 && t < 40){ crowd.forEach(p => { if (evWalk(p, r1.x + rand(-2,2), r1.z + rand(-2,2), 2.2, dt)) p.evPose = "duck"; }); }
      if (plot === "bystander" && t > 8 && t < 30){ const hero = crowd[0]; if (evWalk(hero, r2.x, r2.z, 5, dt)){ r2.evPose = "handsup"; r2.look.anim = "walk"; hero.evPose = "point"; } else hero.evPose = "run"; }
      if (plot === "dogchase" && t > 6 && t < 30){ const d = Life.dogs.find(d => !d.free && Math.hypot(d.x - r1.x, d.z - r1.z) < 80); if (d){ d.free = { tx: r1.x, tz: r1.z }; if (Math.floor(t) !== Math.floor(t - dt)) SND.play("bark", d.x, d.z, 1.3); } }
      if (plot === "standoff" && t > 8 && t < 60){ r1.look.anim = "walk"; r1.evMoving = false; r1.evPose = "handsup"; }
      else if (plot !== "falsealarm" && t > 2 && t < 40) robbers.forEach((p, k) => { if (!(plot === "bystander" && k === 1 && t > 12)) evWalk(p, run.x + ax[0]*k, run.z + ax[1]*k, 4.8, dt); });
      if (t > 40) robbers.forEach(p => { if (plot !== "standoff") p.hidden = true; });
      if (t > 12 && t < dur - 15){ vehDrive(p1, park.x, park.z, dt, 15); vehLights(p1, true, t); if (t < 30 && Math.floor(t/3.2) !== Math.floor((t-dt)/3.2)) SND.play("siren", p1.x, p1.z, 1.4); }
      if (t > 30 && t < dur - 15){ cops.forEach((p, k) => { if (p.hidden) evPlace(p, p1.x + st.az*1.4*(k%2?1:-1), p1.z - st.ax*1.4*(k%2?1:-1), 0, type);
          if (plot === "copsleave" && t > 45){ if (evWalk(p, p1.x, p1.z, 2, dt)) p.hidden = true; }
          else if (plot === "standoff"){ if (evWalk(p, r1.x - ax[0]*dir*(2.5 + k), r1.z - ax[1]*dir*(2.5 + k), 2.2, dt)){ face(p, r1.x, r1.z); p.evPose = "point"; } }
          else { const w_ = crowd[k % crowd.length]; if (evWalk(p, w_.x - o[0]*1.1, w_.z - o[1]*1.1, 2, dt)){ face(p, w_.x, w_.z); p.evPose = k === 0 ? "radio" : null; face(w_, p.x, p.z); w_.evPose = Math.floor(t/5) % 2 ? "point" : "shrug"; } } });
        if (plot === "copsleave" && t > 55 && t < 70){ vehDrive(p1, p1.x + st.ax*dir*200, p1.z + st.az*dir*200, dt, 12); crowd.forEach(p => p.evPose = "handsup"); } }
      if (plot === "falsealarm" && t > 45 && t < 60){ cops.forEach(p => { p.evPose = "shrug"; }); crowd.forEach(p => p.evPose = Math.random() < 0.3 ? "laugh" : null); }
      if (t > dur - 15){ cops.forEach(p => { if (!p.hidden && evWalk(p, p1.x, p1.z, 2.2, dt)) p.hidden = true; }); if (plot === "standoff") robbers.forEach(p => { if (!p.hidden && evWalk(p, p1.x, p1.z, 1.4, dt)) p.hidden = true; }); vehDrive(p1, p1.x + st.ax*dir*200, p1.z + st.az*dir*200, dt, 10); }
      if (t > dur){ p1.g.visible = false; robbers.forEach(p => p.look.anim = "walk"); Life.dogs.forEach(d => { if (d.free && d.free.tx !== undefined && !d.free.t) d.free = null; }); E.done = true; } };
  }
  else if (type === "nuptials"){
    const cast = genActors(10); if (cast.length < 7) return null; E.ppl = cast; const [bride, groom, ...guests] = cast, spot = { x: near.x, z: near.z };
    recolor(bride, "#f6f3ec", "#f6f3ec"); recolor(groom, pickv(["#1d1d20","#6b1f22","#2f4b5a","#e9e6de"]), "#1d1d20");
    const plot = pickv(["runaway","conga","doves","dance","objection","rain"]); evPlace(bride, spot.x - ax[0]*0.4, spot.z - ax[1]*0.4, 0, type); evPlace(groom, spot.x + ax[0]*0.4, spot.z + ax[1]*0.4, 0, type);
    guests.forEach((p, k) => evPlace(p, spot.x + o[0]*(1.6 + (k%2)*0.8) + ax[0]*(k*1.1 - 3), spot.z + o[1]*(1.6 + (k%2)*0.8) + ax[1]*(k*1.1 - 3), 0, type));
    const white = new THREE.Color(1.1, 1.1, 1.1), dur = rand(110, 150); let rained = false;
    E.step = (dt) => { const t = E.t; face(bride, groom.x, groom.z); face(groom, bride.x, bride.z);
      if (t < 25){ bride.evPose = groom.evPose = "hug"; guests.forEach(p => { face(p, spot.x, spot.z); p.evPose = "clap"; }); }
      else if (plot === "runaway"){ bride.look.anim = "jog"; evWalk(bride, spot.x + ax[0]*60, spot.z + ax[1]*60, 4.2, dt); bride.evPose = "run"; groom.evPose = t < 32 ? "handsface" : null; if (t > 32) evWalk(groom, bride.x - ax[0]*6, bride.z - ax[1]*6, 3.4, dt); guests.forEach(p => { face(p, bride.x, bride.z); p.evPose = pickv(["handsface","point"]); }); if (t > 25 && t - dt <= 25) SND.play("gasp", spot.x, spot.z, 1.3); }
      else if (plot === "conga"){ const lead = { x: spot.x + Math.sin(t*0.3)*6*ax[0] + Math.cos(t*0.3)*3*o[0], z: spot.z + Math.sin(t*0.3)*6*ax[1] + Math.cos(t*0.3)*3*o[1] }; [bride, groom, ...guests].forEach((p, k) => { const tg = k ? cast[k-1] : lead; evWalk(p, tg.x, tg.z, 1.4, dt); p.evPose = "dance"; }); if (Math.floor(t/2) !== Math.floor((t-dt)/2)) SND.play("music", spot.x, spot.z, 1.2); }
      else if (plot === "doves"){ if (t < 30) for (let k=0;k<3;k++) Smoke.emit(spot.x + rand(-0.5,0.5), groundY(spot.x, spot.z) + 1.6, spot.z + rand(-0.5,0.5), rand(-3,3), rand(2,5), rand(-3,3), 0.12, 4, 0.95, white, 0.6, 0.1); bride.evPose = groom.evPose = "cheer"; guests.forEach(p => { p.headPitch = -0.6; p.evPose = "point"; }); if (t > 25 && t - dt <= 25) SND.play("applause", spot.x, spot.z, 1.3); }
      else if (plot === "dance"){ bride.evPose = groom.evPose = "dance"; bride.heading += dt*2; groom.heading += dt*2; guests.forEach((p, k) => { const a = k/guests.length*6.28 + t*0.2; evWalk(p, spot.x + Math.sin(a)*3, spot.z + Math.cos(a)*3, 1, dt); face(p, spot.x, spot.z); p.evPose = "clap"; }); if (Math.floor(t/2) !== Math.floor((t-dt)/2)) SND.play("music", spot.x, spot.z, 1.1); }
      else if (plot === "objection"){ const ob = guests[0]; ob.evPose = t < 45 ? "fist" : "point"; face(ob, groom.x, groom.z); if (t > 25 && t - dt <= 25) SND.play("shout", ob.x, ob.z, 1.3); guests.slice(1).forEach(p => { face(p, ob.x, ob.z); p.evPose = "handsface"; }); groom.evPose = t > 40 ? "shout" : "handsup"; bride.evPose = t > 55 ? "laugh" : "handsface"; }
      else if (plot === "rain"){ if (!rained && S.custom.autoWeather==='on'){ rained = true; E.rainRev=S.weatherRevision; E.rainWas = S.rain; S.rain = true; applyTime(); } bride.evPose = groom.evPose = "hug"; guests.forEach(p => p.evPose = pickv(["cheer","laugh"])); }
      if (t > dur){ if (rained && E.rainRev===S.weatherRevision){ S.rain = E.rainWas; applyTime(); } uncolor(bride); uncolor(groom); bride.look.anim = "walk"; E.done = true; } };
  }
  else if (type === "freeze"){
    const mob = Life.people.filter(q => !q.pool && !q.hidden && !q.stationary && Math.hypot(q.x - near.x, q.z - near.z) < 28).slice(0, 14); if (mob.length < 5) return null;
    const start = rand(2, 5), len = rand(15, 30);
    E.step = (dt) => { const t = E.t; mob.forEach(q => { if (t > start && t < start + len){ q.pause = 2; q.frozen = true; } else if (t >= start + len) q.frozen = false; }); if (t > start + len + 2){ mob.forEach(q => q.frozen = false); E.done = true; } };
  }
  else if (type === "bubbles"){
    const cast = genActors(4); if (cast.length < 3) return null; E.ppl = cast; const [artist, ...kids] = cast; evPlace(artist, near.x, near.z, Math.atan2(-o[0], -o[1]), type);
    kids.forEach((p, k) => evPlace(p, near.x + o[0]*2 + ax[0]*(k*1.5 - 1.5), near.z + o[1]*2 + ax[1]*(k*1.5 - 1.5), 0, type));
    const tint = [new THREE.Color(0.8,0.9,1.1), new THREE.Color(1.1,0.9,1.0), new THREE.Color(0.95,1.1,0.9)], dur = rand(90, 140);
    E.step = (dt) => { const t = E.t; artist.evPose = (Math.floor(t/3) % 2) ? "cheer" : "hose"; if (Math.random() < 0.4) Smoke.emit(artist.x + rand(-0.5,0.5), artist.y + 1.8 + rand(0,0.6), artist.z + rand(-0.5,0.5), rand(-0.6,0.6) + 0.4, rand(0.1,0.5), rand(-0.6,0.6), rand(0.15, 0.5), rand(4, 8), 0.28, tint[(Math.random()*3)|0], 0.05, 0.2);
      kids.forEach((p, k) => { face(p, artist.x, artist.z); p.evPose = Math.sin(t*2 + k) > 0.3 ? "cheer" : null; p.headPitch = -0.4; }); if (t > dur) E.done = true; };
  }
  else if (type === "yoga"){
    const cast = genActors(4 + (Math.random()*4|0)); if (cast.length < 4) return null; E.ppl = cast;
    cast.forEach((p, k) => evPlace(p, near.x + ax[0]*(k*1.6 - cast.length*0.8) + o[0]*((k%2)*1.2), near.z + ax[1]*(k*1.6 - cast.length*0.8) + o[1]*((k%2)*1.2), Math.atan2(-o[0], -o[1]), type));
    const poses = ["cheer","hose","duck","handsup","fist"], dur = rand(100, 150);
    E.step = (dt) => { const t = E.t, ps = poses[Math.floor(t/7) % poses.length]; cast.forEach((p, k) => { p.evPose = k === 0 && Math.floor(t/3.5) % 2 ? "shout" : ps; }); if (t > dur) E.done = true; };
  }
  else if (type === "preacher"){
    const cast = genActors(1); if (!cast.length) return null; E.ppl = cast; const p = cast[0]; evPlace(p, near.x, near.z, Math.atan2(o[0], o[1]), type); p.evSign = true; const dur = rand(90, 160);
    E.step = (dt) => { const t = E.t; p.evPose = Math.floor(t/2.5) % 3 === 0 ? "fist" : null; p.heading = Math.atan2(o[0], o[1]) + Math.sin(t*0.5)*0.6; if (Math.floor(t/3) !== Math.floor((t-dt)/3)) SND.play("shout", p.x, p.z, 0.8); if (t > dur){ p.evSign = false; E.done = true; } };
  }
  return E;
}
(function(){ const base = startEvent; startEvent = function(type){ return V8EVENTS[type] ? (function(){ const E = startV8(type); if (E) S.evHist = (S.evHist || []).concat(type).slice(-8); return E; })() : base(type); }; })();
(function(){ const base = posePerson; posePerson = function(p, i, moving, ...rest){ if (p.frozen) moving = 0; return base(p, i, moving, ...rest); }; })();

(function(){ const base = curFlash; curFlash = function(){ const f = base(); if (!f || !f.gn || !sk("flashmaster")) return f; return Object.assign({}, f, { gn: f.gn*(1 + 0.25*sk("flashmaster")) }); }; })();
(function(){ const base = judgePhoto; judgePhoto = function(rec){ const res = base(rec); const c = sk("composition"); if (c && res && res.cats){ res.cats.comp = clamp(res.cats.comp + 3*c, 0, 100); res.total = clamp(res.total + c, 1, 100); } return res; }; })();
(function(){ const base = rollTension; rollTension = function(dt){ base(dt); if (sk("patience") && Player.raise > 0.6 && Player.speed < 0.1){ Player.breath = Math.min(1, (Player.breath||0) + dt*0.05*sk("patience")); } }; })();
(function(){ const base = Audio.init; Audio.init = function(){ const r = base.apply(Audio, arguments); const m = Audio.master && Audio.master(); if (m && S){ const vol = ({ off:0, half:0.5, full:1 })[S.custom.masterVol] ?? 1; m.gain.value = 0.8*vol; } return r; }; })();

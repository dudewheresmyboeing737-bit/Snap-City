(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const X = SC.city = { built: false, cranes: [], crews: [], alleyFolk: [], cats: [] };

  const LOW = { renderQuality: "performance", graphicsPreset: "low", graphicsEnhance: "off", cinematicBloom: "off",
    atmosphereStrength: "subtle", cloudLife: "off", livingSky: "off", architectureDetail: "lean", shopLife: "quiet",
    stylizedPalette: "off", wetStreets: "off" };
  const NEW = { dateStamp: "off", photoBorder: "none", hudAccent: "amber", constructionLife: "on", alleyLife: "on" };
  function migrate(s){
    if (!s || !s.custom) return s;
    if (!s.custom._sc45){ Object.assign(s.custom, LOW); s.custom._sc45 = 1; }
    for (const k in NEW) if (s.custom[k] === undefined) s.custom[k] = NEW[k];
    s.sky = s.sky || "clear";
    return s;
  }
  if (typeof defaultState === "function"){ const b = defaultState; window.defaultState = function(){ return migrate(b.apply(this, arguments)); }; }
  if (typeof loadState === "function"){ const b = loadState; window.loadState = function(){ return migrate(b.apply(this, arguments)); }; }

  if (typeof SKILLS !== "undefined"){
    SKILLS.speedload = { name: "Speed loader", max: 2, desc: "Reload film faster: each rank cuts the time spent changing rolls by 40%." };
    SKILLS.bulkroll = { name: "Bulk loader", max: 2, desc: "Hand-roll your own film: each rank squeezes two extra frames onto every roll (not disposables)." };
    SKILLS.stormchaser = { name: "Storm chaser", max: 2, desc: "Editors love bad weather: +15% pay per rank for frames shot in rain, fog, snow, storms or overcast skies." };
    SKILLS.streetsense = { name: "Street sense", max: 2, desc: "You feel the city before it happens: extra street stories start near you, more often with each rank." };
  }
  const rank = k => { try{ return sk(k) || 0; }catch(e){ return 0; } };
  let lastLoad = 0, lastLeft = null, lastBody = null;
  function skillTick(){
    if (typeof GP === "undefined" || typeof S === "undefined" || !S) return;

    if (GP.loadT > lastLoad + 0.05 && rank("speedload")) GP.loadT *= Math.pow(0.6, rank("speedload"));
    lastLoad = GP.loadT || 0;

    try{
      const r = curRoll(), b = curBody();
      if (lastBody === S.body && lastLeft !== null && r.left > lastLeft + 1 && !b.film && rank("bulkroll") && !r._bulk){ r.left += 2 * rank("bulkroll"); r._bulk = true; }
      if (r.left <= 0) r._bulk = false;
      lastLeft = r.left; lastBody = S.body;
    }catch(e){}
  }
  if (typeof applyJudgement === "function"){
    const base = applyJudgement;
    window.applyJudgement = function(rec, res){
      const pay = base.apply(this, arguments);
      try{
        const m = rec.meta || {}, w = m.weather || m;
        const bad = w.rain || w.fog || w.snow || w.storm || m.overcast;
        if (bad && pay && pay.money && rank("stormchaser") && !S.free){ const extra = Math.round(pay.money * 0.15 * rank("stormchaser")); S.money += extra; pay.money += extra; }
      }catch(e){}
      return pay;
    };
  }
  let senseT = 40;
  function streetSense(dt){
    const r = rank("streetsense"); if (!r || !SC.startStory || !SC.stories) return;
    senseT -= dt; if (senseT > 0) return;
    senseT = r >= 2 ? 30 : 50;
    const d = SC.stories[(Math.random() * SC.stories.length) | 0]; try{ SC.startStory(d.id); }catch(e){}
  }

  if (typeof sceneEV === "function"){
    const base = sceneEV;
    window.sceneEV = function(){
      let ev = base.apply(this, arguments);
      if (typeof S !== "undefined" && S){
        if (S.sky === "overcast") ev -= 1.7;
        if (S.sky === "drizzle") ev += 0.8;
        if (S.sky === "sunshower") ev += 1.3;
      }
      return ev;
    };
  }
  if (typeof applyTime === "function"){
    const base = applyTime;
    window.applyTime = function(){
      const r = base.apply(this, arguments);
      try{
        if (!S || !World.sun) return r;
        const T = World.timeDef || {};
        if (S.sky === "overcast" && !S.storm){
          World.sun.intensity *= 0.22; if (World.hemi) World.hemi.intensity *= 0.9;
          if (World.skyMat && World.skyMat.uniforms){ const grey = lin("#9aa3aa"); World.skyMat.uniforms.top.value.lerp(grey, 0.75); World.skyMat.uniforms.bot.value.lerp(lin("#c4c9cc"), 0.7); if (World.skyMat.uniforms.sunAmt) World.skyMat.uniforms.sunAmt.value *= 0.15; }
          if (World.scene.fog) World.scene.fog.density *= 1.25;
        }
        if (S.sky === "sunshower" && T.sunI) World.sun.intensity = Math.max(World.sun.intensity, T.sunI * 0.8);
      }catch(e){}
      return r;
    };
  }
  function setSky(v){
    S.sky = v;
    if (v === "drizzle" || v === "sunshower"){ S.rain = true; S.storm = false; S.snow = false; }
    try{ applyTime(); }catch(e){} saveState();
  }
  SC.setSky = setSky;
  function rainTick(){
    if (typeof Rain === "undefined" || !Rain.mesh || !S) return;
    if ((S.sky === "drizzle" || S.sky === "sunshower") && S.rain && !S.storm){ Rain.mesh.visible = true; const u = Rain.mesh.material.uniforms; if (u && u.uA) u.uA.value = Math.min(u.uA.value, S.sky === "sunshower" ? 0.22 : 0.28); Rain.len = Math.min(Rain.len || 0.3, 0.3); }
  }
  if (typeof menuTime === "function"){
    const base = menuTime;
    window.menuTime = function(){
      const h = base.apply(this, arguments), v = S.sky || "clear";
      const b = (val, label) => `<button data-wx="${val}" aria-pressed="${v === val}">${label}</button>`;
      return h + `<div class="formrow"><label>Sky</label><div class="seg">${b("clear","As is")}${b("overcast","Overcast")}${b("drizzle","Drizzle")}${b("sunshower","Sunshower")}</div><span class="spec">Overcast: flat, soft light about two stops darker. Drizzle: fine rain without the downpour. Sunshower: rain falling through sunlight.</span></div>`;
    };
  }

  if (typeof startGame === "function"){
    const base = startGame;
    window.startGame = function(){
      const r = base.apply(this, arguments);
      try{ migrate(S); if (S.custom.startWeather === "random"){ const x = Math.random(); S.sky = S.storm ? "clear" : x < 0.2 ? "overcast" : x < 0.3 && S.rain ? "drizzle" : x < 0.36 && S.rain ? "sunshower" : "clear"; applyTime(); } }catch(e){}
      applyAccent();
      return r;
    };
  }

  const ACCENTS = { amber: "#e8a33d", green: "#7fd46a", cyan: "#5cc8e0", white: "#f2efe6", red: "#e0503c" };
  function applyAccent(){ try{ const c = ACCENTS[(S && S.custom.hudAccent) || "amber"] || ACCENTS.amber; document.documentElement.style.setProperty("--amber", c); document.documentElement.style.setProperty("--sc-accent", c); }catch(e){} }
  SC.finishPhoto = function(cv){
    if (typeof S === "undefined" || !S) return;
    const x = cv.getContext("2d"), W = cv.width, H_ = cv.height;
    const border = S.custom.photoBorder;
    if (border === "film" || border === "print"){
      const pad = Math.round(Math.min(W, H_) * (border === "print" ? 0.045 : 0.03));
      const tmp = document.createElement("canvas"); tmp.width = W; tmp.height = H_; tmp.getContext("2d").drawImage(cv, 0, 0);
      x.fillStyle = border === "print" ? "#f4f1e8" : "#0c0b0a"; x.fillRect(0, 0, W, H_);
      x.drawImage(tmp, pad, pad, W - 2*pad, H_ - 2*pad);
      if (border === "film"){ x.fillStyle = "#e0a650"; x.font = `bold ${Math.round(pad*0.55)}px monospace`; x.fillText(`SNAP 400  ▸${(S.frameCount||0)+1}`, pad, H_ - pad*0.3); }
    }
    if (S.custom.dateStamp === "on"){
      const d = new Date(), yy = String(d.getFullYear()).slice(2), txt = `'${yy} ${d.getMonth()+1} ${d.getDate()}`;
      const fs = Math.round(H_ * 0.045); x.font = `bold ${fs}px "Courier New", monospace`; x.textAlign = "right";
      x.shadowColor = "rgba(255,120,20,.9)"; x.shadowBlur = fs * 0.35; x.fillStyle = "#ff9a2e";
      x.fillText(txt, W - fs * 1.4, H_ - fs * 1.2); x.shadowBlur = 0; x.textAlign = "left";
    }
  };
  function customRows(){
    const c = S.custom, row = (key, label, opts, spec) => `<div class="formrow"><label>${label}</label><div class="seg" data-seg44="${key}">${opts.map(([v,l]) => `<button data-v="${v}" aria-pressed="${String(c[key])===v}">${l}</button>`).join("")}</div>${spec?`<span class="spec">${spec}</span>`:""}</div>`;
    let size = "standard"; try{ size = localStorage.getItem("snapcity.citySize") || "standard"; }catch(e){}
    return `<div class="formrow"><label>City size</label><div class="seg" data-citysize>${[["compact","Compact"],["standard","Standard"],["large","Large"]].map(([v,l]) => `<button data-v="${v}" aria-pressed="${size===v}">${l}</button>`).join("")}</div><span class="spec">Compact is 25 blocks, Standard 49, Large 81 (plus the edge). Smaller cities run much faster. Takes effect when the city is rebuilt.</span><button class="btn small" data-newcity>Build a new city now</button></div>` +
      row("dateStamp","Date stamp on photos",[["off","Off"],["on","On"]],"The orange date imprint of a 90s point-and-shoot.") +
      row("photoBorder","Photo border",[["none","None"],["film","Film rebate"],["print","White print"]]) +
      row("hudAccent","HUD accent colour",[["amber","Amber"],["green","Green"],["cyan","Cyan"],["white","White"],["red","Red"]]) +
      row("constructionLife","Construction crews",[["on","On"],["off","Off"]]) +
      row("alleyLife","People in alleys",[["on","On"],["off","Off"]]);
  }
  if (typeof menuSettings === "function"){ const base = menuSettings; window.menuSettings = function(){ migrate(S); return customRows() + base.apply(this, arguments); }; }
  if (typeof wireMenu === "function"){
    const base = wireMenu;
    window.wireMenu = function(){
      const r = base.apply(this, arguments);
      document.querySelectorAll("#menubody [data-citysize] button").forEach(b => b.onclick = () => { try{ localStorage.setItem("snapcity.citySize", b.dataset.v); }catch(e){} toast("City size saved. Use “Build a new city now” or reopen the game to apply.", 2600); renderMenu(); });
      const nc = document.querySelector("#menubody [data-newcity]"); if (nc) nc.onclick = () => { try{ saveState(); }catch(e){} location.reload(); };
      document.querySelectorAll("#menubody [data-wx]").forEach(b => b.onclick = () => { setSky(b.dataset.wx); renderMenu(); });
      document.querySelectorAll("#menubody [data-seg44='hudAccent'] button").forEach(b => { const o = b.onclick; b.onclick = () => { o && o(); applyAccent(); }; });
      return r;
    };
  }

  const mats = {}; const m = (c, r, mt, em) => mats[c+(em||"")] || (mats[c+(em||"")] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: r ?? .7, metalness: mt || 0, emissive: em ? lin(c) : 0x000000, emissiveIntensity: em || 0 }));
  const BOX = new THREE.BoxGeometry(1,1,1);
  const bx = (g, c, x, y, z, sx, sy, sz, mm) => { const o = new THREE.Mesh(BOX, mm || m(c)); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; g.add(o); return o; };
  function crane(site){
    const g = new THREE.Group(), h = Math.max(site.top - site.gy + 14, 26), yel = m("#e8b82e", .5, .3);
    const inward = [-site.n[0], -site.n[1]], cx = site.x + inward[0] * 2, cz = site.z + inward[1] * 2;
    g.position.set(cx, site.gy, cz);
    for (const [lx, lz] of [[-.8,-.8],[.8,-.8],[.8,.8],[-.8,.8]]) bx(g, "", lx, h/2, lz, .18, h, .18, yel);
    for (let y = 2; y < h; y += 2.4){ bx(g, "", 0, y, -.8, 1.6, .1, .1, yel); bx(g, "", 0, y, .8, 1.6, .1, .1, yel); bx(g, "", -.8, y, 0, .1, .1, 1.6, yel); bx(g, "", .8, y, 0, .1, .1, 1.6, yel); }
    const jib = new THREE.Group(); jib.position.y = h; g.add(jib);
    bx(jib, "", 10, .6, 0, 22, .7, 1.1, yel); bx(jib, "", -5, .6, 0, 9, .7, 1.1, yel);
    bx(jib, "#6b6f73", -8.2, .1, 0, 2.6, 1.8, 1.6); bx(jib, "#e9e6de", 1.2, -.8, 0, 1.6, 1.6, 1.6); bx(jib, "", 0, 2.6, 0, .5, 4, .5, yel);
    const hook = new THREE.Group(); hook.position.set(14, 0, 0); jib.add(hook);
    const cable = bx(hook, "#222", 0, -h*0.25, 0, .04, h*0.5, .04); const load = bx(hook, "#8a8680", 0, -h*0.5, 0, 1.4, .6, 1.4);
    const light = bx(jib, "#ff3b2f", 21, 1.1, 0, .3, .3, .3, m("#ff3b2f", .4, 0, 1.5));
    G.scene.add(g);
    X.cranes.push({ g, jib, hook, cable, load, h, phase: Math.random() * 6, light, speed: .05 + Math.random() * .06 });
  }
  function crew(site){
    const count = 2 + ((Math.random() * 3) | 0);
    for (let k = 0; k < count; k++){
      if (!SC.makePerson) return;
      const p = SC.makePerson((site.x * 13 + k * 71) | 0, false);
      const along = (Math.random() - .5) * (site.w - 3), inn = 2 + Math.random() * (site.d - 5);
      const t = [site.n[1], -site.n[0]];
      p.g.position.set(site.fx + t[0]*along - site.n[0]*inn, site.gy, site.fz + t[1]*along - site.n[1]*inn);
      p.g.rotation.y = Math.random() * 6.28;
      const hat = new THREE.Mesh(new THREE.SphereGeometry(.15, 10, 6, 0, Math.PI*2, 0, Math.PI/2), m("#f2c230", .5));
      hat.position.copy(p.head.position).add(new THREE.Vector3(0, .07, 0)); p.g.add(hat);
      const vest = new THREE.Mesh(BOX, m("#ff7a1a", .6, 0, .15)); vest.scale.set(.38, .4, .22); vest.position.set(0, p.head.position.y - .5, 0); p.g.add(vest);
      G.scene.add(p.g);
      X.crews.push(Object.assign(p, { act: ["hammer","carry","point","dig"][k % 4] }));
    }

    for (const s of [-1, 1]){ const lg = new THREE.Group(); const t = [site.n[1], -site.n[0]]; lg.position.set(site.fx + t[0]*s*site.w*0.3 - site.n[0]*1.2, site.gy, site.fz + t[1]*s*site.w*0.3 - site.n[1]*1.2); bx(lg, "#2b2f33", 0, 1.1, 0, .06, 2.2, .06); X.lamps = X.lamps || []; X.lamps.push(bx(lg, "#fff4c8", 0, 2.25, 0, .5, .3, .15, m("#fff4c8", .3, 0, 0))); G.scene.add(lg); }
  }
  function roadWorks(){

    const lots = (World.lots || []).filter(l => Math.abs(l.i) <= NB && Math.abs(l.j) <= NB);
    for (let k = 0; k < 4 && lots.length; k++){
      const l = lots[(Math.random() * lots.length) | 0], z = l.cz + HALF + SWK + 1.3, x0 = l.cx - 12 + Math.random() * 20;
      const g = new THREE.Group(); g.position.set(x0, H(x0, z) + .02, z);
      for (let c = 0; c < 6; c++){ const cone = new THREE.Mesh(new THREE.ConeGeometry(.18, .6, 10).translate(0, .3, 0), m("#ff6a1a", .6)); cone.position.set(c * 1.3, 0, (c % 2) * .2); g.add(cone); }
      bx(g, "#f2efe6", 3.2, .7, .9, 4.5, .35, .08); bx(g, "#e0503c", 3.2, .7, .92, 4.5, .12, .09);
      for (const lx of [1.1, 5.3]) bx(g, "#2b2f33", lx, .35, .9, .08, .7, .08);
      const pit = new THREE.Mesh(new THREE.BoxGeometry(2.4, .02, 1.2), m("#3a2e26", .95)); pit.position.set(3.2, .01, .2); g.add(pit);
      G.scene.add(g);
      if (SC.makePerson){ const p = SC.makePerson((x0 * 7) | 0, false); p.g.position.set(x0 + 3.2, H(x0, z) + .02, z - .3); const hat = new THREE.Mesh(new THREE.SphereGeometry(.15, 10, 6, 0, Math.PI*2, 0, Math.PI/2), m("#f2c230", .5)); hat.position.copy(p.head.position).add(new THREE.Vector3(0,.07,0)); p.g.add(hat); G.scene.add(p.g); X.crews.push(Object.assign(p, { act: "dig" })); }
    }
  }

  const MURALS = [];
  function muralTex(k){
    const c = document.createElement("canvas"); c.width = 512; c.height = 256; const x = c.getContext("2d");
    const pal = [["#e6406b","#35c1e0","#f2d24a","#1d1d1d"],["#2f7fc1","#f28cb1","#fff4c8","#3aa06b"],["#e36f2d","#8a3fb5","#16a3a3","#f2efe6"],["#1e3a5f","#e8b82e","#c0362c","#e9e6de"]][k % 4];
    x.fillStyle = pal[3]; x.fillRect(0, 0, 512, 256);
    for (let i = 0; i < 14; i++){ x.fillStyle = pal[i % 3]; x.globalAlpha = .85; x.beginPath(); x.arc(Math.random()*512, Math.random()*256, 20 + Math.random()*70, 0, 7); x.fill(); }
    x.globalAlpha = 1; x.save(); x.translate(256, 150); x.rotate(-.08); x.font = "bold 86px Impact, sans-serif"; x.textAlign = "center"; x.lineWidth = 8; x.strokeStyle = "#111"; x.fillStyle = pal[(k+1) % 3];
    const word = ["SNAP","CITY","LOOK UP","SMILE","WILD","SHUTTER","FOCUS","HELLO"][k % 8]; x.strokeText(word, 0, 0); x.fillText(word, 0, 0); x.restore();
    const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return new THREE.MeshStandardMaterial({ map: t, roughness: .9 });
  }
  function alleys(){
    const walls = World.alleyWalls || [];
    walls.forEach((a, i) => {
      const len = Math.max(4, a.x1 - a.x0);
      if (Math.random() < 0.8){
        const mm = MURALS[i % 6] || (MURALS[i % 6] = muralTex(i));
        const side = Math.random() < .5 ? -1 : 1, w = Math.min(len - 1, 8 + Math.random() * 6), x = (a.x0 + a.x1) / 2 + (Math.random() - .5) * (len - w);
        const pl = new THREE.Mesh(new THREE.PlaneGeometry(w, 2.3), mm); pl.position.set(x, H(x, a.cz) + .16 + 1.3, a.cz + side * (a.AW - .0)); pl.rotation.y = side > 0 ? Math.PI : 0; G.scene.add(pl);
      }
      if (S.custom.alleyLife === "off" || !SC.makePerson) return;
      if (Math.random() < .6){
        const p = SC.makePerson((a.cx * 3 + a.cz * 5) | 0, false), x = a.x0 + Math.random() * len, side = Math.random() < .5 ? -1 : 1;
        p.g.position.set(x, H(x, a.cz) + .16, a.cz + side * (a.AW - .5)); p.g.rotation.y = side > 0 ? Math.PI : 0;
        const kind = Math.random() < .5 ? "smoke" : "cook";
        if (kind === "cook"){ const ap = new THREE.Mesh(BOX, m("#f4f4f0")); ap.scale.set(.34, .5, .22); ap.position.set(0, p.head.position.y - .55, 0.02); p.g.add(ap); }
        else { const cig = new THREE.Mesh(BOX, m("#ff7a3a", .4, 0, 1.2)); cig.scale.set(.02, .02, .08); cig.position.set(.05, -.5, .05); p.armR.add(cig); }
        G.scene.add(p.g); X.alleyFolk.push(Object.assign(p, { act: kind }));
      }
      if (Math.random() < .35){
        const g = new THREE.Group(), x = a.x0 + Math.random() * len, col = m(["#1a1a1a","#e36f2d","#9a9a9a","#f2efe6"][(Math.random()*4)|0], .9);
        bx(g, "", 0, .18, 0, .18, .16, .42, col); bx(g, "", 0, .3, .24, .14, .14, .14, col); bx(g, "", 0, .3, -.28, .04, .04, .22, col);
        g.position.set(x, H(x, a.cz) + .16, a.cz + (Math.random() - .5) * a.AW); g.rotation.y = Math.random() * 6.28; G.scene.add(g); X.cats.push({ g, phase: Math.random() * 6, x0: g.position.x });
      }
    });
  }

  function build(){
    if (X.built || typeof G === "undefined" || !G.scene || typeof World === "undefined" || !World.lots || !World.lots.length || typeof S === "undefined" || !S) return;
    X.built = true;
    try{ for (const site of (World.construction || [])){ crane(site); if (S.custom.constructionLife !== "off") crew(site); } }catch(e){ console.warn("[Snap City] construction", e); }
    try{ if (S.custom.constructionLife !== "off") roadWorks(); }catch(e){ console.warn("[Snap City] road works", e); }
    try{ alleys(); }catch(e){ console.warn("[Snap City] alleys", e); }
    applyAccent();
  }
  function animate(dt, t){
    for (const c of X.cranes){
      c.jib.rotation.y = Math.sin(t * c.speed + c.phase) * 1.4 + c.phase;
      const lift = (Math.sin(t * c.speed * 2.3 + c.phase) * .5 + .5) * c.h * .55;
      c.load.position.y = -c.h * .9 + lift; c.cable.scale.y = Math.max(.5, c.h * .9 - lift); c.cable.position.y = -(c.h * .9 - lift) / 2;
      c.light.material.emissiveIntensity = (Math.sin(t * 3 + c.phase) > 0) ? 2 : .2;
    }
    const night = World.timeDef && (World.timeDef.id === "night" || World.timeDef.id === "blue");
    for (const l of (X.lamps || [])) l.material.emissiveIntensity = night ? 2.2 : 0;
    for (const p of X.crews){
      const s = Math.sin(t * 5 + p.phase);
      if (p.act === "hammer"){ p.armR.rotation.x = -1.6 + Math.max(0, s) * 1.2; }
      else if (p.act === "dig"){ p.armL.rotation.x = p.armR.rotation.x = -.9 + s * .5; p.g.rotation.x = Math.max(0, s) * .15; }
      else if (p.act === "carry"){ p.armL.rotation.x = p.armR.rotation.x = -1.2; p.g.position.y += 0; }
      else { p.armR.rotation.x = -1.4 + Math.sin(t * .8 + p.phase) * .2; p.head.rotation.y = Math.sin(t * .6 + p.phase) * .5; }
    }
    for (const p of X.alleyFolk){
      if (p.act === "smoke"){ const s = Math.max(0, Math.sin(t * .5 + p.phase)); p.armR.rotation.x = -.3 - s * 1.5; p.head.rotation.x = s * .1; }
      else { p.head.rotation.y = Math.sin(t * .4 + p.phase) * .6; p.armL.rotation.x = -.4; }
    }
    for (const c of X.cats){ c.g.position.x = c.x0 + Math.sin(t * .15 + c.phase) * 3; c.g.rotation.y = Math.cos(t * .15 + c.phase) > 0 ? Math.PI/2 : -Math.PI/2; }
  }
  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{
        if (!X.built) build();
        if (typeof S !== "undefined" && S && Game.started){ skillTick(); streetSense(dt); rainTick(); }
        animate(dt, performance.now() / 1000);
      }catch(e){ console.warn("[Snap City 45]", e); }
      return r;
    };
  }
  const iv = setInterval(() => { try{ build(); if (X.built) clearInterval(iv); }catch(e){} }, 700);
})();

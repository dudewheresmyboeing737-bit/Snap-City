(function(){
"use strict";
const CS145 = window.CS145 = {
  insideShop:false,
  acts:[],
  events:[],
  ambientTimer:6,
  eventTimer:18,
  cues:[],
  ready:false,
  motifs:[],
  templates:[]
};
function R(a,b){ return a + Math.random()*(b-a); }
function I(a,b){ return (a + Math.floor(Math.random()*(b-a+1))); }
function dirCue(x,z){
  const ang = Math.atan2(-(x-Player.x), -(z-Player.z));
  const rel = Math.atan2(Math.sin(ang - Player.yaw), Math.cos(ang - Player.yaw));
  return Math.abs(rel) < 0.6 ? 'ahead' : Math.abs(rel) > 2.4 ? 'behind you' : rel > 0 ? 'to your left' : 'to your right';
}
function nearestTheme(){
  const themes=['commuters','nightlife','transit','rain','workers','youth','tourists','wealth','loneliness','ritual','fashion','labor','sports'];
  return themes[(Math.random()*themes.length)|0];
}
function ensurePerfDefaults(){
  if(!window.S || !S.custom) return;

  if(!S.custom._v145Applied) S.custom._v145Applied=true;
}
function enforcePrecip(source){
  if(!window.S) return;
  if(S.storm){ S.rain=true; S.snow=false; }
  if(S.snow){ S.rain=false; S.storm=false; }
  if(S.rain && S.snow){ if(source==='snow'){ S.rain=false; } else { S.snow=false; } }
}
function wirePrecipExclusivity(){
  document.addEventListener('click', ev=>{
    const b = ev.target.closest && ev.target.closest('[data-snow] button,[data-rain] button,[data-storm] button');
    if(!b) return;
    setTimeout(()=>{
      if(b.closest('[data-snow]')) enforcePrecip('snow');
      else if(b.closest('[data-storm]')) enforcePrecip('storm');
      else enforcePrecip('rain');
      try{ applyTime(); saveState(); }catch(e){}
    }, 0);
  }, true);
}
function softenInsideGlass(inside){
  if(!window.World || !World.mats || !World.mats.glass) return;
  const g = World.mats.glass;
  if(inside){ g.opacity = 0.12; g.roughness = 0.03; g.envMapIntensity = 0.1; }
  else { g.opacity = 0.22; g.roughness = 0.08; g.envMapIntensity = ({ clear:0.25, balanced:0.45, reflective:0.8 })[S.custom.windowGlass] || 0.45; }
  g.needsUpdate=true;
  CS145.insideShop = !!inside;
}
if(typeof enterShop==='function' && typeof leaveZone==='function'){
  const _enter145 = enterShop, _leave145 = leaveZone;
  enterShop = function(){ const r=_enter145.apply(this, arguments); try{ softenInsideGlass(true); }catch(e){} return r; };
  leaveZone = function(){ try{ softenInsideGlass(false); }catch(e){} return _leave145.apply(this, arguments); };
}

function cap(s){ return String(s||'').replace(/\b\w/g, m=>m.toUpperCase()); }
function readingBadge(v){ return v>=85?'excellent':v>=70?'strong':v>=55?'alive':v>=40?'mixed':'weak'; }
function computeReadings(p,res){
  const m=p.meta||{}, st=(m.stats||{}), cats=(p.cats||res&&res.cats||{}), title=((essayState&&essayState().title)||'').toLowerCase();
  const people=st.people||0, dogs=st.dogs||0, event=(m.eventType||m.event||''), hood=(m.hood||'').toLowerCase();
  const formal = Math.round((0.35*(cats.comp||50)+0.2*(cats.color||50)+0.2*(cats.sharp||50)+0.15*(cats.light||50)+0.1*((st.layers||2)*20)));
  const human = Math.round((0.45*(cats.subj||50)+ (people?12:0) + (event?10:0) + (dogs?5:0) + (m.weather&&m.weather.wind>0.9?6:0) + (m.hip?4:0)));
  const documentary = Math.round(40 + (hood?10:0) + (m.street?8:0) + (event?18:0) + ((m.weather&&(m.weather.rain||m.weather.snow||m.weather.storm))?8:0) + (people>3?8:0));
  let personal = 45;
  const titleWords = title.split(/\W+/).filter(w=>w.length>3);
  const sceneWords = [hood,m.street,m.timeName,m.filterName,m.filmName,event, m.weather&&m.weather.snow?'snow':'',m.weather&&m.weather.rain?'rain':'',m.weather&&m.weather.storm?'storm':'', people>3?'crowd':'', dogs?'dog':'', m.transit?'transit':''].join(' ').toLowerCase();
  titleWords.forEach(w=>{ if(sceneWords.includes(w)) personal += 8; });
  if(title.includes('street study')||title.includes('untitled')) personal -= 4;
  personal = Math.max(25, Math.min(95, personal));
  let ethical = 62;
  if(people===1 && (st.faceClose||0)>0) ethical -= 10;
  if(people>4) ethical += 6;
  if(m.hip) ethical -= 8;
  if(CS145.insideShop && people>0) ethical += 2;
  if(m.accidentalSelf) ethical += 4;
  ethical = Math.max(20, Math.min(95, ethical));
  const notes = {
    formal: choiceByScore(formal,['geometry is doing real work','layering helps the frame breathe','negative space strengthens the picture','colour and edge rhythm give the frame structure','the arrangement is carrying as much as the subject'],['the frame could use cleaner geometry','the edges feel crowded','negative space is not yet doing enough','the composition needs stronger internal order']),
    human: choiceByScore(human,['gesture and human energy carry the picture','there is a real emotional current here','the ambiguity helps rather than confuses','the intimacy feels earned','people are doing something that matters'],['the human charge is still faint','gesture could be stronger','the people are present but not yet expressive','there is not enough tension between subjects']),
    documentary: choiceByScore(documentary,['the place feels specific rather than generic','this says something about the city, not just a corner','the frame has a useful documentary specificity','it reads as a record of a real social space'],['the frame could reveal more context','place is visible but not fully specific','the social context remains thin']),
    personal: choiceByScore(personal,['it connects well with your long-term project','this feels close to the project you say you are building','the frame belongs naturally in your ongoing sequence'],['it may be a good picture without fitting your project closely','as a single frame it works better than as part of your stated project','the connection to your larger body of work is still loose']),
    ethical: choiceByScore(ethical,['the editorial stance feels measured','there is enough context to publish responsibly','the picture feels observed rather than extracted'],['publication would benefit from more context','the frame raises questions about distance or consent','editorially this needs care in how it is presented'])
  };
  return { formal:{score:formal,note:notes.formal}, human:{score:human,note:notes.human}, documentary:{score:documentary,note:notes.documentary}, personal:{score:personal,note:notes.personal}, ethical:{score:ethical,note:notes.ethical} };
}
function choiceByScore(score, good, bad){ const src = score>=60 ? good : bad; return src[(Math.random()*src.length)|0]; }
if(typeof applyJudgement==='function'){
  const _apply145=applyJudgement;
  applyJudgement=function(p,res){ const out=_apply145.apply(this, arguments); try{ p.readings = computeReadings(p,res); }catch(e){} return out; };
}
if(typeof renderLbSide==='function'){
  const _rlb145 = renderLbSide;
  renderLbSide = function(p, info){
    const r = _rlb145.apply(this, arguments);
    const side = document.getElementById('lbside'); if(!side) return r;
    let box = side.querySelector('.cs145-titlebox');
    if(!box){
      box = document.createElement('div'); box.className='cs145-titlebox';
      box.style.margin='12px 0'; box.style.padding='10px'; box.style.background='rgba(255,255,255,.04)'; box.style.border='1px solid rgba(255,255,255,.08)'; box.style.borderRadius='10px';
      box.innerHTML=`<div style="font-weight:700;margin-bottom:6px">Image title</div><div style="display:flex;gap:8px"><input id="cs145_title" type="text" maxlength="80" placeholder="Untitled frame" style="flex:1;background:#171614;color:#f4f1e8;border:1px solid #555;padding:8px;border-radius:8px"><button class="btn small" id="cs145_saveTitle">Save name</button></div><div class="spec" style="display:block;margin-top:6px">Give a frame a working title for the archive without changing the photograph itself.</div>`;
      side.insertBefore(box, side.querySelector('.actions'));
    }
    const inp = box.querySelector('#cs145_title'); if(inp) inp.value = p.title || '';
    const sb = box.querySelector('#cs145_saveTitle'); if(sb) sb.onclick = async ()=>{ p.title = (inp.value||'').trim(); await DB.put(p); toast(p.title?`Saved as “${p.title}”.`:'Removed image title.',1500); };
    let rd = side.querySelector('.cs145-readings'); if(rd) rd.remove();
    if(p.readings){
      rd = document.createElement('div'); rd.className='cs145-readings'; rd.style.marginTop='12px';
      const rows = ['formal','human','documentary','personal','ethical'].map(k=>`<div style="margin:10px 0"><div style="display:flex;justify-content:space-between;gap:10px"><b>${cap(k)}</b><span>${p.readings[k].score} · ${readingBadge(p.readings[k].score)}</span></div><div class="spec" style="display:block">${p.readings[k].note}</div></div>`).join('');
      rd.innerHTML = `<div class="edgroup" style="margin-bottom:8px">Independent readings</div><div class="note" style="margin-bottom:10px">The highest score is not automatically the “best” photograph. These parallel readings look at different values.</div>${rows}`;
      side.appendChild(rd);
    }
    return r;
  };
}

if(typeof captureShot==='function'){
  const _cap145 = captureShot;
  captureShot = async function(){
    const rec = await _cap145.apply(this, arguments);
    try{
      if(rec && rec.meta){
        const reflChance = (S.filter==='polar'?0.12:0.22) + (S.rain?0.08:0) + (S.storm?0.08:0) + (S.custom.windowGlass==='reflective'?0.06:0);
        rec.meta.accidentalSelf = Math.random() < reflChance;
        rec.meta.transit = !!(window.GP && GP.ride && GP.ride.v);
        rec.meta.projectTitle = (essayState&&essayState().title)||'';
        await DB.put(rec);
      }
    }catch(e){}
    return rec;
  };
}

const MOTIFS = [
['cyclist with flowers','bike'],['cyclist in a suit','bike'],['bike courier with messenger bag','bike'],['slow commuter bike','bike'],['wobbling tourist cyclist','bike'],['parent on a bike','bike'],['night rider with tote bag','bike'],['bmx kid on a bike','bike'],['fixie rider in black','bike'],['rain-jacket cyclist','bike'],
['skater with headphones','skate'],['fast downhill skater','skate'],['nervous beginner skater','skate'],['filmer following a skater','skate'],['skater carrying shoes','skate'],['late-night skater','skate'],['two skaters racing','skate'],['skater in bright socks','skate'],['boarder weaving traffic','skate'],['curb-hop skater','skate'],
['pizza runner with a warm box','pizza'],['delivery worker holding two pizzas','pizza'],['slice shop employee on break','pizza'],['pizza courier crossing in rain','pizza'],['someone protecting pizza from wind','pizza'],
['movers carrying a couch','mover'],['movers carrying a mattress','mover'],['movers with a lamp and chair','mover'],['movers dragging boxes','mover'],['movers with a mirror','mover'],['movers resting on a dolly','mover'],
['balloon seller','balloons'],['flower seller','flowers'],['umbrella couple','umbrella'],['commuter with newspaper','commuter'],['fashion pair in black','fashion'],['runner with coffee','runner'],['dog walker with three leashes','dogwalk'],['tourist with a map','tourist'],['chef smoking outside','chef'],
['street musician packing up','music'],['busker tuning a guitar','music'],['brass duo','music'],['wedding guest in heels','wedding'],['best man carrying flowers','wedding'],['protest volunteer with flyers','protest'],['banner carrier','protest'],['tattooed punk pair','punk'],['student with tripod','camera'],['older photographer with rangefinder','camera'],
['man carrying a pizza and flowers','pizza'],['construction worker with lunch','worker'],['house painter on a break','worker'],['window washer heading home','worker'],['barista taking out trash','worker'],['bookstore clerk with a stack of books','worker'],['nurse leaving shift','worker'],['chef with a bread crate','worker'],['florist with buckets','worker'],['record-store employee','worker'],
['teenagers sharing earbuds','youth'],['couple under one umbrella','umbrella'],['roller bag traveler','tourist'],['person carrying a birdcage','odd'],['guy with a mannequin arm','odd'],['woman with a giant hatbox','odd'],['mime on break','odd'],['person in sequins','odd'],['street magician with cards','odd'],['groom carrying his jacket','wedding'],
['student with drafting tube','student'],['architecture tour group','tour'],['saxophonist between sets','music'],['pigeon chaser','odd'],['street chess winner','odd'],['late courier with helmet','bike'],['messenger in a yellow slicker','bike'],['roller skater','skate'],['skate couple holding hands','skate'],['pizza guy on a skateboard','pizza'],
['movers carrying framed art','mover'],['movers with a side table','mover'],['delivery worker balancing boxes','worker'],['transit rider running for a bus','runner'],['fashion student in a dramatic coat','fashion'],['tourist with instant camera','camera'],['film student with clapperboard','camera'],['umbrella seller','umbrella'],['dog walker in rain boots','dogwalk'],['balloon bundle in wind','balloons'],
['street poet with flyers','odd'],['club kid with glitter','fashion'],['sleepy office worker','commuter'],['vendor carrying oranges','worker'],['pizza courier on bike','bike'],['movers carrying a couch uphill','mover'],['skater filming another skater','skate'],['cyclist ringing a bell','bike'],['bouquet delivery on foot','flowers'],['night worker with mop bucket','worker']
];
const EVENTS = [
['runaway veil','wedding','gasp'],['street chess upset','odd','crowd'],['petty cab argument','commuter','shout'],['busker steals a crowd','music','music'],['pizza box spill','pizza','shout'],['bike courier near-miss','bike','horn'],['umbrella turns inside out','umbrella','crowd'],['flowers dropped in a crosswalk','flowers','gasp'],['movers stuck on a stoop','mover','shout'],['late-night balloon escape','balloons','gasp'],
['dog bolts toward pigeons','dogwalk','bark'],['small protest chant','protest','chant'],['wedding band rounds a corner','wedding','music'],['street preacher draws hecklers','odd','crowd'],['violin case pops open','music','gasp'],['skateboard wheel scream','skate','skate'],['sudden downpour scramble','umbrella','crowd'],['delivery van double-parks','worker','horn'],['chef drops a baguette crate','worker','gasp'],['tour group blocks the lane','tour','crowd'],
['mirror almost breaks','mover','gasp'],['camera battery panic','camera','shout'],['suit runner misses the bus','runner','horn'],['coffee lid catastrophe','commuter','gasp'],['flower vendor swarmed','flowers','crowd'],['bar argument spills outside','odd','shout'],['street magician pulls a crowd','odd','applause'],['roller skater almost collides','skate','skate'],['rain hat rescue','umbrella','crowd'],['marching band warm-up','music','music'],
['politely tense portrait session','camera','crowd'],['wedding car honks through','wedding','horn'],['pizza exchange gone wrong','pizza','shout'],['bicycle chain slips','bike','hum'],['dog refuses to move','dogwalk','bark'],['bus doors close on a joke','commuter','crowd'],['street poet recitation','odd','music'],['club queue laugh burst','fashion','crowd'],['lost tourist map consultation','tourist','crowd'],['record-store crate drop','worker','gasp'],
['two skaters film a trick','skate','skate'],['quick sidewalk memorial','odd','crowd'],['flower petals in the wind','flowers','gasp'],['runner ties a shoe in crosswalk','runner','horn'],['transit bell and applause','commuter','applause'],['delivery bike cuts through steam','bike','hum'],['drummer busker duel','music','beat'],['balloons hit a sign','balloons','gasp'],['movers negotiate a couch pivot','mover','shout'],['distant thunder gathers a crowd','umbrella','thunder']
];
CS145.motifs = MOTIFS; CS145.templates = EVENTS;
function mmat(c,r=.78,m=0.02,e=0){ return new THREE.MeshStandardMaterial({color:lin(c), roughness:r, metalness:m, emissive:e?lin(c):0, emissiveIntensity:e}); }
function basicHuman(seed, palette){
  const rnd = (typeof mulberry !== 'undefined') ? mulberry(seed) : Math.random;
  const g = new THREE.Group();
  const skin = lin(['#f2ceb0','#dca77f','#c1845c','#9a6543','#71472e','#4d3020'][((rnd()*6)|0)]);
  const topC = lin(palette&&palette.top || ['#253447','#5f312a','#2d4238','#7d6a54','#5a4a74'][((rnd()*5)|0)]);
  const botC = lin(palette&&palette.bottom || ['#202226','#37435d','#51483e','#17181a'][((rnd()*4)|0)]);
  const torso = new THREE.Mesh(new THREE.BoxGeometry(.36,.58,.22), mmat(topC)); torso.position.y=1.03; g.add(torso);
  for(const sx of [-1,1]){ const leg=new THREE.Mesh(new THREE.BoxGeometry(.13,.68,.16), mmat(botC)); leg.position.set(sx*.09,.36,0); g.add(leg); const arm=new THREE.Mesh(new THREE.CylinderGeometry(.05,.06,.55,8), mmat(topC)); arm.position.set(sx*.23,.99,0); arm.rotation.z=sx*.1; g.add(arm); }
  const head = new THREE.Mesh(new THREE.SphereGeometry(.16,12,9), mmat(skin,.72)); head.position.y=1.45; g.add(head);
  if(rnd()<.7){ const hair=new THREE.Mesh(new THREE.SphereGeometry(.17,10,7,0,Math.PI*2,0,Math.PI*.55), mmat(['#1b1511','#3e2a1d','#6e4a2d','#b99966','#777'][((rnd()*5)|0)],.7)); hair.position.y=1.54; g.add(hair); }
  return g;
}
function bikeGroup(seed, label){
  const g = new THREE.Group(); const rider = basicHuman(seed);
  const dark = mmat('#242628',.55,.35), paint=mmat(choiceColour(label),.48,.18), tyre=mmat('#111',.95,.05);
  for(const sx of [-.38,.38]){ const w = new THREE.Mesh(new THREE.TorusGeometry(.18,.028,8,16), tyre); w.rotation.y=Math.PI/2; w.position.set(sx,.18,0); g.add(w); }
  const f = new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,.76,8).rotateZ(Math.PI/2), dark); f.position.set(0,.34,0); g.add(f);
  const d = new THREE.Mesh(new THREE.CylinderGeometry(.018,.018,.45,8).rotateZ(-.8), paint); d.position.set(-.05,.42,0); g.add(d);
  const h = new THREE.Mesh(new THREE.CylinderGeometry(.016,.016,.32,8).rotateZ(.9), dark); h.position.set(.18,.56,0); g.add(h);
  rider.position.y=0; rider.scale.setScalar(.98); g.add(rider); return g;
}
function skateGroup(seed, label){
  const g=new THREE.Group(), rider=basicHuman(seed);
  const board=new THREE.Mesh(new THREE.BoxGeometry(.52,.03,.14), mmat(choiceColour(label),.48,.18)); board.position.set(0,.08,0); g.add(board);
  for(const sx of [-.18,.18]) for(const sz of [-.05,.05]){ const wh=new THREE.Mesh(new THREE.CylinderGeometry(.028,.028,.02,10).rotateZ(Math.PI/2), mmat('#d9c16b',.5,.1)); wh.position.set(sx,.04,sz); g.add(wh); }
  rider.position.y=0; g.add(rider); return g;
}
function propGroup(seed, kind, label){
  if(kind==='bike') return bikeGroup(seed,label);
  if(kind==='skate') return skateGroup(seed,label);
  const g=new THREE.Group();
  if(kind==='mover'){
    const a=basicHuman(seed,{top:'#546276',bottom:'#2a2e35'}), b=basicHuman(seed+1,{top:'#7a5d47',bottom:'#2a2e35'}); a.position.x=-.42; b.position.x=.42; g.add(a,b);
    const sofa=new THREE.Mesh(new THREE.BoxGeometry(1.1,.42,.48), mmat('#6b5244',.86)); sofa.position.set(0,.9,0); g.add(sofa);
  } else {
    const p=basicHuman(seed); g.add(p);
    if(kind==='pizza'){ const box=new THREE.Mesh(new THREE.BoxGeometry(.28,.04,.28), mmat('#d9c9ab',.82)); box.position.set(.18,1.08,.16); g.add(box); }
    if(kind==='balloons'){ for(let i=0;i<5;i++){ const b=new THREE.Mesh(new THREE.SphereGeometry(.08,10,8), mmat(choiceColour(label+i),.45,.05,.25)); b.position.set(.12+i*.02,1.72+i*.08,.08*(i%2)); g.add(b); } }
    if(kind==='flowers'){ const wrap=new THREE.Mesh(new THREE.ConeGeometry(.08,.22,8), mmat('#d2c7a6',.85)); wrap.position.set(.16,1.06,.14); wrap.rotation.z=-.7; g.add(wrap); }
    if(kind==='camera'){ const cam=new THREE.Mesh(new THREE.BoxGeometry(.14,.09,.07), mmat('#111',.45,.3)); cam.position.set(.16,1.1,.14); g.add(cam); }
  }
  return g;
}
function choiceColour(seedish){
  const s=String(seedish||''); const cols=['#d44f44','#3b7fc2','#2f9a5f','#e0a742','#7a63c7','#d07a2d','#dddddd','#1b1c1e'];
  let h=0; for(let i=0;i<s.length;i++) h=(h*31+s.charCodeAt(i))>>>0; return cols[h%cols.length];
}
function spawnActor(label, kind, eventMode){
  if(!window.G || !G.scene) return null;
  const fromSide = Math.random()<.5 ? 'x':'z';
  const span=210;
  let x = fromSide==='x' ? (Math.random()<.5?-span:span) : R(-span,span);
  let z = fromSide==='z' ? (Math.random()<.5?-span:span) : R(-span,span);
  x += Player.x*0.15; z += Player.z*0.15;
  { const lim = ((window.SnapCity && SnapCity.island && SnapCity.island.edge) || 1e9) - 10; x = Math.max(-lim, Math.min(lim, x)); z = Math.max(-lim, Math.min(lim, z)); if (typeof collidePoint === "function"){ const c = collidePoint(x, z, 0.6); x = c[0]; z = c[1]; } }
  const group = (kind==='bike'||kind==='skate') ? (kind==='bike'?bikeGroup(Math.random()*1e6|0,label):skateGroup(Math.random()*1e6|0,label)) : propGroup(Math.random()*1e6|0,kind,label);
  group.position.set(x,H(x,z)+0.02,z);
  G.scene.add(group);
  const tx = -x + R(-60,60), tz = -z + R(-60,60);
  const ang = Math.atan2(tz-z, tx-x);
  group.rotation.y = -ang + Math.PI/2;
  return {label,kind,g:group,x,z,tx,tz,ang,speed:eventMode?R(1.8,3.8):R(1.2,3.2),life:eventMode?R(18,38):R(30,70),stage:0,event:eventMode,phase:R(0,6),cueT:0,resolve:false};
}
function ambientCue(a){
  if(Math.hypot(a.x-Player.x,a.z-Player.z)>42) return;
  const map = { skate:'skate', bike:'hum', music:'music', protest:'chant', balloons:'gasp', mover:'shout', pizza:'crowd', dogwalk:'bark', wedding:'music', commuter:'crowd' };
  const snd = map[a.kind] || (a.event && a.sound) || null;
  if(snd) try{ SND.play(snd, a.x, a.z, 0.65); }catch(e){}
  if(S.custom && S.custom.eventPopups==='on' && (S.custom.eventNotify==='clue'||S.custom.eventNotify==='none')) toast(`You hear ${a.label} ${dirCue(a.x,a.z)}.`, 1700);
}
function spawnAmbient(){
  if(CS145.acts.length>18) return;
  const [label, kind] = MOTIFS[(Math.random()*MOTIFS.length)|0];
  const a = spawnActor(label, kind, false); if(!a) return;
  a.theme = nearestTheme();
  CS145.acts.push(a);
  if(Math.random()<0.35) ambientCue(a);
}
function spawnEvent(){
  if(CS145.events.length>3) return;
  const [label, kind, sound] = EVENTS[(Math.random()*EVENTS.length)|0];
  const e = spawnActor(label, kind, true); if(!e) return; e.sound=sound; e.variants=[`The ${label} gathers itself.`,`The ${label} changes shape.`,`The ${label} starts to resolve.`];
  if(sound) try{ SND.play(sound, e.x, e.z, 0.95); }catch(err){}
  if(S.custom && S.custom.eventPopups==='on' && (S.custom.eventNotify==='clue'||S.custom.eventNotify==='none')) toast(`A ${label} is unfolding ${dirCue(e.x,e.z)}.`, 2200);
  CS145.events.push(e);
}
function updateActor(a,dt){
  if(!a||!a.g) return false;
  a.life -= dt;
  if(a.life < 12 && !a.resolve){ a.resolve = true; a.tx += R(-120,120); a.tz += R(-120,120); }
  const dx=a.tx-a.x, dz=a.tz-a.z, d=Math.hypot(dx,dz) || 1;
  if(d < 3){ if(a.event && a.stage < 2){ a.stage++; a.tx += R(-40,40); a.tz += R(-40,40); a.life += 6; if(Math.random()<0.45 && a.sound) try{ SND.play(a.sound, a.x, a.z, 0.75); }catch(e){} } else { a.life = -1; } }
  const sp = a.speed * (a.kind==='bike'?1.25:a.kind==='skate'?1.15:1);
  { let nx = a.x + dx/d*sp*dt, nz = a.z + dz/d*sp*dt;
    const c = (typeof collidePoint === "function") ? collidePoint(nx, nz, 0.45) : [nx, nz];
    { const lim = ((window.SnapCity && SnapCity.island && SnapCity.island.edge) || 1e9) - 6; if (Math.abs(c[0]) > lim || Math.abs(c[1]) > lim){ c[0] = Math.max(-lim, Math.min(lim, c[0])); c[1] = Math.max(-lim, Math.min(lim, c[1])); a.stuck = 1; } }
    if (Math.abs(c[0]-nx) + Math.abs(c[1]-nz) > 1e-4){

      nx = c[0]; nz = c[1]; a.stuck = (a.stuck||0) + dt;
      if (a.stuck > 0.5){ a.stuck = 0; const sx = (Math.round(a.x/P - 0.5) + 0.5)*P, sz = (Math.round(a.z/P - 0.5) + 0.5)*P;
        if (Math.abs(a.x - sx) < Math.abs(a.z - sz)){ a.tx = sx + (a.x > sx ? 7 : -7); a.tz = a.z + (Math.random()<0.5?-1:1)*R(40,90); }
        else { a.tz = sz + (a.z > sz ? 7 : -7); a.tx = a.x + (Math.random()<0.5?-1:1)*R(40,90); } }
    } else a.stuck = 0;
    a.x = nx; a.z = nz; }
  a.g.position.set(a.x, H(a.x,a.z)+0.02, a.z);
  a.g.rotation.y = -Math.atan2(dz,dx) + Math.PI/2;
  a.g.rotation.z = Math.sin(Game.t*1.6 + a.phase) * (a.kind==='skate'?0.04:0.015);
  if(a.kind==='bike'||a.kind==='skate') a.g.position.y += Math.abs(Math.sin(Game.t*8+a.phase))*0.01;
  if(a.event && a.life < 6){ a.g.traverse(o=>{ if(o.material && 'transparent' in o.material){ o.material.transparent=true; o.material.opacity=Math.max(0,Math.min(1,a.life/6)); } }); }
  if(a.life <= 0 || Math.abs(a.x)>520 || Math.abs(a.z)>520){ try{ G.scene.remove(a.g); }catch(e){} return false; }
  return true;
}

function weatherName(){ if(S.storm) return 'thunderstorm'; if(S.snow) return 'snow'; if(S.rain) return 'rain'; if(S.fog) return 'fog'; return 'clear'; }

function ready145(){
  if(CS145.ready || !window.G || !G.scene || !window.Game) return;
  CS145.ready = true;
  ensurePerfDefaults();
  enforcePrecip('storm');
  console.log('[Contact Sheet v14.5] ambient acts, events, and archive readings active.');
}
if(typeof gameplayUpdate==='function'){
  const _gp145 = gameplayUpdate;
  gameplayUpdate = function(dt){
    const r = _gp145.apply(this, arguments);
    try{
      ready145();
      ensurePerfDefaults();
      enforcePrecip();
      CS145.ambientTimer -= dt; CS145.eventTimer -= dt;
      if(CS145.ambientTimer<=0){ CS145.ambientTimer = R(1.8,4.6); spawnAmbient(); }
      if(CS145.eventTimer<=0){ CS145.eventTimer = R(24,48); spawnEvent(); }
      CS145.acts = CS145.acts.filter(a=>updateActor(a,dt));
      CS145.events = CS145.events.filter(a=>updateActor(a,dt));
    }catch(e){}
    return r;
  };
}
wirePrecipExclusivity();
setInterval(()=>{ try{ ensurePerfDefaults(); enforcePrecip(); }catch(e){} }, 1200);
})();

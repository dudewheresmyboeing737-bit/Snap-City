function photoFilename(p){ const m = p.meta || {}; const place = (m.street || "snap-city").replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase().slice(0, 32); return `snap-city-${String(p.frameNo ?? 0).padStart(3, "0")}-${place || "sf"}${p.edited ? "-edit" : ""}.jpg`; }
async function savePhoto(p){
  const blob = p.edited || p.orig; if (!blob) return;
  const name = photoFilename(p);
  if (UI.downloads){
    try { const r = await UI.downloads.save({ filename:name, data:blob }); if (r && r.status === "saved") toast("Saved to your device.", 1400); return; }
    catch(e){ if (e && e.code === "declined") return; if (e && e.code === "rate_limited"){ toast("A save is already waiting for you to confirm.", 1600); return; } if (e && e.code !== "unavailable"){ toast("Couldn't save that file.", 1600); return; } UI.downloads = null; }
  }

  const a = document.createElement("a"), url = URL.createObjectURL(blob); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
}
function canShareFiles(){ try { return !!(navigator.canShare && navigator.share && navigator.canShare({ files:[new File([new Blob(["x"], { type:"image/jpeg" })], "t.jpg", { type:"image/jpeg" })] })); } catch(e){ return false; } }
async function sharePhoto(p){
  const blob = p.edited || p.orig; if (!blob) return; const m = p.meta || {};
  const file = new File([blob], photoFilename(p), { type:"image/jpeg" });
  const text = [m.bodyName, m.filmName, m.N ? `${fmtA(m.N)} ${fmtShutter(m.t)}` : "", m.street].filter(Boolean).join(" · ");
  try { if (canShareFiles()){ await navigator.share({ files:[file], title:"Snap City", text }); return; } } catch(e){ if (e && e.name === "AbortError") return; }
  toast("Sharing isn't available here, so it's saving instead.", 1800); savePhoto(p);
}

const PEEK = { el:null, t:0, url:null, rec:null };
function showPeek(rec){
  if (!rec || !rec.orig || (S && S.custom.shotPreview === "off")) return;
  if (!PEEK.el){ const d = document.createElement("div"); d.id = "shotPeek"; d.className = "interactive";
    d.innerHTML = `<img alt="The frame you just took"><div class="pk-bar"><span class="pk-meta"></span><button data-pk="save" title="Save JPEG">⤓</button><button data-pk="share" title="Share">↗</button></div>`;
    document.body.appendChild(d); PEEK.el = d;
    d.addEventListener("pointerdown", ev => ev.stopPropagation(), true);
    d.addEventListener("click", ev => { ev.preventDefault(); ev.stopPropagation(); const b = ev.target.closest("[data-pk]"); const r = PEEK.rec; if (!r) return;
      if (b && b.dataset.pk === "save") savePhoto(r); else if (b && b.dataset.pk === "share") sharePhoto(r);
      else { hidePeek(true); if (document.pointerLockElement) document.exitPointerLock(); openLightbox(r.id); } }, true);
    d.addEventListener("mouseenter", () => { PEEK.hold = true; }); d.addEventListener("mouseleave", () => { PEEK.hold = false; PEEK.t = Math.max(PEEK.t, 1.2); }); }
  if (PEEK.url) URL.revokeObjectURL(PEEK.url); PEEK.url = URL.createObjectURL(rec.orig); PEEK.rec = rec;
  const img = PEEK.el.querySelector("img"); img.src = PEEK.url; const m = rec.meta || {};
  img.className = m.instant ? "instant" : ""; PEEK.el.querySelector(".pk-meta").textContent = `#${rec.frameNo ?? ""} · ${m.filmName || ""}`;
  PEEK.el.querySelector('[data-pk="share"]').style.display = canShareFiles() ? "" : "none";
  PEEK.el.classList.remove("out"); void PEEK.el.offsetWidth; PEEK.el.classList.add("in"); PEEK.t = ({ short:2, normal:3.5, long:6 })[S.custom.shotPreviewTime] ?? 3.5;
}
function hidePeek(now){ if (!PEEK.el) return; PEEK.el.classList.remove("in"); PEEK.el.classList.add("out"); PEEK.t = 0; if (now){} }
(function(){ const base = onShotTaken; onShotTaken = function(rec){ base(rec); showPeek(rec); }; })();
(function(){ const base = gameplayUpdate; gameplayUpdate = function(dt){ base(dt); if (PEEK.el && PEEK.t > 0 && !PEEK.hold){ PEEK.t -= dt; if (PEEK.t <= 0) hidePeek(); } }; })();

(function(){ const base = renderLbSide; renderLbSide = function(p, info){ base(p, info); const actions = $("#lbside .actions"); if (!actions) return;
  const old = $("#lbDown"); if (old) old.remove();
  if (!$("#lbSaveJpg")){ const b = document.createElement("button"); b.className = "btn small"; b.id = "lbSaveJpg"; b.textContent = "Save JPEG"; b.onclick = () => savePhoto(p); actions.prepend(b); }
  if (!$("#lbShare") && canShareFiles()){ const b = document.createElement("button"); b.className = "btn small alt"; b.id = "lbShare"; b.textContent = "Share"; b.onclick = () => sharePhoto(p); actions.prepend(b); } }; })();
Object.assign(V7_DEFAULTS, { shotPreview:"on", shotPreviewTime:"normal" });
(function(){ const base = menuSettings; menuSettings = function(){ const c = S.custom, seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  return base() + `<div class="sectionhead">After the shutter</div>
    <div class="formrow"><label>Photo preview</label>${seg("shotPreview",[["on","Show in the corner"],["off","Off (true film: wait for the contact sheet)"]])}</div>
    <div class="formrow"><label>Preview time</label>${seg("shotPreviewTime",[["short","2 s"],["normal","3.5 s"],["long","6 s"]])}<span class="spec">Click the preview to open it; ⤓ saves a JPEG, ↗ shares it.</span></div>`; }; })();

(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const X = SC.v57 = { crash: null, ufo: null, crashT: 150 + Math.random() * 120, ufoT: 420 + Math.random() * 400 };
  const rnd = (a, b) => a + Math.random() * (b - a), pick = a => a[(Math.random() * a.length) | 0];
  const mats = {}; const m = (c, r, mt, em, op) => { const k = [c, r, mt, em, op].join("|"); return mats[k] || (mats[k] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: r ?? .6, metalness: mt || 0, emissive: em ? lin(c) : 0x000000, emissiveIntensity: em || 0, transparent: op !== undefined, opacity: op ?? 1, depthWrite: op === undefined })); };
  const BOX = new THREE.BoxGeometry(1,1,1), SPH = new THREE.SphereGeometry(.5,16,10), CYL = new THREE.CylinderGeometry(.5,.5,1,16);
  const part = (g, geo, mm, x, y, z, sx, sy, sz) => { const o = new THREE.Mesh(geo, mm); o.position.set(x, y, z); o.scale.set(sx, sy, sz); g.add(o); return o; };
  const gy = (x, z) => { try{ return groundY(x, z); }catch(e){ return H(x, z) + .16; } };
  const person = seed => SC.makePerson ? SC.makePerson(seed | 0, false) : null;
  const custom = k => (typeof S !== "undefined" && S && S.custom) ? S.custom[k] : undefined;

  function migrate(s){ if (s && s.custom && !s.custom._sc57){ s.custom.menuTheme = "nikon"; s.custom._sc57 = 1; } return s; }
  if (typeof loadState === "function"){ const b = loadState; window.loadState = function(){ return migrate(b.apply(this, arguments)); }; }
  if (typeof defaultState === "function"){ const b = defaultState; window.defaultState = function(){ return migrate(b.apply(this, arguments)); }; }

  function notify(name, x, z){
    try{ if (SC.life && SC.life.feed && custom("eventNotices") !== "off"){ const E = { x, z, done: false }; SC.life.feed.unshift({ E, name, t: 0 }); return E; } }catch(e){}
    return { done: false };
  }
  function streetName(x, z){ try{ const l = locationName(x, z); return (l && l.street) ? l.street.split(",")[0] : "nearby"; }catch(e){ return "nearby"; } }
  function nearIntersection(){
    const cands = [];
    for (let i = -NB - 1; i <= NB; i++) for (let j = -NB - 1; j <= NB; j++){
      const x = (i + .5) * P, z = (j + .5) * P, d = Math.hypot(x - Player.x, z - Player.z);
      if (d > 35 && d < 110) cands.push({ x, z });
    }
    return cands.length ? pick(cands) : null;
  }

  function carGroup(color){
    let g;
    try{ g = buildCarGroup(pick(["sedan","hatch","wagon","classic","van"]), lin(color), {}, [Life.carLightMats[0], CarMats.tailOff]); }
    catch(e){ g = new THREE.Group(); part(g, BOX, m(color, .4, .3), 0, .7, 0, 1.9, 1, 4.4); }
    return g;
  }
  function startCrash(){
    const at = nearIntersection(); if (!at) return false;
    const g1 = carGroup(pick(CAR_COLORS)), g2 = carGroup(pick(CAR_COLORS));
    const y = H(at.x, at.z) + .02;
    g1.position.set(at.x - 16, y, at.z - 1.3); g1.rotation.y = Math.PI / 2;
    g2.position.set(at.x + 1.3, y, at.z + 16); g2.rotation.y = Math.PI;
    G.scene.add(g1, g2);
    const glass = new THREE.Group(); for (let k = 0; k < 18; k++) part(glass, BOX, m("#cfe3ea", .1, .3, 0, .8), rnd(-1.5, 1.5), .02, rnd(-1.5, 1.5), .12, .01, .08).rotation.y = Math.random() * 6; glass.position.set(at.x, y, at.z); glass.visible = false; G.scene.add(glass);
    const hazards = [g1, g2].map(g => { const l = part(g, SPH, m("#ffb030", .3, 0, 2.5), 0, .9, 2.25, .18, .12, .08); return l; });
    X.crash = { at, g1, g2, glass, hazards, t: 0, hit: false, people: [], police: null, E: notify("A car crash at " + streetName(at.x, at.z), at.x, at.z), y };
    return true;
  }
  function crashTick(dt, t){
    const C = X.crash; if (!C) return; C.t += dt;
    const { at, g1, g2, y } = C;
    if (!C.hit){
      const u = Math.min(1, C.t / 2.2);
      g1.position.x = at.x - 16 + u * 15.2; g2.position.z = at.z + 16 - u * 15.6;
      if (u >= 1){
        C.hit = true; C.glass.visible = true;
        g1.rotation.y = Math.PI / 2 + .35; g2.rotation.y = Math.PI - .5; g2.position.x += .6;
        try{ SND.play("crash", at.x, at.z, 1); }catch(e){ try{ SND.play("horn", at.x, at.z, 1); }catch(e2){} }
        for (const [g, s] of [[g1, 1], [g2, -1]]){ const p = person(at.x * 7 + s); if (p){ p.g.position.set(g.position.x + s * 1.6, gy(g.position.x, g.position.z), g.position.z + 1.2); G.scene.add(p.g); C.people.push({ p, role: "driver", s }); } }
        for (let k = 0; k < 5; k++){ const a = Math.random() * 6.28, r = rnd(5, 9), x = at.x + Math.cos(a) * r, z = at.z + Math.sin(a) * r; const p = person(at.z * 3 + k); if (!p) continue; p.g.position.set(x, gy(x, z), z); p.g.lookAt(at.x, p.g.position.y, at.z); G.scene.add(p.g); C.people.push({ p, role: pick(["phone","point","handsface","phone"]) }); }
        toast("Screech — then a crunch of metal nearby.", 2200);
      }
      return;
    }
    const smoke = C.t < 40 && typeof Smoke !== "undefined";
    if (smoke && Math.random() < .5){ try{ Smoke.emit(g1.position.x + Math.sin(g1.rotation.y) * 2, y + 1, g1.position.z + Math.cos(g1.rotation.y) * 2, rnd(-.2, .2), 1.2, rnd(-.2, .2), .5, 3, .35, new THREE.Color(.55, .55, .56), 0, .9); }catch(e){} }
    for (const h of C.hazards) h.material.emissiveIntensity = Math.sin(t * 6) > 0 ? 2.5 : 0;
    for (const q of C.people){ const p = q.p, s = Math.sin(t * 2 + p.phase);
      if (q.role === "driver"){ const other = C.people.find(o => o.role === "driver" && o !== q); if (other) p.g.lookAt(other.p.g.position.x, p.g.position.y, other.p.g.position.z); p.armR.rotation.x = -1.5 + s * .5; p.armL.rotation.x = -.8 - Math.max(0, -s) * .6; }
      else if (q.role === "phone"){ p.armR.rotation.x = -1.7; p.armL.rotation.x = -1.5; }
      else if (q.role === "point"){ p.armR.rotation.x = -1.6; }
      else { p.armL.rotation.x = p.armR.rotation.x = -2.2; } }
    if (C.t > 25 && !C.police){
      const pc = carGroup("#f2f2ee"); const bar = new THREE.Group(); part(bar, BOX, m("#ff3344", .3, 0, 2), -.35, 0, 0, .55, .12, .22); part(bar, BOX, m("#3388ff", .3, 0, 2), .35, 0, 0, .55, .12, .22); bar.position.set(0, 1.55, -.3); pc.add(bar);
      pc.position.set(C.at.x - 60, C.y, C.at.z + 1.3); pc.rotation.y = Math.PI / 2; G.scene.add(pc); C.police = { g: pc, bar, officer: null };
    }
    if (C.police){ const pc = C.police; if (pc.g.position.x < C.at.x - 9) pc.g.position.x += dt * 12;
      else if (!pc.officer){ const o = person(9911); if (o){ o.g.position.set(pc.g.position.x + 1, gy(pc.g.position.x, pc.g.position.z), pc.g.position.z - 1.4); part(o.g, BOX, m("#1d2d44", .6), 0, o.head.position.y - .5, 0, .44, .5, .28); part(o.head, CYL, m("#1d2d44", .6), 0, .12, 0, .32, .1, .32); G.scene.add(o.g); pc.officer = o; } }
      if (pc.officer){ pc.officer.g.lookAt(C.at.x, pc.officer.g.position.y, C.at.z); pc.officer.armR.rotation.x = -.9 + Math.sin(t * 1.5) * .2; }
      pc.bar.children.forEach((l, i) => l.material.emissiveIntensity = ((t * 4 + i) % 2) < 1 ? 3 : .2); }
    if (C.t > 100){ for (const o of [C.g1, C.g2, C.glass, C.police && C.police.g, C.police && C.police.officer && C.police.officer.g]) if (o) G.scene.remove(o); for (const q of C.people) G.scene.remove(q.p.g); if (C.E) C.E.done = true; X.crash = null; }
  }

  function startUFO(){
    const spots = (World.specials || []).filter(s => Math.hypot(s.cx - Player.x, s.cz - Player.z) < 160);
    let x, z; if (spots.length){ const s = pick(spots); x = s.cx + rnd(-8, 8); z = s.cz + rnd(-8, 8); }
    else { const at = nearIntersection(); if (!at) return false; x = at.x + rnd(-3, 3); z = at.z + rnd(-3, 3); }
    const g = new THREE.Group();
    part(g, SPH, m("#b8bcc0", .25, .8), 0, 0, 0, 12, 2.4, 12); part(g, SPH, m("#9fd8ff", .1, .3, .6, .75), 0, 1.1, 0, 4.6, 3.2, 4.6);
    const ring = new THREE.Group(); g.add(ring);
    for (let k = 0; k < 12; k++){ const a = k / 12 * 6.283; part(ring, SPH, m(pick(["#7dff8a","#ff5a5a","#6ad1ff","#ffd24a"]), .2, 0, 3), Math.cos(a) * 5.6, -.3, Math.sin(a) * 5.6, .5, .5, .5); }
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 5.5, 1, 24, 1, true), new THREE.MeshBasicMaterial({ color: 0xbfffd0, transparent: true, opacity: .0, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
    g.add(beam);
    const gy0 = gy(x, z); g.position.set(x + 260, 140, z - 260); G.scene.add(g);
    const victims = []; for (let k = 0; k < 1 + ((Math.random() * 2) | 0); k++){ const p = person(x * 13 + k); if (!p) continue; p.g.position.set(x + rnd(-1.2, 1.2), gy0, z + rnd(-1.2, 1.2)); G.scene.add(p.g); victims.push(p); }
    const crowd = []; for (let k = 0; k < 6; k++){ const a = Math.random() * 6.28, r = rnd(8, 14), px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r; const p = person(z * 7 + k); if (!p) continue; p.g.position.set(px, gy(px, pz), pz); p.g.lookAt(x, p.g.position.y, z); G.scene.add(p.g); crowd.push({ p, act: pick(["point","handsface","phone","run"]) }); }
    X.ufo = { g, ring, beam, x, z, gy0, t: 0, victims, crowd, E: notify("Strange lights over " + streetName(x, z) + "!", x, z) };
    toast("A low hum fills the air. Everyone is looking up…", 2600);
    return true;
  }
  function ufoTick(dt, t){
    const U = X.ufo; if (!U) return; U.t += dt; const hover = U.gy0 + 16;
    U.ring.rotation.y += dt * 2.5;
    if (U.t < 8){ const u = U.t / 8, e = 1 - Math.pow(1 - u, 3); U.g.position.set(U.x + 260 * (1 - e), 140 + (hover - 140) * e, U.z - 260 * (1 - e)); }
    else if (U.t < 22){
      U.g.position.set(U.x + Math.sin(t * .8) * .4, hover + Math.sin(t * 1.3) * .3, U.z);
      const bo = Math.min(.55, (U.t - 8) / 2); U.beam.material.opacity = bo * (.8 + Math.sin(t * 9) * .2); U.beam.scale.set(1, hover - U.gy0, 1); U.beam.position.y = -(hover - U.gy0) / 2;
      const lift = Math.max(0, (U.t - 11) / 10);
      U.victims.forEach((p, i) => { p.g.position.y = U.gy0 + lift * lift * (hover - U.gy0 - 1); p.g.rotation.y += dt * (2 + i); p.armL.rotation.x = p.armR.rotation.x = -2.6 + Math.sin(t * 6 + i) * .4; p.g.visible = lift < .98; });
    } else {
      U.beam.material.opacity = Math.max(0, U.beam.material.opacity - dt);
      const u = (U.t - 22) / 3; U.g.position.set(U.x - u * u * 400, hover + u * u * 180, U.z + u * u * 120);
      if (U.t > 26){ G.scene.remove(U.g); for (const p of U.victims) G.scene.remove(p.g); for (const c of U.crowd) G.scene.remove(c.p.g); if (U.E) U.E.done = true; X.ufo = null; return; }
    }
    for (const c of U.crowd){ const p = c.p;
      if (c.act === "point") p.armR.rotation.x = -2.2; else if (c.act === "handsface") p.armL.rotation.x = p.armR.rotation.x = -2.4; else if (c.act === "phone"){ p.armR.rotation.x = -2.1; p.head.rotation.x = -.4; }
      else { const d = new THREE.Vector3(p.g.position.x - U.x, 0, p.g.position.z - U.z).normalize(); { const L = ((SC.island && SC.island.edge) || 1e9) - 3; p.g.position.x = Math.max(-L, Math.min(L, p.g.position.x + d.x * dt * 2.5)); p.g.position.z = Math.max(-L, Math.min(L, p.g.position.z + d.z * dt * 2.5)); } p.g.position.y = gy(p.g.position.x, p.g.position.z); p.g.rotation.y = Math.atan2(d.x, d.z); const sw = Math.sin(t * 10) * .8; p.armL.rotation.x = sw; p.armR.rotation.x = -sw; } }
  }

  if (typeof menuSettings === "function"){
    const base = menuSettings;
    window.menuSettings = function(){
      const c = S.custom; if (c.crashes === undefined) c.crashes = "on"; if (c.ufos === undefined) c.ufos = "on";
      const row = (key, label, spec) => `<div class="formrow"><label>${label}</label><div class="seg" data-seg44="${key}">${[["on","On"],["off","Off"]].map(([v,l]) => `<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div><span class="spec">${spec}</span></div>`;
      return row("crashes", "Car crashes", "Now and then two cars collide at a nearby junction: drivers argue, onlookers film, the police turn up.") + row("ufos", "Alien visits", "Very rarely a saucer drops out of the sky and beams someone up. More likely at night.") + base.apply(this, arguments);
    };
  }

  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{
        if (typeof S !== "undefined" && S && Game.started){
          const t = performance.now() / 1000;
          if (!X.crash && custom("crashes") !== "off" && (X.crashT -= dt) <= 0){ X.crashT = rnd(240, 480); startCrash(); }
          const night = World.timeDef && (World.timeDef.id === "night" || World.timeDef.id === "blue");
          if (!X.ufo && custom("ufos") !== "off" && (X.ufoT -= dt * (night ? 2.5 : 1)) <= 0){ X.ufoT = rnd(700, 1400); startUFO(); }
          crashTick(dt, t); ufoTick(dt, t);
        }
      }catch(e){ console.warn("[Snap City 57]", e); }
      return r;
    };
  }
  SC.startCrash = startCrash; SC.startUFO = startUFO;
})();

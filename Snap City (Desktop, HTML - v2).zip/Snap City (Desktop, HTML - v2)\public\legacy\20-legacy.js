(function(){
"use strict";

const V6_DEFAULTS = {
  editorOverlays: "on",
  editorPersonality: "on",
  currentEditor: "formalist",
  waitMode: "on",
  sceneEcology: "on",
  neighborhoodIdentity: "on",
  weatherPolish: "on",
  essayEnhanced: "on",
  difficultyProfile: "street",
  graphicsEnhance: "on",
  accessibility: {
    reducedShake: "false",
    motionComfort: "false",
    colorFilter: "none",
    timeScale: 1.0,
    textSize: "normal"
  },
  overlayLayers: {
    thirds: true, subject: true, leading: false, dof: false, clipping: false, motion: false, heatmap: false
  }
};

const _loadStateBase = loadState;
loadState = function(){
  const s = _loadStateBase();
  if (s){
    s.custom = s.custom || {};
    const defs = JSON.parse(JSON.stringify(V6_DEFAULTS));

    for (const k of Object.keys(defs)){
      if (k === "accessibility"){
        s.custom.accessibility = Object.assign({}, defs.accessibility, s.custom.accessibility || {});
      } else if (k === "overlayLayers"){
        s.custom.overlayLayers = Object.assign({}, defs.overlayLayers, s.custom.overlayLayers || {});
      } else if (s.custom[k] === undefined){
        s.custom[k] = defs[k];
      }
    }
  }
  return s;
};

const _defaultStateBase = defaultState;
defaultState = function(free){
  const s = _defaultStateBase(free);
  s.custom = s.custom || {};
  const defs = JSON.parse(JSON.stringify(V6_DEFAULTS));
  for (const k of Object.keys(defs)){
    if (k === "accessibility"){
      s.custom.accessibility = Object.assign({}, defs.accessibility, s.custom.accessibility || {});
    } else if (k === "overlayLayers"){
      s.custom.overlayLayers = Object.assign({}, defs.overlayLayers, s.custom.overlayLayers || {});
    } else {
      s.custom[k] = defs[k];
    }
  }
  return s;
};

const EDITORS = {
  formalist: {
    name: "Eleanor Vance", type: "The Formalist",
    desc: "Geometry, discipline, tonal control, layered scenes.",
    emphasis: { comp: 1.25, subj: 0.9, light: 1.1, sharp: 1.0, color: 1.0 },
    quotes: {
      high: "The geometry holds. Every line earns its place in the frame.",
      mid: "The structure is there, but the discipline wavers at the edges.",
      low: "Form requires intention. This feels discovered, not built."
    }
  },
  humanist: {
    name: "Marcus Reyes", type: "The Humanist",
    desc: "Gesture, intimacy, emotion, relationships between people.",
    emphasis: { comp: 0.9, subj: 1.35, light: 0.95, sharp: 0.95, color: 0.9 },
    quotes: {
      high: "You found the breath between two strangers. That's the photograph.",
      mid: "The gesture is half-formed. Wait for the body to finish its sentence.",
      low: "Where is the human moment? I see a street, not a story."
    }
  },
  documentarian: {
    name: "Sarah Okafor", type: "The Documentarian",
    desc: "Place, local stories, events, specificity.",
    emphasis: { comp: 1.0, subj: 1.1, light: 1.0, sharp: 1.05, color: 1.0 },
    quotes: {
      high: "This is a place at a moment. It will not look this way again.",
      mid: "The street is here, but the story hasn't arrived yet.",
      low: "A document without a subject is just a record. What is this about?"
    }
  },
  tabloid: {
    name: "Jimmy 'Flash' Doyle", type: "The Tabloid",
    desc: "Immediacy, confrontation, urgency, rare moments.",
    emphasis: { comp: 0.85, subj: 1.3, light: 0.9, sharp: 1.1, color: 0.95 },
    quotes: {
      high: "Now THAT'S a frame. Front page material, kid.",
      mid: "You're close, but you flinched. Get in there next time.",
      low: "Too polite. Street photography isn't a tea party. Get closer."
    }
  },
  curator: {
    name: "Dr. Anya Lindqvist", type: "The Art-Book Curator",
    desc: "Coherence across a portfolio, recurring motifs, ambiguity.",
    emphasis: { comp: 1.1, subj: 1.0, light: 1.05, sharp: 0.95, color: 1.15 },
    quotes: {
      high: "This image asks a question it doesn't answer. That's what makes it last.",
      mid: "A single image can be pretty. Does it belong to something larger?",
      low: "Technically competent, but it doesn't resonate beyond itself."
    }
  }
};

function currentEditor(){
 const all=Object.values(EDITORS), emphasis={};
 for(const k of Object.keys(all[0].emphasis)) emphasis[k]=all.reduce((v,e)=>v+e.emphasis[k],0)/all.length;
 return {name:"The Photo Desk",type:"Combined editorial review",desc:all.map(e=>e.desc).join(" "),emphasis,quotes:all[0].quotes};
}

function editorAdjustedScore(baseScore, cats){
  const ed = currentEditor();
  let weighted = 0, totalW = 0;
  for (const k of Object.keys(cats)){
    const w = ed.emphasis[k] || 1;
    weighted += cats[k] * w;
    totalW += w;
  }
  return Math.round(weighted / totalW);
}

function editorQuote(score){
  const band=score>=75?"high":score>=45?"mid":"low";
  return Object.values(EDITORS).map(e=>e.type+": "+e.quotes[band]).join(" • ");
}

const Overlay = {
  canvas: null, ctx: null, img: null,
  layers: {},
  init(){
    this.canvas = $("#lbOverlay");
    this.ctx = this.canvas.getContext("2d");
    this.img = $("#lbimg");
  },
  resize(){
    if (!this.canvas || !this.img) return;
    const r = this.img.getBoundingClientRect();
    if (r.width < 10) return;
    this.canvas.width = r.width;
    this.canvas.height = r.height;
    this.canvas.style.width = r.width + "px";
    this.canvas.style.height = r.height + "px";
  },
  clear(){ if (this.ctx) this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height); },
  draw(p){
    if (!this.ctx) this.init();
    if (!this.ctx) return;
    this.clear();
    if (!p || !p.judged) return;
    const L = S.custom.overlayLayers || {};
    const W = this.canvas.width, H = this.canvas.height;
    const m = p.meta;
    const ctx = this.ctx;
    ctx.lineWidth = 2;
    ctx.font = "600 11px 'Barlow Condensed', sans-serif";

    if (L.thirds){
      ctx.strokeStyle = "rgba(232,163,61,.5)"; ctx.lineWidth = 1.5;
      for (let i = 1; i < 3; i++){ ctx.beginPath(); ctx.moveTo(W*i/3, 0); ctx.lineTo(W*i/3, H); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, H*i/3); ctx.lineTo(W, H*i/3); ctx.stroke(); }

      ctx.fillStyle = "rgba(232,163,61,.7)";
      for (let i = 1; i < 3; i++) for (let j = 1; j < 3; j++){ ctx.beginPath(); ctx.arc(W*i/3, H*j/3, 4, 0, Math.PI*2); ctx.fill(); }
    }

    const subs = (m.subjects || []).filter(s => s.vis > 0.3 && s.kind !== "car");
    if (L.subject && subs.length){
      const prim = subs.sort((a,b) => b.area - a.area)[0];
      if (prim){
        const sw = Math.max(30, Math.sqrt(prim.area) * W * 0.15);
        const sh = sw * 1.3;
        const sx = W * 0.5, sy = H * 0.5;

        const px = (prim.px !== undefined) ? prim.px * W : sx;
        const py = (prim.py !== undefined) ? prim.py * H : sy;
        ctx.strokeStyle = "#c0362c"; ctx.lineWidth = 2.5;
        ctx.strokeRect(px - sw/2, py - sh/2, sw, sh);

        if (prim.heading !== undefined){
          const dx = Math.sin(prim.heading) * 30, dy = -Math.cos(prim.heading) * 30;
          ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + dx, py + dy); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(px + dx, py + dy); ctx.lineTo(px + dx - dx*0.3 - dy*0.2, py + dy + dy*0.3 - dx*0.2); ctx.lineTo(px + dx - dx*0.3 + dy*0.2, py + dy + dy*0.3 + dx*0.2); ctx.closePath(); ctx.fillStyle = "#c0362c"; ctx.fill();
        }
      }
    }

    if (L.leading){
      ctx.strokeStyle = "rgba(100,180,255,.4)"; ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 4]);

      const hy = H * 0.6;
      ctx.beginPath(); ctx.moveTo(0, hy); ctx.lineTo(W, hy); ctx.stroke();

      for (const fx of [0.15, 0.85]){ ctx.beginPath(); ctx.moveTo(W*fx, H); ctx.lineTo(W*0.5, hy); ctx.stroke(); }
      ctx.setLineDash([]);
    }

    if (L.dof && m.stats && m.stats.dofNear !== undefined){
      const focusY = H * (0.4 + (m.stats.focusDist || 5) * 0.03);
      const dofH = Math.min(H * 0.3, (m.stats.dofFar - m.stats.dofNear) * H * 0.03);
      ctx.fillStyle = "rgba(232,163,61,.12)";
      ctx.fillRect(0, focusY - dofH/2, W, dofH);
      ctx.strokeStyle = "rgba(232,163,61,.3)"; ctx.lineWidth = 1;
      ctx.strokeRect(0, focusY - dofH/2, W, dofH);
      ctx.fillStyle = "rgba(232,163,61,.6)";
      ctx.fillText("DOF", 6, focusY + 4);
    }

    if (L.clipping && m.stats){
      if (m.stats.hiClip > 0.1){ ctx.fillStyle = "rgba(255,0,0,.15)"; ctx.fillRect(0, 0, W, H * m.stats.hiClip); ctx.fillStyle = "rgba(255,80,80,.7)"; ctx.fillText("Highlights clipped", 6, 14); }
      if (m.stats.shClip > 0.1){ ctx.fillStyle = "rgba(0,0,255,.1)"; ctx.fillRect(0, H * (1 - m.stats.shClip), W, H * m.stats.shClip); ctx.fillStyle = "rgba(80,80,255,.7)"; ctx.fillText("Shadows crushed", 6, H - 6); }
    }

    if (L.motion && subs.length){
      ctx.strokeStyle = "rgba(200,160,255,.5)"; ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      for (const s of subs){ if (s.stride > 0.5){ const px = (s.px || 0.5) * W, py = (s.py || 0.5) * H; const len = s.stride * 40; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + len, py); ctx.stroke(); } }
      ctx.setLineDash([]);
    }

    if (L.heatmap && subs.length){
      const prim = subs.sort((a,b) => b.area - a.area)[0];
      const cx = (prim.px || 0.5) * W, cy = (prim.py || 0.5) * H;
      const grad = ctx.createRadialGradient(cx, cy, 5, cx, cy, W * 0.4);
      grad.addColorStop(0, "rgba(255,200,0,.25)");
      grad.addColorStop(0.5, "rgba(255,100,0,.1)");
      grad.addColorStop(1, "rgba(255,0,0,0)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = "rgba(255,200,0,.7)";
      ctx.fillText("Eye path", 6, 14);
    }
  },
  toggle(layer){
    const L = S.custom.overlayLayers || (S.custom.overlayLayers = {});
    L[layer] = !L[layer];
    saveState();
    this.draw(UI._currentPhoto);
  },
  toggleAll(on){
    if (!on){ $("#lbOverlay").classList.add("hidden"); return; }
    $("#lbOverlay").classList.remove("hidden");
  }
};

const WaitMode = {
  active: false, t: 0, shakeMult: 1,
  toggle(){
    if (!S.custom.waitMode) return;
    this.active = !this.active;
    this.t = 0;
    const ind = $("#waitIndicator");
    if (ind) ind.classList.toggle("on", this.active);
    if (this.active) toast("You plant your feet and settle into the scene. Framing steadies.", 2000);
  },
  update(dt){
    if (!this.active) { this.shakeMult = 1; return; }
    this.t += dt;

    this.shakeMult = Math.max(0.25, 1 - this.t * 0.375);

    if (this.t > 3 && Math.random() < 0.002){

      if (Life.people){
        for (const p of Life.people){
          if (p.hidden || p.busy) continue;
          const d = Math.hypot(p.x - Player.x, p.z - Player.z);
          if (d < 15 && Math.random() < 0.3){ p.gestureT = 0.5; }
        }
      }
    }
  }
};

const Ecology = {
  t: 5,
  update(dt){
    if (!S.custom.sceneEcology) return;
    this.t -= dt;
    if (this.t > 0) return;
    this.t = rand(4, 10);
    const hint = $("#ecologyHint");
    let msg = "";

    if (Life.busker && !Life.busker.hidden){
      const d = Math.hypot(Life.busker.x - Player.x, Life.busker.z - Player.z);
      if (d < 40){

        for (const p of Life.people){
          if (p.hidden || p.busy || p.eventTag) continue;
          const pd = Math.hypot(p.x - Life.busker.x, p.z - Life.busker.z);
          if (pd < 20 && pd > 4 && Math.random() < 0.15){
            p.target = { x: Life.busker.x + rand(-3, 3), z: Life.busker.z + rand(-3, 3) };
            p.gatherT = rand(8, 20);
          }
        }
        if (Math.random() < 0.3) msg = "A small crowd gathers around the music.";
      }
    }

    if (Life.dogs && Life.dogs.length && Life.flocks && Life.flocks.length){
      for (const dog of Life.dogs){
        if (dog.free) continue;
        for (const flock of Life.flocks){
          const d = Math.hypot(dog.x - flock.cx, dog.z - flock.cz);
          if (d < 12 && Math.random() < 0.1){
            flock.scatter = 2;
            if (Math.random() < 0.5) msg = "A dog lunges at the pigeons and they scatter skyward.";
          }
        }
      }
    }

    for (const E of EV.list){
      if (E.type === "protest" && E.t > 5 && E.t < 60 && Math.random() < 0.2){
        const idle = Life.people.filter(p => p.pool && !p.busy && !p.eventTag);
        if (idle.length > 2){
          const recruit = idle[Math.floor(Math.random() * Math.min(3, idle.length))];
          const d = Math.hypot(recruit.x - E.x, recruit.z - E.z);
          if (d < 50){ recruit.target = { x: E.x + rand(-4, 4), z: E.z + rand(-4, 4) }; recruit.gatherT = rand(15, 30); }
          if (Math.random() < 0.4) msg = "More people drift toward the chanting.";
        }
      }
    }
    if (msg && hint){ hint.textContent = msg; hint.classList.add("on"); setTimeout(() => hint.classList.remove("on"), 4000); }
  }
};

const DISTRICTS = {
  vic: { name: "The Vicinity", desc: "Quiet residential blocks. Old bay-windowed rowhouses, narrow sidewalks, morning light.", sounds: ["chirp", "voices"], eventBoost: 0.7 },
  mixed: { name: "The Mix", desc: "Shops and apartments. The city's everyday texture.", sounds: ["voices", "horn"], eventBoost: 1.0 },
  down: { name: "Downtown", desc: "Tall façades, busy crosswalks, tram bells.", sounds: ["horn", "siren"], eventBoost: 1.4 },
  filler: { name: "The Edge", desc: "Where the grid frays into parking lots and wind.", sounds: ["gull", "caw"], eventBoost: 0.5 }
};

const NEIGHBORHOOD_RHYTHMS = [
  { time: "dawn", desc: "Joggers, delivery trucks, first light on wet pavement." },
  { time: "morning", desc: "Commuter rush, coffee steam, the city leaning forward." },
  { time: "midday", desc: "Lunch crowds, sun high and flat, tourists asking directions." },
  { time: "afternoon", desc: "Long shadows, school out, buses idling at corners." },
  { time: "evening", desc: "Golden light, happy hour spilling onto sidewalks." },
  { time: "night", desc: "Streetlights, neon, the city's second shift begins." }
];

function timeOfDayName(){
  const h = S.clock || clockOf(S.time);
  if (h < 6) return "dawn";
  if (h < 10) return "morning";
  if (h < 14) return "midday";
  if (h < 17) return "afternoon";
  if (h < 20) return "evening";
  return "night";
}

function districtFor(x, z){
  const loc = locationName(x, z);
  const hood = loc.hood.toLowerCase();
  if (hood.includes("vic") || hood.includes("residential")) return DISTRICTS.vic;
  if (hood.includes("down") || hood.includes("commercial")) return DISTRICTS.down;
  if (hood.includes("fill") || hood.includes("edge")) return DISTRICTS.filler;
  return DISTRICTS.mixed;
}

let _districtUpdateT = 0;
function updateDistrictCard(dt){
  if (!S.custom.neighborhoodIdentity || S.custom.hud === "off") { $("#districtCard").classList.remove("on"); return; }
  _districtUpdateT -= dt;
  if (_districtUpdateT > 0) return;
  _districtUpdateT = 2;
  const d = districtFor(Player.x, Player.z);
  const card = $("#districtCard");
  const tod = timeOfDayName();
  const rhythm = NEIGHBORHOOD_RHYTHMS.find(r => r.time === tod) || NEIGHBORHOOD_RHYTHMS[2];
  card.querySelector(".dc-name").textContent = d.name;
  card.querySelector(".dc-desc").textContent = rhythm.desc;
  card.classList.add("on");
}

const WeatherPolish = {
  update(dt){
    if (!S.custom.weatherPolish) return;
    const T = World.timeDef || TIMES[2];

    const glare = $("#sunGlare");
    if (glare){
      const isDay = T.id === "day" || T.id === "golden";
      const sunDir = World.sunDir;
      let show = false;
      if (isDay && sunDir && !S.fog){

        const camDir = new THREE.Vector3(0, 0, -1).applyQuaternion(G.cam.getWorldQuaternion(new THREE.Quaternion()));
        const sunAngle = Math.acos(camDir.dot(sunDir.clone().normalize()));
        if (sunAngle < 0.6) show = true;
      }
      glare.classList.toggle("on", show);
    }

    const mist = $("#mistOverlay");
    if (mist){ mist.classList.toggle("on", !!S.fog && !S.rain); }

    const puddle = $("#puddleShimmer");
    if (puddle){ puddle.classList.toggle("on", !!S.rain); }
  }
};

const PROFILES = {
  practice: { name: "Practice", desc: "More HUD, event pins on, slower time, reduced shake.", timeScale: 0.6, eventPace: "calm", eventPins: "on", hud: "on", reducedShake: true, overlays: true },
  street: { name: "Street", desc: "Balanced defaults. The intended experience.", timeScale: 1.0, eventPace: "normal", eventPins: "heard", hud: "on", reducedShake: false, overlays: true },
  assignment: { name: "Assignment", desc: "Essay prompts on, events busier, harder HUD.", timeScale: 1.0, eventPace: "busy", eventPins: "heard", hud: "min", reducedShake: false, overlays: false },
  classic: { name: "Classic", desc: "Fewer assists, no overlays, no event pins.", timeScale: 1.0, eventPace: "calm", eventPins: "off", hud: "min", reducedShake: false, overlays: false },
  relaxed: { name: "Relaxed Walk", desc: "Slow time, reduced motion, calm events.", timeScale: 0.5, eventPace: "calm", eventPins: "on", hud: "on", reducedShake: true, overlays: false }
};

function applyDifficultyProfile(profileId){
  const p = PROFILES[profileId];
  if (!p) return;
  S.custom.difficultyProfile = profileId;
  S.custom.accessibility = S.custom.accessibility || {};
  S.custom.accessibility.timeScale = p.timeScale;
  S.custom.accessibility.reducedShake = p.reducedShake ? "true" : "false";
  S.custom.eventPace = p.eventPace;
  S.custom.eventPins = p.eventPins;
  S.custom.hud = p.hud;
  S.custom.editorOverlays = p.overlays ? "on" : "off";
  S.custom.flow = p.timeScale < 1.0;
  applyHudPref();
  saveState();
  const badge = $("#diffBadge");
  if (badge) badge.textContent = p.name;
  toast(`Difficulty: ${p.name}. ${p.desc}`, 3000);
}

function applyAccessibility(){
  const a = S.custom.accessibility || {};

  document.body.classList.remove("cv-protanopia", "cv-deuteranopia", "cv-tritanopia");
  if (a.colorFilter && a.colorFilter !== "none") document.body.classList.add("cv-" + a.colorFilter);

  document.body.classList.remove("text-large", "text-xlarge");
  if (a.textSize === "large") document.body.classList.add("text-large");
  else if (a.textSize === "xlarge") document.body.classList.add("text-xlarge");

  document.body.classList.toggle("reduced-motion", a.motionComfort === "true");

  const badge = $("#diffBadge");
  if (badge && PROFILES[S.custom.difficultyProfile]) badge.textContent = PROFILES[S.custom.difficultyProfile].name;
}

function effectiveTimeScale(){
  const a = S.custom.accessibility || {};
  return a.timeScale || 1.0;
}

function effectiveShakeMult(){
  const a = S.custom.accessibility || {};
  let m = a.reducedShake === "true" ? 0.4 : 1.0;
  if (WaitMode.active) m *= WaitMode.shakeMult;
  // Steadiness progression belongs to the skill; accessibility remains independent.
  return m;
}

const EXTRA_THEMES = {
  waiting: { n: "People Waiting", d: "Bus stops, benches, queues, corners. Stillness in motion." },
  redrain: { n: "Red in the Rain", d: "A colour in weather. Find it again and again." },
  edge: { n: "At the Edge of the Frame", d: "Subjects at the border. Tension between in and out." },
  morning: { n: "The Morning Shift", d: "Early light, first movements, the city waking." },
  looking: { n: "Looking Back", d: "Gaze, awareness, the moment someone notices." },
  solitude: { n: "Public Solitude", d: "Alone in a crowd. The interior life on a public stage." },
  hills: { n: "Hills and Shadows", d: "The city's vertical drama. Slopes, stairs, sky." },
  slow: { n: "The City at 1/15", d: "Slow shutter work. Motion as subject, not accident." },
  cablecar: { n: "After the Last Tram", d: "Night, empty tracks, the city after transit sleeps." }
};

for (const [k, v] of Object.entries(EXTRA_THEMES)){ if (!THEMES[k]) THEMES[k] = v; }

const _menuSettingsBase = menuSettings;
menuSettings = function(){
  const base = _menuSettingsBase();
  const c = S.custom;
  const seg = (key, opts) => `<div class="seg" data-seg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${c[key]===v}">${l}</button>`).join("")}</div>`;
  const a = c.accessibility || {};
  const aSeg = (key, opts) => `<div class="seg" data-aseg="${key}">${opts.map(([v,l])=>`<button data-v="${v}" aria-pressed="${String(a[key])===String(v)}">${l}</button>`).join("")}</div>`;

  let h = base;
  h += `<div class="sectionhead">Editor personalities</div>
    <div class="formrow"><label>Editor personality</label>${seg("editorPersonality",[["on","On"],["off","Off"]])}<span class="spec">Different editors give different feedback on the same image.</span></div>
    <div class="formrow"><label>Active editor</label>${seg("currentEditor", Object.entries(EDITORS).map(([id,e])=>[id,e.type]))}<span class="spec">${currentEditor().name} — ${currentEditor().desc}</span></div>
    <div class="formrow"><label>Editor overlays</label>${seg("editorOverlays",[["on","Show"],["off","Hide"]])}<span class="spec">Toggle analysis overlays in the lightbox: rule-of-thirds, subject box, leading lines, DOF, clipping, motion, eye path.</span></div>`;

  h += `<div class="sectionhead">Graphics enhancement</div>
    <div class="formrow"><label>Photorealism</label>${seg("graphicsEnhance",[["on","On"],["off","Off"]])}<span class="spec">SSAO, chromatic aberration, procedural normal maps, and enhanced shadow softness.</span></div>`;

  h += `<div class="sectionhead">Gameplay enhancements</div>
    <div class="formrow"><label>Wait mode</label>${seg("waitMode",[["on","On"],["off","Off"]])}<span class="spec">Press J to plant your feet. Framing steadies, and the street may reward patience.</span></div>
    <div class="formrow"><label>Scene ecology</label>${seg("sceneEcology",[["on","On"],["off","Off"]])}<span class="spec">Crowds gather around buskers, dogs chase pigeons, protests swell organically.</span></div>
    <div class="formrow"><label>Neighborhood identity</label>${seg("neighborhoodIdentity",[["on","On"],["off","Off"]])}<span class="spec">Each district shows its character and time-of-day rhythm.</span></div>
    <div class="formrow"><label>Weather polish</label>${seg("weatherPolish",[["on","On"],["off","Off"]])}<span class="spec">Sun glare, volumetric mist, puddle shimmer, snow.</span></div>
    <div class="formrow"><label>Essay enhancement</label>${seg("essayEnhanced",[["on","On"],["off","Off"]])}<span class="spec">More themes, 6–12 frames, gallery wall view.</span></div>`;

  h += `<div class="sectionhead">Difficulty profile</div>
    <div class="formrow"><label>Profile</label>${seg("difficultyProfile", Object.entries(PROFILES).map(([id,p])=>[id,p.name]))}<span class="spec">${PROFILES[c.difficultyProfile] ? PROFILES[c.difficultyProfile].desc : ""}</span></div>`;

  h += `<div class="sectionhead">Accessibility</div>
    <div class="formrow"><label>Reduced shake</label>${aSeg("reducedShake",[["true","On"],["false","Off"]])}<span class="spec">Halves handheld camera sway.</span></div>
    <div class="formrow"><label>Motion comfort</label>${aSeg("motionComfort",[["true","On"],["false","Off"]])}<span class="spec">Disables animations and transitions.</span></div>
    <div class="formrow"><label>Colour-vision filter</label>${aSeg("colorFilter",[["none","None"],["protanopia","Protanopia"],["deuteranopia","Deuteranopia"],["tritanopia","Tritanopia"]])}<span class="spec">Simulates how the scene looks with different colour vision.</span></div>
    <div class="formrow"><label>Time scale</label>${aSeg("timeScale",[["1.0","Normal"],["0.75","75%"],["0.5","50%"],["0.35","35%"]])}<span class="spec">Slow the simulation for reading moments.</span></div>
    <div class="formrow"><label>Text size</label>${aSeg("textSize",[["normal","Normal"],["large","Large"],["xlarge","Extra large"]])}</div>`;

  c.overlayLayers = { thirds:true, subject:true, leading:true, dof:true, clipping:true, motion:true, heatmap:true };

  return h;
};

const _wireMenuBase = wireMenu;
wireMenu = function(){
  _wireMenuBase();
  const body = $("#menubody");

  $$("[data-seg='currentEditor'] button", body).forEach(b => b.onclick = () => { S.custom.currentEditor = b.dataset.v; saveState(); renderMenu(); });

  for (const key of ["editorOverlays", "editorPersonality", "waitMode", "sceneEcology", "neighborhoodIdentity", "weatherPolish", "essayEnhanced", "graphicsEnhance"]){
    $$(`[data-seg='${key}'] button`, body).forEach(b => b.onclick = () => { S.custom[key] = b.dataset.v; saveState(); if (key === "neighborhoodIdentity") updateDistrictCard(0); if (key === "graphicsEnhance") applyGraphicsEnhance(); renderMenu(); });
  }

  $$("[data-seg='difficultyProfile'] button", body).forEach(b => b.onclick = () => { applyDifficultyProfile(b.dataset.v); renderMenu(); });

  for (const key of ["reducedShake", "motionComfort"]){
    $$(`[data-aseg='${key}'] button`, body).forEach(b => b.onclick = () => { S.custom.accessibility = S.custom.accessibility || {}; S.custom.accessibility[key] = b.dataset.v; saveState(); applyAccessibility(); renderMenu(); });
  }
  $$("[data-aseg='colorFilter'] button", body).forEach(b => b.onclick = () => { S.custom.accessibility = S.custom.accessibility || {}; S.custom.accessibility.colorFilter = b.dataset.v; saveState(); applyAccessibility(); renderMenu(); });
  $$("[data-aseg='timeScale'] button", body).forEach(b => b.onclick = () => { S.custom.accessibility = S.custom.accessibility || {}; S.custom.accessibility.timeScale = parseFloat(b.dataset.v); saveState(); applyAccessibility(); renderMenu(); });
  $$("[data-aseg='textSize'] button", body).forEach(b => b.onclick = () => { S.custom.accessibility = S.custom.accessibility || {}; S.custom.accessibility.textSize = b.dataset.v; saveState(); applyAccessibility(); renderMenu(); });

  $$("[data-ol]", body).forEach(b => b.onclick = () => { Overlay.toggle(b.dataset.ol); renderMenu(); });
};

const _renderLbSideBase = renderLbSide;
renderLbSide = function(p, info){
  _renderLbSideBase(p, info);
  UI._currentPhoto = p;
  const side = $("#lbside");
  if (!side || !p) return;

  if (S.custom.editorPersonality && p.judged){
    const ed = currentEditor();
    const adjustedScore = editorAdjustedScore(p.score, p.cats);
    const delta = adjustedScore - p.score;
    const quote = editorQuote(adjustedScore);
    const card = document.createElement("div");
    card.className = "editor-card";
    card.innerHTML = `<div class="ed-type">${ed.type}</div><div class="ed-name">${ed.name}</div><div class="ed-quote">“${quote}”</div>${delta !== 0 ? `<div class="ed-delta">${delta > 0 ? "+" : ""}${delta} from the combined editorial review</div>` : ""}`;

    const critique = side.querySelector(".critique");
    if (critique) side.insertBefore(card, critique); else side.appendChild(card);
  }

  if (S.custom.editorOverlays && p.judged){
    const wrap = document.createElement("div");
    wrap.className = "overlay-toggles";
    wrap.style.marginTop = "8px";
    const ol = S.custom.overlayLayers || {};
    for (const [k, label] of [["thirds","Thirds"],["subject","Subject"],["leading","Lines"],["dof","DOF"],["clipping","Clip"],["motion","Motion"],["heatmap","Heatmap"]]){
      const btn = document.createElement("button");
      btn.className = ol[k] ? "on" : "";
      btn.textContent = label;
      btn.onclick = () => { Overlay.toggle(k); btn.classList.toggle("on"); };
      wrap.appendChild(btn);
    }

    const master = document.createElement("button");
    master.textContent = $("#lbOverlay").classList.contains("hidden") ? "Show overlays" : "Hide overlays";
    master.className = "on";
    master.onclick = () => {
      const cv = $("#lbOverlay");
      const hidden = cv.classList.contains("hidden");
      if (hidden){ cv.classList.remove("hidden"); master.textContent = "Hide overlays"; Overlay.resize(); Overlay.draw(p); }
      else { cv.classList.add("hidden"); master.textContent = "Show overlays"; }
    };
    wrap.appendChild(master);
    side.appendChild(wrap);

    if (!$("#lbOverlay").classList.contains("hidden")){ setTimeout(() => { Overlay.resize(); Overlay.draw(p); }, 50); }
  }
};

const _openLightboxBase = openLightbox;
openLightbox = async function(id, info){
  await _openLightboxBase(id, info);
  setTimeout(() => { Overlay.init(); Overlay.resize(); if (UI._currentPhoto) Overlay.draw(UI._currentPhoto); }, 100);
};

addEventListener("resize", () => { if (!$("#lightbox").classList.contains("hidden")){ Overlay.resize(); if (UI._currentPhoto) Overlay.draw(UI._currentPhoto); } });

const _renderEssayBase = renderEssay;
renderEssay = async function(){
  await _renderEssayBase();
  const e = essayState();

  const wallToggle = $("#essayWallToggle");
  if (wallToggle){ wallToggle.style.display = (S.custom.essayEnhanced && e.photos.length >= 2) ? "" : "none"; }
};

function initWallView(){
  const btn = $("#essayWallBtn");
  if (!btn) return;
  btn.onclick = () => {
    const wall = $("#essayWall");
    const isOn = wall.classList.toggle("on");
    btn.textContent = isOn ? "Back to strip" : "Gallery wall view";
    if (isOn) renderWallView();
  };
}
function renderWallView(){
  const wall = $("#essayWall");
  const e = essayState();
  const chosen = e.photos.map(id => UI.essayAll.find(p => p.id === id)).filter(Boolean);
  wall.innerHTML = chosen.map((p, i) => `<div class="wall-frame" data-wid="${p.id}"><img src="${p.editedThumb || p.thumb}" alt=""><span class="wf-num">${i+1}</span></div>`).join("");

  let dragId = null;
  $$(".wall-frame", wall).forEach(el => {
    el.draggable = true;
    el.ondragstart = (ev) => { dragId = el.dataset.wid; ev.dataTransfer.effectAllowed = "move"; };
    el.ondragover = (ev) => { ev.preventDefault(); ev.dataTransfer.dropEffect = "move"; };
    el.ondrop = (ev) => {
      ev.preventDefault();
      const targetId = el.dataset.wid;
      if (!dragId || dragId === targetId) return;
      const arr = e.photos;
      const from = arr.indexOf(isNaN(+dragId) ? dragId : +dragId);
      const to = arr.indexOf(isNaN(+targetId) ? targetId : +targetId);
      if (from < 0 || to < 0) return;
      const [item] = arr.splice(from, 1);
      arr.splice(to, 0, item);
      saveState(); renderWallView();
    };
  });
}

const _submitEssayBase = submitEssay;
submitEssay = async function(){
  await _submitEssayBase();
  renderWallView();
};

const _onKeyBase = onKey;
onKey = function(ev){

  if (ev.code === "KeyJ" && Game.started && !UI.open && $("#lightbox").classList.contains("hidden")){
    if (!ev.repeat) WaitMode.toggle();
    return;
  }
  _onKeyBase(ev);
};

const _gameplayUpdateV6 = gameplayUpdate;
gameplayUpdate = function(dt){
  const ts = effectiveTimeScale();
  const scaledDt = dt * ts;
  _gameplayUpdateV6(scaledDt);
  if (Game.started){
    WaitMode.update(scaledDt);
    Ecology.update(scaledDt);
    WeatherPolish.update(dt);
    updateDistrictCard(dt);
  }
};

const _updatePlayerBase = updatePlayer;
updatePlayer = function(dt){
  const ts = effectiveTimeScale();
  if (WaitMode.active && Game.started){

    const saved = { KeyW: Input.keys.KeyW, KeyA: Input.keys.KeyA, KeyS: Input.keys.KeyS, KeyD: Input.keys.KeyD };
    Input.keys.KeyW = false; Input.keys.KeyA = false; Input.keys.KeyS = false; Input.keys.KeyD = false;
    Input.joy.x = 0; Input.joy.y = 0;
    _updatePlayerBase(dt * ts);

    Object.assign(Input.keys, saved);

    if (Player.raise > 0.3){
      Player.breathing = true;
      Player.breath = Math.min(1, Player.breath + dt * 0.5);
    }
  } else {
    _updatePlayerBase(dt * ts);
  }
};

const _bootBase = boot;
boot = async function(){
  await _bootBase();

  applyAccessibility();

  Overlay.init();

  setTimeout(() => initWallView(), 500);

  const badge = $("#diffBadge");
  if (badge && PROFILES[S.custom.difficultyProfile]) badge.textContent = PROFILES[S.custom.difficultyProfile].name;

  patchEssayAddLimit();
};

function patchEssayAddLimit(){

  const origRenderEssay = renderEssay;

  const observer = new MutationObserver(() => {
    const pick = $("#essayPick");
    if (!pick) return;
    $$("[data-add]", pick).forEach(b => {
      if (b.dataset.v6patched) return;
      b.dataset.v6patched = "1";
      const origClick = b.onclick;
      b.onclick = (ev) => {
        const e = essayState();
        const max = S.custom.essayEnhanced ? 12 : 10;
        if (e.photos.length >= max){ toast(max === 12 ? "Twelve frames is the limit." : "Ten frames is the limit."); return; }
        const id = isNaN(+b.dataset.add) ? b.dataset.add : +b.dataset.add;
        e.photos.push(id); saveState(); renderEssay();
      };
    });
  });
  const essayPanel = $("#essayPanel");
  if (essayPanel) observer.observe(essayPanel, { childList: true, subtree: true });
}

function applyGraphicsEnhance(){
  if (!G.post) return;
  const enhance = S.custom.graphicsEnhance === "on";
  if (enhance && !G.post.userData.v6patched){
    G.post.userData.v6patched = true;

    G.post.uniforms.uCA = { value: 0.003 };

    let fs = G.post.fragmentShader;
    fs = fs.replace('uniform float vig;', 'uniform float vig; uniform float uCA;');

    fs = fs.replace(
      'gl_FragColor = vec4(clamp(col,0.0,1.0)*accW, 1.0);',
      'if (uCA > 0.001) { vec2 dir = vUv - 0.5; float dist = length(dir); if (dist > 0.01) { vec2 ndir = dir / dist; float amt = uCA * dist; float rRaw = texture2D(tColor, vUv - ndir * amt).r * exposure; float bRaw = texture2D(tColor, vUv + ndir * amt).b * exposure; float rProc = pow(clamp((rRaw*(2.51*rRaw+0.03))/(rRaw*(2.43*rRaw+0.59)+0.14), 0.0, 1.0), 1.0/2.2); float bProc = pow(clamp((bRaw*(2.51*bRaw+0.03))/(bRaw*(2.43*bRaw+0.59)+0.14), 0.0, 1.0), 1.0/2.2); col.r = mix(col.r, rProc, 0.6); col.b = mix(col.b, bProc, 0.6); } } gl_FragColor = vec4(clamp(col,0.0,1.0)*accW, 1.0);'
    );
    G.post.fragmentShader = fs;
    G.post.needsUpdate = true;
  }
}

const SSAO = {
  mat: null, rt: null, blendMat: null, blendRT: null,
  init(){
    if (this.mat) return;
    const fs = `
      #include <packing>
      uniform sampler2D tDepth; uniform vec2 texel; uniform float cNear; uniform float cFar; varying vec2 vUv;
      float viewZ(float d){ return -perspectiveDepthToViewZ(d, cNear, cFar); }
      void main(){
        float center = viewZ(texture2D(tDepth, vUv).x);
        float occ = 0.0;
        for (int i = 0; i < 24; i++){
          float a = float(i) * 0.2618; float r = 0.012 + float(i) * 0.003;
          vec2 off = vec2(cos(a), sin(a)) * r;
          float s = viewZ(texture2D(tDepth, vUv + off).x);
          float diff = center - s;
          if (diff > 0.3 && diff < 8.0) occ += 1.0;
        }
        occ = clamp(occ / 24.0, 0.0, 1.0) * 0.55;
        gl_FragColor = vec4(vec3(1.0 - occ), 1.0);
      }
    `;
    this.mat = new THREE.ShaderMaterial({ vertexShader:POST_VS, fragmentShader:fs, depthTest:false, depthWrite:false, uniforms:{ tDepth:{value:null}, texel:{value:new THREE.Vector2()}, cNear:{value:0.08}, cFar:{value:3000} } });
    this.blendMat = new THREE.ShaderMaterial({ vertexShader:POST_VS, fragmentShader:`uniform sampler2D tColor; uniform sampler2D tSSAO; varying vec2 vUv; void main(){ vec3 c = texture2D(tColor, vUv).rgb; float a = texture2D(tSSAO, vUv).r; gl_FragColor = vec4(c * a, 1.0); }`, depthTest:false, depthWrite:false, uniforms:{ tColor:{value:null}, tSSAO:{value:null} } });
    const w = G.rtLive.width, h = G.rtLive.height, aoS = (S && S.custom && S.custom.renderQuality === "ultra") ? 1 : 0.5;
    this.rt = new THREE.WebGLRenderTarget(Math.floor(w*aoS), Math.floor(h*aoS), { type: THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
    this.blendRT = new THREE.WebGLRenderTarget(w, h, { type: G.halfFloat ? THREE.HalfFloatType : THREE.UnsignedByteType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
  },
  render(){
    if (S.custom.graphicsEnhance !== "on") return;
    if (!this.mat) this.init();
    if (!this.mat || !G.rtLive) return;
    const r = G.renderer;

    this.mat.uniforms.tDepth.value = G.rtLive.depthTexture;
    this.mat.uniforms.texel.value.set(1/this.rt.width, 1/this.rt.height);
    this.mat.uniforms.cNear.value = G.cam.near;
    this.mat.uniforms.cFar.value = G.cam.far;
    G.quad.material = this.mat;
    r.setRenderTarget(this.rt); r.render(G.postScene, G.postCam);

    this.blendMat.uniforms.tColor.value = G.rtLive.texture;
    this.blendMat.uniforms.tSSAO.value = this.rt.texture;
    G.quad.material = this.blendMat;
    r.setRenderTarget(this.blendRT); r.render(G.postScene, G.postCam);

    G.quad.material = G.post;
    G.post.uniforms.tColor.value = this.blendRT.texture;
  }
};

function makeBrickNormalMap(){
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const x = c.getContext('2d');
  x.fillStyle = 'rgb(128,128,255)'; x.fillRect(0,0,256,256);

  for (let row = 0; row < 8; row++){
    const yOff = row * 32; const offset = (row % 2) * 32;
    for (let col = -1; col < 9; col++){
      const bx = col * 64 + offset;

      x.fillStyle = 'rgb(110,110,200)';
      x.fillRect(bx, yOff, 64, 2); x.fillRect(bx, yOff, 2, 32);
      x.fillStyle = 'rgb(140,140,255)';
      x.fillRect(bx+1, yOff+2, 62, 1); x.fillRect(bx+2, yOff+2, 1, 30);
    }
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
function makeConcreteNormalMap(){
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const x = c.getContext('2d');
  x.fillStyle = 'rgb(128,128,255)'; x.fillRect(0,0,256,256);

  for (let i = 0; i < 200; i++){
    const px = Math.random()*256, py = Math.random()*256, r = 2 + Math.random()*6;
    const bright = 120 + Math.random()*40;
    x.fillStyle = `rgb(${bright},${bright},255)`;
    x.beginPath(); x.arc(px, py, r, 0, Math.PI*2); x.fill();
  }

  for (let i = 0; i < 5; i++){
    x.strokeStyle = 'rgb(100,100,180)'; x.lineWidth = 1.5;
    x.beginPath(); x.moveTo(Math.random()*256, Math.random()*256);
    for (let j = 0; j < 4; j++) x.lineTo(Math.random()*256, Math.random()*256);
    x.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
const _brickNormal = null, _concreteNormal = null;
function applyNormalMaps(){
  if (S.custom.graphicsEnhance !== "on") return;
  if (!World.mats) return;
  const brickNM = makeBrickNormalMap();
  const concreteNM = makeConcreteNormalMap();

  if (World.mats.plain){
    World.mats.plain.normalMap = brickNM; World.mats.plain.normalScale = new THREE.Vector2(0.5, 0.5); World.mats.plain.needsUpdate = true;
  }
  if (World.mats.metal){
    World.mats.metal.normalMap = concreteNM; World.mats.metal.normalScale = new THREE.Vector2(0.3, 0.3); World.mats.metal.needsUpdate = true;
  }
  if (World.mats.road){
    World.mats.road.normalMap = concreteNM; World.mats.road.normalScale = new THREE.Vector2(0.3, 0.3); World.mats.road.needsUpdate = true;
  }
  if (World.mats.walk){
    World.mats.walk.normalMap = concreteNM; World.mats.walk.normalScale = new THREE.Vector2(0.3, 0.3); World.mats.walk.needsUpdate = true;
  }
}

const _renderLiveBaseV6 = renderLive;
renderLive = function(){
  if (S.custom.graphicsEnhance !== "on" || !G.rtLive){ _renderLiveBaseV6(); return; }

  const r = G.renderer;
  Refl.render(G.cam); r.setRenderTarget(G.rtLive); r.render(G.scene, G.cam);

  if (!SSAO.mat) SSAO.init();
  let colorTex = G.rtLive.texture;
  if (SSAO.mat && G.rtLive.depthTexture){
    SSAO.mat.uniforms.tDepth.value = G.rtLive.depthTexture;
    SSAO.mat.uniforms.texel.value.set(1/SSAO.rt.width, 1/SSAO.rt.height);
    SSAO.mat.uniforms.cNear.value = G.cam.near;
    SSAO.mat.uniforms.cFar.value = G.cam.far;
    G.quad.material = SSAO.mat;
    r.setRenderTarget(SSAO.rt); r.render(G.postScene, G.postCam);
    SSAO.blendMat.uniforms.tColor.value = G.rtLive.texture;
    SSAO.blendMat.uniforms.tSSAO.value = SSAO.rt.texture;
    G.quad.material = SSAO.blendMat;
    r.setRenderTarget(SSAO.blendRT); r.render(G.postScene, G.postCam);
    colorTex = SSAO.blendRT.texture;
  }

  const u = G.post.uniforms; G.quad.material = G.post;
  u.tColor.value = colorTex; u.tDepth.value = G.rtLive.depthTexture; u.texel.value.set(1/G.rtLive.width, 1/G.rtLive.height);
  u.cNear.value = G.cam.near; u.cFar.value = G.cam.far; u.outScale.value = 1;
  u.tint.value = 0; u.soft.value = 0; setShafts(u, G.cam);
  u.exposure.value = expoScale(1); u.dofOn.value = 0;
  u.sat.value = 1; u.con.value = 1; u.mono.value = 0; u.warm.value = 0; u.fade.value = 0; u.vig.value = Game.started ? 0.12 : 0.3;
  r.setRenderTarget(null); r.render(G.postScene, G.postCam);
};

const Snow = {
  mesh: null,
  init(scene){
    const n = 3000, pos = new Float32Array(n*3), sizes = new Float32Array(n);
    for (let i = 0; i < n; i++){
      pos[i*3] = (Math.random()-0.5)*80;
      pos[i*3+1] = Math.random()*30;
      pos[i*3+2] = (Math.random()-0.5)*80;
      sizes[i] = 0.08 + Math.random()*0.12;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { uTime:{value:0}, uCam:{value:new THREE.Vector3()}, uCol:{value:new THREE.Color(0.95,0.95,0.98)} },
      vertexShader: `attribute float aSize; uniform float uTime; uniform vec3 uCam; varying float vAlpha;
        void main(){
          vec3 p = position;
          p.y = mod(p.y - uTime*1.5, 30.0) - 5.0 + uCam.y;
          p.x = mod(p.x - uCam.x + sin(uTime + position.z)*0.3, 80.0) - 40.0 + uCam.x;
          p.z = mod(p.z - uCam.z + cos(uTime*0.7 + position.x)*0.3, 80.0) - 40.0 + uCam.z;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = aSize * 300.0 / -mv.z;
          vAlpha = clamp(1.0 - (-mv.z)/30.0, 0.0, 1.0);
        }`,
      fragmentShader: `uniform vec3 uCol; varying float vAlpha; void main(){
        float d = length(gl_PointCoord - vec2(0.5));
        if (d > 0.5) discard;
        float a = (1.0 - d*2.0) * vAlpha * 0.8;
        gl_FragColor = vec4(uCol, a);
      }`
    });
    this.mesh = new THREE.Points(g, mat);
    this.mesh.frustumCulled = false; this.mesh.visible = false; this.mesh.renderOrder = 6;
    scene.add(this.mesh);
  },
  update(dt, camPos){
    if (!this.mesh || !this.mesh.visible) return;
    this.mesh.material.uniforms.uTime.value += dt;
    this.mesh.material.uniforms.uCam.value.copy(camPos);
    const T = World.timeDef || TIMES[2];
    this.mesh.material.uniforms.uCol.value.setRGB(T.id==='night'?0.7:0.95, T.id==='night'?0.7:0.95, T.id==='night'?0.75:0.98);
  }
};

const _applyTimeBase = applyTime;
applyTime = function(silent){
  _applyTimeBase(silent);
  if (S && S.snow){
    if (!Snow.mesh && G.scene) Snow.init(G.scene);
    if (Snow.mesh) Snow.mesh.visible = true;
  } else {
    if (Snow.mesh) Snow.mesh.visible = false;
  }
};

const Airplanes = {
  mesh: null, active: false, t: 0, nextT: 30,
  init(scene){
    const g = new THREE.Group();

    const fus = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 4, 8), new THREE.MeshBasicMaterial({ color: 0xe8e8e8 }));
    fus.rotation.z = Math.PI/2; g.add(fus);

    const wing = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.08, 5), new THREE.MeshBasicMaterial({ color: 0xe8e8e8 }));
    wing.position.y = 0.05; g.add(wing);

    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.6, 0.1), new THREE.MeshBasicMaterial({ color: 0xe8e8e8 }));
    tail.position.set(-1.8, 0.3, 0); g.add(tail);

    const tw = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 1.5), new THREE.MeshBasicMaterial({ color: 0xe8e8e8 }));
    tw.position.set(-1.8, 0.3, 0); g.add(tw);
    g.visible = false; g.scale.set(3, 3, 3);
    this.mesh = g; scene.add(g);
  },
  update(dt, camPos){
    if (!this.mesh){ if (G.scene) this.init(G.scene); else return; }
    if (!this.active){
      this.nextT -= dt;
      if (this.nextT <= 0){
        this.active = true; this.t = 0;
        this.startX = camPos.x + rand(-200, 200);
        this.startZ = camPos.z + rand(-200, 200);
        this.startY = 120 + rand(20, 60);
        this.dir = rand(0, Math.PI*2);
        this.mesh.visible = true;
      }
    } else {
      this.t += dt;
      const speed = 25;
      const dist = this.t * speed;
      const x = this.startX + Math.sin(this.dir) * dist;
      const z = this.startZ + Math.cos(this.dir) * dist;
      this.mesh.position.set(x, this.startY, z);
      this.mesh.rotation.y = this.dir + Math.PI/2;

      this.mesh.rotation.z = Math.sin(this.t * 0.1) * 0.05;

      const d = Math.hypot(x - camPos.x, z - camPos.z);
      this.mesh.visible = d < 400;
      if (d > 500 || this.t > 25){ this.active = false; this.mesh.visible = false; this.nextT = rand(45, 120); }
    }
  }
};

if (typeof CAR_TYPES !== 'undefined'){
  CAR_TYPES.muscle = { L:5.0, W:1.95, clr:0.22, belt:0.9, nose:0.78, tail:0.85, wf:1.62, wr:-1.52, R:0.35, cabin:[[-1.1,0],[-0.55,1],[0.35,1],[0.95,0]], ch:0.44, chromeBumpers:true, muscle:true };
  CAR_TYPES.roadster = { L:4.2, W:1.78, clr:0.16, belt:0.78, nose:0.68, tail:0.76, wf:1.35, wr:-1.3, R:0.32, cabin:[[-0.3,0],[0.2,1],[0.25,1],[0.85,0]], ch:0.36, open:true, bev:0.12 };
  CAR_TYPES.microvan = { L:3.8, W:1.68, clr:0.22, belt:1.1, nose:0.95, tail:1.05, wf:1.5, wr:-1.3, R:0.34, cabin:[[-1.85,0],[-1.8,1],[0.55,1],[0.95,0]], ch:0.95, win:"van" };
  CAR_TYPES.estate = { L:4.85, W:1.84, clr:0.18, belt:0.9, nose:0.8, tail:0.92, wf:1.48, wr:-1.48, R:0.33, cabin:[[-2.3,0],[-2.25,1],[0.5,1],[1.2,0]], ch:0.5, wood:true };

  CAR_TYPE_WEIGHTS.push(["muscle", 0.8], ["roadster", 0.4], ["microvan", 0.6], ["estate", 0.8]);

  if (!CAR_PALETTES.muscle) CAR_PALETTES.muscle = ["#c0362c", "#1e3a5f", "#15171a", "#e8b82e", "#2f5a3a"];
  if (!CAR_PALETTES.roadster) CAR_PALETTES.roadster = ["#c0362c", "#f2efe6", "#1e3a5f", "#e8b82e"];
  if (!CAR_PALETTES.microvan) CAR_PALETTES.microvan = ["#f2efe6", "#9cc3e0", "#e8dcc0", "#3aa06b"];
  if (!CAR_PALETTES.estate) CAR_PALETTES.estate = ["#6b4a2e", "#3f5e7a", "#d8c9a3", "#2d4a3c"];
}

if (typeof SKILLS !== 'undefined'){
  SKILLS.composition = { name:"Composition eye", max:2, desc:"Each rank improves your eye for framing. The viewfinder shows a composition guide overlay." };
  SKILLS.patience = { name:"Patience", max:2, desc:"Wait mode steadies the camera faster, and nearby gestures happen sooner." };
  SKILLS.streetwise = { name:"Streetwise", max:2, desc:"People notice your camera from shorter distances, and the minimap shows more life." };
  SKILLS.goldenhour = { name:"Golden hour", max:1, desc:"You can read light quality even on cameras without a meter. Shows EV and light direction." };
  SKILLS.flashmaster = { name:"Flash mastery", max:2, desc:"Flash recycling is faster, and the effective range increases with each rank." };
}

const _defaultStateBaseV6 = defaultState;
defaultState = function(free){
  const s = _defaultStateBaseV6(free);
  if (free) s.skills.steady = 1;
  return s;
};

const _wireMenuBaseV6 = wireMenu;
wireMenu = function(){
  _wireMenuBaseV6();
  const body = $("#menubody");

  $$("[data-skill]", body).forEach(b => {
    b.oncontextmenu = (ev) => {
      ev.preventDefault();
      const id = b.dataset.skill;
      if (S.skills[id] > 0){
        S.skills[id]--; S.skillPts++; saveState();
        toast(`Unlearned ${SKILLS[id].name} (rank ${S.skills[id]}).`, 1400);
        renderMenu();
      }
    };
  });
};

const _askClaudeBase = askClaude;
askClaude = async function(p, btn){
  const out = $("#lbClaude"); if (!out) return;
  out.innerHTML = `<div class="claude-out">Looking at this frame...</div>`;
  const box = out.firstChild; if (btn) btn.disabled = true;
  const m = p.meta;

  const prim = primOf(m);
  const subs = m.subjects || [];
  const subjectDesc = prim ? `Primary subject: a ${prim.kind || 'person'} at ~${Math.round(prim.dist||5)}m, ${prim.area > 0.1 ? 'large' : prim.area > 0.02 ? 'medium' : 'small'} in frame, ${prim.gpeak > 0.5 ? 'mid-gesture' : 'still'}, ${prim.aware ? 'aware of camera' : 'unaware'}, ${prim.stride > 0.5 ? 'in motion' : 'standing'}${prim.clipped > 0.05 ? ', partially clipped at frame edge' : ''}` : 'No clear primary subject detected.';
  const sceneDesc = `${subs.length} subject(s) visible, ${m.layers || 1} depth layer(s), street: ${m.street}, neighborhood: ${m.hood}`;
  const lightDesc = `${m.timeName}${m.fog ? ', foggy' : ''}${m.rain ? ', raining' : ''}, EV ~${Math.round(sceneEV ? sceneEV() : 12)}`;
  const techDesc = `${m.bodyName}, ${m.lens}${m.feq ? ` (${Math.round(m.feq)}mm equiv.)` : ''}, ${fmtShutter(m.t)} at ${fmtA(m.N)}, ASA ${m.iso}${m.flash ? ', ' + m.flash : ''}${m.push ? `, push ${m.push>0?'+':''}${m.push}` : ''}, ${m.filmName || 'film'}`;
  const scoreDesc = p.judged ? `In-game score: ${p.score}/100 (composition ${p.cats.comp}, subject ${p.cats.subj}, light ${p.cats.light}, sharpness ${p.cats.sharp}, colour ${p.cats.color}).` : 'Not yet judged.';
  const editorDesc = S.custom.editorPersonality === 'on' ? ` Current editor: ${currentEditor().name} (${currentEditor().type}), who values ${currentEditor().desc.toLowerCase()}` : '';

  const prompt = `You are a master street photography editor with decades of experience. Examine this photograph from a street photography game set in a stylized fictional city called Snap City.

Give a detailed, specific critique in 2-3 short paragraphs (under 250 words total). Reference what you actually see in the image — the composition, the subject's gesture or expression, the light, the timing, the background. Be specific about what works and what doesn't. End with one concrete thing to try next time.

Technical: ${techDesc}
Scene: ${sceneDesc}
Subject: ${subjectDesc}
Light: ${lightDesc}
${scoreDesc}${editorDesc}
${p.edit ? 'The photographer edited this in the darkroom.' : 'Straight from the camera.'}

Speak as ${currentEditor().name}, ${currentEditor().type}. Match their voice and priorities.`;

  try {
    if (!UI.sample){ throw { code:'not_granted' }; }
    const { text } = await UI.sample(prompt, { images: p.edited || p.orig, onText: ({text}) => { box.textContent = text; } });
    box.textContent = text;
  } catch(e){
    const msg = { not_granted:"AI critiques were declined for this session.", images_unavailable:"This view can't send images to the AI.", rate_limited:"Too many requests right now. Try again in a minute.", cancelled:"" }[e && e.code];
    if (e && (e.code === 'not_granted' || e.code === 'images_unavailable')){ UI.sample = null; if (btn) btn.remove(); }
    box.textContent = (box.textContent ? box.textContent + "\n\n" : "") + (msg ?? "The AI couldn't answer just now.");
  } finally { if (btn) btn.disabled = false; }
};

const _menuTimeBase = menuTime;
menuTime = function(){
  const base = _menuTimeBase();
  return base + `
    <div class="formrow" style="margin-top:18px"><label>Snow</label><div class="seg" data-snow><button data-v="0" aria-pressed="${!S.snow}">No snow</button><button data-v="1" aria-pressed="${!!S.snow}">Snowing</button></div><span class="spec">Snow falls and drifts across the city. Combine with fog for a winter mood.</span></div>`;
};

const _wireMenuBaseV7 = wireMenu;
wireMenu = function(){
  _wireMenuBaseV7();
  const body = $("#menubody");
  const sn = $("[data-snow]", body);
  if (sn) $$("button", sn).forEach(b => b.onclick = () => { S.snow = b.dataset.v === "1"; applyTime(); saveState(); renderMenu(); });
};

const _gameplayUpdateV6Final = gameplayUpdate;
gameplayUpdate = function(dt){

  _gameplayUpdateV6Final(dt);
  if (Game.started){

    const scaledDt = dt * effectiveTimeScale();
    if (Snow.mesh && S.snow) Snow.update(scaledDt, G.cam.position);
    Airplanes.update(scaledDt, G.cam.position);
  }
};

const _bootBaseV6Final = boot;
boot = async function(){
  await _bootBaseV6Final();
  applyGraphicsEnhance();
  applyNormalMaps();
};

const _menuKeysBaseV6Final = menuKeys;
menuKeys = function(){
  const base = _menuKeysBaseV6Final();
  return base + `<p class="note" style="margin-top:14px"><b>v6 additions:</b> J — Plant feet / wait mode · Right-click a skill to unlearn it (refunds the point).</p>
  <p class="note">New skills: Composition eye, Patience, Streetwise, Golden hour, Flash mastery. Steady hands starts at rank 1.</p>`;
};

console.log("[Contact Sheet v6.1] Graphics + features patch loaded.");
})();

# Photographer quotations

100 short quotations and sentence excerpts by 49 photographers. Each displayed credit links to its source. Excerpts are marked in the game. Wording is preserved; punctuation is normalized in a few entries. Retrieved 25 September 2026.

| # | Photographer | Quotation | Source |
|---|---|---|---|
| 1 | Ansel Adams | There are always two people in every picture: the photographer and the viewer. | [Source](https://en.wikiquote.org/wiki/Ansel_Adams) |
| 2 | Ansel Adams | Then, using that musical analogy, the print is the performance. (excerpt) | [Source](https://en.wikiquote.org/wiki/Ansel_Adams) |
| 3 | Dorothea Lange | One should really use the camera as though tomorrow you'd be stricken blind. | [Source](https://en.wikiquote.org/wiki/Dorothea_Lange) |
| 4 | Dorothea Lange | Photography takes an instant out of time, altering life by holding it still. | [Source](https://photoquotes.com/author/dorothea-lange) |
| 5 | Dorothea Lange | To be good, photographs have to be full of the world. | [Source](https://photoquotes.com/author/dorothea-lange) |
| 6 | Henri Cartier-Bresson | I watch, watch, watch. I understand things through my eyes. (excerpt) | [Source](https://en.wikiquote.org/wiki/Henri_Cartier-Bresson) |
| 7 | Henri Cartier-Bresson | But there is no standard plan, no pattern from which to work. (excerpt) | [Source](https://en.wikiquote.org/wiki/Henri_Cartier-Bresson) |
| 8 | Diane Arbus | My favorite thing is to go where I've never been. | [Source](https://en.wikiquote.org/wiki/Diane_Arbus) |
| 9 | Diane Arbus | I never have taken a picture I've intended. They're always better or worse. | [Source](https://en.wikiquote.org/wiki/Diane_Arbus) |
| 10 | Garry Winogrand | Anything and all things are photographable. (excerpt) | [Source](https://en.wikiquote.org/wiki/Garry_Winogrand) |
| 11 | Garry Winogrand | I like to think of photographing as a two-way act of respect. (excerpt) | [Source](https://en.wikiquote.org/wiki/Garry_Winogrand) |
| 12 | Robert Capa | If your pictures aren't good enough, you aren't close enough. | [Source](https://en.wikiquote.org/wiki/Robert_Capa) |
| 13 | Berenice Abbott | Photography doesn’t teach you how to express your emotions; it teaches you how to see. (excerpt) | [Source](https://en.wikiquote.org/wiki/Berenice_Abbott) |
| 14 | Robert Frank | Black and white are the colors of photography. (excerpt) | [Source](https://en.wikiquote.org/wiki/Robert_Frank) |
| 15 | Robert Frank | There is one thing the photograph must contain, the humanity of the moment. (excerpt) | [Source](https://en.wikiquote.org/wiki/Robert_Frank) |
| 16 | Walker Evans | The important thing is to do the picture. (excerpt) | [Source](https://en.wikiquote.org/wiki/Walker_Evans) |
| 17 | Walker Evans | It is the way to educate your eyes, and more. Stare, pry, listen, eavesdrop. | [Source](https://en.wikiquote.org/wiki/Walker_Evans) |
| 18 | Man Ray | A creator needs only one enthusiast to justify him. | [Source](https://en.wikiquote.org/wiki/Man_Ray) |
| 19 | Man Ray | I do not photograph nature. I photograph my visions. | [Source](https://en.wikiquote.org/wiki/Man_Ray) |
| 20 | Alfred Stieglitz | Photography is my passion. (excerpt) | [Source](https://en.wikiquote.org/wiki/Alfred_Stieglitz) |
| 21 | Alfred Stieglitz | Utopia is in the moment. (excerpt) | [Source](https://en.wikiquote.org/wiki/Alfred_Stieglitz) |
| 22 | Alfred Stieglitz | Nearly right is child's play | [Source](https://en.wikiquote.org/wiki/Alfred_Stieglitz) |
| 23 | Annie Leibovitz | When I take a picture I take 10 percent of what I see. | [Source](https://www.johnpaulcaponigro.com/blog/12935/28-quotes-by-photographer-annie-leibovitz/) |
| 24 | Annie Leibovitz | A very subtle difference can make the picture or not. | [Source](https://www.johnpaulcaponigro.com/blog/12935/28-quotes-by-photographer-annie-leibovitz/) |
| 25 | Irving Penn | A fashion picture is a portrait just as a portrait is a fashion picture. | [Source](https://photoquotes.com/author/irving-penn) |
| 26 | Irving Penn | Because God lights things better than most photographers I know. | [Source](https://photoquotes.com/author/irving-penn) |
| 27 | Richard Avedon | All photographs are accurate. None of them is the truth. | [Source](https://photoquotes.com/author/richard-avedon) |
| 28 | Richard Avedon | My portraits are more about me than they are about the people I photograph. | [Source](https://photoquotes.com/author/richard-avedon) |
| 29 | Elliott Erwitt | A picture should be looked at - not talked about. | [Source](https://photoquotes.com/author/elliott-erwitt) |
| 30 | Elliott Erwitt | Photography is simply a function of noticing things. Nothing more. (excerpt) | [Source](https://photoquotes.com/author/elliott-erwitt) |
| 31 | Elliott Erwitt | To me, photography is an art of observation. It’s about finding something interesting in an ordinary place. (excerpt) | [Source](https://www.brainyquote.com/authors/elliott-erwitt-quotes) |
| 32 | Edward Weston | I see no reason for recording the obvious. | [Source](https://photoquotes.com/author/edward-weston) |
| 33 | Edward Weston | Photography is the strongest way of seeing. | [Source](https://photoquotes.com/author/edward-weston) |
| 34 | Imogen Cunningham | Which of my photographs is my favorite? The one I'm going to take tomorrow. | [Source](https://photoquotes.com/author/imogen-cunningham) |
| 35 | Imogen Cunningham | The thing that’s fascinating about portraiture is that nobody is alike. | [Source](https://photoquotes.com/author/imogen-cunningham) |
| 36 | Minor White | Let the subject generate its own photographs. Become a camera. | [Source](https://photoquotes.com/author/minor-white) |
| 37 | Minor White | I am always mentally photographing everything as practice. | [Source](https://photoquotes.com/author/minor-white) |
| 38 | Paul Strand | All good art is abstract in its structure. | [Source](https://photoquotes.com/author/paul-strand) |
| 39 | Paul Strand | Your photography is a record of your living, for anyone who really sees. | [Source](https://photoquotes.com/author/paul-strand) |
| 40 | Bill Brandt | I am not interested in rules or conventions. (excerpt) | [Source](https://photoquotes.com/author/bill-brandt) |
| 41 | Bill Brandt | Photography is not a sport. It has no rules. Everything must be dared and tried! | [Source](https://photoquotes.com/author/bill-brandt) |
| 42 | Alfred Eisenstaedt | When I have a camera in my hand, I know no fear. | [Source](https://photoquotes.com/author/alfred-eisenstaedt) |
| 43 | Alfred Eisenstaedt | It is more important to click with people than to click the shutter. | [Source](https://photoquotes.com/author/alfred-eisenstaedt) |
| 44 | André Kertész | Seeing is not enough; you have to feel what you photograph. | [Source](https://photoquotes.com/author/andre-kertesz) |
| 45 | André Kertész | I do not document anything, I give an interpretation. | [Source](https://photoquotes.com/author/andre-kertesz) |
| 46 | Brassaï | To me photography must suggest, not insist or explain. | [Source](https://photoquotes.com/author/brassai) |
| 47 | Brassaï | I invent nothing, but I imagine everything. | [Source](https://photoquotes.com/author/brassai) |
| 48 | Helmut Newton | My job as a portrait photographer is to seduce, amuse and entertain. | [Source](https://photoquotes.com/author/helmut-newton) |
| 49 | Helmut Newton | Look, I'm not an intellectual - I just take pictures. | [Source](https://photoquotes.com/author/helmut-newton) |
| 50 | David Bailey | I like people with their own beauty. | [Source](https://photoquotes.com/author/david-bailey) |
| 51 | David Bailey | Everyone will take one great picture, I’ve done better because I’ve taken two. | [Source](https://photoquotes.com/author/david-bailey) |
| 52 | Don McCullin | I only use a camera like I use a toothbrush. It does the job. | [Source](https://photoquotes.com/author/don-mccullin) |
| 53 | Don McCullin | Photography isn’t about just pushing that button. (excerpt) | [Source](https://photoquotes.com/author/don-mccullin) |
| 54 | Martin Parr | I make serious photographs disguised as entertainment. | [Source](https://photoquotes.com/author/martin-parr) |
| 55 | Martin Parr | Wait for rain, it makes shooting on the street easier and more interesting. | [Source](https://photoquotes.com/author/martin-parr) |
| 56 | Steve McCurry | I strive for individual pictures that will burn in people’s memories. | [Source](https://photoquotes.com/author/steve-mccurry) |
| 57 | Steve McCurry | My photos are just a whimsical, poetic look at this commonality of humanity. | [Source](https://photoquotes.com/author/steve-mccurry) |
| 58 | William Eggleston | You can take a good picture of anything. A bad one, too. | [Source](https://photoquotes.com/author/william-eggleston) |
| 59 | William Eggleston | I am at war with the obvious. | [Source](https://photoquotes.com/author/william-eggleston) |
| 60 | William Klein | Why must a photograph be a mirror? | [Source](https://photoquotes.com/author/william-klein) |
| 61 | William Klein | If you look carefully at life, you see blur. Shake your hand. Blur is part of life. | [Source](https://photoquotes.com/author/william-klein) |
| 62 | Joel Meyerowitz | Photography looks like pictures but it's really ideas, and they're your ideas. | [Source](https://photoquotes.com/author/joel-meyerowitz) |
| 63 | Joel Meyerowitz | Making any statement of your feelings is risky. (excerpt) | [Source](https://photoquotes.com/author/joel-meyerowitz) |
| 64 | Saul Leiter | I see something, I take a picture. | [Source](https://photoquotes.com/author/saul-leiter) |
| 65 | Saul Leiter | Seeing is a neglected enterprise. | [Source](https://photoquotes.com/author/saul-leiter) |
| 66 | Saul Leiter | I don’t have a philosophy; I have a camera. | [Source](https://photoquotes.com/author/saul-leiter) |
| 67 | Sally Mann | Here is my theory of photography: I think pictures actually create memories. | [Source](https://photoquotes.com/author/sally-mann) |
| 68 | Sally Mann | Stop trying to get it right. Just take the picture. | [Source](https://photoquotes.com/author/sally-mann) |
| 69 | Mary Ellen Mark | Photograph the world as it is. Nothing's more interesting than reality. | [Source](https://photoquotes.com/author/mary-ellen-mark) |
| 70 | Mary Ellen Mark | If you can shoot on the street you can shoot anything. | [Source](https://photoquotes.com/author/mary-ellen-mark) |
| 71 | Robert Mapplethorpe | I'm looking for the unexpected. I'm looking for things I've never seen before. | [Source](https://photoquotes.com/author/robert-mapplethorpe) |
| 72 | Robert Mapplethorpe | In the end, photography is the perfect way to make a sculpture. | [Source](https://photoquotes.com/author/robert-mapplethorpe) |
| 73 | Sebastião Salgado | It’s not the photographer who makes the picture, but the person being photographed. | [Source](https://photoquotes.com/author/sebastiao-salgado) |
| 74 | Sebastião Salgado | I looked through a lens and ended up abandoning everything else. | [Source](https://photoquotes.com/author/sebastiao-salgado) |
| 75 | Robert Adams | Both poetry and photography tend toward metaphor. | [Source](https://photoquotes.com/author/robert-adams) |
| 76 | Robert Adams | Basically, you photograph because you like what you see. | [Source](https://photoquotes.com/author/robert-adams) |
| 77 | Stephen Shore | A photograph has edges, the world does not. | [Source](https://photoquotes.com/author/stephen-shore) |
| 78 | Stephen Shore | I can see things fresh. (excerpt) | [Source](https://photoquotes.com/author/stephen-shore) |
| 79 | Duane Michals | I often try to photograph things about a person that are not visible. | [Source](https://photoquotes.com/author/duane-michals) |
| 80 | Duane Michals | I use photography to help me explain my experiences to myself. | [Source](https://photoquotes.com/author/duane-michals) |
| 81 | Josef Koudelka | I prefer people to look at my pictures and invent their own stories. (excerpt) | [Source](https://photoquotes.com/author/josef-koudelka) |
| 82 | Josef Koudelka | A good photo is a miracle. (excerpt) | [Source](https://photoquotes.com/author/josef-koudelka) |
| 83 | Gordon Parks | The subject matter is so much more important than the photographer. | [Source](https://photoquotes.com/author/gordon-parks) |
| 84 | Gordon Parks | You know, the camera is not meant just to show misery. | [Source](https://photoquotes.com/author/gordon-parks) |
| 85 | James Nachtwey | I have been a witness, and these pictures are my testimony. (excerpt) | [Source](https://photoquotes.com/author/james-nachtwey) |
| 86 | James Nachtwey | My job is not to go to someplace and fall apart. | [Source](https://photoquotes.com/author/james-nachtwey) |
| 87 | David Hurn | Learn from the best; the second-raters have nothing to offer. | [Source](https://photoquotes.com/author/david-hurn) |
| 88 | Michael Kenna | Easier is not necessarily better. | [Source](https://photoquotes.com/author/michael-kenna) |
| 89 | Michael Kenna | Nothing is ever the same twice because everything is always gone forever, and yet each moment has infinite photographic possibilities. | [Source](https://photoquotes.com/author/michael-kenna) |
| 90 | Lee Friedlander | The world makes up my pictures, not me. | [Source](https://photoquotes.com/author/lee-friedlander) |
| 91 | Lee Friedlander | I tend to photograph the things that get in front of my camera. | [Source](https://photoquotes.com/author/lee-friedlander) |
| 92 | Yousuf Karsh | Character, like a photograph, develops in darkness. | [Source](https://photoquotes.com/author/yousuf-karsh) |
| 93 | Yousuf Karsh | Memorable photographs have been made with the simplest of cameras using available light. | [Source](https://photoquotes.com/author/yousuf-karsh) |
| 94 | Eve Arnold | My passport was my camera. | [Source](https://photoquotes.com/author/eve-arnold) |
| 95 | Eve Arnold | What you need to be a good photographer is an overwhelming curiosity and a good digestion. | [Source](https://photoquotes.com/author/eve-arnold) |
| 96 | Nan Goldin | If I want to take a picture, I take it no matter what. | [Source](https://photoquotes.com/author/nan-goldin) |
| 97 | Nan Goldin | Where is the line between life and photographing life? | [Source](https://photoquotes.com/author/nan-goldin) |
| 98 | Daido Moriyama | The camera doesn't matter. | [Source](https://photoquotes.com/author/daido-moriyama) |
| 99 | Daido Moriyama | A single photograph contains different images. | [Source](https://photoquotes.com/author/daido-moriyama) |
| 100 | Daido Moriyama | Making a definitive declaration of intent or meaning kills the photograph. | [Source](https://photoquotes.com/author/daido-moriyama) |

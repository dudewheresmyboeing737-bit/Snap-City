(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const Q = SC.sea50 = { built: false, ships: [], jumps: [], promenade: [], birds: [], weeds: [], veh: [], craft: [], walkers: [], buoys: [], dolphins: [], whale: null };
  const rnd = (a, b) => a + Math.random() * (b - a), pick = a => a[(Math.random() * a.length) | 0];
  const mats = {}; const m = (c, r, mt, em, op) => { const k = [c, r, mt, em, op].join("|"); return mats[k] || (mats[k] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: r ?? .7, metalness: mt || 0, emissive: em ? lin(c) : 0x000000, emissiveIntensity: em || 0, transparent: op !== undefined, opacity: op ?? 1, depthWrite: op === undefined })); };
  const BOX = new THREE.BoxGeometry(1,1,1), CYL = new THREE.CylinderGeometry(.5,.5,1,14), SPH = new THREE.SphereGeometry(.5,14,10);
  const part = (g, geo, mm, x, y, z, sx, sy, sz) => { const o = new THREE.Mesh(geo, mm); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; g.add(o); return o; };
  const wheel = (g, x, y, z, r, w) => { const o = part(g, CYL, m("#141414", .9), x, y, z, r * 2, w, r * 2); o.rotation.z = Math.PI / 2; return o; };
  const custom = k => (typeof S !== "undefined" && S && S.custom) ? S.custom[k] : undefined;
  const EDGE = () => (SC.island && SC.island.edge) || ((NOUT + .5) * P + 20);
  const SEA = -1.4;

  function sea(){
    if (!World.water) return;
    const c = document.createElement("canvas"); c.width = c.height = 256; const x = c.getContext("2d");
    const g = x.createLinearGradient(0, 0, 256, 256); g.addColorStop(0, "#1f6fa8"); g.addColorStop(.5, "#2a84bd"); g.addColorStop(1, "#1a5f94"); x.fillStyle = g; x.fillRect(0, 0, 256, 256);
    for (let k = 0; k < 140; k++){ const y = Math.random() * 256, x0 = Math.random() * 256, w = 20 + Math.random() * 60; x.strokeStyle = k % 3 ? "rgba(120,190,230,.45)" : "rgba(240,250,255,.7)"; x.lineWidth = k % 3 ? 2 : 1.4; x.beginPath(); x.moveTo(x0, y); x.quadraticCurveTo(x0 + w / 2, y - 4, x0 + w, y); x.stroke(); }
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(220, 220); t.encoding = THREE.sRGBEncoding;
    const w = World.water.material; w.map = t; w.color = lin("#ffffff"); w.roughness = .4; w.metalness = 0; if (w.emissive){ w.emissive = lin("#0b4a78"); w.emissiveIntensity = .55; } w.needsUpdate = true; Q.tex = t;

    const E = EDGE(), foamMat = new THREE.MeshBasicMaterial({ color: 0xf2f8ff, transparent: true, opacity: .5, depthWrite: false });
    Q.foam = foamMat;
    for (let side = 0; side < 4; side++){
      const f = new THREE.Mesh(new THREE.PlaneGeometry(E * 2 + 20, 5, 1, 1).rotateX(-Math.PI / 2), foamMat);
      if (side === 0) f.position.set(0, SEA + .06, E + 3); if (side === 1) f.position.set(0, SEA + .06, -E - 3);
      if (side === 2){ f.rotation.y = Math.PI / 2; f.position.set(E + 3, SEA + .06, 0); } if (side === 3){ f.rotation.y = Math.PI / 2; f.position.set(-E - 3, SEA + .06, 0); }
      G.scene.add(f);
    }

    Q.swell = [];
    for (let k = 0; k < 3; k++){
      const s = new THREE.Mesh(new THREE.RingGeometry(E * 1.42 + k * 26, E * 1.42 + k * 26 + 2.2, 4, 1).rotateX(-Math.PI / 2).rotateY(Math.PI / 4), new THREE.MeshBasicMaterial({ color: 0xdff2ff, transparent: true, opacity: .25, depthWrite: false }));
      s.position.y = SEA + .05; G.scene.add(s); Q.swell.push({ s, k });
    }
  }

  function ship(kind){
    const g = new THREE.Group(), hullC = pick(["#2b3a4a","#7a1f1f","#1f3a2a","#2f2f35"]);
    if (kind === "cargo"){ part(g, BOX, m(hullC, .6), 0, 3, 0, 22, 6, 140); part(g, BOX, m("#f2efe6", .5), 0, 11, -58, 18, 10, 14);
      for (let r = 0; r < 8; r++) for (let c = 0; c < 3; c++) for (let h = 0; h < 2; h++) part(g, BOX, m(pick(["#c0362c","#2f7fc1","#e8b82e","#3aa06b","#e36f2d","#8a8e92"]), .7), -6 + c * 6, 8 + h * 3, -40 + r * 12, 5.6, 2.8, 11.5); }
    else if (kind === "ferry"){ part(g, BOX, m("#f2efe6", .5), 0, 2.5, 0, 14, 5, 60); part(g, BOX, m("#f2efe6", .5), 0, 7, 0, 12, 4, 44); part(g, BOX, m("#1b2430", .2, .4), 0, 7, 0, 12.2, 1.2, 44.2); part(g, CYL, m("#c0362c", .5), 0, 12, -6, 3, 6, 3); }
    else { part(g, BOX, m(hullC, .6), 0, 3, 0, 20, 6, 120); part(g, BOX, m("#f2efe6", .5), 0, 10, -50, 16, 8, 12); for (let k = 0; k < 4; k++) part(g, CYL, m("#9aa0a6", .4, .5), 0, 8, -30 + k * 20, 14, 5, 14); }
    const a = Math.random() * 6.28, R = rnd(900, 1500); g.position.set(Math.cos(a) * R, SEA, Math.sin(a) * R); G.scene.add(g);
    Q.ships.push({ g, a, R, sp: rnd(.004, .009) * (Math.random() < .5 ? -1 : 1), bob: Math.random() * 6 });
  }
  function surfer(){
    if (!SC.makePerson) return;
    const g = new THREE.Group(), p = SC.makePerson(7777, false); p.g.position.y = .12; p.armL.rotation.z = 1.1; p.armR.rotation.z = -1.1; p.g.rotation.y = Math.PI / 2; g.add(p.g);
    part(g, BOX, m(pick(["#e36f2d","#f2efe6","#2f7fc1","#e8b82e"]), .4), 0, .05, 0, .6, .08, 2.4);
    const crest = part(g, SPH, m("#f2f8ff", .2, 0, 0, .75), -1.6, -.1, 0, 3.5, .7, 8);
    const E = EDGE(), side = (Math.random() * 4) | 0; G.scene.add(g);
    Q.surfer = { g, p, crest, side, u: rnd(-E * .6, E * .6), dir: 1, off: rnd(22, 34) };
  }

  function craft(kind){
    const g = new THREE.Group(), E = EDGE();
    if (kind === "sail"){ part(g, SPH, m(pick(["#f2efe6","#1e3a5f","#c0362c"]), .5), 0, .3, 0, 2.2, 1.0, 7); part(g, BOX, m("#a37c4f", .8), 0, .75, 0, 1.6, .1, 4.4); part(g, CYL, m("#e9e6de", .4), 0, 5, .3, .1, 9, .1);
      const sail = new THREE.Mesh(new THREE.BufferGeometry().setAttribute("position", new THREE.Float32BufferAttribute([0,1.2,.4, 0,9,.3, 0,1.2,-3.2], 3)), m(pick(["#fff4e0","#f2efe6","#e8b82e","#c0362c"]), .8)); sail.geometry.computeVertexNormals(); sail.material = sail.material.clone(); sail.material.side = THREE.DoubleSide; g.add(sail); }
    else if (kind === "speed"){ part(g, BOX, m(pick(["#f2efe6","#c0362c","#1a1a1a"]), .3, .2), 0, .4, 0, 1.8, .6, 5.5); part(g, BOX, m("#1b2430", .1, .4), 0, 1.0, .6, 1.5, .4, .9); if (SC.makePerson){ const d = SC.makePerson((Math.random() * 1e5) | 0, true); d.g.position.set(0, .4, -.5); g.add(d.g); }
      part(g, SPH, m("#f2f8ff", .2, 0, 0, .55), 0, 0, -6, 2.4, .1, 8); }
    else if (kind === "yacht"){ part(g, BOX, m("#f7f7f4", .3, .1), 0, 1.2, 0, 5, 2.2, 18); part(g, BOX, m("#f7f7f4", .3, .1), 0, 3.2, -1, 4, 1.8, 10); part(g, BOX, m("#1b2430", .1, .4), 0, 3.3, -1, 4.05, .7, 10.05); part(g, BOX, m("#f7f7f4", .3), 0, 4.6, -2, 2.6, 1, 4); }
    else if (kind === "kayak"){ part(g, SPH, m(pick(["#e8b82e","#c0362c","#3aa06b"]), .4), 0, .15, 0, .7, .35, 3.4); if (SC.makePerson){ const d = SC.makePerson((Math.random() * 1e5) | 0, true); d.g.position.set(0, -.1, 0); d.armL.rotation.x = d.armR.rotation.x = -1.3; g.add(d.g); } const pad = part(g, BOX, m("#2b2b2b", .6), 0, .9, .3, 2.4, .04, .08); g.userData.paddle = pad; }
    else { part(g, BOX, m(pick(["#2f5d8a","#8a1f22","#2f6b4a"]), .6), 0, .8, 0, 3.4, 1.8, 11); part(g, BOX, m("#f2efe6", .5), 0, 2.4, 2, 2.6, 1.8, 3); part(g, CYL, m("#6b6f73", .4, .5), 0, 4, -2, .12, 5, .12); const boom = part(g, CYL, m("#6b6f73", .4, .5), 1.4, 5, -2, .08, 4, .08); boom.rotation.z = 1.0; }
    const near = kind === "kayak" ? rnd(8, 30) : kind === "speed" ? rnd(40, 160) : kind === "yacht" ? rnd(120, 300) : rnd(50, 260);
    G.scene.add(g); Q.craft.push({ g, kind, R: E * 1.08 + near, a: Math.random() * 6.28, sp: (kind === "speed" ? rnd(.05, .09) : kind === "kayak" ? rnd(.004, .008) : rnd(.008, .02)) * (Math.random() < .5 ? -1 : 1), bob: Math.random() * 6 });
  }

  const FISHG = new THREE.SphereGeometry(.5, 10, 8);
  function jump(){
    const E = EDGE(), px = Player.x, pz = Player.z;
    const dx = E - Math.abs(px), dz = E - Math.abs(pz); if (Math.min(dx, dz) > 70) return;
    let x, z; const off = rnd(10, 40), along = rnd(-40, 40);
    if (dx < dz){ x = Math.sign(px) * (E + off); z = pz + along; } else { z = Math.sign(pz) * (E + off); x = px + along; }
    const g = new THREE.Group(); part(g, FISHG, m(pick(["#9fb8c2","#c9d6dc","#7a9aa8"]), .3, .5), 0, 0, 0, .35, .38, 1.2); const tail = part(g, BOX, m("#6f8a96", .4, .4), 0, 0, -.7, .05, .45, .35);
    g.position.set(x, SEA, z); g.rotation.y = Math.random() * 6.28; G.scene.add(g);
    const ring = new THREE.Mesh(new THREE.RingGeometry(.3, .6, 20).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .8, depthWrite: false })); ring.position.set(x, SEA + .07, z); G.scene.add(ring);
    Q.jumps.push({ g, tail, ring, t: 0, x, z, h: rnd(1.2, 2.4), dur: rnd(.9, 1.4), ring2: null });
  }

  function promenade(){
    if (!SC.makePerson) return;
    const E = EDGE(), inner = E - 3.2, spots = [];
    for (let side = 0; side < 4; side++) for (let u = -E + 40; u < E - 40; u += rnd(38, 60)){
      const x = side === 0 ? u : side === 1 ? u : side === 2 ? inner : -inner, z = side === 0 ? inner : side === 1 ? -inner : u, face = side === 0 ? 0 : side === 1 ? Math.PI : side === 2 ? Math.PI / 2 : -Math.PI / 2;
      spots.push({ x, z, face });
    }
    for (const s of spots){
      const kind = Math.random(), y = (() => { try{ return groundY(s.x, s.z); }catch(e){ return H(s.x, s.z) + .16; } })();
      const g = new THREE.Group(); g.position.set(s.x, y, s.z); g.rotation.y = s.face; g.userData.mergeStatic = true; G.scene.add(g);
      part(g, BOX, m("#6b4a2e", .8), 0, .45, 0, 1.8, .08, .5); part(g, BOX, m("#6b4a2e", .8), 0, .78, -.24, 1.8, .45, .06); part(g, BOX, m("#2b2926", .6), 0, .22, 0, 1.7, .44, .08);
      try{ World.colliders.push({ x0: s.x - 1, x1: s.x + 1, z0: s.z - 1, z1: s.z + 1 }); }catch(e){}
      const who = kind < .12 ? "couple" : kind < .36 ? "sit" : kind < .48 ? "fish" : kind < .58 ? "tripod" : kind < .66 ? "kite" : kind < .74 ? "paint" : kind < .84 ? "icecream" : kind < .92 ? "binoculars" : "empty";
      if (who === "couple"){
        const a = SC.makePerson((s.x * 7) | 0, true), b = SC.makePerson((s.z * 11) | 0, true);
        a.g.position.set(-.35, .06, .05); b.g.position.set(.35, .06, .05); g.add(a.g, b.g);
        a.armR.rotation.x = -.35; a.armR.rotation.z = -.55; b.armL.rotation.x = -.35; b.armL.rotation.z = .55;
        Q.promenade.push({ a, b, kind: "couple" });
      } else if (who === "sit"){ const a = SC.makePerson((s.x * 13 + s.z) | 0, true); a.g.position.set(rnd(-.4, .4), .06, .05); g.add(a.g); Q.promenade.push({ a, kind: pick(["watch","read","phone","eat"]) }); }
      else if (who === "empty"){ }
      else {
        const a = SC.makePerson((s.z * 3 + s.x) | 0, false); a.g.position.set(1.8, 0, 1.3); g.add(a.g);
        if (who === "fish"){ a.armL.rotation.x = a.armR.rotation.x = -1.1; const rod = part(a.g, CYL, m("#3a2e26", .6), 0, 1.35, .9, .03, 3.2, .03); rod.rotation.x = 1.0; part(g, BOX, m("#2f5d8a", .6), 2.4, .2, .9, .5, .4, .35); }
        if (who === "tripod"){ for (let k = 0; k < 3; k++){ const l = part(g, CYL, m("#2b2b2b"), 1.8 + Math.cos(k * 2.1) * .25, .7, 1.9 + Math.sin(k * 2.1) * .25, .025, 1.4, .025); l.rotation.set(Math.sin(k * 2.1) * .2, 0, -Math.cos(k * 2.1) * .2); } part(g, BOX, m("#1a1a1a", .4), 1.8, 1.45, 1.9, .16, .12, .22); a.armL.rotation.x = a.armR.rotation.x = -1.4; }
        if (who === "kite"){ a.armR.rotation.x = -2.4; const kite = new THREE.Group(); part(kite, BOX, m(pick(["#c0362c","#e8b82e","#2f7fc1","#8a3fb5"]), .6), 0, 0, 0, 1.2, 1.2, .02).rotation.z = Math.PI / 4; kite.position.set(0, 14, 18); g.add(kite); Q.promenade.push({ a, kite, kind: "kite" }); continue; }
        if (who === "paint"){ const ea = part(g, BOX, m("#f2efe6", .8), 2.4, 1.3, 1.9, .7, .8, .03); part(g, BOX, m("#6b4a2e"), 2.4, .65, 1.9, .05, 1.3, .05); a.g.rotation.y = .6; }
        if (who === "icecream"){ const c = part(a.armR, new THREE.ConeGeometry(.05, .14, 8), m("#d9a24a", .8), 0, -.5, .12, 1, 1, 1); c.rotation.x = Math.PI; part(a.armR, SPH, m(pick(["#f5c6d6","#f2efe6","#6b4a2e","#9acd32"]), .6), 0, -.42, .12, .1, .1, .1); }
        if (who === "binoculars"){ part(a.g, BOX, m("#1a1a1a", .4), 0, 1.52, .17, .16, .07, .1); a.armL.rotation.x = a.armR.rotation.x = -2.0; }
        Q.promenade.push({ a, kind: who });
      }
    }
  }

  function promenadeWalkers(){
    if (!SC.makePerson) return;
    const E = EDGE(), inner = E - 5.5;
    for (let k = 0; k < 10; k++){
      const side = k % 4, p = SC.makePerson((k * 977) | 0, false), jog = Math.random() < .4;
      G.scene.add(p.g); Q.walkers.push({ p, side, u: rnd(-E + 30, E - 30), dir: Math.random() < .5 ? 1 : -1, sp: jog ? rnd(2.4, 3.2) : rnd(1.0, 1.4), jog, inner });
    }
  }

  function buoys(){
    const E = EDGE();
    for (let k = 0; k < 10; k++){ const g = new THREE.Group(), red = k % 2; part(g, CYL, m(red ? "#c0362c" : "#2f8a4a", .5), 0, .6, 0, .9, 1.6, .9); part(g, new THREE.ConeGeometry(.45, .9, 10), m(red ? "#c0362c" : "#2f8a4a", .5), 0, 1.8, 0, 1, 1, 1);
      const lamp = part(g, SPH, m(red ? "#ff4a3a" : "#4aff7a", .3, 0, 1.5), 0, 2.4, 0, .25, .25, .25);
      const a = k / 10 * 6.28, R = E + 60 + (k % 3) * 25, sq = Math.max(Math.abs(Math.cos(a)), Math.abs(Math.sin(a)));
      g.position.set(Math.cos(a) * R / sq, SEA - .3, Math.sin(a) * R / sq); G.scene.add(g); Q.buoys.push({ g, lamp, ph: Math.random() * 6 }); }
  }
  function dolphins(){
    const E = EDGE(), px = Player.x, pz = Player.z; if (Math.min(E - Math.abs(px), E - Math.abs(pz)) > 90) return;
    const alongX = E - Math.abs(pz) < E - Math.abs(px), off = rnd(40, 90), base = alongX ? { x: px - 40, z: Math.sign(pz) * (E + off) } : { x: Math.sign(px) * (E + off), z: pz - 40 };
    const n = 3 + ((Math.random() * 3) | 0);
    for (let k = 0; k < n; k++){ const g = new THREE.Group(); part(g, SPH, m("#6f7f8a", .4, .2), 0, 0, 0, .7, .7, 2.4); part(g, BOX, m("#6f7f8a", .4), 0, .45, -.1, .06, .5, .4).rotation.x = -.5; part(g, BOX, m("#6f7f8a", .4), 0, 0, -1.3, .8, .06, .35);
      G.scene.add(g); Q.dolphins.push({ g, x: base.x + (alongX ? k * 2.5 : rnd(-3, 3)), z: base.z + (alongX ? rnd(-3, 3) : k * 2.5), alongX, t: -k * .35, life: 14 }); }
  }
  function jetski(){
    const g = new THREE.Group(); part(g, BOX, m(pick(["#e8b82e","#c0362c","#2f7fc1"]), .3, .2), 0, .3, 0, .9, .5, 2.6); part(g, BOX, m("#1a1a1a"), 0, .75, .2, .5, .15, .8);
    if (SC.makePerson){ const d = SC.makePerson(31337, false); d.g.position.set(0, .5, -.3); d.g.scale.multiplyScalar(.9); d.armL.rotation.x = d.armR.rotation.x = -1.2; g.add(d.g); }
    part(g, SPH, m("#f2f8ff", .2, 0, 0, .6), 0, 0, -3.5, 1.4, .1, 5); G.scene.add(g); Q.jetski = { g, a: 0, R: 30 };
  }
  function whale(){
    const E = EDGE(), px = Player.x, pz = Player.z, dx = E - Math.abs(px), dz = E - Math.abs(pz);
    if (Math.min(dx, dz) > 60 || Q.whale) return false;
    const off = rnd(45, 80), along = rnd(-25, 25), x = dx < dz ? Math.sign(px) * (E + off) : px + along, z = dx < dz ? pz + along : Math.sign(pz) * (E + off);
    const g = new THREE.Group(), skin = m("#3b4550", .6, .1), belly = m("#c9ccd0", .6);
    part(g, SPH, skin, 0, 0, 0, 5, 4.4, 16); part(g, SPH, belly, 0, -1.2, 1.5, 3.8, 2.4, 11);
    for (const s of [-1, 1]){ const f = part(g, BOX, skin, s * 3.2, -1, 2.5, 4.5, .25, 1.6); f.rotation.z = s * .5; }
    const tail = new THREE.Group(); tail.position.z = -8.5; g.add(tail); for (const s of [-1, 1]){ const f = part(tail, BOX, skin, s * 1.8, 0, -.8, 3.4, .25, 1.6); f.rotation.y = s * .4; }
    g.position.set(x, SEA - 8, z); g.rotation.y = Math.random() * 6.28; G.scene.add(g);
    Q.whale = { g, tail, t: 0, x, z, rings: [] };

    if (SC.makePerson){ const t = SC.makePerson(8080, false); const tx = px + rnd(-4, 4), tz = pz + rnd(-4, 4); t.g.position.set(tx, groundY(tx, tz), tz); t.g.lookAt(x, t.g.position.y, z); t.armL.rotation.x = t.armR.rotation.x = -1.6; part(t.g, BOX, m("#1a1a1a", .4), 0, 1.5, .2, .18, .12, .12); G.scene.add(t.g); Q.whale.tourist = t; }
    try{ if (SC.life && SC.life.feed){ SC.life.feed.unshift({ E: { x, z, done: false }, name: "A whale is breaching offshore!", t: 0 }); Q.whale.feedE = SC.life.feed[0].E; } toast("Something huge is rising out of the water…", 2200); }catch(e){}
    return true;
  }

  const HEAVY = {
    semi: { len: 15, w: 2.6, vmax: 7, build(g){ const c = pick(["#c0362c","#1e4f8a","#e9e6de","#2f6b2f","#1a1a1a"]);
      part(g, BOX, m(c, .4, .3), 0, 1.9, 5.8, 2.5, 2.6, 3); part(g, BOX, m("#1b2430", .1, .4), 0, 2.5, 7.32, 2.2, .9, .05); part(g, CYL, m("#b8bcc0", .3, .8), 1.1, 3.4, 4.6, .15, 2, .15);
      part(g, BOX, m(pick(["#e9e6de","#c9ccd0","#2f6b4a","#8a1f22"]), .6), 0, 2.4, -1.8, 2.6, 3.2, 11.5);
      for (const s of [-1, 1]){ for (const zz of [6.2, 4.4, -5, -6.3]) wheel(g, s * 1.15, .5, zz, .5, .38); } } },
    tanker: { len: 13, w: 2.5, vmax: 7, build(g){ const c = pick(["#e36f2d","#f2efe6","#1e4f8a"]);
      part(g, BOX, m(c, .4, .3), 0, 1.8, 4.9, 2.4, 2.4, 2.6); part(g, BOX, m("#1b2430", .1, .4), 0, 2.4, 6.22, 2.1, .8, .05);
      const tk = part(g, CYL, m("#c9ccd0", .25, .8), 0, 2.0, -1.4, 2.4, 9.5, 2.4); tk.rotation.x = Math.PI / 2;
      for (const s of [-1, 1]) for (const zz of [5.2, -4, -5.4]) wheel(g, s * 1.1, .5, zz, .5, .36); } },
    dump: { len: 8.4, w: 2.5, vmax: 6, build(g){ const c = pick(["#e8b82e","#e36f2d","#6b6f73"]);
      part(g, BOX, m(c, .5, .2), 0, 1.8, 3.1, 2.4, 2.2, 2.0); part(g, BOX, m("#1b2430", .1, .4), 0, 2.3, 4.12, 2.1, .8, .05);
      const bed = part(g, BOX, m(c, .6, .2), 0, 2.2, -1.1, 2.5, 1.6, 5.2); for (let k = 0; k < 3; k++) part(g, SPH, m("#7a6a52", .95), rnd(-.6, .6), 3.0, -2.6 + k * 1.4, 1.3, .7, 1.2);
      for (const s of [-1, 1]) for (const zz of [3.0, -.8, -2.6]) wheel(g, s * 1.15, .55, zz, .55, .42); } },
    army: { len: 7.6, w: 2.5, vmax: 6, build(g){ const o = m("#4b5320", .8);
      part(g, BOX, o, 0, 1.8, 2.9, 2.3, 2.0, 1.8); part(g, BOX, m("#1b2430", .1, .4), 0, 2.2, 3.82, 2, .7, .05);
      part(g, BOX, m("#5b5f3a", .9), 0, 2.5, -1.2, 2.5, 2.2, 4.8); for (let k = 0; k < 4; k++) part(g, CYL, m("#5b5f3a", .9), 0, 3.4, -3.2 + k * 1.3, 2.4, .08, .08).rotation.z = Math.PI / 2;
      for (const s of [-1, 1]) for (const zz of [2.8, -.8, -2.4]) wheel(g, s * 1.1, .55, zz, .55, .4); } },
    apc: { len: 6.6, w: 2.8, vmax: 5, build(g){ const o = m(pick(["#4b5320","#6b6b4a","#8a7a5a"]), .8);
      part(g, BOX, o, 0, 1.4, 0, 2.7, 1.6, 6.2); const nose = part(g, BOX, o, 0, 1.0, 3.4, 2.6, 1.0, 1.4); nose.rotation.x = -.5;
      part(g, BOX, o, 0, 2.4, -.6, 1.2, .5, 1.4); const gun = part(g, CYL, m("#2b2b2b"), 0, 2.5, .6, .1, 2, .1); gun.rotation.x = Math.PI / 2;
      for (const s of [-1, 1]) for (const zz of [2.2, .7, -.8, -2.3]) wheel(g, s * 1.35, .55, zz, .55, .4); } },
    tank2: { len: 7.4, w: 3.3, vmax: 3, build(g){ const o = m(pick(["#b8a47a","#8a7a5a","#4b5320"]), .8);
      part(g, BOX, o, 0, 1.0, 0, 3.1, .9, 6.8); for (const s of [-1, 1]){ part(g, BOX, m("#2a2a28", .9), s * 1.45, .55, 0, .55, 1.0, 7.2); for (let k = 0; k < 7; k++) part(g, CYL, m("#3a3a36", .8), s * 1.45, .45, -3 + k, .7, .56, .7).rotation.z = Math.PI / 2; }
      const tur = new THREE.Group(); tur.position.set(0, 1.8, -.4); g.add(tur); part(tur, SPH, o, 0, 0, 0, 2.6, 1.0, 3.0); const gun = part(tur, CYL, o, 0, .1, 3.2, .2, 4.2, .2); gun.rotation.x = Math.PI / 2; g.userData.turret = tur; } },
    limo: { len: 7.2, w: 2.0, vmax: 8, build(g){ const c = pick(["#1a1a1a","#f2efe6"]);
      part(g, BOX, m(c, .25, .5), 0, .75, 0, 1.95, .7, 7.0); part(g, BOX, m(c, .25, .5), 0, 1.3, -.4, 1.8, .5, 4.6); part(g, BOX, m("#101418", .1, .5), 0, 1.3, -.4, 1.82, .38, 4.5);
      for (const s of [-1, 1]) for (const zz of [2.6, -2.6]) wheel(g, s * .95, .36, zz, .36, .26); } }
  };
  const HEAVY_MIX = [["semi", 1.6], ["tanker", 1.1], ["dump", 1.3], ["army", .8], ["apc", .5], ["tank2", .45], ["limo", .7]];
  function wpick(list){ let t = 0; for (const [, w] of list) t += w; let r = Math.random() * t; for (const [k, w] of list){ r -= w; if (r <= 0) return k; } return list[0][0]; }
  function heavyTraffic(){
    const streets = [...new Set(Life.cars.filter(c => !c.bus).map(c => Math.round((c.z - c.lane * 1.3) / P - .5)))].map(i => (i + .5) * P);
    if (!streets.length) return;
    const tail = new THREE.MeshStandardMaterial({ color: lin("#6a1414"), emissive: lin("#ff2a1a"), emissiveIntensity: 0 });
    const n = 8 + ((Math.random() * 4) | 0), E = EDGE() - 25;
    for (let k = 0; k < n; k++){
      const kind = wpick(HEAVY_MIX), K = HEAVY[kind], g = new THREE.Group(); K.build(g);
      const lane = Math.random() < .5 ? 1 : -1, z = pick(streets) + lane * 1.3;
      let x = 0, ok = false; for (let t = 0; t < 40 && !ok; t++){ x = rnd(-E, E); ok = !Life.cars.some(o => Math.abs(o.z - z) < 1.8 && Math.abs(o.x - x) < ((o.len || 5) + K.len) / 2 + 3) && (!SC.vehicleClear || SC.vehicleClear({ len: K.len, width: K.w }, x, z)); }
      if (!ok) continue;
      G.scene.add(g);
      const c = { type: "car", special: kind, len: K.len, width: K.w, tailMat: tail, g, lane, z, x, speed: 0, vmax: K.vmax * rnd(.9, 1.1), heading: lane > 0 ? Math.PI / 2 : -Math.PI / 2, color: 0 };
      Life.cars.push(c); Q.veh.push({ kind, g, c });
    }
  }

  function birdMesh(c, span, body){ const g = new THREE.Group(), mm = m(c, .8);
    part(g, BOX, mm, 0, 0, 0, body * .3, body * .25, body); const wl = new THREE.Group(), wr = new THREE.Group();
    part(wl, BOX, mm, -span / 2, 0, 0, span, .03, body * .5); part(wr, BOX, mm, span / 2, 0, 0, span, .03, body * .5); g.add(wl, wr); g.userData.w = [wl, wr]; return g; }
  function geese(){ const E = EDGE(), a = Math.random() * 6.28, g = new THREE.Group(), n = 7 + ((Math.random() * 6) | 0), dir = new THREE.Vector3(-Math.cos(a), 0, -Math.sin(a));
    for (let k = 0; k < n; k++){ const b = birdMesh(k % 4 ? "#4a4038" : "#2b2622", 1.4, 1.0); const row = Math.ceil(k / 2), s = k % 2 ? 1 : -1; b.position.set(s * row * 2.2, 0, -row * 2.4); g.add(b); }
    g.position.set(Math.cos(a) * (E + 500), rnd(70, 120), Math.sin(a) * (E + 500)); g.lookAt(g.position.clone().add(dir)); G.scene.add(g);
    Q.birds.push({ g, kind: "geese", v: dir.multiplyScalar(14), life: 110 }); }
  function pelicans(){ const E = EDGE(), side = (Math.random() * 4) | 0, g = new THREE.Group();
    for (let k = 0; k < 3; k++){ const b = birdMesh("#e8e2d6", 1.6, 1.3); b.position.set(0, k * .4, -k * 4); g.add(b); }
    g.userData.side = side; G.scene.add(g); Q.birds.push({ g, kind: "pelican", side, u: -E - 40, life: 80 }); }
  function hawk(){ const g = birdMesh("#6b4a2e", 1.8, 1.1); G.scene.add(g); Q.birds.push({ g, kind: "hawk", a: 0, cx: rnd(-150, 150), cz: rnd(-150, 150), r: rnd(30, 60), h: rnd(60, 90), life: 90 }); }
  function parrots(){ const spot = (World.specials || []).find(s => s.kind === "park" || s.kind === "glasshouse") || { cx: 0, cz: 0 }, g = new THREE.Group();
    for (let k = 0; k < 9; k++){ const b = birdMesh(pick(["#3aa06b","#e8b82e","#c0362c","#2f7fc1"]), .35, .35); b.position.set(rnd(-3, 3), rnd(-1, 1), rnd(-3, 3)); g.add(b); }
    G.scene.add(g); Q.birds.push({ g, kind: "parrots", cx: spot.cx, cz: spot.cz, a: 0, life: 60 }); }
  function sparrows(){ const x = Player.x + rnd(-12, 12), z = Player.z + rnd(-12, 12); try{ const c = collidePoint(x, z, .3); if (Math.abs(c[0] - x) + Math.abs(c[1] - z) > .01) return; }catch(e){}
    const g = new THREE.Group(); for (let k = 0; k < 6; k++){ const b = birdMesh("#8a6a4a", .12, .14); b.position.set(rnd(-1.2, 1.2), .07, rnd(-1.2, 1.2)); b.rotation.y = Math.random() * 6; b.userData.w[0].rotation.z = .9; b.userData.w[1].rotation.z = -.9; g.add(b); }
    g.position.set(x, groundY(x, z), z); G.scene.add(g); Q.birds.push({ g, kind: "sparrows", life: 40, fly: 0 }); }

  function tumbleweed(){
    const g = new THREE.Group(), mm = m("#a08a5a", .95);
    for (let k = 0; k < 14; k++){ const t = part(g, BOX, mm, 0, 0, 0, .04, .04, rnd(.6, .9)); t.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6); }
    const along = Math.random() < .5, sz = rnd(.5, .8); g.scale.setScalar(sz);
    const street = (Math.round((along ? Player.z : Player.x) / P - .5) + .5) * P, start = (along ? Player.x : Player.z) - 60;
    const x = along ? start : street, z = along ? street : start; g.position.set(x, H(x, z) + .4, z); G.scene.add(g);
    Q.weeds.push({ g, along, v: rnd(2.5, 4.5), life: 45, bounce: Math.random() * 6 });
  }

  function rooftops(){
    const roofs = (World.roofs || []).filter(r => r.top && Math.abs(r.x) < (NOUT + .5) * P && Math.abs(r.z) < (NOUT + .5) * P);
    const lists = { ac: [], dish: [], ant: [], solar: [], tank: [], tankLeg: [], plant: [], chimney: [] };
    const push = (k, x, y, z, sx, sy, sz, ry) => { const mm = new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, ry || 0, 0)), new THREE.Vector3(sx, sy, sz)); lists[k].push(mm); };
    const bars = [];
    for (const r of roofs){
      const c = Math.cos(r.ry || 0), s = Math.sin(r.ry || 0), at = (lx, lz) => [r.x + lx * c + lz * s, r.z - lx * s + lz * c], hw = (r.w || 8) / 2 - 1, hd = (r.d || 12) / 2 - 1, y = r.top;
      const roll = Math.random(), tall = y - H(r.x, r.z) > 26;
      for (let k = 0; k < 1 + ((Math.random() * 3) | 0); k++){ const [x, z] = at(rnd(-hw, hw), rnd(-hd, hd)); push("ac", x, y + .45, z, 1.1, .9, .9, r.ry); }
      if (Math.random() < .35){ const [x, z] = at(rnd(-hw, hw), rnd(-hd, hd)); push("dish", x, y + .6, z, 1, .35, 1, r.ry); push("ant", x, y + .3, z, .08, .6, .08); }
      if (Math.random() < .3){ const [x, z] = at(rnd(-hw, hw) * .5, rnd(-hd, hd) * .5); push("ant", x, y + 2.5, z, .07, 5, .07); }
      if (roll < .22){ for (let a = 0; a < 3; a++) for (let b = 0; b < 2; b++){ const [x, z] = at(-hw * .6 + a * 1.6, -hd * .4 + b * 1.4); push("solar", x, y + .55, z, 1.4, .06, 1.1, r.ry); } }
      else if (roll < .38 && !tall){ const [x, z] = at(rnd(-hw, hw) * .6, rnd(-hd, hd) * .6); push("tank", x, y + 3.2, z, 2.6, 2.6, 2.6); for (const [lx, lz] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) push("tankLeg", x + lx, y + 1, z + lz, .15, 2, .15); }
      else if (roll < .5){ for (let k = 0; k < 6; k++){ const [x, z] = at(rnd(-hw, hw), rnd(-hd, hd)); push("plant", x, y + .5, z, rnd(.8, 1.4), rnd(.6, 1), rnd(.8, 1.4)); } }
      else if (roll < .56 && bars.length < 10){ bars.push({ r, at, y, hw, hd }); }
      if (Math.random() < .3 && !tall){ const [x, z] = at(rnd(-hw, hw), rnd(-hd, hd)); push("chimney", x, y + .9, z, .6, 1.8, .6, r.ry); }
    }
    const inst = (k, geo, mm) => { if (!lists[k].length) return; const im = new THREE.InstancedMesh(geo, mm, lists[k].length); lists[k].forEach((mt, i) => im.setMatrixAt(i, mt)); im.castShadow = true; G.scene.add(im); };
    inst("ac", BOX, m("#b8bcc0", .5, .4)); inst("dish", new THREE.SphereGeometry(.7, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2.4), m("#e9e6de", .4, .2));
    inst("ant", CYL, m("#6b6f73", .4, .6)); inst("solar", BOX, m("#1e3a5f", .15, .6)); inst("tank", new THREE.CylinderGeometry(.5, .5, 1, 14), m("#7a5a3a", .9));
    inst("tankLeg", CYL, m("#3a2e26", .8)); inst("plant", SPH, m("#4f6b3a", .9)); inst("chimney", BOX, m("#8a4a3a", .9));

    for (const b of bars){
      const g = new THREE.Group();
      for (let k = 0; k < 3; k++){ const [x, z] = b.at(-b.hw * .5 + k * b.hw * .5, 0); const u = new THREE.Group(); u.position.set(x, b.y, z); part(u, CYL, m("#2b2b2b"), 0, 1.1, 0, .05, 2.2, .05); part(u, new THREE.ConeGeometry(1.3, .6, 10), m(pick(["#c0362c","#f2efe6","#e8b82e","#2f7fc1"]), .8), 0, 2.3, 0, 1, 1, 1); g.add(u);
        if (SC.makePerson && Math.random() < .7){ const p = SC.makePerson((x * 9) | 0, false); p.g.position.set(x + .8, b.y, z + .5); p.g.rotation.y = Math.random() * 6; g.add(p.g); } }
      for (let k = 0; k < 10; k++){ const [x, z] = b.at(-b.hw + k * (b.hw * 2 / 9), b.hd * .7); part(g, SPH, m("#fff4c8", .3, 0, 1.5), x, b.y + 2.6 - Math.sin(k / 9 * Math.PI) * .4, z, .12, .12, .12); }
      g.userData.mergeStatic = true; G.scene.add(g);
    }

    const ADS = ["SNAP CITY COLA", "FILM IS NOT DEAD", "HARBOR BANK", "EAT AT JOE'S", "CANAL ST. OPERA", "SLEEP INN", "SUNNY SODA", "OCEAN AIR"];
    roofs.filter(r => r.top - H(r.x, r.z) > 14).slice(0, 8).forEach((r, i) => {
      const c = document.createElement("canvas"); c.width = 512; c.height = 192; const x = c.getContext("2d"); x.fillStyle = pick(["#c0362c","#1e3a5f","#e8b82e","#2f6b4a","#1a1a1a"]); x.fillRect(0, 0, 512, 192); x.fillStyle = "#f7f3ea"; x.textAlign = "center"; x.font = "bold 58px Georgia, serif"; x.fillText(ADS[i % ADS.length], 256, 118);
      const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding;
      const g = new THREE.Group(); g.position.set(r.x, r.top, r.z); g.rotation.y = (r.ry || 0) + (Math.random() < .5 ? 0 : Math.PI / 2);
      const board = new THREE.Mesh(new THREE.PlaneGeometry(9, 3.4), new THREE.MeshStandardMaterial({ map: t, roughness: .7, side: THREE.DoubleSide, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: .15 })); board.position.y = 4.5; g.add(board);
      for (const s of [-1, 1]) part(g, BOX, m("#2b2f33", .5, .5), s * 3.5, 1.4, -.1, .15, 2.8, .15);
      g.userData.mergeStatic = true; G.scene.add(g);
    });
  }

  if (typeof menuSettings === "function"){
    const base = menuSettings;
    window.menuSettings = function(){
      const c = S.custom; for (const [k, v] of [["seaLife","on"],["tumbleweeds","on"],["heavyTraffic","on"]]) if (c[k] === undefined) c[k] = v;
      const row = (key, label, opts, spec) => `<div class="formrow"><label>${label}</label><div class="seg" data-seg44="${key}">${opts.map(([v,l]) => `<button data-v="${v}" aria-pressed="${String(c[key])===v}">${l}</button>`).join("")}</div>${spec?`<span class="spec">${spec}</span>`:""}</div>`;
      return row("seaLife", "Sea life", [["on","On"],["off","Off"]], "Ships, sailboats, a surfer, jumping fish and seabirds around the island.") +
        row("tumbleweeds", "Tumbleweeds", [["on","On"],["off","Off"]], "Every so often one rolls down the street on the wind.") + base.apply(this, arguments);
    };
  }

  let jumpT = rnd(6, 14), geeseT = rnd(40, 90), pelT = rnd(30, 70), hawkT = rnd(20, 60), parrotT = rnd(120, 260), sparT = rnd(10, 25), weedT = rnd(90, 200);
  function build(){
    if (Q.built || typeof G === "undefined" || !G.scene || typeof World === "undefined" || !World.lots || !World.lots.length || typeof S === "undefined" || !S || !World.water) return;
    Q.built = true;
    try{ for (const k of ["cargo","ferry","tanker","cargo","ferry"]) ship(k); for (const k of ["sail","sail","sail","sail","speed","speed","yacht","yacht","kayak","kayak","kayak","trawler","trawler"]) craft(k); surfer(); promenade(); promenadeWalkers(); buoys(); jetski(); }catch(e){ console.warn("[Snap City 50] coast", e); }
    try{ rooftops(); }catch(e){ console.warn("[Snap City 50] rooftops", e); }
  }
  function tick(dt, t){
    if (!Q.seaDone && (!SC.island || SC.island.built)){ Q.seaDone = true; try{ sea(); }catch(e){ console.warn("[Snap City 50] sea", e); } }
    if (!Q.heavyDone && Life.cars.length > 10){ Q.heavyDone = true; try{ if (custom("specialTraffic") !== "off") heavyTraffic(); }catch(e){ console.warn("[Snap City 50] traffic", e); } }
    if (Q.tex){ Q.tex.offset.x = (Q.tex.offset.x + dt * .012) % 1; Q.tex.offset.y = (Q.tex.offset.y + dt * .006) % 1; }
    if (Q.foam) Q.foam.opacity = .3 + .25 * (Math.sin(t * 1.3) * .5 + .5);
    if (Q.swell) for (const s of Q.swell){ const k = ((t * .08 + s.k / 3) % 1); s.s.scale.setScalar(1 - k * .28); s.s.material.opacity = .28 * Math.sin(k * Math.PI); }
    const seaOn = custom("seaLife") !== "off";
    for (const s of Q.ships){ s.g.visible = seaOn; s.a += s.sp * dt; s.g.position.set(Math.cos(s.a) * s.R, SEA + Math.sin(t * .4 + s.bob) * .3, Math.sin(s.a) * s.R); s.g.rotation.y = -s.a + (s.sp > 0 ? 0 : Math.PI); s.g.rotation.z = Math.sin(t * .5 + s.bob) * .02; }
    for (const c of Q.craft){ c.g.visible = seaOn; c.a += c.sp * dt * 60 / c.R; const sq = Math.max(Math.abs(Math.cos(c.a)), Math.abs(Math.sin(c.a))), x = Math.cos(c.a) * c.R / sq, z = Math.sin(c.a) * c.R / sq;
      c.g.position.set(x, SEA + Math.sin(t * 1.1 + c.bob) * .15, z); const nx = Math.cos(c.a + .01 * Math.sign(c.sp)) / Math.max(Math.abs(Math.cos(c.a + .01 * Math.sign(c.sp))), Math.abs(Math.sin(c.a + .01 * Math.sign(c.sp)))) * c.R, nz = Math.sin(c.a + .01 * Math.sign(c.sp)) / Math.max(Math.abs(Math.cos(c.a + .01 * Math.sign(c.sp))), Math.abs(Math.sin(c.a + .01 * Math.sign(c.sp)))) * c.R;
      c.g.rotation.y = Math.atan2(nx - x, nz - z); c.g.rotation.z = Math.sin(t * .8 + c.bob) * (c.kind === "sail" ? .08 : .03); if (c.g.userData.paddle) c.g.userData.paddle.rotation.z = Math.sin(t * 2.5 + c.bob) * .5; }
    if (Q.surfer){ const f = Q.surfer, E = EDGE(); f.g.visible = seaOn; f.u += f.dir * dt * 5; if (Math.abs(f.u) > E * .7) f.dir *= -1;
      const off = E + f.off, x = f.side === 0 ? f.u : f.side === 1 ? f.u : f.side === 2 ? off : -off, z = f.side === 0 ? off : f.side === 1 ? -off : f.u;
      f.g.position.set(x, SEA + .2 + Math.sin(t * 1.4) * .25, z); f.g.rotation.y = (f.side < 2 ? 0 : Math.PI / 2) + (f.dir > 0 ? 0 : Math.PI) + Math.PI / 2; f.g.rotation.z = Math.sin(t * .9) * .12; }
    for (const w of Q.walkers){ const p = w.p; w.u += w.dir * w.sp * dt; if (Math.abs(w.u) > EDGE() - 25) w.dir *= -1; const inner = w.inner, x = w.side === 0 ? w.u : w.side === 1 ? w.u : w.side === 2 ? inner : -inner, z = w.side === 0 ? inner : w.side === 1 ? -inner : w.u;
      p.g.position.set(x, groundY(x, z), z); p.g.rotation.y = (w.side < 2 ? Math.PI / 2 : 0) * (w.dir > 0 ? 1 : -1) + (w.side >= 2 && w.dir < 0 ? Math.PI : 0); const sw = Math.sin(t * (w.jog ? 10 : 6) + w.u) * (w.jog ? .8 : .4); p.armL.rotation.x = sw; p.armR.rotation.x = -sw; }
    for (const b of Q.buoys){ b.g.position.y = SEA - .3 + Math.sin(t * 1.3 + b.ph) * .2; b.g.rotation.z = Math.sin(t * .9 + b.ph) * .08; b.lamp.material.emissiveIntensity = Math.sin(t * 2 + b.ph) > .7 ? 2.5 : .2; }
    if (seaOn && Game.started && (Q.dolT = (Q.dolT ?? rnd(30, 70)) - dt) <= 0){ Q.dolT = rnd(60, 140); dolphins(); }
    Q.dolphins = Q.dolphins.filter(d => { d.t += dt; d.life -= dt; const ph = ((d.t % 2.2) + 2.2) % 2.2, up = d.t > 0 && ph < 1.1; const adv = d.t * 6; d.g.position.set(d.alongX ? d.x + adv : d.x, SEA + (up ? Math.sin(ph / 1.1 * Math.PI) * 1.6 : -1), d.alongX ? d.z : d.z + adv); d.g.rotation.y = d.alongX ? Math.PI / 2 : 0; d.g.rotation.x = up ? -Math.cos(ph / 1.1 * Math.PI) * .7 : 0; d.g.visible = up; if (d.life <= 0){ G.scene.remove(d.g); return false; } return true; });
    if (Q.jetski){ const j = Q.jetski, E = EDGE(); j.g.visible = seaOn; j.a += dt * .45; const cx = E + 70, x = Math.cos(j.a) * 40, z = cx + Math.sin(j.a) * 22; j.g.position.set(x, SEA + .15 + Math.abs(Math.sin(t * 3)) * .1, z); j.g.rotation.y = -j.a; j.g.rotation.z = -.25; }
    if (seaOn && Game.started && (Q.whaleT = (Q.whaleT ?? rnd(200, 420)) - dt) <= 0){ Q.whaleT = whale() ? rnd(420, 900) : 20; }
    if (Q.whale){ const w = Q.whale; w.t += dt; const u = w.t / 7;
      if (u < 1){ const y = Math.sin(u * Math.PI); w.g.position.y = SEA - 8 + y * 13; w.g.rotation.x = -Math.cos(u * Math.PI) * .9; w.tail.rotation.x = Math.sin(t * 2) * .3; w.g.position.x += Math.sin(w.g.rotation.y) * dt * 4; w.g.position.z += Math.cos(w.g.rotation.y) * dt * 4; }
      if (u > .15 && !w.splash1){ w.splash1 = true; const r = new THREE.Mesh(new THREE.RingGeometry(1, 2, 28).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .9, depthWrite: false })); r.position.set(w.x, SEA + .08, w.z); G.scene.add(r); w.rings.push({ r, t: 0 }); }
      if (u > .95 && !w.splash2){ w.splash2 = true; const r = new THREE.Mesh(new THREE.RingGeometry(1, 3, 28).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .95, depthWrite: false })); r.position.set(w.g.position.x, SEA + .08, w.g.position.z); G.scene.add(r); w.rings.push({ r, t: 0 }); }
      for (const r of w.rings){ r.t += dt; r.r.scale.setScalar(1 + r.t * 4); r.r.material.opacity = Math.max(0, .9 - r.t * .25); }
      if (w.t > 12){ G.scene.remove(w.g); for (const r of w.rings) G.scene.remove(r.r); if (w.tourist) G.scene.remove(w.tourist.g); if (w.feedE) w.feedE.done = true; Q.whale = null; } }

    if (seaOn && (jumpT -= dt) <= 0){ jumpT = rnd(9, 24); jump(); }
    Q.jumps = Q.jumps.filter(j => {
      j.t += dt; const u = j.t / j.dur;
      if (u < 1){ j.g.position.y = SEA + Math.sin(u * Math.PI) * j.h; j.g.rotation.x = -Math.cos(u * Math.PI) * 1.1; j.tail.rotation.y = Math.sin(t * 30) * .5; }
      else { j.g.visible = false; if (!j.ring2){ j.ring2 = j.ring.clone(); j.ring2.material = j.ring.material.clone(); const d = new THREE.Vector3(0, 0, 1).applyQuaternion(j.g.quaternion); j.ring2.position.set(j.x + d.x * j.h * 1.1, SEA + .07, j.z + d.z * j.h * 1.1); G.scene.add(j.ring2); } }
      j.ring.scale.setScalar(1 + j.t * 2.2); j.ring.material.opacity = Math.max(0, .8 - j.t * .45);
      if (j.ring2){ const k = j.t - j.dur; j.ring2.scale.setScalar(1 + k * 2.5); j.ring2.material.opacity = Math.max(0, .9 - k * .5); }
      if (j.t > j.dur + 2){ G.scene.remove(j.g); G.scene.remove(j.ring); if (j.ring2) G.scene.remove(j.ring2); return false; } return true;
    });

    for (const p of Q.promenade){ if (p.kind === "couple"){ p.a.head.rotation.y = -.3 + Math.sin(t * .3) * .2; p.b.head.rotation.y = .3 + Math.sin(t * .35 + 1) * .2; }
      else if (p.kind === "read"){ p.a.armL.rotation.x = p.a.armR.rotation.x = -1.2; p.a.head.rotation.x = .35; }
      else if (p.kind === "kite"){ p.kite.position.set(Math.sin(t * .4) * 4, 14 + Math.sin(t * .7) * 2, 18); p.kite.rotation.z = Math.sin(t * .9) * .4; p.a.armR.rotation.x = -2.4 + Math.sin(t * .7) * .2; }
      else if (p.kind === "eat" || p.kind === "icecream"){ p.a.armR.rotation.x = -1.2 - Math.max(0, Math.sin(t * .8 + p.a.phase)) * .6; }
      else if (p.kind === "paint"){ p.a.armR.rotation.x = -1.4 + Math.sin(t * 1.2) * .3; }
      else if (p.kind === "tripod" || p.kind === "binoculars"){ p.a.head.rotation.y = Math.sin(t * .15) * .2; } else if (p.kind === "phone"){ p.a.armR.rotation.x = -1.8; } else if (p.kind === "fish"){ p.a.armR.rotation.x = -1.1 + Math.sin(t * .6) * .1; } else p.a.head.rotation.y = Math.sin(t * .2) * .4; }

    if (seaOn){ if ((geeseT -= dt) <= 0){ geeseT = rnd(90, 180); geese(); } if ((pelT -= dt) <= 0){ pelT = rnd(60, 130); pelicans(); } }
    if ((hawkT -= dt) <= 0){ hawkT = rnd(80, 160); hawk(); }
    if ((parrotT -= dt) <= 0){ parrotT = rnd(240, 480); parrots(); }
    if ((sparT -= dt) <= 0){ sparT = rnd(25, 50); sparrows(); }
    const E = EDGE();
    Q.birds = Q.birds.filter(b => {
      b.life -= dt;
      const flap = (g, sp, amt) => g.traverse(o => { if (o.userData.w){ const f = Math.sin(t * sp + o.id) * amt; o.userData.w[0].rotation.z = f; o.userData.w[1].rotation.z = -f; } });
      if (b.kind === "geese"){ b.g.position.addScaledVector(b.v, dt); flap(b.g, 6, .45); }
      else if (b.kind === "pelican"){ b.u += dt * 11; const off = E + 18, x = b.side < 2 ? b.u : (b.side === 2 ? off : -off), z = b.side < 2 ? (b.side === 0 ? off : -off) : b.u; b.g.position.set(x, SEA + 1.4 + Math.sin(t) * .3, z); b.g.rotation.y = b.side < 2 ? Math.PI / 2 : 0; flap(b.g, 2, .12); }
      else if (b.kind === "hawk"){ b.a += dt * .25; b.g.position.set(b.cx + Math.cos(b.a) * b.r, b.h, b.cz + Math.sin(b.a) * b.r); b.g.rotation.y = -b.a; b.g.rotation.z = .35; flap(b.g, 3, Math.sin(t * .5) > .8 ? .4 : .03); }
      else if (b.kind === "parrots"){ b.a += dt * .6; b.g.position.set(b.cx + Math.cos(b.a) * 16, 10 + Math.sin(t) * 2, b.cz + Math.sin(b.a) * 16); b.g.rotation.y = -b.a; flap(b.g, 14, .6); }
      else if (b.kind === "sparrows"){ const near = Math.hypot(b.g.position.x - Player.x, b.g.position.z - Player.z) < 3; if (near && !b.fly) b.fly = .01;
        if (b.fly){ b.fly += dt; b.g.position.y += dt * 4; b.g.position.x += dt * 3; flap(b.g, 22, .8); if (b.fly > 5) b.life = 0; }
        else b.g.children.forEach((c, i) => { c.position.y = .07 + Math.max(0, Math.sin(t * 6 + i * 1.7)) * .06; }); }
      if (b.life <= 0){ G.scene.remove(b.g); return false; } return true;
    });

    if (custom("tumbleweeds") !== "off" && Game.started && !(S.rain || S.storm || S.snow) && (weedT -= dt) <= 0){ weedT = rnd(150, 360); tumbleweed(); }
    Q.weeds = Q.weeds.filter(w => {
      w.life -= dt; const d = w.v * dt; if (w.along) w.g.position.x += d; else w.g.position.z += d;
      const x = w.g.position.x, z = w.g.position.z; w.g.position.y = H(x, z) + .35 + Math.abs(Math.sin(t * 3 + w.bounce)) * .45;
      if (w.along) w.g.rotation.z -= d * 1.6; else w.g.rotation.x += d * 1.6;
      if (w.life <= 0){ G.scene.remove(w.g); return false; } return true;
    });
    for (const v of Q.veh){ if (v.g.userData.turret) v.g.userData.turret.rotation.y = Math.sin(t * .25) * .6; }
  }
  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{ if (!Q.built) build(); if (typeof S !== "undefined" && S) tick(dt, performance.now() / 1000); }catch(e){ console.warn("[Snap City 50]", e); }
      return r;
    };
  }
  const iv = setInterval(() => { try{ build(); if (Q.built) clearInterval(iv); }catch(e){} }, 700);
})();

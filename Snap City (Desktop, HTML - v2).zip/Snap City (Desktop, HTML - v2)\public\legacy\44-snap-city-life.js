(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const LIFE = SC.life = { shopFolk: [], feed: [], built: false };

  const NEW_DEFAULTS = {
    renderQuality: "balanced", graphicsPreset: "medium",
    shotPreview: "on", shotPreviewTime: "normal",
    neighborhoodIdentity: "off",
    eventNotices: "on", mapLegend: "button", startWeather: "random",
    shopLife: "lively", carVariety: "high", locationLabel: "street",
    minimapSize: "normal", crosshair: "dot", uiScale: "100"
  };
  function migrate(s){
    if (!s || !s.custom) return s;
    if (!s.custom._sc44){ Object.assign(s.custom, NEW_DEFAULTS); s.custom._sc44 = 1; }
    for (const k in NEW_DEFAULTS) if (s.custom[k] === undefined) s.custom[k] = NEW_DEFAULTS[k];
    return s;
  }
  if (typeof defaultState === "function"){ const base = defaultState; window.defaultState = function(){ return migrate(base.apply(this, arguments)); }; }
  if (typeof loadState === "function"){ const base = loadState; window.loadState = function(){ return migrate(base.apply(this, arguments)); }; }

  if (typeof startGame === "function"){
    const base = startGame;
    window.startGame = function(){
      const r = base.apply(this, arguments);
      try{
        migrate(S); applyUiPrefs();
        if (S.custom.startWeather === "random"){
          const roll = Math.random();
          const mode = roll < 0.5 ? "clear" : roll < 0.75 ? "rain" : roll < 0.87 ? "storm" : "clear";
          const fog = Math.random() < (mode === "clear" ? 0.22 : 0.35);
          if (SC.weather) SC.weather(mode, fog); else { S.rain = mode !== "clear"; S.storm = mode === "storm"; S.fog = fog; applyTime(); }
          if (S.custom.autoWeather !== "on") S.weatherManual = false;
        }
      }catch(e){ console.warn("[Snap City] start weather skipped", e); }
      return r;
    };
  }

  function applyUiPrefs(){
    if (typeof S === "undefined" || !S || !S.custom) return;
    const b = document.body;
    b.dataset.loc = S.custom.locationLabel || "street";
    b.dataset.mapsize = S.custom.minimapSize || "normal";
    b.dataset.crosshair = S.custom.crosshair || "dot";
    document.documentElement.style.setProperty("--sc-ui-scale", (+S.custom.uiScale || 100) / 100);
    const leg = document.getElementById("mapLegend"); if (leg) leg.classList.toggle("always", S.custom.mapLegend === "always");
    const feed = document.getElementById("eventFeed"); if (feed) feed.classList.toggle("off", S.custom.eventNotices === "off");
  }
  SC.applyUiPrefs = applyUiPrefs;

  function ensureMapUI(){
    const hud = document.getElementById("hud"); if (!hud || document.getElementById("mapLegend")) return;
    const wrap = document.createElement("div"); wrap.id = "mapSide"; wrap.className = "interactive";
    wrap.innerHTML = `<button id="mapLegendBtn" title="What do the map symbols mean?" aria-expanded="false">? Map key</button>
      <div id="mapLegend" role="note" aria-label="Map key">
        <div><i class="mk you"></i>You (arrow points where you face)</div>
        <div><i class="mk ev"></i>Street event</div><div><i class="mk evr"></i>Rare event</div>
        <div><i class="mk bus"></i>City bus</div><div><i class="mk tram"></i>Tram</div><div><i class="mk car"></i>Heritage streetcar</div>
        <div><i class="mk dog"></i>Dog walker</div><div><i class="mk bird"></i>Pigeon flock</div>
        <div><i class="mk blk"></i>City block</div><div><i class="mk rd"></i>Street</div>
      </div>
      <div id="eventFeed" aria-live="polite"></div>`;
    hud.appendChild(wrap);
    const btn = wrap.querySelector("#mapLegendBtn"), leg = wrap.querySelector("#mapLegend");
    btn.onclick = () => { const on = !leg.classList.contains("open"); leg.classList.toggle("open", on); btn.setAttribute("aria-expanded", on); };
    applyUiPrefs();
  }
  function compass(dx, dz){

    const a = Math.atan2(dx, -dz), dirs = ["N","NE","E","SE","S","SW","W","NW"];
    return dirs[((Math.round(a / (Math.PI/4)) % 8) + 8) % 8];
  }
  function pushFeed(E, name){
    if (!E || typeof S === "undefined" || S.custom.eventNotices === "off") return;
    ensureMapUI();
    const item = { E, name: name || (E.info && E.info.name) || String(E.type || "something").replace(/_/g, " "), t: 0 };
    LIFE.feed.unshift(item); LIFE.feed = LIFE.feed.slice(0, 4);
    renderFeed();
  }
  function renderFeed(){
    const el = document.getElementById("eventFeed"); if (!el) return;
    LIFE.feed = LIFE.feed.filter(f => f.t < 45 && !(f.E && f.E.done));
    el.innerHTML = LIFE.feed.map((f, index) => {
      const x = f.E.x !== undefined ? f.E.x : (f.E.ppl && f.E.ppl[0] ? f.E.ppl[0].x : Player.x), z = f.E.z !== undefined ? f.E.z : (f.E.ppl && f.E.ppl[0] ? f.E.ppl[0].z : Player.z);
      const d = Math.hypot(x - Player.x, z - Player.z);
      return `<button type="button" class="ef" data-event-index="${index}" title="Flash this area on the map"><b>${f.name}</b><span>${d < 12 ? "right here" : Math.round(d) + " m " + compass(x - Player.x, z - Player.z)}</span></button>`;
    }).join("");
  }
  if (typeof startEvent === "function"){
    const base = startEvent;
    window.startEvent = function(type){
      const E = base.apply(this, arguments);
      try{ if (E) pushFeed(E, (typeof EVENTS !== "undefined" && EVENTS[type] && EVENTS[type].name) || null); }catch(e){}
      return E;
    };
  }

  const MORE = [
    ["sc_busker_duo","a busking duo",2,140,["dance","cheer"],["smile","smile"],"none","Two buskers trade verses on the corner."],
    ["sc_proposal","a sidewalk proposal",2,120,["kneel","surprised"],["smile","surprised"],"flowers","Someone drops to one knee outside the café."],
    ["sc_lost_dog","the lost-dog poster",2,150,["point","watch"],["sad","curious"],"sign","A kid tapes a LOST DOG poster to a lamppost."],
    ["sc_chalk","chalk artists",2,200,["kneel","kneel"],["curious","smile"],"mural","Chalk artists are turning the pavement into a mural."],
    ["sc_selfie","the group selfie",3,110,["phone","cheer","wave"],["smile","smile","smile"],"none","A group squeezes in for a selfie."],
    ["sc_argument","a parking argument",2,120,["point","point"],["angry","angry"],"none","Two drivers argue over a parking space."],
    ["sc_delivery","the big delivery",2,140,["give","take"],["curious","smile"],"suitcase","A courier wrestles a huge parcel to a doorway."],
    ["sc_reunion","a reunion",2,110,["hug","hug"],["smile","smile"],"suitcase","Two old friends spot each other across the street."],
    ["sc_chess","sidewalk chess",2,220,["watch","point"],["curious","curious"],"lunch","A sidewalk chess game draws a quiet crowd."],
    ["sc_breakdance","breakdancers",3,160,["dance","dance","cheer"],["smile","smile","surprised"],"none","Breakdancers roll out a piece of cardboard."],
    ["sc_protest","a small march",4,200,["cheer","cheer","point","cheer"],["angry","smile","angry","smile"],"sign","A small march turns the corner with hand-painted signs."],
    ["sc_flower_cart","the flower cart",2,180,["give","take"],["smile","smile"],"flowers","A flower seller sets out buckets of tulips."],
    ["sc_newlyweds","newlyweds",2,130,["hug","wave"],["smile","smile"],"flowers","Newlyweds pose on the town hall steps."],
    ["sc_graduation","graduation photos",3,150,["cheer","phone","wave"],["smile","smile","smile"],"prints","Graduates throw their caps for a family photo."],
    ["sc_fortune","the fortune teller",2,160,["watch","talk"],["curious","smile"],"coin","A fortune teller reads palms at a folding table."],
    ["sc_mime","the mime",2,140,["point","watch"],["surprised","smile"],"none","A mime is trapped in an invisible box."],
    ["sc_sketch","the sketcher",1,180,["watch"],["curious"],"prints","Someone sketches the street on a folding stool."],
    ["sc_film_crew","a film crew",4,220,["point","watch","phone","talk"],["curious","curious","smile","curious"],"film","A small film crew blocks off the sidewalk for a take."],
    ["sc_rain_dash","the rain dash",2,90,["run","run"],["surprised","smile"],"none","Two people sprint for cover under one jacket."],
    ["sc_kite","the kite",2,130,["point","cheer"],["smile","surprised"],"none","A kid's kite catches the wind between buildings."],
    ["sc_bike_fix","the bike repair",2,150,["kneel","watch"],["curious","curious"],"none","A cyclist fixes a chain on the curb."],
    ["sc_yoga","yoga in the plaza",3,200,["dance","dance","dance"],["smile","smile","smile"],"none","A yoga class spills onto the plaza."],
    ["sc_bake_sale","the bake sale",3,200,["give","take","talk"],["smile","smile","curious"],"lunch","A school bake sale sets up on a folding table."],
    ["sc_street_food","the food cart",3,180,["give","take","talk"],["smile","smile","smile"],"market","A food cart draws a lunch queue."],
    ["sc_open_mic","the open mic",3,180,["cheer","talk","watch"],["smile","smile","curious"],"none","Someone reads poetry to anyone who'll listen."],
    ["sc_fashion","a fashion shoot",3,190,["dance","point","watch"],["smile","curious","curious"],"runway","A fashion shoot takes over a stretch of sidewalk."],
    ["sc_gallery","the pop-up gallery",3,220,["point","watch","talk"],["curious","curious","smile"],"gallery","A pop-up gallery hangs prints along a wall."],
    ["sc_parade","the neighbourhood parade",5,240,["cheer","dance","cheer","wave","dance"],["smile","smile","smile","smile","smile"],"sign","A neighbourhood parade comes up the street."],
    ["sc_birthday","a surprise party",4,140,["cheer","cheer","give","surprised"],["smile","smile","smile","surprised"],"none","A surprise birthday bursts out of a doorway."],
    ["sc_market_day","market day",5,260,["give","take","talk","point","watch"],["smile","smile","curious","curious","smile"],"market","Stalls pop up for an impromptu street market."]
  ];
  function addStories(){
    if (!SC.stories || typeof EVENTS === "undefined" || SC._more) return;
    SC._more = true;
    for (const [id, name, n, d, pose, mood, prop, cue] of MORE){
      const major = ["market","runway","gallery","mural"].includes(prop) || n >= 4;
      SC.stories.push({ id, name, n, d, pose, mood, prop, cue, major });
      EVENTS[id] = { name, w: major ? .45 : .65, bonus: major ? 16 : 10, night: false };
    }
  }
  let extraStoryT = 14;
  function frequentStories(dt){
    if (!SC.startStory || S.custom.streetMoments !== "frequent") return;
    extraStoryT -= dt;
    if (extraStoryT > 0) return;
    extraStoryT = 12 + Math.random() * 10;
    const active = (typeof EV !== "undefined" ? EV.list : []).filter(e => String(e.type).startsWith("sc_")).length;
    if (active >= 4) return;
    const list = SC.stories.filter(x => !x.night || S.time === "night" || S.time === "blue");
    const d = list[(Math.random() * list.length) | 0];
    try{ SC.startStory(d.id); }catch(e){}
  }

  const SHOP_ACTS = {
    cafe: ["eat","sip","sip","read","talk"], bar: ["sip","sip","talk","talk","lean"], diner: ["eat","eat","talk","sip"],
    restaurant: ["eat","eat","talk","sip"], pizza: ["eat","eat","talk"], noodle: ["eat","eat","sip"],
    video: ["browse","browse","browse","hold"], books: ["browse","read","read","browse"], records: ["browse","listen","browse"],
    barber: ["chair","wait","read"], laundry: ["wait","read","fold"], market: ["browse","hold","browse"],
    florist: ["browse","hold"], default: ["browse","wait","talk"]
  };
  const SEATED = new Set(["eat","sip","read","talk","chair","wait","listen"]);
  const pmat = {}; function mat(c){ return pmat[c] || (pmat[c] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: .85 })); }
  const PG = {};
  function geos(){
    if (PG.box) return PG;
    PG.box = new THREE.BoxGeometry(1,1,1); PG.cyl = new THREE.CylinderGeometry(.5,.5,1,8); PG.head = new THREE.SphereGeometry(.12, 10, 8); return PG;
  }
  const COATS = ["#303f56","#5b4658","#465c49","#6b3f3c","#39414b","#665f79","#8a5a2e","#2f6b6b","#a8433b","#c9a24a","#e4ddcf","#1f2226"];
  const SKINS = ["#f1c9a8","#e0b394","#c29172","#a8744f","#8d5a3c","#6b4430","#4a3021"];
  const HAIR = ["#1a1411","#3b2618","#6b4a2e","#a67b4b","#d9c08a","#8a8a8a","#c24f2a","#e8e2d6"];
  function person(seed, seated){
    geos(); const r = mulberry(seed), pk = a => a[(r() * a.length) | 0];
    const g = new THREE.Group(), coat = mat(pk(COATS)), legs = mat(pk(["#27292c","#3a3f46","#2a3550","#5a4a3a","#1d1d1d"])), skin = mat(pk(SKINS)), hair = mat(pk(HAIR));
    const tall = 0.92 + r() * 0.16;
    const add = (geo, m, x, y, z, sx, sy, sz) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.scale.set(sx, sy, sz); g.add(o); return o; };
    const hip = seated ? 0.46 : 0.86;
    if (seated){ add(PG.box, legs, -.08, .46, .2, .12, .12, .42); add(PG.box, legs, .08, .46, .2, .12, .12, .42); add(PG.box, legs, -.08, .23, .4, .11, .46, .11); add(PG.box, legs, .08, .23, .4, .11, .46, .11); }
    else { add(PG.box, legs, -.08, .43, 0, .13, .86, .13); add(PG.box, legs, .08, .43, 0, .13, .86, .13); }
    add(PG.box, coat, 0, hip + .3, 0, .36, .6, .2);
    const head = add(PG.head, skin, 0, hip + .74, 0, 1, 1.1, 1);
    add(PG.head, hair, 0, hip + .8, -.02, 1.05, .8, 1.05);
    const armL = new THREE.Group(), armR = new THREE.Group(); armL.position.set(-.22, hip + .56, 0); armR.position.set(.22, hip + .56, 0);
    const a1 = new THREE.Mesh(PG.box, coat); a1.scale.set(.1, .5, .1); a1.position.y = -.25; armL.add(a1);
    const a2 = new THREE.Mesh(PG.box, coat); a2.scale.set(.1, .5, .1); a2.position.y = -.25; armR.add(a2);
    g.add(armL, armR); g.scale.setScalar(tall);
    return { g, head, armL, armR, phase: r() * 6.28 };
  }
  SC.makePerson = person;
  function fitRoomBits(sh, depth){
    const th = SHOPS[sh.theme] || {}, id = th.id || "default";
    const acts = SHOP_ACTS[id] || SHOP_ACTS.default;
    const n = sh.n, room = new THREE.Group();
    const at = (along, inn, y) => [sh.x + n[1]*along - n[0]*inn, sh.gy + y, sh.z - n[0]*along - n[1]*inn];
    const ry = Math.atan2(n[0], n[1]);
    const place = (obj, along, inn, y, face) => { const p = at(along, inn, y); obj.position.set(p[0], p[1], p[2]); obj.rotation.y = ry + (face || 0); room.add(obj); return obj; };
    const W = sh.w, wood = mat(["#6b4a2e","#4a3424","#8a6a44","#2b2926"][sh.theme % 4]), top = mat("#d9d2c2");

    const cAlong = W * 0.25, cInn = depth - 1.25;
    const counter = new THREE.Mesh(geos().box, wood); counter.scale.set(Math.min(2.6, W*0.4), 1.05, .6); place(counter, cAlong, cInn, .52);
    const ctop = new THREE.Mesh(PG.box, top); ctop.scale.set(Math.min(2.7, W*0.42), .05, .7); place(ctop, cAlong, cInn, 1.07);
    const reg = new THREE.Mesh(PG.box, mat("#1f2226")); reg.scale.set(.35, .22, .3); place(reg, cAlong + .5, cInn, 1.2);
    const clerk = person(sh.theme * 131 + Math.round(sh.x * 7), false); place(clerk.g, cAlong, cInn + .7, 0, Math.PI);
    LIFE.shopFolk.push(Object.assign(clerk, { act: "clerk" }));
    LIFE.counter = { x: at(cAlong, cInn - .45, 0)[0], z: at(cAlong, cInn - .45, 0)[2], id };

    if (S.custom.shopLife !== "off"){
      const count = S.custom.shopLife === "quiet" ? 2 : 4 + ((Math.random() * 3) | 0);
      for (let k = 0; k < count; k++){
        const act = acts[k % acts.length], seated = SEATED.has(act);
        const along = -W/2 + 1 + (k / Math.max(1, count - 1)) * (W * 0.55), inn = 1.9 + (k % 2) * 1.6;
        const who = person(sh.theme * 977 + k * 53 + Math.round(sh.z * 3), seated);
        if (seated && (act === "eat" || act === "sip" || act === "talk" || act === "read")){
          const table = new THREE.Mesh(PG.cyl, top); table.scale.set(.75, .05, .75); place(table, along, inn + .5, .74);
          const leg = new THREE.Mesh(PG.cyl, mat("#2b2926")); leg.scale.set(.08, .72, .08); place(leg, along, inn + .5, .37);
          const plate = new THREE.Mesh(PG.cyl, mat(act === "sip" ? "#e4d7bd" : "#f4f4f0")); plate.scale.set(act === "sip" ? .09 : .26, act === "sip" ? .14 : .02, act === "sip" ? .09 : .26); place(plate, along, inn + .38, act === "sip" ? .84 : .78);
          const seat = new THREE.Mesh(PG.box, wood); seat.scale.set(.42, .06, .42); place(seat, along, inn, .44);
          place(who.g, along, inn, 0, 0);
        } else if (act === "chair"){
          const chair = new THREE.Mesh(PG.box, mat("#8a1f22")); chair.scale.set(.6, .5, .6); place(chair, along, inn, .25); place(who.g, along, inn, .1, 0);
        } else if (act === "browse" || act === "hold" || act === "listen"){
          const shelf = new THREE.Mesh(PG.box, wood); shelf.scale.set(1.4, 1.8, .35); place(shelf, along, inn + .75, .9);
          for (let b = 0; b < 8; b++){ const it = new THREE.Mesh(PG.box, mat(COATS[(b * 3 + k) % COATS.length])); it.scale.set(.12, .28, .2); place(it, along - .6 + b * .17, inn + .6, .4 + ((b % 3) * .5)); }
          place(who.g, along, inn, 0, Math.PI);
        } else place(who.g, along, inn, 0, (Math.random() - .5));
        LIFE.shopFolk.push(Object.assign(who, { act }));
      }
    }
    G.scene.add(room); LIFE.room = room;
  }
  function clearRoomBits(){ if (LIFE.room){ G.scene.remove(LIFE.room); LIFE.room = null; } LIFE.shopFolk = []; LIFE.counter = null; }
  function animateShop(t){
    for (const p of LIFE.shopFolk){
      const s = Math.sin(t * 1.6 + p.phase);
      if (p.act === "eat"){ p.armR.rotation.x = -1.1 - Math.max(0, s) * .8; p.head.rotation.x = Math.max(0, s) * .15; }
      else if (p.act === "sip"){ p.armR.rotation.x = -1 - Math.max(0, Math.sin(t * .7 + p.phase)) * 1.1; }
      else if (p.act === "read"){ p.armL.rotation.x = p.armR.rotation.x = -1.2; p.head.rotation.x = .35; }
      else if (p.act === "talk"){ p.armR.rotation.x = -.6 + s * .35; p.head.rotation.y = Math.sin(t * .8 + p.phase) * .4; }
      else if (p.act === "browse" || p.act === "hold"){ p.armR.rotation.x = -1.3 + s * .2; p.head.rotation.y = Math.sin(t * .5 + p.phase) * .5; p.g.position.y += 0; }
      else if (p.act === "clerk"){ p.armL.rotation.x = p.armR.rotation.x = -.7 + s * .15; }
      else if (p.act === "fold"){ p.armL.rotation.x = p.armR.rotation.x = -1 + s * .4; }
      else { p.head.rotation.y = Math.sin(t * .4 + p.phase) * .3; }
    }
  }
  if (typeof enterShop === "function"){
    const base = enterShop;
    window.enterShop = function(sh){
      clearRoomBits();
      const r = base.apply(this, arguments);
      try{
        fitRoomBits(sh, 6.4);
        const th = SHOPS[sh.theme] || {};
        if (th.id === "cafe" || th.id === "bar") setTimeout(() => toast(`Inside ${th.names[0]}. Walk up to the counter and press Enter to order; press Enter anywhere else to step out.`, 3400), 120);
      }catch(e){ console.warn("[Snap City] shop interior", e); }
      return r;
    };
  }
  if (typeof leaveZone === "function"){ const base = leaveZone; window.leaveZone = function(){ clearRoomBits(); return base.apply(this, arguments); }; }

  if (typeof enterAction === "function"){
    const base = enterAction;
    window.enterAction = function(){
      try{
        if (typeof ZONE !== "undefined" && ZONE.mode === "shop" && LIFE.counter && (LIFE.counter.id === "cafe" || LIFE.counter.id === "bar")){
          const d = Math.hypot(Player.x - LIFE.counter.x, Player.z - LIFE.counter.z);
          if (d > 1.9){
            const keepC = window.CS131 && CS131.boughtHere, keepB = window.CS142 && CS142.barBought;
            if (window.CS131) CS131.boughtHere = true; if (window.CS142) CS142.barBought = true;
            const r = base.apply(this, arguments);
            if (window.CS131) CS131.boughtHere = keepC; if (window.CS142) CS142.barBought = keepB;
            return r;
          }
        }
      }catch(e){}
      return base.apply(this, arguments);
    };
  }

  function lensBlurb(id){
    const L = LENSES[id]; if (!L || L.d) return L && L.d;
    const f = L.f, zoom = !!L.f2;
    const kind = zoom ? `A ${L.f}–${L.f2}mm zoom that trades a little speed for never having to walk` :
      f <= 24 ? "Ultra-wide: step in close and the street wraps around the frame" :
      f <= 30 ? "A classic street wide — everything in focus, everything in context" :
      f <= 40 ? "The storyteller's focal length: wide enough for context, tight enough for faces" :
      f <= 60 ? "A normal lens that sees roughly the way you do" :
      f <= 90 ? "Portrait length — pulls a face out of the crowd from a polite distance" :
      "Telephoto compression: stack the city's layers and pick people off from across the street";
    const speed = L.a <= 1.4 ? "fast enough for night streets and paper-thin focus" : L.a <= 2 ? "bright enough for dusk" : L.a <= 2.8 ? "a sensible, sharp aperture" : "slow glass that likes daylight and f/8";
    const look = L.swirl ? "Out-of-focus backgrounds swirl." : L.glow > 0.2 ? "Highlights glow wide open." : L.sh >= 0.95 ? "Crisp corner to corner." : L.sh < 0.84 ? "Soft, vintage rendering." : L.vig > 0.3 ? "Dark corners pull the eye inward." : "Honest, dependable rendering.";
    return `${kind}; ${speed}. ${look}`;
  }
  for (const id in (typeof LENSES !== "undefined" ? LENSES : {})) if (!LENSES[id].d) LENSES[id].d = lensBlurb(id);

  const MOUNT_TINT = { M:"#c9c9c4", F:"#1b1b1a", FD:"#1c1c1c", OM:"#d9d9d4", K:"#1d1d1c", M42:"#b8b8b2", XP:"#b0aca2" };
  function lensSVG(id){
    const L = LENSES[id], len = Math.min(70, 18 + (L.f2 || L.f) * .28), dia = Math.min(44, 20 + (L.f / Math.max(1, L.a)) * .55);
    const x0 = 80 - len / 2, body = L.m === "M" || L.m === "M42" && L.f < 40 ? "#c9c9c4" : "#1c1c1c", ring = MOUNT_TINT[L.m] || "#888";
    const rings = L.f2 ? 3 : 2; let r = "";
    for (let k = 0; k < rings; k++){ const rx = x0 + 6 + k * (len - 12) / rings; r += `<rect x="${rx}" y="${45 - dia/2 - 1}" width="${(len-12)/rings - 3}" height="${dia + 2}" rx="2" fill="#0d0d0d" opacity=".55"/>` + Array.from({length: 7}, (_, i) => `<rect x="${rx + 1 + i * ((len-12)/rings - 5)/7}" y="${45 - dia/2 - 1}" width="1" height="${dia + 2}" fill="#fff" opacity=".12"/>`).join(""); }
    return `<svg class="camart gearart" viewBox="0 0 160 90" role="img" aria-label="Illustration of the ${L.n}">
      <ellipse cx="80" cy="80" rx="${len/2 + 16}" ry="4" fill="#000" opacity=".25"/>
      <rect x="${x0 - 6}" y="${45 - dia/2 + 4}" width="8" height="${dia - 8}" rx="2" fill="${ring}"/>
      <rect x="${x0}" y="${45 - dia/2}" width="${len}" height="${dia}" rx="4" fill="${body}"/>${r}
      <rect x="${x0 + len - 4}" y="${45 - dia/2 - 3}" width="8" height="${dia + 6}" rx="2" fill="${body}" stroke="#000" stroke-opacity=".3"/>
      <ellipse cx="${x0 + len + 4}" cy="45" rx="4" ry="${dia/2 - 2}" fill="#16202a"/><ellipse cx="${x0 + len + 5}" cy="${45 - dia/6}" rx="1.6" ry="${dia/7}" fill="#9fc3dc" opacity=".5"/>
      <text x="${x0 + len/2}" y="${45 + 3}" font-size="7" text-anchor="middle" fill="#e8a33d" font-family="monospace">${L.f}${L.f2 ? "–" + L.f2 : ""}</text></svg>`;
  }
  function flashSVG(id){
    const F = FLASHES[id] || {}, big = (F.gn || 20) > 30, col = (F.soft || /ring/i.test(F.name || F.n || "")) ? "ring" : "";
    if (col) return `<svg class="camart gearart" viewBox="0 0 160 90"><ellipse cx="80" cy="82" rx="46" ry="4" fill="#000" opacity=".25"/><circle cx="80" cy="45" r="30" fill="#1c1c1c"/><circle cx="80" cy="45" r="22" fill="none" stroke="#f7f3e6" stroke-width="7"/><circle cx="80" cy="45" r="14" fill="#0c0f14"/></svg>`;
    return `<svg class="camart gearart" viewBox="0 0 160 90" role="img" aria-label="Illustration of a flash"><ellipse cx="80" cy="84" rx="40" ry="4" fill="#000" opacity=".25"/>
      <rect x="64" y="70" width="32" height="8" rx="2" fill="#555"/><rect x="${big?58:62}" y="${big?30:38}" width="${big?44:36}" height="${big?42:34}" rx="4" fill="#1c1c1c"/>
      <rect x="${big?54:58}" y="${big?8:18}" width="${big?52:44}" height="${big?24:20}" rx="3" fill="#232323"/><rect x="${big?58:62}" y="${big?12:22}" width="${big?44:36}" height="${big?16:12}" rx="2" fill="#f7f3e6" opacity=".92"/>
      <circle cx="${big?94:90}" cy="${big?60:62}" r="3" fill="#e8a33d"/></svg>`;
  }
  const FILTER_TINT = { uv:"#dfe8f2", yellow:"#f2d24a", orange:"#f08a2a", red:"#c0362c", green:"#5aa05a", polar:"#3a4450", nd8:"#6b6b6b", nd64:"#2e2e2e", skylight:"#f2c9c0", blue:"#4a78c9", star:"#dfe8f2", soft:"#eee" };
  function filterSVG(k){
    const tint = FILTER_TINT[k] || "#cfd6dc";
    return `<svg class="camart gearart" viewBox="0 0 160 90" role="img" aria-label="Illustration of a filter"><ellipse cx="80" cy="82" rx="36" ry="4" fill="#000" opacity=".25"/>
      <circle cx="80" cy="44" r="32" fill="#1c1c1c"/><circle cx="80" cy="44" r="27" fill="${tint}" opacity=".78"/>
      <path d="M62 30 A24 24 0 0 1 90 22" stroke="#fff" stroke-width="4" fill="none" opacity=".45"/>${k === "polar" ? '<circle cx="80" cy="44" r="29" fill="none" stroke="#9aa" stroke-dasharray="2 3"/>' : ""}</svg>`;
  }
  if (typeof lensItem === "function"){ const base = lensItem; window.lensItem = function(id){ const h = base.apply(this, arguments); try{ const d = LENSES[id].d; let out = h.replace("<h4>", lensSVG(id) + "<h4>"); if (d && !/class="desc"/.test(h)) out = out.replace('</div>\n    <div class="foot">', `</div><div class="desc">${d}</div>\n    <div class="foot">`); return out; }catch(e){ return h; } }; }
  if (typeof filterItem === "function"){ const base = filterItem; window.filterItem = function(k){ const h = base.apply(this, arguments); try{ return h.replace("<h4>", filterSVG(k) + "<h4>"); }catch(e){ return h; } }; }
  function decorateFlashes(){
    const byName = {};
    if (typeof FLASHES !== "undefined") for (const id in FLASHES) if (id !== "none") byName[FLASHES[id].name || FLASHES[id].n] = () => flashSVG(id);
    if (typeof LENS_FILTERS !== "undefined") for (const k in LENS_FILTERS) if (k !== "none") byName[LENS_FILTERS[k].n] = () => filterSVG(k);
    document.querySelectorAll("#menubody .item").forEach(it => {
      if (it.querySelector(".gearart,.camart,img")) return;
      const h = it.querySelector("h4"); if (!h) return;
      const f = byName[h.textContent.trim()]; if (f) h.insertAdjacentHTML("beforebegin", f());
    });
  }

  (function watchGear(){
    const body = document.getElementById("menubody"); if (!body){ setTimeout(watchGear, 800); return; }
    let busy = false;
    new MutationObserver(() => { if (busy) return; busy = true; requestAnimationFrame(() => { try{ decorateFlashes(); }catch(e){} busy = false; }); }).observe(body, { childList: true, subtree: false });
  })();

  const CATEGORY_ORDER = [
    "Camera & film",
    "Camera HUD & controls",
    "Movement & controls",
    "Weather & time",
    "City & street life",
    "Sea & sky",
    "Graphics & performance",
    "Events & notices",
    "Sound",
    "Accessibility",
    "Rules & economy",
    "Develop"
  ];
  const CATEGORY_KEYS = {
    "Camera & film": ["filmAdvance","vfPreview","grainAmt","halation","lightLeaks","shotPreview","shotPreviewTime","dateStamp","photoBorder","captureQuality","steadiness","exposureCoach","perfectProgram","perfectExposureMode","exposureMetering","exposurePriority","protectHighlights","critiqueDepth","editorPersonality","currentEditor","editorOverlays","essayEnhanced"],
    "Camera HUD & controls": ["sideCamera","quickCamera","sidePosition","quickDial","quickPickHud","hud","grid","crosshair","minimapSize","locationLabel","mapLegend","mapTransit","menuTheme","uiScale","hudAccent"],
    "Movement & controls": ["walkOnWater","mouseSensitivity","walkBob","jumpHeight","invertY","walkFov","runSpeed","roofParkour","tButtons","tJoy","tLook","tHanded","tHaptics"],
    "Weather & time": ["fogPref","windPref","startWeather","autoWeather","fogAmount","weatherPolish","windStrength","windDrama","timeSpeed"],
    "City & street life": ["windowGlass","sceneEcology","neighborhoodIdentity","peopleDensity","trafficDensity","birdLife","streetcars","signalTiming","neonAmount","stringLights","litterOn","characterVariety","streetDetail","specialVehicles","coffeeSystem","windowLife","vehicleVariety","streetMoments","crowdPresentation","shopLife","carVariety","constructionLife","alleyLife"],
    "Graphics & performance": ["detailDistance","graphicsPreset","graphicsEnhance","atmosphereStrength","wetStreets","livingSky","cloudLife","facadeDetail","architectureDetail","renderQuality","reflections","psxStyle","citySize"],
    "Events & notices": ["crashes","ufos","eventPace","eventPins","eventNotify","eventNotices"],
    "Sea & sky": ["seaLife","skyLife","fireworks","bubbles","tumbleweeds"],
    "Develop": ["performanceOverlay"],
    "Sound": ["masterVol","ambienceVol","eventVol","heartbeat","trolleyBell"],
    "Accessibility": ["reducedShake","motionComfort","colorFilter","timeScale","textSize"],
    "Rules & economy": ["waitMode","difficultyProfile","filmPrice","earnings","judging"]
  };
  const KEY_CATEGORY = (() => { const m = {}; for (const name of CATEGORY_ORDER) for (const k of CATEGORY_KEYS[name]) m[k] = name; return m; })();
  const CATEGORY_INDEX = (() => { const m = {}; CATEGORY_ORDER.forEach((n, i) => { m[n] = i; }); return m; })();
  const FALLBACK_RULES = [
    [/restore|visual profile/i, "Graphics & performance"],
    [/film|exposure|aperture|shutter|grain|halation|leak|preview|border|date stamp|steadiness|editor|essay|critique|develop/i, "Camera & film"],
    [/hud|viewfinder|interface|menu|minimap|map|overlay|quick pick|panel|display|centre dot|crosshair|accent/i, "Camera HUD & controls"],
    [/walk|run|jump|mouse|touch|joystick|swipe|vibration|look|parkour|fov|sensitiv/i, "Movement & controls"],
    [/weather|rain|snow|storm|fog|wind|clock|time of day/i, "Weather & time"],
    [/graphics|render|reflection|atmosphere|sky|cloud|palette|performance|picture|resolution|quality|city size/i, "Graphics & performance"],
    [/city|street|traffic|people|pedestrian|crowd|car|vehicle|shop|window|coffee|construction|alley|neon|litter|bird|transit|streetcar|trolley|signal|architecture|facade/i, "City & street life"],
    [/event|notice|pin/i, "Events & notices"],
    [/sound|volume|audio|ambience|heartbeat|bell/i, "Sound"],
    [/access|motion comfort|contrast|colour-vision|color filter|text size|reduced shake/i, "Accessibility"],
    [/price|money|earn|pay|judg|difficulty|economy|wait mode/i, "Rules & economy"]
  ];
  function settingKeys(row){
    const out = [];
    row.querySelectorAll("[data-seg],[data-sc-setting],[data-seg44],[data-aseg]").forEach(el => {
      const k = el.dataset.seg || el.dataset.scSetting || el.dataset.seg44 || el.dataset.aseg;
      if (k && out.indexOf(k) < 0) out.push(k);
    });
    if (row.querySelector("[data-citysize]")) out.push("citySize");
    return out;
  }
  function categorize(row){
    for (const k of settingKeys(row)) if (KEY_CATEGORY[k]) return KEY_CATEGORY[k];
    const label = ((row.querySelector("label") || row).textContent || "").trim();
    for (const [re, cat] of FALLBACK_RULES) if (re.test(label)) return cat;
    return "More settings";
  }
  function regroupSettings(){
    const body = document.querySelector("#menubody"); if (!body) return;
    const rows = [...body.querySelectorAll(".formrow, .sc-setting")].filter(r => !r.parentElement.closest(".formrow") && (r.querySelector("button,select,input")));
    if (rows.length < 4) return;
    body.querySelectorAll(".spec").forEach(sp => { if (/^Adjusts .* for the way you want to play\.?$/i.test(sp.textContent.trim())) sp.remove(); });

    const overlayToggles = body.querySelector(".overlay-toggles");
    const notes = [...body.querySelectorAll("p.note")];

    const buckets = new Map();
    rows.forEach(r => { const c = categorize(r); if (!buckets.has(c)) buckets.set(c, []); buckets.get(c).push(r); });
    const names = [...buckets.keys()].sort((a, b) => ((CATEGORY_INDEX[a] ?? 99) - (CATEGORY_INDEX[b] ?? 99)));

    body.innerHTML = "";
    names.forEach(name => {
      const det = document.createElement("details"); det.className = "sc-settings-section"; det.open = false;
      det.innerHTML = `<summary>${name} <small>${buckets.get(name).length}</small></summary>`;
      buckets.get(name).forEach(r => det.appendChild(r));
      if (name === "Camera & film" && overlayToggles){
        const sub = document.createElement("div");
        sub.innerHTML = '<div class="sc-subhead">Editor analysis overlays</div>';
        sub.appendChild(overlayToggles);
        det.appendChild(sub);
      }
      body.appendChild(det);
    });
    if (overlayToggles && !buckets.has("Camera & film")) body.appendChild(overlayToggles);
    notes.forEach(n => body.appendChild(n));
  }
  function newSettingRows(){
    const c = S.custom, row = (key, label, opts, spec) => `<div class="formrow"><label>${label}</label><div class="seg" data-seg44="${key}">${opts.map(([v,l]) => `<button data-v="${v}" aria-pressed="${String(c[key])===v}">${l}</button>`).join("")}</div>${spec?`<span class="spec">${spec}</span>`:""}</div>`;
    return row("startWeather","Start-of-game weather",[["random","Random"],["keep","Keep last"]],"Random rolls sun, rain, storm or fog each time you start.") +
      row("eventNotices","Event notices under the map",[["on","On"],["off","Off"]],"Lists what just started, how far away and in which direction.") +
      row("mapLegend","Map key",[["button","On a button"],["always","Always shown"]]) +
      row("locationLabel","Location label",[["street","Street name"],["off","Hidden"]]) +
      row("minimapSize","Minimap size",[["small","Small"],["normal","Normal"],["large","Large"]]) +
      row("crosshair","Centre dot",[["dot","Dot"],["off","Off"]]) +
      row("uiScale","Interface size",[["90","90%"],["100","100%"],["115","115%"]]) +
      row("shopLife","People inside shops",[["off","Empty"],["quiet","Quiet"],["lively","Lively"]],"Customers eating, drinking, browsing and waiting when you step inside.") +
      row("carVariety","Car details",[["normal","Normal"],["high","Varied"]],"Stripes, racks, spoilers, bull bars and rarer paint colours on traffic and parked cars.");
  }
  if (typeof menuSettings === "function"){ const base = menuSettings; window.menuSettings = function(){ migrate(S); return newSettingRows() + base.apply(this, arguments); }; }
  if (typeof wireMenu === "function"){
    const base = wireMenu;
    window.wireMenu = function(){
      const r = base.apply(this, arguments);
      document.querySelectorAll("#menubody [data-seg44] button").forEach(b => b.onclick = () => { S.custom[b.closest("[data-seg44]").dataset.seg44] = b.dataset.v; saveState(); applyUiPrefs(); renderMenu(); });
      return r;
    };
  }
  if (typeof renderMenu === "function"){
    const base = renderMenu;
    window.renderMenu = function(){
      const r = base.apply(this, arguments);
      try{
        if (UI.menuTab === "settings") regroupSettings();
        if (UI.menuTab === "gear") decorateFlashes();
      }catch(e){ console.warn("[Snap City] menu polish", e); }
      return r;
    };
  }

  if (typeof carParts === "function"){
    const base = carParts, BX = new THREE.BoxGeometry(1,1,1).toNonIndexed();
    window.carParts = function(type, paint, opts){
      const out = base.apply(this, arguments);
      try{
        if (typeof S === "undefined" || !S || S.custom.carVariety === "normal" || !CAR_TYPES[type] || /bus|boxtruck/.test(type) || (opts && opts.taxi)) return out;
        const T = CAR_TYPES[type], r = Math.random, L = T.L, W = T.W, belt = T.belt, roofY = (T.cabin && T.cabin[1]) ? T.cabin[1][1] : belt + 0.5;
        const accent = lin(["#f2efe6","#15171a","#c0362c","#e8b82e","#2f7fc1","#3aa06b"][(r()*6)|0]);
        const push = (key, x, y, z, sx, sy, sz, c) => out[key].push({ g: BX, m: TM(x, y, z, 0, 0, 0, sx, sy, sz), c });
        const roll = r();
        if (roll < 0.14){ for (const sx of [-0.18, 0.18]){ push("paint", sx, belt + 0.012, L*0.28, 0.16, 0.012, L*0.4, accent); push("paint", sx, roofY + 0.012, 0, 0.16, 0.012, L*0.3, accent); } }
        else if (roll < 0.3){ for (const s of [-1, 1]) push("paint", s*(W/2 + 0.004), belt - 0.18, 0, 0.012, 0.06, L*0.78, accent); }
        if (r() < 0.16 && /sedan|hatch|classic|coupe/.test(type)) push("trim", 0, T.tail + 0.08, -L/2 + 0.18, W*0.8, 0.05, 0.22, lin("#15171a"));
        if (r() < 0.12 && /suv|pickup|van/.test(type)) push("chrome", 0, T.clr + 0.35, L/2 + 0.06, W*0.7, 0.35, 0.06, lin("#b8bcc0"));
        if (r() < 0.1) push("trim", 0, roofY + 0.05, -0.1, 0.5, 0.08, 0.6, lin("#111"));
        if (r() < 0.12) for (const s of [-1, 1]) push("trim", s*(W/2 + 0.02), T.clr + 0.12, -L/2 + 0.35, 0.03, 0.22, 0.3, lin("#111"));
      }catch(e){}
      return out;
    };
  }
  if (typeof carPaint === "function"){
    const base = carPaint, RARE = ["#2aa198","#6c3fa0","#e36f2d","#9acd32","#d4145a","#b87333","#556b2f","#f0e68c","#4169e1","#708090"];
    window.carPaint = function(){ if (typeof S !== "undefined" && S && S.custom.carVariety !== "normal" && Math.random() < 0.22) return lin(RARE[(Math.random()*RARE.length)|0]); return base.apply(this, arguments); };
  }

  function buildLandmarks(){
    if (LIFE.built || typeof G === "undefined" || !G.scene || typeof World === "undefined" || !World.lots || !World.lots.length) return;
    LIFE.built = true;
    const root = new THREE.Group(), E = (NOUT + 0.5) * P + 60;
    const m = (c, rough, metal, em) => new THREE.MeshStandardMaterial({ color: lin(c), roughness: rough ?? .8, metalness: metal || 0, emissive: em ? lin(c) : 0x000000, emissiveIntensity: em || 0 });
    const add = (g, geo, mm, x, y, z) => { const o = new THREE.Mesh(geo, mm); o.position.set(x, y, z); o.castShadow = true; g.add(o); return o; };
    const gy = (x, z) => { try{ return H(x, z); }catch(e){ return 0; } };

    { const g = new THREE.Group(); g.position.set(160, 0, -E - 420); const rk = m("#6e6a5e", .95), wh = m("#e8e4da"), rd = m("#b3312b");
      const isle = add(g, new THREE.SphereGeometry(70, 18, 8, 0, Math.PI*2, 0, Math.PI/2), rk, 0, -6, 0); isle.scale.set(1.5, .3, .8);
      for (let k = 0; k < 6; k++) add(g, new THREE.CylinderGeometry(3.4 - k*.2, 3.6 - k*.2, 5, 14).translate(0, 2.5, 0), k % 2 ? rd : wh, 20, 14 + k*5, 0);
      add(g, new THREE.CylinderGeometry(2.6, 2.6, 3, 12).translate(0, 1.5, 0), m("#fff4c8", .3, 0, .9), 20, 44, 0); add(g, new THREE.BoxGeometry(30, 8, 14).translate(0, 4, 0), wh, -20, 12, 0); root.add(g); }

    { const g = new THREE.Group(), x = (0.5)*P, z = 18; g.position.set(x, gy(x, z), z); g.rotation.y = 0; const iron = m("#2b2f33", .5, .6), gold = m("#d9b45a", .4, .7, .1);
      for (const s of [-1, 1]) add(g, new THREE.BoxGeometry(.7, 7.5, .7).translate(0, 3.75, 0), iron, s*5.6, 0, 0);
      for (let k = 0; k <= 20; k++){ const a = Math.PI*k/20, seg = add(g, new THREE.BoxGeometry(.9, .35, .35), iron, Math.cos(a)*5.6, 7.5 + Math.sin(a)*2.2, 0); seg.rotation.z = a + Math.PI/2; }
      const c = document.createElement("canvas"); c.width = 512; c.height = 96; const x2 = c.getContext("2d"); x2.fillStyle = "#1b2126"; x2.fillRect(0,0,512,96); x2.fillStyle = "#e8c572"; x2.textAlign = "center"; let fs = 54; do { x2.font = `bold ${fs}px Georgia, serif`; fs -= 2; } while (x2.measureText("SNAP CITY MARKET").width > 470 && fs > 20); x2.fillText("SNAP CITY MARKET", 256, 64); x2.strokeStyle = "#e8c572"; x2.lineWidth = 3; x2.strokeRect(8, 8, 496, 80);
      const tx = new THREE.CanvasTexture(c); tx.encoding = THREE.sRGBEncoding; const sign = new THREE.Mesh(new THREE.PlaneGeometry(7, 1.3), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide })); sign.position.set(0, 7.9, 0); g.add(sign);
      add(g, new THREE.SphereGeometry(.4, 10, 8), gold, 0, 10.3, 0); root.add(g);
      try{ for (const s of [-1, 1]){ World.colliders.push({ x0: x + s*5.6 - .45, x1: x + s*5.6 + .45, z0: z - .6, z1: z + .6 }); } }catch(e){} }
    root.traverse(o => { o.matrixAutoUpdate = false; o.updateMatrix(); }); root.updateMatrixWorld(true);
    G.scene.add(root);
  }

  try{
    if (typeof NEUTRAL !== "undefined") NEUTRAL.push("#7a4a3a","#a0785a","#c2b280","#556b2f","#4a5d6b","#8b6f8e","#b5a38c","#39424e","#6e7f80","#d9cbb5","#704214","#2e3b33");
    if (typeof BRIGHT !== "undefined") BRIGHT.push("#ff8fab","#7bdff2","#b2f7ef","#f7d6e0","#f2b5d4","#9b5de5","#00bbf9","#00f5d4","#fee440","#f15bb5","#ef476f","#06d6a0","#118ab2","#ffd166");
    if (typeof JEANS !== "undefined") JEANS.push("#5a7ba3","#8fa7c4","#1a1f2b","#7a7f88","#b8c4d6");
    if (typeof TROUSERS !== "undefined") TROUSERS.push("#a0522d","#556b2f","#d2b48c","#800020","#36454f","#e8e2d0");
    if (typeof SHOES !== "undefined") SHOES.push("#f2efe6","#d4a017","#2f7fc1","#c8367a","#3aa06b","#6b4226");
    if (typeof HAIRC !== "undefined") HAIRC.push("#b5651d","#e0ac69","#4b3621","#d6c4a8","#7b3f00","#6a5acd","#2e8b57","#ff69b4");
  }catch(e){}

  let feedT = 0;
  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{
        if (!LIFE.built) buildLandmarks();
        addStories(); ensureMapUI();
        if (typeof S !== "undefined" && S && Game.started){ frequentStories(dt); for (const f of LIFE.feed) f.t += dt; feedT -= dt; if (feedT <= 0){ feedT = 0.5; renderFeed(); } }
        if (LIFE.shopFolk.length) animateShop(performance.now() / 1000);
      }catch(e){ console.warn("[Snap City 44] update", e); }
      return r;
    };
  }
  const iv = setInterval(() => { try{ if (typeof S !== "undefined" && S){ migrate(S); applyUiPrefs(); } buildLandmarks(); if (LIFE.built) clearInterval(iv); }catch(e){} }, 600);
})();

(function(){
  "use strict";
  const SC = window.SnapCity = window.SnapCity || {};
  const Z = SC.z48 = { built: false, veh: [], planes: [], balloons: [], fw: [], bubbles: [], rainbow: null, wasRain: false };
  const rnd = (a, b) => a + Math.random() * (b - a), pick = a => a[(Math.random() * a.length) | 0];
  const mats = {}; const m = (c, r, mt, em, op) => { const k = c + "|" + (r||0) + "|" + (mt||0) + "|" + (em||0) + "|" + (op||1); return mats[k] || (mats[k] = new THREE.MeshStandardMaterial({ color: lin(c), roughness: r ?? .7, metalness: mt || 0, emissive: em ? lin(c) : 0x000000, emissiveIntensity: em || 0, transparent: !!op, opacity: op || 1 })); };
  const BOX = new THREE.BoxGeometry(1,1,1), CYL = new THREE.CylinderGeometry(.5,.5,1,14), SPH = new THREE.SphereGeometry(.5,14,10);
  const part = (g, geo, mm, x, y, z, sx, sy, sz) => { const o = new THREE.Mesh(geo, mm); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; g.add(o); return o; };
  const wheel = (g, x, y, z, r, w) => { const o = part(g, CYL, m("#141414", .9), x, y, z, r * 2, w, r * 2); o.rotation.z = Math.PI / 2; part(g, CYL, m("#9aa0a6", .4, .6), x + Math.sign(x) * (w / 2 + .005), y, z, r * .9, .02, r * .9).rotation.z = Math.PI / 2; return o; };
  const custom = k => (typeof S !== "undefined" && S && S.custom) ? S.custom[k] : undefined;

  const TAGGED = [];
  if (typeof buildCarGroup === "function"){
    const base = buildCarGroup;
    window.buildCarGroup = function(type){ const g = base.apply(this, arguments); g.userData.vehicle = type; TAGGED.push(g); return g; };
  }
  function bigColliders(){ return (World.colliders || []).filter(c => (c.x1 - c.x0) > 8 && (c.z1 - c.z0) > 8); }
  let BIG = null, bigT = 0;
  const inBuilding = (x, z) => BIG.some(c => x > c.x0 + .7 && x < c.x1 - .7 && z > c.z0 + .7 && z < c.z1 - .7);
  const _v = new THREE.Vector3();
  function vehicleGuard(dt){
    if ((bigT -= dt) <= 0 || !BIG){ BIG = bigColliders(); bigT = 5; }

    const lanes = {};
    for (const c of Life.cars){ const k = c.lane + "|" + c.z.toFixed(1); (lanes[k] = lanes[k] || []).push(c); }
    for (const k in lanes){
      const list = lanes[k], dir = list[0].lane > 0 ? 1 : -1; list.sort((a, b) => (a.x - b.x) * dir);
      for (let i = 0; i < list.length - 1; i++){
        const back = list[i], front = list[i + 1], need = ((back.len || (back.bus ? 11.5 : 4.6)) + (front.len || (front.bus ? 11.5 : 4.6))) / 2 + .4, d = (front.x - back.x) * dir;
        if (d > 0 && d < need){ back.x = front.x - dir * need; back.speed = Math.min(back.speed, front.speed); back.g.position.x = back.x; }
      }
    }

  }

  function motionGuard(dt){
    if (!dt) return;
    for (const p of Life.people){
      if (p.hidden){ p._mx = undefined; continue; }
      if (p._mx !== undefined){
        const moved = Math.hypot(p.x - p._mx, p.z - p._mz) / dt;
        if (p.evPose === "run" && moved < .6){ p._stuckRun = (p._stuckRun || 0) + dt; if (p._stuckRun > .35){ p.evPose = null; p.pause = 0; } } else p._stuckRun = 0;
        if (p.evMoving && moved < .08){ p._stuckWalk = (p._stuckWalk || 0) + dt; if (p._stuckWalk > .4) p.evMoving = false; } else p._stuckWalk = 0;
      }
      p._mx = p.x; p._mz = p.z;
    }
  }

  const KINDS = {
    tractor: { len: 3.8, vmax: 4, w: 1.6, build(g){ const c = pick(["#b3171b","#2f6b2f","#1e4f8a"]);
      part(g, BOX, m(c, .5, .2), 0, 1.0, .5, 1.1, .8, 2.0); part(g, BOX, m(c, .5, .2), 0, 1.25, -.8, 1.3, .5, 1.0);
      for (const s of [-1, 1]){ part(g, BOX, m("#1a1a1a"), s * .55, 2.0, -.8, .06, 1.4, .06); part(g, BOX, m("#1a1a1a"), s * .55, 2.0, -.2, .06, 1.4, .06); }
      part(g, BOX, m(c, .5, .2), 0, 2.72, -.5, 1.3, .06, 1.0); part(g, CYL, m("#2b2b2b", .5, .5), .35, 1.8, 1.2, .1, 1.2, .1);
      for (const s of [-1, 1]){ wheel(g, s * .85, .75, -.8, .75, .45); wheel(g, s * .7, .4, 1.1, .4, .25); }
      if (SC.makePerson){ const d = SC.makePerson((Math.random() * 1e5) | 0, true); d.g.position.set(0, 1.1, -.9); d.armL.rotation.x = d.armR.rotation.x = -1.1; g.add(d.g); const hat = part(g, SPH, m(pick(["#e8b82e","#2f6b2f","#c0362c"]), .6), 0, d.g.position.y + d.head.position.y + .12, -.9, .36, .16, .36); } } },
    garbage: { len: 8.2, vmax: 6, w: 2.4, build(g){ const c = pick(["#2f6b4a","#e9e6de","#1e4f8a"]);
      part(g, BOX, m("#e9e6de", .5, .2), 0, 1.6, 3.2, 2.3, 2.1, 1.8); part(g, BOX, m("#1b2430", .1, .4), 0, 2.1, 4.12, 2.0, .7, .05);
      part(g, BOX, m(c, .6, .2), 0, 2.0, -.8, 2.4, 2.9, 5.6); part(g, BOX, m("#1a1a1a", .7), 0, 1.2, -3.7, 2.2, 1.6, .5);
      for (const s of [-1, 1]) for (const zz of [3.0, -.6, -2.4]) wheel(g, s * 1.1, .5, zz, .5, .35); } },
    mixer: { len: 8.0, vmax: 6, w: 2.4, build(g){ const c = pick(["#e8b82e","#e36f2d","#e9e6de"]);
      part(g, BOX, m(c, .5, .2), 0, 1.6, 3.0, 2.3, 2.1, 1.8); part(g, BOX, m("#1b2430", .1, .4), 0, 2.1, 3.92, 2.0, .7, .05); part(g, BOX, m("#3a3b3e", .6, .3), 0, 1.0, -.6, 2.2, .5, 5.8);
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(1.05, .6, 4.2, 16), m("#d9d6cf", .5, .3)); drum.rotation.x = Math.PI / 2 - .25; drum.position.set(0, 2.3, -.8); g.add(drum); g.userData.spin = drum;
      for (let k = 0; k < 4; k++){ const f = new THREE.Mesh(BOX, m(c, .5)); f.scale.set(.12, 3.6, .12); f.position.set(Math.cos(k * 1.57) * .86, 0, Math.sin(k * 1.57) * .86); drum.add(f); }
      for (const s of [-1, 1]) for (const zz of [2.9, -1.2, -2.6]) wheel(g, s * 1.1, .5, zz, .5, .35); } },
    flatbed: { len: 7.6, vmax: 7, w: 2.3, build(g){ const c = pick(["#1e4f8a","#6b1f22","#3a3b3e"]);
      part(g, BOX, m(c, .5, .2), 0, 1.6, 2.9, 2.2, 2.0, 1.8); part(g, BOX, m("#1b2430", .1, .4), 0, 2.1, 3.82, 1.9, .7, .05); part(g, BOX, m("#5a4a3a", .8), 0, 1.15, -1.0, 2.3, .2, 5.6);
      for (let k = 0; k < 3; k++) part(g, BOX, m(pick(["#8a6a44","#a07a4a","#6b4a2e"]), .9), rnd(-.4, .4), 1.6, -2.8 + k * 1.8, 1.4, .8, 1.4);
      for (const s of [-1, 1]) for (const zz of [2.8, -1.6, -3.0]) wheel(g, s * 1.05, .5, zz, .48, .32); } },
    icecream: { len: 5.6, vmax: 7, w: 2.1, build(g){
      part(g, BOX, m("#f7f3ea", .5, .1), 0, 1.5, 0, 2.0, 2.2, 5.4); part(g, BOX, m("#f28cb1", .5), 0, 1.0, 0, 2.02, .35, 5.42); part(g, BOX, m("#1b2430", .1, .4), 0, 1.9, 2.72, 1.8, .7, .05);
      part(g, BOX, m("#1b2430", .1, .4), 1.01, 1.8, -.4, .02, .9, 2.2);
      const cone = new THREE.Mesh(new THREE.ConeGeometry(.35, .9, 12), m("#d9a24a", .8)); cone.rotation.x = Math.PI; cone.position.set(0, 3.05, .8); g.add(cone); part(g, SPH, m("#f5c6d6", .6), 0, 3.6, .8, .75, .7, .75);
      for (const s of [-1, 1]) for (const zz of [1.8, -1.8]) wheel(g, s * .98, .42, zz, .42, .3); } },
    schoolbus: { len: 10.5, vmax: 7, w: 2.5, build(g){ const y = m("#f2b705", .5, .2);
      part(g, BOX, y, 0, 1.8, -.4, 2.4, 2.4, 9.2); part(g, BOX, y, 0, 1.2, 4.6, 2.3, 1.2, 1.4); part(g, BOX, m("#1a1a1a"), 0, 1.3, 0, 2.42, .12, 10.2);
      for (let k = 0; k < 7; k++) for (const s of [-1, 1]) part(g, BOX, m("#1b2430", .1, .4), s * 1.21, 2.3, -4.0 + k * 1.2, .02, .7, .9);
      for (const s of [-1, 1]) for (const zz of [3.4, -3.2]) wheel(g, s * 1.15, .5, zz, .5, .35); } },
    motorbike: { len: 2.3, vmax: 11, w: .8, build(g){ const c = pick(["#c0362c","#1a1a1a","#2f7fc1","#e8b82e"]);
      part(g, BOX, m(c, .4, .4), 0, .75, 0, .35, .4, 1.3); part(g, BOX, m("#1a1a1a", .7), 0, .98, -.2, .3, .12, .7); part(g, CYL, m("#9aa0a6", .3, .7), 0, 1.0, .75, .06, .5, .06).rotation.x = .4;
      for (const zz of [.8, -.75]){ const w = part(g, CYL, m("#141414", .9), 0, .35, zz, .7, .12, .7); w.rotation.z = Math.PI / 2; }
      if (SC.makePerson){ const p = SC.makePerson((Math.random() * 1e5) | 0, true); p.g.position.set(0, .45, -.25); p.g.scale.multiplyScalar(.95); p.armL.rotation.x = p.armR.rotation.x = -1.2; g.add(p.g); part(g, SPH, m(c, .3, .3), 0, p.head.position.y + .5, -.25, .32, .3, .34); } } },
    tank: { len: 7.2, vmax: 3, w: 3.2, build(g){ const o = m(pick(["#4b5320","#5b5f3a","#6b6b4a"]), .8, .2);
      part(g, BOX, o, 0, 1.0, 0, 3.0, .9, 6.6); for (const s of [-1, 1]){ part(g, BOX, m("#2a2a28", .9), s * 1.4, .55, 0, .5, 1.0, 7.0); for (let k = 0; k < 6; k++){ const w = part(g, CYL, m("#3a3a36", .8), s * 1.4, .45, -2.8 + k * 1.12, .7, .52, .7); w.rotation.z = Math.PI / 2; } }
      const tur = new THREE.Group(); tur.position.set(0, 1.75, -.3); g.add(tur); part(tur, BOX, o, 0, 0, 0, 2.0, .7, 2.6); const gun = part(tur, CYL, o, 0, .05, 2.8, .18, 3.6, .18); gun.rotation.x = Math.PI / 2; g.userData.turret = tur; if (SC.makePerson){ const c = SC.makePerson((Math.random() * 1e5) | 0, false); c.g.position.set(-.4, -.55, -.6); c.g.scale.multiplyScalar(.9); tur.add(c.g); part(tur, CYL, m("#3a3a36", .6), -.4, .35, -.6, .7, .12, .7); }   } }
  };
  const MIX = [["tractor", 1.1], ["garbage", 1.3], ["mixer", 1.0], ["flatbed", 1.3], ["icecream", .8], ["schoolbus", .9], ["motorbike", 1.8], ["tank", .25]];
  function wpick(list){ let t = 0; for (const [, w] of list) t += w; let r = Math.random() * t; for (const [k, w] of list){ r -= w; if (r <= 0) return k; } return list[0][0]; }
  function addTraffic(){
    const streets = [...new Set(Life.cars.filter(c => !c.bus).map(c => (c.z - c.lane * 1.3).toFixed(2)))].map(Number);
    if (!streets.length) return;
    const n = 9 + ((Math.random() * 4) | 0), E = (NOUT + .5) * P;
    const tail = new THREE.MeshStandardMaterial({ color: lin("#6a1414"), emissive: lin("#ff2a1a"), emissiveIntensity: 0 });
    for (let k = 0; k < n; k++){
      let kind = wpick(MIX); if (kind === "tank" && Z.veh.some(v => v.kind === "tank")) kind = "flatbed";
      const K = KINDS[kind], g = new THREE.Group(); K.build(g);
      const lane = Math.random() < .5 ? 1 : -1, z = pick(streets) + lane * 1.3;
      let x = 0, tries = 0; do { x = rnd(-E, E); tries++; } while (tries < 30 && Life.cars.some(o => o.lane === lane && Math.abs(o.z - z) < .5 && Math.abs(o.x - x) < ((o.len || 4.6) + K.len) / 2 + 3));
      g.traverse(o => { if (o.isMesh) o.castShadow = true; });
      G.scene.add(g);
      const c = { type: "car", special: kind, len: K.len, width: K.w, tailMat: tail, g, lane, z, x, speed: 0, vmax: K.vmax * rnd(.9, 1.1), heading: lane > 0 ? Math.PI / 2 : -Math.PI / 2, color: 0 };
      Life.cars.push(c); Z.veh.push({ kind, g, c });
    }
  }

  function bannerTex(text){ const c = document.createElement("canvas"); c.width = 1024; c.height = 128; const x = c.getContext("2d"); x.fillStyle = "#f7f3ea"; x.fillRect(0, 0, 1024, 128); x.fillStyle = "#c0362c"; x.font = "bold 84px Georgia, serif"; x.textAlign = "center"; x.fillText(text, 512, 96); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t; }
  const BANNERS = ["SMILE, SNAP CITY!", "MARRY ME, JO?", "FRESH BAGELS — CANAL ST", "SAVE THE HARBOUR", "HAPPY BIRTHDAY DAD", "LOOK UP ↑"];
  function localPlane(){
    const g = new THREE.Group(), body = m(pick(["#f2efe6","#e8b82e","#c0362c","#2f7fc1"]), .5, .2);
    part(g, BOX, body, 0, 0, 0, 1.2, 1.2, 7); part(g, BOX, body, 0, .5, .6, 11, .12, 1.5); part(g, BOX, body, 0, .2, -3.2, 3.4, .1, 1.0); part(g, BOX, body, 0, .8, -3.3, .1, 1.4, 1.0);
    part(g, BOX, m("#1b2430", .1, .4), 0, .55, 1.4, 1.0, .5, 1.1);
    const prop = new THREE.Group(); prop.position.z = 3.6; part(prop, BOX, m("#1a1a1a"), 0, 0, 0, 2.2, .15, .08); g.add(prop);
    const ban = new THREE.Mesh(new THREE.PlaneGeometry(22, 2.8), new THREE.MeshBasicMaterial({ map: bannerTex(pick(BANNERS)), side: THREE.DoubleSide })); ban.position.set(0, -.4, -24); ban.rotation.y = Math.PI / 2; g.add(ban);
    part(g, BOX, m("#444"), 0, -.2, -8.5, .03, .03, 10);
    G.scene.add(g); Z.planes.push({ g, prop, kind: "local", a: Math.random() * 6.28, r: rnd(260, 380), h: rnd(110, 160), life: rnd(70, 100), dir: Math.random() < .5 ? 1 : -1 });
  }
  function airliner(){
    const g = new THREE.Group(), w = m("#e9e6de", .5, .2);
    part(g, CYL, w, 0, 0, 0, 3, 36, 3).rotation.x = Math.PI / 2; part(g, BOX, w, 0, 0, 2, 34, .5, 5); part(g, BOX, w, 0, 0, -15, 12, .4, 3); part(g, BOX, m(pick(["#c0362c","#1e3a5f","#2f7fc1","#3aa06b"])), 0, 3, -15, .4, 6, 3.5);
    const trail = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 260), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .35, depthWrite: false, side: THREE.DoubleSide, fog: false }));
    trail.rotation.x = -Math.PI / 2; trail.position.z = -140; g.add(trail);
    const a = Math.random() * 6.28; g.position.set(Math.cos(a) * 1400, rnd(420, 600), Math.sin(a) * 1400); g.lookAt(-g.position.x * .3, g.position.y, -g.position.z * .3);
    G.scene.add(g); Z.planes.push({ g, kind: "jet", life: 42 });
  }

  function balloonTex(){ const c = document.createElement("canvas"); c.width = 256; c.height = 128; const x = c.getContext("2d"); const cols = pick([["#c0362c","#e8b82e"],["#2f7fc1","#f2efe6"],["#3aa06b","#e36f2d"],["#8a3fb5","#f28cb1"]]);
    for (let k = 0; k < 16; k++){ x.fillStyle = cols[k % 2]; x.fillRect(k * 16, 0, 16, 128); } x.fillStyle = "rgba(255,255,255,.25)"; x.fillRect(0, 50, 256, 10); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; return t; }
  function balloon(){
    const g = new THREE.Group(), env = new THREE.Mesh(new THREE.SphereGeometry(8, 24, 16), new THREE.MeshStandardMaterial({ map: balloonTex(), roughness: .8 }));
    env.scale.y = 1.2; env.position.y = 12; g.add(env);
    const cone = new THREE.Mesh(new THREE.CylinderGeometry(4.2, 1.2, 5, 16, 1, true), env.material); cone.position.y = 2.8; g.add(cone);
    part(g, BOX, m("#8a6a44", .9), 0, -1.2, 0, 1.6, 1.2, 1.6); const flame = part(g, SPH, m("#ffb347", .3, 0, 2), 0, .6, 0, .5, .8, .5); flame.visible = false;
    const E = (NOUT + .5) * P; g.position.set(rnd(-E, E), rnd(90, 170), rnd(-E, E) - 200); G.scene.add(g);
    Z.balloons.push({ g, flame, vx: rnd(1, 2.4), vz: rnd(-.6, .6), bob: Math.random() * 6 });
  }

  const FW_COLS = ["#ff5a5a","#ffd24a","#6ad1ff","#a66cff","#7dff8a","#ffffff","#ff8ad6"];
  function firework(){
    const n = 120, pos = new Float32Array(n * 3), vel = [], col = new THREE.Color(pick(FW_COLS));
    const cx = rnd(-200, 200), cy = rnd(70, 120), cz = rnd(-260, -120);
    for (let k = 0; k < n; k++){ const u = Math.random() * 2 - 1, a = Math.random() * 6.28, s = Math.sqrt(1 - u * u), sp = rnd(14, 22); vel.push([Math.cos(a) * s * sp, u * sp, Math.sin(a) * s * sp]); pos.set([cx, cy, cz], k * 3); }
    const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({ color: col, size: 2.2, transparent: true, opacity: 1, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
    const pts = new THREE.Points(geo, mat); G.scene.add(pts);
    Z.fw.push({ pts, vel, t: 0 });
    try{ if (typeof SND !== "undefined" && SND.play) SND.play("crackle", cx, cz, .4); }catch(e){}
  }

  function rainbow(){
    if (Z.rainbow) return;
    const g = new THREE.Group(), cols = ["#ff3b3b","#ff9a2e","#ffe14a","#54d66a","#3aa0ff","#5a5aff","#a45aff"];
    cols.forEach((c, k) => { const t = new THREE.Mesh(new THREE.TorusGeometry(520 - k * 9, 4.2, 6, 64, Math.PI), new THREE.MeshBasicMaterial({ color: lin(c), transparent: true, opacity: 0, depthWrite: false, fog: false, blending: THREE.AdditiveBlending })); g.add(t); });
    const sun = World.sun ? World.sun.position.clone().setY(0).normalize() : new THREE.Vector3(1, 0, 0);
    g.position.set(-sun.x * 900, -60, -sun.z * 900); g.lookAt(0, -60, 0);
    G.scene.add(g); Z.rainbow = { g, t: 0 };
    try{ toast("A rainbow is out over the city.", 2200); }catch(e){}
  }

  let bubbleMat = null, bubbleSpot = null;
  function bubbleArtist(){
    const gp = (World.gaps || []).find(g => g.kind === "park"); if (!gp || !SC.makePerson) return;
    bubbleSpot = { x: gp.fx - gp.n[0] * 2.5, z: gp.fz - gp.n[1] * 2.5, y: gp.gy };
    const p = SC.makePerson(4242, false); p.g.position.set(bubbleSpot.x, bubbleSpot.y, bubbleSpot.z); G.scene.add(p.g); p.armL.rotation.x = p.armR.rotation.x = -2.4; Z.artist = p;
    part(p.g, CYL, m("#6b4a2e"), .3, 2.0, .2, .03, 1.2, .03);
    bubbleMat = new THREE.MeshPhysicalMaterial ? new THREE.MeshPhysicalMaterial({ color: 0xf2f8ff, roughness: 0, metalness: .1, transparent: true, opacity: .22, clearcoat: 1, depthWrite: false }) : m("#ffffff", 0, 0, 0, .22);
  }
  function blowBubble(){
    if (!bubbleSpot || Z.bubbles.length > 9) return;
    const s = rnd(.6, 2.4), b = new THREE.Mesh(SPH, bubbleMat); b.scale.setScalar(s); b.position.set(bubbleSpot.x + rnd(-.5, .5), bubbleSpot.y + 2.4, bubbleSpot.z + rnd(-.5, .5)); G.scene.add(b);
    Z.bubbles.push({ b, vx: rnd(-.5, .5) + (typeof WIND !== "undefined" ? WIND.x * .6 : .3), vz: rnd(-.5, .5) + (typeof WIND !== "undefined" ? WIND.z * .6 : 0), vy: rnd(.15, .45), life: rnd(8, 16), wob: Math.random() * 6 });
  }

  if (typeof menuSettings === "function"){
    const base = menuSettings;
    window.menuSettings = function(){
      const c = S.custom; for (const [k, v] of [["skyLife","on"],["fireworks","on"],["specialTraffic","on"],["bubbles","on"]]) if (c[k] === undefined) c[k] = v;
      const row = (key, label, opts, spec) => `<div class="formrow"><label>${label}</label><div class="seg" data-seg44="${key}">${opts.map(([v,l]) => `<button data-v="${v}" aria-pressed="${String(c[key])===v}">${l}</button>`).join("")}</div>${spec?`<span class="spec">${spec}</span>`:""}</div>`;
      return row("skyLife", "Planes & balloons", [["on","On"],["off","Off"]], "A local plane towing a banner, airliners with contrails, hot-air balloons on clear days, and a rainbow when rain clears.") +
        row("fireworks", "Night fireworks", [["on","On"],["off","Off"]], "Bursts over the harbour after dark.") +
        row("specialTraffic", "Unusual vehicles", [["on","On"],["off","Off"]], "Tractors, garbage trucks, cement mixers, semis, tankers, dump trucks, army trucks, APCs, tanks, ice-cream vans, school buses, limousines and motorbikes. Applies to the next city.") +
        row("bubbles", "Bubble artist", [["on","On"],["off","Off"]], "Giant soap bubbles drifting over a park.") + base.apply(this, arguments);
    };
  }

  let planeT = rnd(15, 40), jetT = rnd(40, 90), fwT = 5, bubbleT = 0;
  function build(){
    if (Z.built || typeof G === "undefined" || !G.scene || typeof World === "undefined" || !World.lots || !World.lots.length || typeof S === "undefined" || !S || !Life.cars.length) return;
    Z.built = true;
    try{ if (custom("specialTraffic") !== "off") addTraffic(); }catch(e){ console.warn("[Snap City 48] traffic", e); }
    try{ if (custom("skyLife") !== "off") for (let k = 0; k < 3; k++) balloon(); }catch(e){}
    try{ if (custom("bubbles") !== "off") bubbleArtist(); }catch(e){}
  }
  function tick(dt, t){
    const T = World.timeDef || {}, night = T.id === "night" || T.id === "blue", day = !night && T.id !== "dusk";
    for (const v of Z.veh){ if (v.g.userData.spin) v.g.userData.spin.rotateY(dt * 1.2); if (v.g.userData.turret) v.g.userData.turret.rotation.y = Math.sin(t * .2) * .5; }

    if (custom("skyLife") !== "off"){
      if ((planeT -= dt) <= 0){ planeT = rnd(90, 180); localPlane(); }
      if ((jetT -= dt) <= 0){ jetT = rnd(120, 220); airliner(); }
    }
    Z.planes = Z.planes.filter(p => {
      p.life -= dt;
      if (p.kind === "local"){ p.a += dt * p.dir * 22 / p.r; p.g.position.set(Math.cos(p.a) * p.r, p.h + Math.sin(t * .2) * 3, Math.sin(p.a) * p.r); p.g.rotation.set(0, -p.a + (p.dir > 0 ? Math.PI : 0), p.dir * .25); p.prop.rotation.z += dt * 40; }
      else { const f = new THREE.Vector3(0, 0, 1).applyQuaternion(p.g.quaternion); p.g.position.addScaledVector(f, 70 * dt); }
      if (p.life <= 0){ G.scene.remove(p.g); return false; } return true;
    });

    for (const b of Z.balloons){
      b.g.visible = day && custom("skyLife") !== "off";
      b.g.position.x += b.vx * dt; b.g.position.z += b.vz * dt; b.g.position.y += Math.sin(t * .3 + b.bob) * .05;
      b.flame.visible = Math.sin(t * .7 + b.bob) > .85;
      const E = (NOUT + .5) * P + 250; if (b.g.position.x > E) b.g.position.x = -E;
    }

    if (night && custom("fireworks") !== "off" && (fwT -= dt) <= 0){ fwT = rnd(6, 18); firework(); if (Math.random() < .4) setTimeout(firework, 500); }
    Z.fw = Z.fw.filter(f => {
      f.t += dt; const a = f.pts.geometry.attributes.position;
      for (let k = 0; k < f.vel.length; k++){ const v = f.vel[k]; v[1] -= 9 * dt * .35; v[0] *= .985; v[1] *= .985; v[2] *= .985; a.array[k * 3] += v[0] * dt; a.array[k * 3 + 1] += v[1] * dt; a.array[k * 3 + 2] += v[2] * dt; }
      a.needsUpdate = true; f.pts.material.opacity = Math.max(0, 1 - f.t / 2.6);
      if (f.t > 2.6){ G.scene.remove(f.pts); f.pts.geometry.dispose(); f.pts.material.dispose(); return false; } return true;
    });

    const raining = !!(S.rain || S.storm);
    if (Z.wasRain && !raining && day && custom("skyLife") !== "off") rainbow();
    Z.wasRain = raining;
    if (Z.rainbow){ const r = Z.rainbow; r.t += dt; const o = Math.min(1, r.t / 8) * Math.max(0, 1 - Math.max(0, r.t - 70) / 20) * .22; r.g.children.forEach(c => c.material.opacity = o); if (r.t > 90){ G.scene.remove(r.g); Z.rainbow = null; } }

    if (Z.artist){ Z.artist.armR.rotation.x = -2.2 + Math.sin(t * .8) * .5; if (custom("bubbles") !== "off" && !(S.rain || S.storm || S.snow) && (bubbleT -= dt) <= 0){ bubbleT = rnd(.8, 2.2); blowBubble(); } }
    Z.bubbles = Z.bubbles.filter(b => {
      b.life -= dt; b.b.position.x += b.vx * dt; b.b.position.z += b.vz * dt; b.b.position.y += b.vy * dt + Math.sin(t * 2 + b.wob) * .01; b.b.rotation.y += dt;
      if (b.life <= 0){ G.scene.remove(b.b); return false; } return true;
    });
  }
  if (typeof gameplayUpdate === "function"){
    const base = gameplayUpdate;
    window.gameplayUpdate = function(dt){
      const r = base.apply(this, arguments);
      try{
        if (!Z.built) build();

        if (typeof S !== "undefined" && S) tick(dt, performance.now() / 1000);
      }catch(e){ console.warn("[Snap City 48]", e); }
      return r;
    };
  }
  const iv = setInterval(() => { try{ build(); if (Z.built) clearInterval(iv); }catch(e){} }, 700);
})();

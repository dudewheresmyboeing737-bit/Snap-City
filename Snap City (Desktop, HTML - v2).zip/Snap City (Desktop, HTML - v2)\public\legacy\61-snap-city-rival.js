(function(){
"use strict";
const SC = window.SnapCity = window.SnapCity || {};
const RIV = SC.rival = { idx: -1, prop: null, shootT: 8, moveT: 0, spotEl: null };
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
const NAMES = ["Vic Marlowe", "Rosa Quill", "Dex Halloran", "Nell Voss", "Artie Crane", "June Okafor", "Milo Strand", "Tess Arden"];
const rand = (a, b) => a + Math.random()*(b - a);
const on = () => !S.custom || S.custom.rival !== "off";

function desk(){ return SC.desk && SC.desk.state ? SC.desk.state() : null; }
function rstate(){
  const d = desk(); if (!d) return null;
  const r = d.rival = d.rival || {};
  if (!r.name){ r.name = NAMES[Math.floor(Math.random()*NAMES.length)]; r.paper = "the Evening Ledger"; }
  r.target = r.target ?? null; r.prog = r.prog || 0; r.need = r.need || 0;
  r.cool = r.cool ?? 150; r.wins = r.wins || 0; r.beaten = r.beaten || 0;
  d.lost = d.lost || [];
  return r;
}
function first(n){ return String(n).split(" ")[0]; }

function conditionsHold(b){
  const t = SC.desk.TPL && SC.desk.TPL[b.tpl]; if (!t) return true;
  if (t.times && !SC.desk.timeMatchesNow(t.times)) return false;
  if (t.weather === "rain" && !S.rain) return false;
  if (t.weather === "fog" && !S.fog) return false;
  return true;
}

function rivalPerson(){
  const L = Life.people || [];
  if (RIV.idx >= 0 && L[RIV.idx] && !L[RIV.idx].hidden) return L[RIV.idx];
  const pool = L.map((p, i) => [p, i]).filter(([p]) => p.type === "person" && !p.performer && !p.stationary && !p.role && !p.pool && !p.watcher && !p.hidden && p.a !== undefined && !(p.look && p.look.costume) && !p._fantasy && !p.archetype && !p.knight && !p.dog && !p.ev);
  if (!pool.length) return null;
  const [p, i] = pool[Math.floor(Math.random()*pool.length)];
  RIV.idx = i; p.rival = true; p.noPause = false;
  if (p.look) p.look.mood = "neutral";
  return p;
}

function buildProp(){
  if (RIV.prop || !window.G || !G.scene) return RIV.prop;
  const g = new THREE.Group();
  const black = new THREE.MeshStandardMaterial({ color:0x1b1c1e, roughness:0.55, metalness:0.2 });
  const chrome = new THREE.MeshStandardMaterial({ color:0xb9bcc0, roughness:0.3, metalness:0.8 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.09, 0.06), black); g.add(body);
  const top = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.02, 0.058), chrome); top.position.y = 0.055; g.add(top);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.033, 0.09, 12), black); lens.rotation.x = Math.PI/2; lens.position.z = 0.07; g.add(lens);
  const strap = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.006, 4, 16, Math.PI), black); strap.position.y = 0.04; strap.rotation.x = -0.25; g.add(strap);
  g.traverse(o => { o.userData._scDyn = true; o.userData._rt = 1; o.castShadow = false; });
  g.name = "rival-camera";
  G.scene.add(g);
  RIV.strap = strap;
  return RIV.prop = g;
}

function placeProp(p){
  const g = buildProp(); if (!g) return;
  const vis = on() && p && !p.hidden && Math.hypot(p.x - Player.x, p.z - Player.z) < 70;
  g.visible = !!vis; if (!vis) return;
  const sc = p.scale || 1, raised = p.pause > 0 && p._rivalShoot;
  const fx = Math.sin(p.heading), fz = Math.cos(p.heading);
  const h = raised ? 1.56*sc : 1.08*sc, fwd = raised ? 0.2*sc : 0.19*sc;
  g.position.set(p.x + fx*fwd, (p.y || 0) + h, p.z + fz*fwd);
  g.rotation.set(raised ? 0.05 : 0.35, p.heading, 0);
  RIV.strap.visible = !raised;
}

function relocate(p, hood){
  if (!hood || !World.lots) return;
  let here = null; try { here = locationName(p.x, p.z).hood; } catch(e){}
  if (here === hood) return;
  const dx = p.x - Player.x, dz = p.z - Player.z, dist = Math.hypot(dx, dz);
  const fx = -Math.sin(Player.yaw), fz = -Math.cos(Player.yaw);
  if (dist < 60 || (dx*fx + dz*fz) / dist > 0.2) return;
  const lots = World.lots.filter(l => { try { return locationName(l.cx, l.cz).hood === hood && Math.hypot(l.cx - Player.x, l.cz - Player.z) > 50; } catch(e){ return false; } });
  if (!lots.length) return;
  const l = lots[Math.floor(Math.random()*lots.length)];
  p.cx = l.cx; p.cz = l.cz; p.cross = null; p.pause = 0;
}

function toastLater(msg, ms, delay){ setTimeout(() => toast(msg, ms), delay || 0); }

function tick(dt){
  const d = desk(), r = rstate(); if (!d || !r) return;
  const p = rivalPerson();
  if (!on()){ if (RIV.prop) RIV.prop.visible = false; return; }
  if (r.target){
    const b = d.briefs.find(x => x.id === r.target);
    if (!b){
      const mine = d.done.find(x => x.id === r.target);
      if (mine){ r.beaten++; toastLater(`You beat ${r.name} to "${mine.title}". ${first(r.name)} is not pleased.`, 3000, 7600); }
      r.target = null; r.prog = 0; r.cool = rand(150, 300);
    } else {
      if (conditionsHold(b)){
        r.prog += dt;
        if (p){
          RIV.shootT -= dt;
          if (RIV.shootT <= 0 && p.pause <= 0){ p.pause = rand(2, 3.5); p._rivalShoot = true; p.act = "stare"; RIV.shootT = rand(9, 18); }
        }
      }
      RIV.moveT -= dt; if (RIV.moveT <= 0 && p){ RIV.moveT = 5; relocate(p, b.hood); }
      if (r.prog >= r.need){
        const title = SC.desk.describe(b).title;
        d.briefs = d.briefs.filter(x => x !== b);
        if (d.pinned === b.id) d.pinned = null;
        d.lost.unshift({ id:b.id, title, by:r.name, at:Date.now() }); d.lost = d.lost.slice(0, 6);
        d.stats.rivalLost = (d.stats.rivalLost || 0) + 1; r.wins++;
        d.nextAt = Math.min(d.nextAt || Infinity, d.play + 30);
        toast(`${r.name} filed "${title}" for ${r.paper}. The desk won't need yours.`, 3400);
        r.target = null; r.prog = 0; r.cool = rand(200, 380);
        saveState();
      }
    }
  } else {
    r.cool -= dt;
    if (r.cool <= 0){
      const open = d.briefs.filter(b => d.play - b.issued > 180 && b.expires - d.play > 300), ready = open.filter(conditionsHold);
      const pool = ready.length ? ready : open;
      if (pool.length){
        const b = Math.random() < 0.6 ? pool.slice().sort((a, c) => c.money - a.money)[0] : pool[Math.floor(Math.random()*pool.length)];
        r.target = b.id; r.prog = 0; r.need = Math.min(b.expires - d.play - 60, rand(420, 720));
        toast(`Word on the street: ${r.name} from ${r.paper} is chasing "${SC.desk.describe(b).title}".`, 3200);
        saveState();
      } else r.cool = 30;
    }
  }
  if (p && p._rivalShoot && p.pause <= 0) p._rivalShoot = false;
  placeProp(p);
}

function rivalWhere(){
  const p = RIV.idx >= 0 && Life.people[RIV.idx]; if (!p) return "";
  const dx = p.x - Player.x, dz = p.z - Player.z, dist = Math.hypot(dx, dz);
  if (dist > 90) { try { return `in ${locationName(p.x, p.z).hood}`; } catch(e){ return ""; } }
  const fx = -Math.sin(Player.yaw), fz = -Math.cos(Player.yaw), dot = (dx*fx + dz*fz)/(dist||1), cross = fx*dz - fz*dx;
  const dir = dot > 0.7 ? "ahead" : dot < -0.7 ? "behind you" : cross > 0 ? "to your right" : "to your left";
  return `${Math.max(5, Math.round(dist/5)*5)} m ${dir}`;
}

window.deskRivalNote = function(b, where){
  if (!on()) return "";
  const r = rstate(); if (!r || r.target !== b.id) return "";
  const left = Math.max(0, r.need - r.prog), hold = conditionsHold(b);
  const eta = hold ? `files in about ${Math.max(1, Math.ceil(left/60))} min` : "waiting for the right conditions";
  const pct = Math.round(100*Math.min(1, r.prog/Math.max(1, r.need)));
  if (where === "chip") return `<div class="dk-cond dk-rival">! ${esc(first(r.name))} is on it: ${eta}</div>`;
  return `<div class="desk-rival"><b>${esc(r.name)} is chasing this</b><span>${eta}${rivalWhere() ? ` · ${esc(rivalWhere())}` : ""}</span><i style="width:${pct}%"></i></div>`;
};

window.deskRivalPanel = function(){
  const r = rstate(), d = desk(); if (!r) return "";
  const v = on() ? "on" : "off";
  const lost = (d.lost || []).length ? `<table class="keys desk-history">${d.lost.map(x => `<tr><td>${esc(x.title)}</td><td>filed by ${esc(x.by)}</td><td>lost</td></tr>`).join("")}</table>` : "";
  return `<div class="sectionhead" style="margin-top:22px">The competition</div>
    <p class="note">${esc(r.name)} shoots for ${esc(r.paper)}. Now and then ${esc(first(r.name))} goes after one of your briefs that has been open for three minutes or more. ${esc(first(r.name))} only makes progress while the brief's light and weather hold, and files after 7 to 12 minutes of street time. File first and the brief is yours. Look for a pedestrian with a camera on a strap. It comes up to their eye when they shoot.</p>
    <p class="note">Score so far: you beat ${esc(first(r.name))} ${r.beaten} time${r.beaten === 1 ? "" : "s"}; ${esc(first(r.name))} beat you ${r.wins} time${r.wins === 1 ? "" : "s"}.${on() && RIV.idx >= 0 ? ` ${esc(first(r.name))} is ${esc(rivalWhere())}.` : ""}</p>
    <div class="formrow"><label>Rival photographer</label><div class="seg"><button data-desk-rival="on" aria-pressed="${v === "on"}">On</button><button data-desk-rival="off" aria-pressed="${v === "off"}">Off</button></div><span class="spec">Off: no one competes for your briefs.</span></div>${lost}`;
};

const baseMenu = renderMenu;
window.renderMenu = function(){
  const res = baseMenu.apply(this, arguments);
  try {
    if (UI.menuTab === "desk") document.querySelectorAll("#menubody [data-desk-rival]").forEach(b => b.onclick = () => {
      S.custom.rival = b.dataset.deskRival;
      if (S.custom.rival === "off"){ const r = rstate(); if (r){ r.target = null; r.prog = 0; r.cool = 150; } }
      saveState(); renderMenu();
    });
  } catch(e){}
  return res;
};

if (typeof menuSettings === "function"){
  const base = menuSettings;
  window.menuSettings = function(){
    const c = S.custom, v = c.awareness === "relaxed" ? "relaxed" : "realistic";
    return `<div class="formrow"><label>People notice the camera</label><div class="seg" data-seg44="awareness"><button data-v="realistic" aria-pressed="${v === "realistic"}">Realistic</button><button data-v="relaxed" aria-pressed="${v === "relaxed"}">Relaxed</button></div><span class="spec">Realistic: a raised camera pointed at someone is noticed from several metres away (farther for SLRs and long lenses, less from behind). Shoot from the hip or with a longer lens to stay unseen. Relaxed: only within about 2 m, as before.</span></div>` + base.apply(this, arguments);
  };
}

function spotted(){
  let el = RIV.spotEl;
  if (!el){ el = RIV.spotEl = document.createElement("div"); el.id = "spotted"; el.className = "hidden"; (document.getElementById("hud") || document.body).appendChild(el); }
  const recent = Life.noticedAt !== undefined && Life.t - Life.noticedAt < 1.6 && Player.raised;
  if (!recent){ el.classList.add("hidden"); return; }
  const txt = { cover:"Spotted: covering their face", waveoff:"Spotted: waving you off", away:"Spotted: turning away", pose:"Spotted: posing for you", wave:"Spotted: waving", stare:"Spotted: staring back" }[Life.noticedReact] || "Spotted";
  el.textContent = txt; el.classList.remove("hidden");
}

const baseGameplay = gameplayUpdate;
window.gameplayUpdate = function(dt){
  const res = baseGameplay.apply(this, arguments);
  try { tick(dt); spotted(); } catch(e){ console.warn("[Snap City] rival tick skipped:", e); }
  return res;
};

RIV.state = rstate; RIV.person = rivalPerson; RIV.tick = tick;
})();
